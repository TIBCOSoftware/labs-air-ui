import { map, switchMap, tap } from 'rxjs';
const route1 = [
    [25.771088, -80.163483],
    [27.439775, -80.32299],
    [28.349469, -80.731105],
    [30.401564, -81.571033],
    [32.116716, -81.144147],
    [32.866511, -79.995399],
    [34.191224, -77.952419],
    [36.850172, -76.319269],
    [36.915037, -76.320643],
    [39.262025, -76.549294],
    [39.900933, -75.143453],
    [40.690263, -74.152375],
    [42.259951, -71.789244],
];
const route2 = [
    [47.492471, -122.26888],
    [45.552207, -122.722648],
    [39.53246, -119.751524],
    [37.803528, -122.312138],
    [37.899332, -121.169307],
    [36.273183, -115.070534],
    [33.77032, -118.273289],
    [34.106012, -117.320254],
    [33.515564, -112.160564],
    [32.126437, -110.848336],
    [31.752085, -106.488887],
    [35.04758, -106.653344],
    [39.796963, -104.995374],
];
const route3 = [
    [29.302729, -98.638744],
    [29.638421, -95.292245],
    [32.615525, -96.693485],
    [29.917836, -90.205272],
    [32.256403, -90.151546],
    [35.044849, -90.153006],
    [38.524627, -90.209535],
    [39.870851, -88.912284],
    [41.705694, -87.577341],
    [41.902382, -89.101932],
    [44.251243, -91.509663],
    [44.970069, -93.174527],
    [46.758181, -92.098748],
];
const emptyRoute = [];
const httpOptions = {
    headers: {
        'Content-Type': 'application/graphql+-',
    },
};
const httpMutateOptions = {
    headers: { 'Content-Type': 'application/rdf' },
};
export class GraphService {
    constructor(http, dGraphUrl, accountRequired) {
        this.http = http;
        this.dGraphUrl = dGraphUrl;
        this.accountRequired = accountRequired;
        this.requireAccountId = true;
        this.requireAccountId = accountRequired;
        //const dGraphBasicAuthEnabled = this.appConfigService.dGraphBasicAuthEnabled;
        //if (dGraphBasicAuthEnabled) {
        //    const dGraphBasicAuth = this.appConfigService.dGraphBasicAuth;
        //    (this.httpOptions.headers = { 'Content-Type': 'application/graphql+-' }), { Authorization: dGraphBasicAuth };
        //    (this.httpMutateOptions.headers = { 'Content-Type': 'application/rdf' }), { Authorization: dGraphBasicAuth };
        //}
    }
    getGateway(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        console.log(`GetGateway service called for ${gatewayName}`);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGateway');
        }), map((response) => response.data.resp));
    }
    getGateways(account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway))
      @filter(${this.getAccountQuery(account)}) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
        numDevices: count(gateway_device)
        }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGateways');
        }), map((response) => response.data.resp), tap((response) => console.log(`fetched ${response.length} gateways`)));
    }
    updateGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('gateway', gateway.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
              var(func: uid(${gateway.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <account> "${account ? account : ''}" .
                uid(v) <address> "${gateway.address}" .
                uid(v) <router> "${gateway.router}" .
                uid(v) <routerPort> "${gateway.routerPort}" .
                uid(v) <deployNetwork> "${gateway.deployNetwork}" .
                uid(v) <description> "${gateway.description}" .
                uid(v) <latitude> "${gateway.latitude}" .
                uid(v) <longitude> "${gateway.longitude}" .
                uid(v) <accessToken> "${gateway.accessToken}" .
                uid(v) <username> "${gateway.username}" .
                uid(v) <platform> "${gateway.platform}" .
                uid(v) <updatedts> "${gateway.updatedts}" .
              }
            }
          }`;
        console.log(`Update Gateway ${gateway.uuid} ${gateway.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateGateway', 'gateway', gateway.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateGateway')), tap(() => console.log(`updated gateway ${gateway.uuid}`)), map(() => 'gateway updated'));
    }
    addGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        if (gateway.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Gateway <dgraph.type> "Gateway" .
        _:Gateway <gateway> "" .
        _:Gateway <type> "gateway" .
        _:Gateway <account> "${account ? account : ''}" .
        _:Gateway <uuid> "${gateway.uuid}" .
        _:Gateway <description> "${gateway.description}" .
        _:Gateway <address> "${gateway.address}" .
        _:Gateway <router> "${gateway.router}" .
        _:Gateway <routerPort> "${gateway.routerPort}" .
        _:Gateway <deployNetwork> "${gateway.deployNetwork}" .
        _:Gateway <latitude> "${gateway.latitude}" .
        _:Gateway <longitude> "${gateway.longitude}" .
        _:Gateway <accessToken> "${gateway.accessToken}" .
        _:Gateway <username> "${gateway.username}" .
        _:Gateway <platform> "${gateway.platform}" .
        _:Gateway <createdts> "${gateway.createdts}" .
        _:Gateway <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log(`Add Gateway ${gateway.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addGateway');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Gateway');
            if (id) {
                gateway.uid = id;
            }
        }), map((response) => (response.data.resp = gateway)), tap(() => console.log(`add gateway ${gateway.uid}/${gateway.uuid}`)));
    }
    deleteGateway(gatewayUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('gateway', gatewayUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${gatewayUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Gateway ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteGateway', 'gateway', gatewayUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteGateway')), tap(() => console.log(`deleted gateway ${gatewayUid}`)), map(() => `${gatewayUid} deleted`));
    }
    getGatewayAndProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid
        protocols: gateway_protocol {
          uid uuid created modified protocolType brokerURL
          topic consumerGroupId connectionTimeout sessionTimeout
          initialOffset retryBackOff fetchMinBytes fetchMaxWait
          commitInterval heartbeatInterval maximumQOS
          username password encryptionMode
          caCertificate clientCertificate clientKey
          authMode serverCertificate
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayWithProtocols');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and Protocols for ${gatewayName}`)));
    }
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayName
     */
    getProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(protocol)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified protocolType brokerURL topic
        consumerGroupId connectionTimeout sessionTimeout initialOffset
        retryBackOff fetchMinBytes fetchMaxWait commitInterval
        heartbeatInterval maximumQOS username password
        encryptionMode caCertificate clientCertificate clientKey
        authMode serverCertificate scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getProtocols');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched protocols for ${gatewayName}`)));
    }
    addProtocol(gatewayUid, protocol, account) {
        this.ensureAccountAuthorized(account);
        if (protocol.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Protocol <dgraph.type> "Protocol" .
        _:Protocol <type> "protocol" .
        _:Protocol <protocol> "" .
        _:Protocol <account> "${account ? account : ''}" .
        _:Protocol <uuid> "${protocol.uuid}" .
        _:Protocol <created> "${protocol.created}" .
        _:Protocol <modified> "${protocol.modified}" .
        _:Protocol <protocolType> "${protocol.protocolType}" .
        _:Protocol <brokerURL> "${protocol.brokerURL}" .
        _:Protocol <topic> "${protocol.topic}" .
        _:Protocol <consumerGroupId> "${protocol.consumerGroupId}" .
        _:Protocol <connectionTimeout> "${protocol.connectionTimeout}" .
        _:Protocol <sessionTimeout> "${protocol.sessionTimeout}" .
        _:Protocol <initialOffset> "${protocol.initialOffset}" .
        _:Protocol <retryBackOff> "${protocol.retryBackOff}" .
        _:Protocol <fetchMinBytes> "${protocol.fetchMinBytes}" .
        _:Protocol <fetchMaxWait> "${protocol.fetchMaxWait}" .
        _:Protocol <commitInterval> "${protocol.commitInterval}" .
        _:Protocol <heartbeatInterval> "${protocol.heartbeatInterval}" .
        _:Protocol <maximumQOS> "${protocol.maximumQOS}" .
        _:Protocol <username> "${protocol.username}" .
        _:Protocol <password> "${protocol.password}" .
        _:Protocol <encryptionMode> "${protocol.encryptionMode}" .
        _:Protocol <caCertificate> "${protocol.caCertificate}" .
        _:Protocol <clientCertificate> "${protocol.clientCertificate}" .
        _:Protocol <clientKey> "${protocol.clientKey}" .
        _:Protocol <authMode> "${protocol.authMode}" .
        _:Protocol <serverCertificate> "${protocol.serverCertificate}" .
        _:Protocol <scope> "${protocol.scope}" .
      }
    }`;
        console.log(`Add protocol ${protocol.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addProtocol');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Protocol');
            if (id) {
                protocol.uid = id;
            }
        }), map((response) => (response.data.resp = protocol)), tap(() => console.log(`add protocols ${protocol.uid}`)));
    }
    updateProtocol(protocol, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('protocol', protocol.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${protocol.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if (eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <uuid> "${protocol.uuid}" .
            uid(v) <modified> "${protocol.modified}" .
            uid(v) <protocolType> "${protocol.protocolType}" .
            uid(v) <brokerURL> "${protocol.brokerURL}" .
            uid(v) <topic> "${protocol.topic}" .
            uid(v) <consumerGroupId> "${protocol.consumerGroupId}" .
            uid(v) <connectionTimeout> "${protocol.connectionTimeout}" .
            uid(v) <sessionTimeout> "${protocol.sessionTimeout}" .
            uid(v) <initialOffset> "${protocol.initialOffset}" .
            uid(v) <retryBackOff> "${protocol.retryBackOff}" .
            uid(v) <fetchMinBytes> "${protocol.fetchMinBytes}" .
            uid(v) <fetchMaxWait> "${protocol.fetchMaxWait}" .
            uid(v) <commitInterval> "${protocol.commitInterval}" .
            uid(v) <heartbeatInterval> "${protocol.heartbeatInterval}" .
            uid(v) <maximumQOS> "${protocol.maximumQOS}" .
            uid(v) <username> "${protocol.username}" .
            uid(v) <password> "${protocol.password}" .
            uid(v) <encryptionMode> "${protocol.encryptionMode}" .
            uid(v) <caCertificate> "${protocol.caCertificate}" .
            uid(v) <clientCertificate> "${protocol.clientCertificate}" .
            uid(v) <clientKey> "${protocol.clientKey}" .
            uid(v) <authMode> "${protocol.authMode}" .
            uid(v) <serverCertificate> "${protocol.serverCertificate}" .
            uid(v) <scope> "${protocol.scope}" .
          }
        }
    }`;
        console.log(`Update ${protocol.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateProtocol', 'protocol', protocol.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateProtocol')), tap(() => console.log(`updated protocol ${protocol.uid}`)), map(() => protocol));
    }
    deleteProtocol(gatewayUid, protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('protocol', protocolUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${protocolUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Protocol ${protocolUid} for ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteProtocol', 'protocol', protocolUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteProtocol')), map(() => `${protocolUid} deleted`));
    }
    getDataStores(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(dataStore)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified dataStoreType
        host port databaseName user password accountName
        warehouse database schema authType username
        clientId clientSecret authorizationCode
        redirectURI loginTimeout url scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getDataStores');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched dataStores for gateway ${gatewayName}`)));
    }
    addDataStore(gatewayUid, dataStore, account) {
        this.ensureAccountAuthorized(account);
        if (dataStore.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:DataStore <dgraph.type> "DataStore" .
        _:DataStore <type> "dataStore" .
        _:DataStore <dataStore> "" .
        _:DataStore <account> "${account ? account : ''}" .
        _:DataStore <uuid> "${dataStore.uuid}" .
        _:DataStore <created> "${dataStore.created}" .
        _:DataStore <modified> "${dataStore.modified}" .
        _:DataStore <dataStoreType> "${dataStore.dataStoreType}" .
        _:DataStore <host> "${dataStore.host}" .
        _:DataStore <port> "${dataStore.port}" .
        _:DataStore <databaseName> "${dataStore.databaseName}" .
        _:DataStore <user> "${dataStore.user}" .
        _:DataStore <password> "${dataStore.password}" .
        _:DataStore <accountName> "${dataStore.accountName}" .
        _:DataStore <warehouse> "${dataStore.warehouse}" .
        _:DataStore <database> "${dataStore.databaseName}" .
        _:DataStore <schema> "${dataStore.schema}" .
        _:DataStore <authType> "${dataStore.authType}" .
        _:DataStore <username> "${dataStore.username}" .
        _:DataStore <clientId> "${dataStore.clientId}" .
        _:DataStore <clientSecret> "${dataStore.clientSecret}" .
        _:DataStore <authorizationCode> "${dataStore.authorizationCode}" .
        _:DataStore <redirectURI> "${dataStore.redirectURI}" .
        _:DataStore <loginTimeout> "${dataStore.loginTimeout}" .
        _:DataStore <url> "${dataStore.url}" .
        _:DataStore <scope> "${dataStore.scope}" .
      }
    }`;
        console.log(`Added datastore ${dataStore.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addDataStore');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'DataStore');
            if (id) {
                dataStore.uid = id;
            }
        }), map((response) => (response.data.resp = dataStore)), tap(() => console.log(`add dataStores ${dataStore.uid}`)));
    }
    updateDataStore(dataStore, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('dataStore', dataStore.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${dataStore.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
                uuid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <account> "${account ? account : ''}" .
                uid(v) <uuid> "${dataStore.uuid}" .
                uid(v) <modified> "${dataStore.modified}" .
                uid(v) <dataStoreType> "${dataStore.dataStoreType}" .
                uid(v) <host> "${dataStore.host}" .
                uid(v) <port> "${dataStore.port}" .
                uid(v) <databaseName> "${dataStore.databaseName}" .
                uid(v) <user> "${dataStore.user}" .
                uid(v) <password> "${dataStore.password}" .
                uid(v) <accountName> "${dataStore.accountName}" .
                uid(v) <warehouse> "${dataStore.warehouse}" .
                uid(v) <database> "${dataStore.databaseName}" .
                uid(v) <schema> "${dataStore.schema}" .
                uid(v) <authType> "${dataStore.authType}" .
                uid(v) <username> "${dataStore.username}" .
                uid(v) <clientId> "${dataStore.clientId}" .
                uid(v) <clientSecret> "${dataStore.clientSecret}" .
                uid(v) <authorizationCode> "${dataStore.authorizationCode}" .
                uid(v) <redirectURI> "${dataStore.redirectURI}" .
                uid(v) <loginTimeout> "${dataStore.loginTimeout}" .
                uid(v) <url> "${dataStore.url}" .
                uid(v) <scope> "${dataStore.scope}" .
              }
            }
          }`;
        console.log(`Update dataStore ${dataStore.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateDataStore', 'dataStore', dataStore.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateDataStore')), tap(() => console.log(`updated dataStore ${dataStore.uid}`)), map(() => dataStore));
    }
    deleteDataStore(gatewayUid, dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('dataStore', dataStoreUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${dataStoreUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete DataStore ${dataStoreUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteDataStore', 'dataStore', dataStoreUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteDataStore')), tap(() => console.log(`deleted dataStore ${dataStoreUid}`)), map(() => `${dataStoreUid} deleted`));
    }
    getGatewayAndModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid
        models: gateway_model {
          uid uuid created modified name
          description inputType url scope
          inputTemplate headers method base64Encoded
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayAndModels');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched gateways and models for ${gatewayName}`)));
    }
    getModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(model)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified name
        description inputType url scope inputTemplate
        headers method base64Encoded
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getModels');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched models for ${gatewayName}`)));
    }
    addModel(gatewayUid, model, account) {
        this.ensureAccountAuthorized(account);
        if (model.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Model <dgraph.type> "Model" .
        _:Model <type> "model" .
        _:Model <model> "" .
        _:Model <account> "${account ? account : ''}" .
        _:Model <uuid> "${model.uuid}" .
        _:Model <created> "${model.created}" .
        _:Model <modified> "${model.modified}" .
        _:Model <name> "${model.name}" .
        _:Model <description> "${model.description}" .
        _:Model <inputType> "${model.inputType}" .
        _:Model <url> "${model.url}" .
        _:Model <scope> "${model.scope}" .
        _:Model <inputTemplate> "${model.inputTemplate}" .
        _:Model <headers> "${model.headers}" .
        _:Model <method> "${model.method}" .
        _:Model <base64Encoded> "${model.base64Encoded}" .
      }
    }`;
        console.log(`Add model ${model.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addModel');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Model');
            if (id) {
                model.uid = id;
            }
        }), map((response) => (response.data.resp = model)), tap(() => console.log(`added model ${model.uid}`)));
    }
    updateModel(model, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('model', model.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${model.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <uuid> "${model.uuid}" .
            uid(v) <modified> "${model.modified}" .
            uid(v) <name> "${model.name}" .
            uid(v) <description> "${model.description}" .
            uid(v) <inputType> "${model.inputType}" .
            uid(v) <url> "${model.url}" .
            uid(v) <scope> "${model.scope}" .
            uid(v) <inputTemplate> "${model.inputTemplate}" .
            uid(v) <headers> "${model.headers}" .
            uid(v) <method> "${model.method}" .
            uid(v) <base64Encoded> "${model.base64Encoded}" .
          }
        }
        }`;
        console.log(`Update model ${model.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateModel', 'model', model.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateModel')), tap(() => console.log(`updated model ${model.uid}`)), map(() => model));
    }
    deleteModel(gatewayUid, modelUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('model', modelUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${modelUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Model ${modelUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteModel', 'model', modelUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteModel')), tap(() => console.log(`deleted model ${modelUid}`)), map(() => `${modelUid} deleted`));
    }
    getGatewayAndPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
        uid uuid brokerURL topic maximumQOS username password encryptionMode caCertificate
        clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
        sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
      }`;
        const pipeline_datastore = `dataStore: pipeline_datastore {
        uid uuid host port databaseName user password accountName warehouse database schema authType
        username clientId clientSecret authorizationCode redirectURI loginTimeout url
      }`;
        const pipeline_filter = 'filter: pipeline_filter { uid deviceNames }';
        const pipeline_streaming = 'streaming: pipeline_streaming { uid deviceName instrumentName function windowType windowSize }';
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid accessToken username platform address router routerPort deployNetwork devicesMetadata
        pipelines: gateway_pipeline {
          uid name uuid pipelineType deployerType protocolType protocolId dataStoreType
          dataStoreId created modified description status flowConfiguration
          logLevel subscriptionTopic
          ${pipeline_protocol}
          ${pipeline_datastore}
          ${pipeline_filter}
          ${pipeline_streaming}
        }
      }
    }`;
        console.log(`Get Gateway and Pipelines for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayWithPipelines');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and pipelines for ${gatewayName}`)));
    }
    getPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
              uid brokerURL topic maximumQOS username password encryptionMode caCertificate
              clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
              sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
  } `;
        const pipeline_datastore = `datastore: pipeline_datastore {
              uid host port databaseName user password accountName warehouse database schema authType
              username clientId clientSecret authorizationCode redirectURI loginTimeout url
            }`;
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        pipelines as gateway_pipeline {
        }
      }
      resp(func: uid(pipelines)) {
        uid name uuid pipelineType deployerType protocolType protocolId
        dataStoreType dataStoreId created modified description status
        flowConfiguration logLevel subscriptionTopic
        ${pipeline_protocol}
        ${pipeline_datastore}
        ${pipeline_filter}
        ${pipeline_streaming}
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPipelines');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched pipelines for ${gatewayName}`)));
    }
    addPipeline(gatewayUid, pipeline, transportObj, dataStoreObj, filterObj, streamingObj, account) {
        this.ensureAccountAuthorized(account);
        if (pipeline.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Pipeline <dgraph.type> "Pipeline" .
        _:Pipeline <account> "${account ? account : ''}" .
        _:Pipeline <name> "${pipeline.name}" .
        _:Pipeline <uuid> "${pipeline.name}" .
        _:Pipeline <type> "pipeline" .
        _:Pipeline <pipeline> "" .
        _:Pipeline <pipelineType> "${pipeline.pipelineType}" .
        _:Pipeline <deployerType> "${pipeline.deployerType}" .
        _:Pipeline <created> "${pipeline.created}" .
        _:Pipeline <modified> "${pipeline.modified}" .
        _:Pipeline <description> "${pipeline.description}" .
        _:Pipeline <status> "${pipeline.status}" .
        _:Pipeline <flowConfiguration> "${pipeline.flowConfiguration}" .
        _:Pipeline <logLevel> "${pipeline.logLevel}" .
        _:Pipeline <subscriptionTopic> "${pipeline.subscriptionTopic}" .
        <${gatewayUid}> <gateway_pipeline> _:Pipeline .
      }
    }`;
        console.log(`add Pipeline ${pipeline.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addPipeline');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Pipeline');
            if (id) {
                pipeline.uid = id;
            }
        }), map((response) => (response.data.resp = pipeline)), tap(() => console.log(`added pipeline ${pipeline.uid}`)));
    }
    updatePipeline(pipeline, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pipeline', pipeline.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${pipeline.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <description> "${pipeline.description}" .
            uid(v) <status> "${pipeline.status}" .
            uid(v) <modified> "${pipeline.modified}" .
            uid(v) <flowConfiguration> "${pipeline.flowConfiguration}" .
            uid(v) <logLevel> "${pipeline.logLevel}" .
            uid(v) <subscriptionTopic> "${pipeline.subscriptionTopic}" .
          }
        }
      }`;
        console.log(`update Pipeline ${pipeline.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updatePipeline', 'pipeline', pipeline.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatePipeline')), tap(() => console.log(`updated pipeline ${pipeline.uid}`)), map(() => pipeline));
    }
    deletePipeline(gatewayUid, pipeline, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pipeline', pipeline.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${pipeline.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
                <${gatewayUid}> <gateway_pipeline> <${pipeline.uid}> .
              }
            }
          }`;
        console.log(`delete Pipeline ${pipeline.uid} with gateway ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deletePipeline', 'pipeline', pipeline.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deletePipeline')), tap(() => console.log(`deleted pipeline ${pipeline.uid} with gateway ${gatewayUid}`)), map(() => `pipeline deleted`));
    }
    /**
     * Get ids of all the pipelines associated with the specified protocol
     * @param protocolUid - the uid of the protocol
     */
    getPipelineIdsFromProtocolUid(protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${protocolUid})) @filter(${this.getAccountQuery(account)}) {
        pipelines as ~pipeline_protocol {
        }
      }

      resp(func: uid(pipelines)) {
        uid uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPipelineIdsFromProtocolUid');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log('fetched pipeline ids')));
    }
    /**
     * Get ids of all the pipelines associated with the specified data store
     * @param dataStoreUid - the uid of the data store
     */
    getPipelineIdsFromDataStoreUid(dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${dataStoreUid})) @filter(${this.getAccountQuery(account)}) {
        pipelines as ~pipeline_datastore {
        }
      }

      resp(func: uid(pipelines)) {
        uid uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPipelineIdsFromDataStoreUid');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log('fetched pipeline ids')));
    }
    getModelConfigs(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        modelConfigs as gateway_modelconfig {
        }
      }
      resp(func: uid(modelConfigs)) {
        uid name uuid description device resource model created  modified
      }
    }`;
        console.log(`getModelConfigs for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getModelConfigs');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched modelConfigs for ${gatewayName}`)));
    }
    addModelConfig(gatewayUid, modelConfig, account) {
        this.ensureAccountAuthorized(account);
        if (modelConfig.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:ModelConfig <dgraph.type> "ModelConfig" .
        _:ModelConfig <account> "${account ? account : ''}" .
        _:ModelConfig <name> "${modelConfig.name}" .
        _:ModelConfig <uuid> "${modelConfig.name}" .
        _:ModelConfig <type> "modelConfig" .
        _:ModelConfig <modelConfig> "" .
        _:ModelConfig <description> "${modelConfig.description}" .
        _:ModelConfig <device> "${modelConfig.device}" .
        _:ModelConfig <resource> "${modelConfig.resource}" .
        _:ModelConfig <model> "${modelConfig.model}" .
        _:ModelConfig <created> "${modelConfig.created}" .
        _:ModelConfig <modified> "${modelConfig.modified}" .
        <${gatewayUid}> <gateway_modelconfig> _:ModelConfig .
      }
    }`;
        console.log(`Add modelConfig for gateway ${gatewayUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addModelConfig');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'ModelConfig');
            if (id) {
                modelConfig.uid = id;
            }
        }), map((response) => (response.data.resp = modelConfig)), tap(() => console.log(`add modelConfig for gateway ${gatewayUid}`)));
    }
    updateModelConfig(modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('modelConfig', modelConfig.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
          query {
          var(func: uid(${modelConfig.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <name> "${modelConfig.name}" .
            uid(v) <uuid> "${modelConfig.uuid}" .
            uid(v) <description> "${modelConfig.description}" .
            uid(v) <condDevice> "${modelConfig.device}" .
            uid(v) <condResource> "${modelConfig.resource}" .
            uid(v) <model> "${modelConfig.model}" .
            uid(v) <modified> "${modelConfig.modified}" .
          }
        }
      }`;
        console.log(`Update modelConfig ${modelConfig.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateModelConfig', 'modelConfig', modelConfig.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatupdateModelConfigeModel')), tap(() => console.log(`updated  modelConfig ${modelConfig.uid}`)), map(() => modelConfig));
    }
    deleteModelConfig(gatewayUid, modelConfigUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('modelConfig', modelConfigUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${modelConfigUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
                <${gatewayUid}> <gateway_modelconfig> <${modelConfigUid}> .
              }
            }
          }`;
        console.log(`Delete ModelConfig ${modelConfigUid} for gateway ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteModelConfig', 'modelConfig', modelConfigUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteModelConfig')), tap(() => console.log(`deleted modelConfig ${modelConfigUid} for gateway ${gatewayUid}`)), map(() => `${modelConfigUid} deleted`));
    }
    getFiltersConfig(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        filtersConfig as gateway_filter {
        }
      }
      resp(func: uid(filtersConfig)) {
        uid
        deviceNames
      }
    }`;
        console.log(`getFiltersConfig for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getFiltersConfigs');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched filtersConfig for ${gatewayName}`)));
    }
    addFiltersConfig(gatewayUid, filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        if (filtersConfig.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Filter <dgraph.type> "filter" .
        _:Filter <type> "filter" .
        _:Filter <filter> "" .
        _:Filter <deviceNames> "${filtersConfig.deviceNames}" .
        <${gatewayUid}> <gateway_filter> _:Filter .
        <${account}> <account> _:Filter .
      }
    }`;
        console.log(`add FiltersConfig for gateway ${gatewayUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addFiltersConfig');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Model');
            if (id) {
                filtersConfig.uid = id;
            }
        }), map((response) => (response.data.resp = filtersConfig)), tap(() => console.log(`added filtersConfig for gateway ${gatewayUid}`)));
    }
    updateFiltersConfig(filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('filterConfig', filtersConfig.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${filtersConfig.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <deviceNames> "${filtersConfig.deviceNames}" .
                <${account}> <account> "${account ? account : ''}" .
              }
            }
          }`;
        console.log(`update FiltersConfig ${filtersConfig.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateFiltersConfig', 'filter', filtersConfig.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateFiltersConfig')), tap(() => console.log(`updated filterConfig ${filtersConfig.uid}`)), map(() => filtersConfig));
    }
    /**
     * Get Python Resources.
     * @param gatewayUid
     */
    getPythonResources(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `
    {
      resp(func: type(PythonResource)) @filter(${this.getAccountQuery(account)} AND(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified name type scope fileContent inputs outputs
      }
    }`;
        console.log(`get python resource from ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPythonResource');
        }), map((response) => response.data.resp));
    }
    /**
     * Update Python Resource.
     * @param PythonResource
     */
    updatePythonResource(pythonResource, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pythonResource', pythonResource.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
              var(func: uid(${pythonResource.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                <${pythonResource.uid}> <account> "${account ? account : ''}" .
                <${pythonResource.uid}> <modified> "${pythonResource.modified}" .
                <${pythonResource.uid}> <name> "${pythonResource.name}" .
                <${pythonResource.uid}> <scope> "${pythonResource.scope}" .
                <${pythonResource.uid}> <type> "${pythonResource.type}" .
                <${pythonResource.uid}> <fileContent> "${pythonResource.fileContent}" .
                <${pythonResource.uid}> <inputs> "${pythonResource.inputs}" .
                <${pythonResource.uid}> <outputs> "${pythonResource.outputs}" .
              }
            }
        }`;
        console.log(`Update PythonResource ${pythonResource.uid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updatePythonResource', 'pythonResource', pythonResource.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatePythonResource')), tap(() => console.log(`updated filterConfig ${pythonResource.uid}`)), map(() => pythonResource));
    }
    /**
     * Add Python Resource.
     * @param PythonResource
     */
    addPythonResource(pythonResource, account) {
        this.ensureAccountAuthorized(account);
        if (pythonResource.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = ` {
      set {
        _:PythonResource <dgraph.type> "PythonResource" .
        _:PythonResource <pythonResource> "" .
        _:PythonResource <type> "pythonResource" .
        _:PythonResource <account> "${account ? account : ''}" .
        _:PythonResource <name> "${pythonResource.name}" .
        _:PythonResource <created> "${pythonResource.created}" .
        _:PythonResource <modified> "${pythonResource.modified}" .
        _:PythonResource <type> "${pythonResource.type}" .
        _:PythonResource <fileContent> "${pythonResource.fileContent}" .
        _:PythonResource <scope> "${pythonResource.scope}" .
        _:PythonResource <inputs> "${pythonResource.inputs}" .
        _:PythonResource <outputs> "${pythonResource.outputs}" .
      }}`;
        console.log(`Add PythonResource ${pythonResource.name}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addPythonResource');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'PythonResource');
            if (id) {
                pythonResource.uid = id;
            }
        }), map((response) => (response.data.resp = pythonResource)), tap(() => console.log(`add pythonResource ${pythonResource.uid}`)));
    }
    /**
     * Delete Python Resource.
     * @param resourceUid
     */
    deletePythonResource(pythonResourceUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pythonResource', pythonResourceUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `upsert {
            query {
              var(func: uid(${pythonResourceUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`${pythonResourceUid} is being deleted`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deletePythonResource', 'pythonResource', pythonResourceUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deletePythonResource')), tap(() => console.log(`updated filterConfig ${pythonResourceUid}`)), map(() => `${pythonResourceUid} deleted`));
    }
    getReadings(deviceName, instrumentName, numReadings, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading (first:-${numReadings}) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadings for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadings');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap((response) => console.log('Response from getReadings: ', response)), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsAt(deviceName, instrumentName, ts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(eq(created, ${ts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsAt for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsAt');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsStartingAt(deviceName, instrumentName, fromts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsStartingAt for for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsStartingAt');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched started at readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsBetween(deviceName, instrumentName, fromts, tots, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsBetween for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsBetween');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched readings between for ${deviceName}, ${instrumentName}`)));
    }
    getLastReadingsForDevice(deviceName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(device)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}")) @normalize {
        device_resource {
          name: name
          resource_reading (first:-1) {
            created: created
            value: value
          }
        }
      }
    }`;
        console.log(`getLastReadingsForDevice for ${deviceName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getLastReadingsForDevice');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched last readings for ${deviceName}`)));
    }
    getNotifications(account) {
        this.ensureAccountAuthorized(account);
        console.log('GetNotifications service called');
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(notification)) @filter(${this.getAccountQuery(account)}) @normalize {
        uid uuid:uuid created:created notifySource:notifySource notifyDevice:notifyDevice
        notifyResource:notifyResource notifyLevel:notifyLevel value:value description:description
        ~gateway_notification {
          gateway: uuid
        }
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getNotifications');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched notifications`)));
    }
    getRoute(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let route = null;
        if (deviceName == 'train-0001') {
            route = route1;
        }
        else if (deviceName == 'train-0002') {
            route = route2;
        }
        else if (deviceName == 'train-0003') {
            route = route3;
        }
        else {
            route = emptyRoute;
        }
        return route;
    }
    getRouteCenter(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let center = null;
        // 39.0 -98.0 zoom 4
        // East 34.765589   -78.709488
        // West 40.487432 -122.803116
        if (deviceName == 'train-0001') {
            center = [34.0, -98.0];
        }
        else if (deviceName == 'train-0002') {
            center = [40.0, -98.0];
        }
        else if (deviceName == 'train-0003') {
            center = [39.0, -98.0];
        }
        else {
            center = [42.8, 12.8];
        }
        return center;
    }
    ensureAccountAuthorized(account) {
        if (this.requireAccountId) {
            if (!account)
                throw new Error('Account must exist');
        }
    }
    getAccountQuery(account) {
        if (this.requireAccountId) {
            return `eq(account, "${account}")`;
        }
        else {
            return `(eq(account, "${account ? account : ''}") OR not(has(account)))`;
        }
    }
    /**
     * Discovers the presence of errors in the response from dGraph and reports them.
     *
     * @param response the response object from dGraph
     * @param operation the operation that was being performed for logging purposes
     */
    checkForErrors(response, operation = 'operation') {
        let hasErrors = false;
        let errors;
        if (response?.data?.errors) {
            hasErrors = true;
            console.log(`${operation} failed: ${response.data.errors[0].message}`);
            errors = { message: response.data.errors[0].message };
        }
        else if (response?.errors) {
            hasErrors = true;
            console.log(`${operation} failed: ${response.errors[0].message}`);
            errors = { message: response.errors[0].message };
        }
        if (hasErrors) {
            throw new Error(JSON.stringify(errors));
        }
    }
    /**
     * If the operation was successful, obtain a UID from the response.
     *
     * @param dGraphResponse A response from dGraph
     * @param objectKey the name of the Object, for example Gateway or Model
     * @returns a UID found from the response
     */
    getIDFromResponse(dGraphResponse, objectKey) {
        if (dGraphResponse.code === 'Success') {
            const uid = dGraphResponse.uids[objectKey];
            return uid;
        }
        return undefined;
    }
    getPreQuery(objectName, uid, account) {
        if (!uid) {
            throw new Error(JSON.stringify({ message: 'No ID defined' }));
        }
        return `{
        resp(func: has(${objectName})) @filter(${this.getAccountQuery(account)} AND (uid(${uid}))) {
          uid uuid
        }
      }`;
    }
    confirmObjectExists(response, operation, objectName, uid) {
        if (!uid) {
            throw new Error(JSON.stringify({ message: 'No ID defined' }));
        }
        this.checkForErrors(response, operation);
        if (Array.isArray(response.data.resp)) {
            const responseArray = response.data.resp;
            if (responseArray.length === 0) {
                console.log(`the ${objectName} with ID ${uid} does not exist in this account`);
                throw new Error(JSON.stringify({ message: 'No existing object' }));
            }
        }
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2xhYnMtYWlyLWdyYXBoLWNsaWVudC9zcmMvYXBpL2dyYXBoLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBWUEsT0FBTyxFQUFFLEdBQUcsRUFBYyxTQUFTLEVBQUUsR0FBRyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBSXZELE1BQU0sTUFBTSxHQUFlO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsUUFBUSxDQUFDO0lBQ3RCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0NBQzFCLENBQUM7QUFFRixNQUFNLE1BQU0sR0FBZTtJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztDQUMzQixDQUFDO0FBRUYsTUFBTSxNQUFNLEdBQWU7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7Q0FDMUIsQ0FBQztBQUVGLE1BQU0sVUFBVSxHQUFlLEVBQUUsQ0FBQztBQUVsQyxNQUFNLFdBQVcsR0FBRztJQUNoQixPQUFPLEVBQUU7UUFDTCxjQUFjLEVBQUUsdUJBQXVCO0tBQzFDO0NBQ0osQ0FBQztBQUVGLE1BQU0saUJBQWlCLEdBQUc7SUFDdEIsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGlCQUFpQixFQUFFO0NBQ2pELENBQUM7QUFFRixNQUFNLE9BQU8sWUFBWTtJQUlyQixZQUFvQixJQUFnQixFQUFZLFNBQWlCLEVBQVUsZUFBd0I7UUFBL0UsU0FBSSxHQUFKLElBQUksQ0FBWTtRQUFZLGNBQVMsR0FBVCxTQUFTLENBQVE7UUFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBUztRQUYzRixxQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFHNUIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLGVBQWUsQ0FBQztRQUN4Qyw4RUFBOEU7UUFDOUUsK0JBQStCO1FBQy9CLG9FQUFvRTtRQUNwRSxtSEFBbUg7UUFDbkgsbUhBQW1IO1FBQ25ILEdBQUc7SUFDUCxDQUFDO0lBRUQsVUFBVSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDNUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFDNUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxtQkFBbUIsQ0FBQztRQUNqRCxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7O01BSzdGLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLENBQ3JELENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQWdCO1FBQ3hCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLG1CQUFtQixDQUFDO1FBQ2pELE1BQU0sS0FBSyxHQUFHOztnQkFFTixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O01BTXZDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLFFBQVEsQ0FBQyxNQUFNLFdBQVcsQ0FBQyxDQUFDLENBQ3hFLENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLE9BQWdCLEVBQUUsT0FBZ0I7UUFDNUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFbkUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLE9BQU8sQ0FBQyxHQUFHO3dCQUNqQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O29DQU1qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtvQ0FDdEIsT0FBTyxDQUFDLE9BQU87bUNBQ2hCLE9BQU8sQ0FBQyxNQUFNO3VDQUNWLE9BQU8sQ0FBQyxVQUFVOzBDQUNmLE9BQU8sQ0FBQyxhQUFhO3dDQUN2QixPQUFPLENBQUMsV0FBVztxQ0FDdEIsT0FBTyxDQUFDLFFBQVE7c0NBQ2YsT0FBTyxDQUFDLFNBQVM7d0NBQ2YsT0FBTyxDQUFDLFdBQVc7cUNBQ3RCLE9BQU8sQ0FBQyxRQUFRO3FDQUNoQixPQUFPLENBQUMsUUFBUTtzQ0FDZixPQUFPLENBQUMsU0FBUzs7O1lBRzNDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixPQUFPLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRTdELGdGQUFnRjtRQUNoRixpRUFBaUU7UUFFakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQzlGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQyxFQUNqRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFDekQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixDQUFDLENBQy9CLENBQUM7SUFDTixDQUFDO0lBRUQsVUFBVSxDQUFDLE9BQWdCLEVBQUUsT0FBZ0I7UUFDekMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNiLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OytCQUtTLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUN6QixPQUFPLENBQUMsSUFBSTttQ0FDTCxPQUFPLENBQUMsV0FBVzsrQkFDdkIsT0FBTyxDQUFDLE9BQU87OEJBQ2hCLE9BQU8sQ0FBQyxNQUFNO2tDQUNWLE9BQU8sQ0FBQyxVQUFVO3FDQUNmLE9BQU8sQ0FBQyxhQUFhO2dDQUMxQixPQUFPLENBQUMsUUFBUTtpQ0FDZixPQUFPLENBQUMsU0FBUzttQ0FDZixPQUFPLENBQUMsV0FBVztnQ0FDdEIsT0FBTyxDQUFDLFFBQVE7Z0NBQ2hCLE9BQU8sQ0FBQyxRQUFRO2lDQUNmLE9BQU8sQ0FBQyxTQUFTO2lDQUNqQixPQUFPLENBQUMsU0FBUzs7TUFFNUMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUUzQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztZQUM1RCxJQUFJLEVBQUUsRUFBRTtnQkFDSixPQUFPLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUNwQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUNqRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLE9BQU8sQ0FBQyxHQUFHLElBQUksT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FDdkUsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsVUFBa0IsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRWxFLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs4QkFHUSxVQUFVO3dCQUNoQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFFTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRTVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQyxDQUFDLEVBQzdGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQyxFQUNqRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUN2RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxVQUFVLFVBQVUsQ0FBQyxDQUNyQyxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsV0FBVzs7Ozs7Ozs7Ozs7O01BWTdGLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRTVELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUseUJBQXlCLENBQUMsQ0FBQztRQUM3RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUM3RSxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILFlBQVksQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQzlDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzswQ0FDb0IsSUFBSSxDQUFDLGVBQWUsQ0FDcEQsT0FBTyxDQUNWLG9CQUFvQixXQUFXOzs7Ozs7OztNQVFoQyxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBa0IsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUNqRSxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxVQUFrQixFQUFFLFFBQWtCLEVBQUUsT0FBZ0I7UUFDaEUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksUUFBUSxDQUFDLEdBQUcsRUFBRTtZQUNkLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7O2dDQUtVLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzZCQUN6QixRQUFRLENBQUMsSUFBSTtnQ0FDVixRQUFRLENBQUMsT0FBTztpQ0FDZixRQUFRLENBQUMsUUFBUTtxQ0FDYixRQUFRLENBQUMsWUFBWTtrQ0FDeEIsUUFBUSxDQUFDLFNBQVM7OEJBQ3RCLFFBQVEsQ0FBQyxLQUFLO3dDQUNKLFFBQVEsQ0FBQyxlQUFlOzBDQUN0QixRQUFRLENBQUMsaUJBQWlCO3VDQUM3QixRQUFRLENBQUMsY0FBYztzQ0FDeEIsUUFBUSxDQUFDLGFBQWE7cUNBQ3ZCLFFBQVEsQ0FBQyxZQUFZO3NDQUNwQixRQUFRLENBQUMsYUFBYTtxQ0FDdkIsUUFBUSxDQUFDLFlBQVk7dUNBQ25CLFFBQVEsQ0FBQyxjQUFjOzBDQUNwQixRQUFRLENBQUMsaUJBQWlCO21DQUNqQyxRQUFRLENBQUMsVUFBVTtpQ0FDckIsUUFBUSxDQUFDLFFBQVE7aUNBQ2pCLFFBQVEsQ0FBQyxRQUFRO3VDQUNYLFFBQVEsQ0FBQyxjQUFjO3NDQUN4QixRQUFRLENBQUMsYUFBYTswQ0FDbEIsUUFBUSxDQUFDLGlCQUFpQjtrQ0FDbEMsUUFBUSxDQUFDLFNBQVM7aUNBQ25CLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7OEJBQ3RDLFFBQVEsQ0FBQyxLQUFLOztNQUV0QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFN0MsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDN0QsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osUUFBUSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7YUFDckI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQzFELENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFFBQWtCLEVBQUUsT0FBZ0I7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFckUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzBCQUdJLFFBQVEsQ0FBQyxHQUFHO29CQUNsQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O2dDQU1qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs2QkFDekIsUUFBUSxDQUFDLElBQUk7aUNBQ1QsUUFBUSxDQUFDLFFBQVE7cUNBQ2IsUUFBUSxDQUFDLFlBQVk7a0NBQ3hCLFFBQVEsQ0FBQyxTQUFTOzhCQUN0QixRQUFRLENBQUMsS0FBSzt3Q0FDSixRQUFRLENBQUMsZUFBZTswQ0FDdEIsUUFBUSxDQUFDLGlCQUFpQjt1Q0FDN0IsUUFBUSxDQUFDLGNBQWM7c0NBQ3hCLFFBQVEsQ0FBQyxhQUFhO3FDQUN2QixRQUFRLENBQUMsWUFBWTtzQ0FDcEIsUUFBUSxDQUFDLGFBQWE7cUNBQ3ZCLFFBQVEsQ0FBQyxZQUFZO3VDQUNuQixRQUFRLENBQUMsY0FBYzswQ0FDcEIsUUFBUSxDQUFDLGlCQUFpQjttQ0FDakMsUUFBUSxDQUFDLFVBQVU7aUNBQ3JCLFFBQVEsQ0FBQyxRQUFRO2lDQUNqQixRQUFRLENBQUMsUUFBUTt1Q0FDWCxRQUFRLENBQUMsY0FBYztzQ0FDeEIsUUFBUSxDQUFDLGFBQWE7MENBQ2xCLFFBQVEsQ0FBQyxpQkFBaUI7a0NBQ2xDLFFBQVEsQ0FBQyxTQUFTO2lDQUNuQixRQUFRLENBQUMsUUFBUTswQ0FDUixRQUFRLENBQUMsaUJBQWlCOzhCQUN0QyxRQUFRLENBQUMsS0FBSzs7O01BR3RDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFdEMsZ0ZBQWdGO1FBQ2hGLGlFQUFpRTtRQUNqRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUNqRyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxFQUNsRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFDMUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUN0QixDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLFdBQW1CLEVBQUUsT0FBZ0I7UUFDcEUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUVwRSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsV0FBVzt3QkFDakIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7OztZQVN6QyxDQUFDO1FBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsV0FBVyxRQUFRLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFaEUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxXQUFXLENBQUMsQ0FBQyxFQUNoRyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxFQUNsRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxXQUFXLFVBQVUsQ0FBQyxDQUN0QyxDQUFDO0lBQ04sQ0FBQztJQUVELGFBQWEsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzsyQ0FDcUIsSUFBSSxDQUFDLGVBQWUsQ0FDckQsT0FBTyxDQUNWLG9CQUFvQixXQUFXOzs7Ozs7O01BT2hDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFtQixDQUFDLEVBQ3BELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQzFFLENBQUM7SUFDTixDQUFDO0lBRUQsWUFBWSxDQUFDLFVBQWtCLEVBQUUsU0FBb0IsRUFBRSxPQUFnQjtRQUNuRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsSUFBSSxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7aUNBS1csT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7OEJBQ3pCLFNBQVMsQ0FBQyxJQUFJO2lDQUNYLFNBQVMsQ0FBQyxPQUFPO2tDQUNoQixTQUFTLENBQUMsUUFBUTt1Q0FDYixTQUFTLENBQUMsYUFBYTs4QkFDaEMsU0FBUyxDQUFDLElBQUk7OEJBQ2QsU0FBUyxDQUFDLElBQUk7c0NBQ04sU0FBUyxDQUFDLFlBQVk7OEJBQzlCLFNBQVMsQ0FBQyxJQUFJO2tDQUNWLFNBQVMsQ0FBQyxRQUFRO3FDQUNmLFNBQVMsQ0FBQyxXQUFXO21DQUN2QixTQUFTLENBQUMsU0FBUztrQ0FDcEIsU0FBUyxDQUFDLFlBQVk7Z0NBQ3hCLFNBQVMsQ0FBQyxNQUFNO2tDQUNkLFNBQVMsQ0FBQyxRQUFRO2tDQUNsQixTQUFTLENBQUMsUUFBUTtrQ0FDbEIsU0FBUyxDQUFDLFFBQVE7c0NBQ2QsU0FBUyxDQUFDLFlBQVk7MkNBQ2pCLFNBQVMsQ0FBQyxpQkFBaUI7cUNBQ2pDLFNBQVMsQ0FBQyxXQUFXO3NDQUNwQixTQUFTLENBQUMsWUFBWTs2QkFDL0IsU0FBUyxDQUFDLEdBQUc7K0JBQ1gsU0FBUyxDQUFDLEtBQUs7O01BRXhDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUVqRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQztZQUM5RCxJQUFJLEVBQUUsRUFBRTtnQkFDSixTQUFTLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUN0QjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FDNUQsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsU0FBb0IsRUFBRSxPQUFnQjtRQUNsRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUV2RSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBRXRELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsU0FBUyxDQUFDLEdBQUc7d0JBQ25CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7O29DQU9qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtpQ0FDekIsU0FBUyxDQUFDLElBQUk7cUNBQ1YsU0FBUyxDQUFDLFFBQVE7MENBQ2IsU0FBUyxDQUFDLGFBQWE7aUNBQ2hDLFNBQVMsQ0FBQyxJQUFJO2lDQUNkLFNBQVMsQ0FBQyxJQUFJO3lDQUNOLFNBQVMsQ0FBQyxZQUFZO2lDQUM5QixTQUFTLENBQUMsSUFBSTtxQ0FDVixTQUFTLENBQUMsUUFBUTt3Q0FDZixTQUFTLENBQUMsV0FBVztzQ0FDdkIsU0FBUyxDQUFDLFNBQVM7cUNBQ3BCLFNBQVMsQ0FBQyxZQUFZO21DQUN4QixTQUFTLENBQUMsTUFBTTtxQ0FDZCxTQUFTLENBQUMsUUFBUTtxQ0FDbEIsU0FBUyxDQUFDLFFBQVE7cUNBQ2xCLFNBQVMsQ0FBQyxRQUFRO3lDQUNkLFNBQVMsQ0FBQyxZQUFZOzhDQUNqQixTQUFTLENBQUMsaUJBQWlCO3dDQUNqQyxTQUFTLENBQUMsV0FBVzt5Q0FDcEIsU0FBUyxDQUFDLFlBQVk7Z0NBQy9CLFNBQVMsQ0FBQyxHQUFHO2tDQUNYLFNBQVMsQ0FBQyxLQUFLOzs7WUFHckMsQ0FBQztRQUVMLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRWpELGdGQUFnRjtRQUNoRixpRUFBaUU7UUFDakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDcEcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQzVELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FDdkIsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsVUFBa0IsRUFBRSxZQUFvQixFQUFFLE9BQWdCO1FBQ3RFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsRUFBRSxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFdEUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLFlBQVk7d0JBQ2xCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7WUFTekMsQ0FBQztRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFlBQVksRUFBRSxDQUFDLENBQUM7UUFFaEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQyxFQUNuRyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsWUFBWSxFQUFFLENBQUMsQ0FBQyxFQUMzRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxZQUFZLFVBQVUsQ0FBQyxDQUN2QyxDQUFDO0lBQ04sQ0FBQztJQUVELG1CQUFtQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDckQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsV0FBVzs7Ozs7Ozs7TUFRN0YsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1FBQ3pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQzNFLENBQUM7SUFDTixDQUFDO0lBRUQsU0FBUyxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDM0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3VDQUNpQixJQUFJLENBQUMsZUFBZSxDQUNqRCxPQUFPLENBQ1Ysb0JBQW9CLFdBQVc7Ozs7O01BS2hDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFlLENBQUMsRUFDaEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FDOUQsQ0FBQztJQUNOLENBQUM7SUFFRCxRQUFRLENBQUMsVUFBa0IsRUFBRSxLQUFZLEVBQUUsT0FBZ0I7UUFDdkQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksS0FBSyxDQUFDLEdBQUcsRUFBRTtZQUNYLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OzZCQUtPLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzBCQUN6QixLQUFLLENBQUMsSUFBSTs2QkFDUCxLQUFLLENBQUMsT0FBTzs4QkFDWixLQUFLLENBQUMsUUFBUTswQkFDbEIsS0FBSyxDQUFDLElBQUk7aUNBQ0gsS0FBSyxDQUFDLFdBQVc7K0JBQ25CLEtBQUssQ0FBQyxTQUFTO3lCQUNyQixLQUFLLENBQUMsR0FBRzsyQkFDUCxLQUFLLENBQUMsS0FBSzttQ0FDSCxLQUFLLENBQUMsYUFBYTs2QkFDekIsS0FBSyxDQUFDLE9BQU87NEJBQ2QsS0FBSyxDQUFDLE1BQU07bUNBQ0wsS0FBSyxDQUFDLGFBQWE7O01BRWhELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFdkMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDMUQsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osS0FBSyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7YUFDbEI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFDL0MsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUNyRCxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxLQUFZLEVBQUUsT0FBZ0I7UUFDdEMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFL0QsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzBCQUdJLEtBQUssQ0FBQyxHQUFHO29CQUNmLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Z0NBTWpCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzZCQUN6QixLQUFLLENBQUMsSUFBSTtpQ0FDTixLQUFLLENBQUMsUUFBUTs2QkFDbEIsS0FBSyxDQUFDLElBQUk7b0NBQ0gsS0FBSyxDQUFDLFdBQVc7a0NBQ25CLEtBQUssQ0FBQyxTQUFTOzRCQUNyQixLQUFLLENBQUMsR0FBRzs4QkFDUCxLQUFLLENBQUMsS0FBSztzQ0FDSCxLQUFLLENBQUMsYUFBYTtnQ0FDekIsS0FBSyxDQUFDLE9BQU87K0JBQ2QsS0FBSyxDQUFDLE1BQU07c0NBQ0wsS0FBSyxDQUFDLGFBQWE7OztVQUcvQyxDQUFDO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFekMsZ0ZBQWdGO1FBQ2hGLGlFQUFpRTtRQUNqRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsYUFBYSxFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDeEYsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDLEVBQy9ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQ25CLENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLFVBQWtCLEVBQUUsUUFBZ0IsRUFBRSxPQUFnQjtRQUM5RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRTlELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs4QkFHUSxRQUFRO3dCQUNkLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7WUFTekMsQ0FBQztRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFFeEMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGFBQWEsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFDdkYsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDLEVBQy9ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFFBQVEsVUFBVSxDQUFDLENBQ25DLENBQUM7SUFDTixDQUFDO0lBRUQsc0JBQXNCLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUN4RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxpQkFBaUIsR0FBRzs7OztRQUkxQixDQUFDO1FBQ0QsTUFBTSxrQkFBa0IsR0FBRzs7O1FBRzNCLENBQUM7UUFDRCxNQUFNLGVBQWUsR0FBRyw2Q0FBNkMsQ0FBQztRQUN0RSxNQUFNLGtCQUFrQixHQUNwQixnR0FBZ0csQ0FBQztRQUVyRyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7OztZQU12RixpQkFBaUI7WUFDakIsa0JBQWtCO1lBQ2xCLGVBQWU7WUFDZixrQkFBa0I7OztNQUd4QixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUU1RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLHlCQUF5QixDQUFDLENBQUM7UUFDN0QsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWlCLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FDN0UsQ0FBQztJQUNOLENBQUM7SUFFRCxZQUFZLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxpQkFBaUIsR0FBRzs7OztLQUk3QixDQUFDO1FBQ0UsTUFBTSxrQkFBa0IsR0FBRzs7O2NBR3JCLENBQUM7UUFDUCxNQUFNLGVBQWUsR0FBRywyQ0FBMkMsQ0FBQztRQUNwRSxNQUFNLGtCQUFrQixHQUNwQiw4RkFBOEYsQ0FBQztRQUVuRyxNQUFNLEtBQUssR0FBRzt3Q0FDa0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7Ozs7O1VBUXhGLGlCQUFpQjtVQUNqQixrQkFBa0I7VUFDbEIsZUFBZTtVQUNmLGtCQUFrQjs7TUFFdEIsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWtCLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FDakUsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQ1AsVUFBa0IsRUFDbEIsUUFBa0IsRUFDbEIsWUFBa0IsRUFDbEIsWUFBa0IsRUFDbEIsU0FBZSxFQUNmLFlBQWtCLEVBQ2xCLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxJQUFJLFFBQVEsQ0FBQyxHQUFHLEVBQUU7WUFDZCxNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDNUM7UUFFRCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7Z0NBR1UsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7NkJBQ3pCLFFBQVEsQ0FBQyxJQUFJOzZCQUNiLFFBQVEsQ0FBQyxJQUFJOzs7cUNBR0wsUUFBUSxDQUFDLFlBQVk7cUNBQ3JCLFFBQVEsQ0FBQyxZQUFZO2dDQUMxQixRQUFRLENBQUMsT0FBTztpQ0FDZixRQUFRLENBQUMsUUFBUTtvQ0FDZCxRQUFRLENBQUMsV0FBVzsrQkFDekIsUUFBUSxDQUFDLE1BQU07MENBQ0osUUFBUSxDQUFDLGlCQUFpQjtpQ0FDbkMsUUFBUSxDQUFDLFFBQVE7MENBQ1IsUUFBUSxDQUFDLGlCQUFpQjtXQUN6RCxVQUFVOztNQUVmLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUU1QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztZQUM3RCxJQUFJLEVBQUUsRUFBRTtnQkFDSixRQUFRLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUNyQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FDM0QsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsUUFBa0IsRUFBRSxPQUFnQjtRQUMvQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUVyRSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7MEJBR0ksUUFBUSxDQUFDLEdBQUc7b0JBQ2xCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Z0NBTWpCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO29DQUNsQixRQUFRLENBQUMsV0FBVzsrQkFDekIsUUFBUSxDQUFDLE1BQU07aUNBQ2IsUUFBUSxDQUFDLFFBQVE7MENBQ1IsUUFBUSxDQUFDLGlCQUFpQjtpQ0FDbkMsUUFBUSxDQUFDLFFBQVE7MENBQ1IsUUFBUSxDQUFDLGlCQUFpQjs7O1FBRzVELENBQUM7UUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUUvQyxnRkFBZ0Y7UUFDaEYsaUVBQWlFO1FBQ2pFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQ2pHLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLEVBQ2xFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUMxRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQ3RCLENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFVBQWtCLEVBQUUsUUFBa0IsRUFBRSxPQUFnQjtRQUNuRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUVyRSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsUUFBUSxDQUFDLEdBQUc7d0JBQ2xCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7O21CQU9sQyxVQUFVLHlCQUF5QixRQUFRLENBQUMsR0FBRzs7O1lBR3RELENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixRQUFRLENBQUMsR0FBRyxpQkFBaUIsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUUxRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUNqRyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxFQUNsRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsUUFBUSxDQUFDLEdBQUcsaUJBQWlCLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFDckYsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQ2hDLENBQUM7SUFDTixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsNkJBQTZCLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUMvRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7c0JBQ0EsV0FBVyxjQUFjLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7OztNQVF0RSxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDO1FBQ25FLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQWtCLENBQUM7YUFDNUM7aUJBQU07Z0JBQ0gsT0FBTyxFQUFnQixDQUFDO2FBQzNCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUNqRCxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILDhCQUE4QixDQUFDLFlBQW9CLEVBQUUsT0FBZ0I7UUFDakUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3NCQUNBLFlBQVksY0FBYyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7TUFRdkUsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0NBQWdDLENBQUMsQ0FBQztRQUNwRSxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7Z0JBQ3JCLE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxJQUFrQixDQUFDO2FBQzVDO2lCQUFNO2dCQUNILE9BQU8sRUFBZ0IsQ0FBQzthQUMzQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FDakQsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUNqRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7d0NBQ2tCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7O01BTzVGLENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRWxELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUNyRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7Z0JBQ3JCLE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxJQUFxQixDQUFDO2FBQy9DO2lCQUFNO2dCQUNILE9BQU8sRUFBbUIsQ0FBQzthQUM5QjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQ3BFLENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFVBQWtCLEVBQUUsV0FBd0IsRUFBRSxPQUFnQjtRQUN6RSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsSUFBSSxXQUFXLENBQUMsR0FBRyxFQUFFO1lBQ2pCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7OzttQ0FHYSxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FDekIsV0FBVyxDQUFDLElBQUk7Z0NBQ2hCLFdBQVcsQ0FBQyxJQUFJOzs7dUNBR1QsV0FBVyxDQUFDLFdBQVc7a0NBQzVCLFdBQVcsQ0FBQyxNQUFNO29DQUNoQixXQUFXLENBQUMsUUFBUTtpQ0FDdkIsV0FBVyxDQUFDLEtBQUs7bUNBQ2YsV0FBVyxDQUFDLE9BQU87b0NBQ2xCLFdBQVcsQ0FBQyxRQUFRO1dBQzdDLFVBQVU7O01BRWYsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFekQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDcEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQztZQUNoRSxJQUFJLEVBQUUsRUFBRTtnQkFDSixXQUFXLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUN4QjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUMsQ0FBQyxFQUNyRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUN0RSxDQUFDO0lBQ04sQ0FBQztJQUVELGlCQUFpQixDQUFDLFdBQXdCLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFM0UsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzBCQUdJLFdBQVcsQ0FBQyxHQUFHO29CQUNyQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O2dDQU1qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs2QkFDekIsV0FBVyxDQUFDLElBQUk7NkJBQ2hCLFdBQVcsQ0FBQyxJQUFJO29DQUNULFdBQVcsQ0FBQyxXQUFXO21DQUN4QixXQUFXLENBQUMsTUFBTTtxQ0FDaEIsV0FBVyxDQUFDLFFBQVE7OEJBQzNCLFdBQVcsQ0FBQyxLQUFLO2lDQUNkLFdBQVcsQ0FBQyxRQUFROzs7UUFHN0MsQ0FBQztRQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRXJELGdGQUFnRjtRQUNoRixpRUFBaUU7UUFFakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLG1CQUFtQixFQUFFLGFBQWEsRUFBRSxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDMUcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLDhCQUE4QixDQUFDLENBQUMsRUFDaEYsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ2pFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FDekIsQ0FBQztJQUNOLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxVQUFrQixFQUFFLGNBQXNCLEVBQUUsT0FBZ0I7UUFDMUUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLGNBQWMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUUxRSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsY0FBYzt3QkFDcEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7bUJBT2xDLFVBQVUsNEJBQTRCLGNBQWM7OztZQUczRCxDQUFDO1FBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsY0FBYyxnQkFBZ0IsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUU5RSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsbUJBQW1CLEVBQUUsYUFBYSxFQUFFLGNBQWMsQ0FBQyxDQUFDLEVBQ3pHLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDLEVBQ3JFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixjQUFjLGdCQUFnQixVQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQ3pGLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLGNBQWMsVUFBVSxDQUFDLENBQ3pDLENBQUM7SUFDTixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUNsRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7d0NBQ2tCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7OztNQVE1RixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUVuRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLG1CQUFtQixDQUFDLENBQUM7UUFDdkQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBOEIsQ0FBQzthQUN4RDtpQkFBTTtnQkFDSCxPQUFPLEVBQTRCLENBQUM7YUFDdkM7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUNyRSxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUNaLFVBQWtCLEVBQ2xCLGFBQW1DLEVBQ25DLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxJQUFJLGFBQWEsQ0FBQyxHQUFHLEVBQUU7WUFDbkIsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7a0NBS1ksYUFBYSxDQUFDLFdBQVc7V0FDaEQsVUFBVTtXQUNWLE9BQU87O01BRVosQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFM0QsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMxRCxJQUFJLEVBQUUsRUFBRTtnQkFDSixhQUFhLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUMxQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsQ0FBQyxFQUN2RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUMxRSxDQUFDO0lBQ04sQ0FBQztJQUVELG1CQUFtQixDQUFDLGFBQW1DLEVBQUUsT0FBZ0I7UUFDckUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLGFBQWEsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFOUUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLGFBQWEsQ0FBQyxHQUFHO3dCQUN2QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O3dDQU1iLGFBQWEsQ0FBQyxXQUFXO21CQUM5QyxPQUFPLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs7O1lBR3BELENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixhQUFhLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUV6RCxnRkFBZ0Y7UUFDaEYsaUVBQWlFO1FBQ2pFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxxQkFBcUIsRUFBRSxRQUFRLEVBQUUsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQ3pHLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDLEVBQ3ZFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixhQUFhLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQzNCLENBQUM7SUFDTixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsa0JBQWtCLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUNwRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7O2lEQUUyQixJQUFJLENBQUMsZUFBZSxDQUMzRCxPQUFPLENBQ1YsbUJBQW1CLFdBQVc7OztNQUcvQixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUN2RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLG1CQUFtQixDQUFDLENBQUM7UUFDdkQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQXdCLENBQUMsQ0FDNUQsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCxvQkFBb0IsQ0FBQyxjQUE4QixFQUFFLE9BQWdCO1FBQ2pFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFakYsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLGNBQWMsQ0FBQyxHQUFHO3dCQUN4QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O21CQU1sQyxjQUFjLENBQUMsR0FBRyxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7bUJBQ3hELGNBQWMsQ0FBQyxHQUFHLGlCQUFpQixjQUFjLENBQUMsUUFBUTttQkFDMUQsY0FBYyxDQUFDLEdBQUcsYUFBYSxjQUFjLENBQUMsSUFBSTttQkFDbEQsY0FBYyxDQUFDLEdBQUcsY0FBYyxjQUFjLENBQUMsS0FBSzttQkFDcEQsY0FBYyxDQUFDLEdBQUcsYUFBYSxjQUFjLENBQUMsSUFBSTttQkFDbEQsY0FBYyxDQUFDLEdBQUcsb0JBQW9CLGNBQWMsQ0FBQyxXQUFXO21CQUNoRSxjQUFjLENBQUMsR0FBRyxlQUFlLGNBQWMsQ0FBQyxNQUFNO21CQUN0RCxjQUFjLENBQUMsR0FBRyxnQkFBZ0IsY0FBYyxDQUFDLE9BQU87OztVQUdqRSxDQUFDO1FBRUgsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFM0QsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLHNCQUFzQixFQUFFLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUNuSCxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsc0JBQXNCLENBQUMsQ0FBQyxFQUN4RSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFDcEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUM1QixDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILGlCQUFpQixDQUFDLGNBQThCLEVBQUUsT0FBZ0I7UUFDOUQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksY0FBYyxDQUFDLEdBQUcsRUFBRTtZQUNwQixNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDNUM7UUFDRCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OztzQ0FLZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7bUNBQ3pCLGNBQWMsQ0FBQyxJQUFJO3NDQUNoQixjQUFjLENBQUMsT0FBTzt1Q0FDckIsY0FBYyxDQUFDLFFBQVE7bUNBQzNCLGNBQWMsQ0FBQyxJQUFJOzBDQUNaLGNBQWMsQ0FBQyxXQUFXO29DQUNoQyxjQUFjLENBQUMsS0FBSztxQ0FDbkIsY0FBYyxDQUFDLE1BQU07c0NBQ3BCLGNBQWMsQ0FBQyxPQUFPO1NBQ25ELENBQUM7UUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixjQUFjLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUV6RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztRQUN2RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFDbkUsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osY0FBYyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7YUFDM0I7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsY0FBYyxDQUFDLENBQUMsRUFDeEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLGNBQWMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQ3JFLENBQUM7SUFDTixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsb0JBQW9CLENBQUMsaUJBQXlCLEVBQUUsT0FBZ0I7UUFDNUQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFaEYsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OEJBRVEsaUJBQWlCO3dCQUN2QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsaUJBQWlCLG1CQUFtQixDQUFDLENBQUM7UUFDckQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLHNCQUFzQixFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbEgsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLHNCQUFzQixDQUFDLENBQUMsRUFDeEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxpQkFBaUIsVUFBVSxDQUFDLENBQzVDLENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxXQUFtQixFQUFFLE9BQWdCO1FBQ3pGLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVUsSUFBSSxjQUFjOytDQUNyRSxXQUFXOzs7Ozs7O01BT3BELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQztRQUVoRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQW1CLENBQUM7YUFDN0M7aUJBQU07Z0JBQ0gsT0FBTyxFQUFpQixDQUFDO2FBQzVCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ3ZFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUNsRixDQUFDO0lBQ04sQ0FBQztJQUVELGFBQWEsQ0FBQyxVQUFrQixFQUFFLGNBQXNCLEVBQUUsRUFBVSxFQUFFLE9BQWdCO1FBQ2xGLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVUsSUFBSSxjQUFjOzJEQUN6RCxFQUFFOzs7Ozs7O01BT3ZELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQztRQUVsRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQW1CLENBQUM7YUFDN0M7aUJBQU07Z0JBQ0gsT0FBTyxFQUFpQixDQUFDO2FBQzVCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQ2xGLENBQUM7SUFDTixDQUFDO0lBRUQscUJBQXFCLENBQ2pCLFVBQWtCLEVBQ2xCLGNBQXNCLEVBQ3RCLE1BQWMsRUFDZCxPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixVQUFVLElBQUksY0FBYzsyREFDekQsTUFBTTs7Ozs7OztNQU8zRCxDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUM7UUFFOUUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO1FBQzNELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQW1CLENBQUM7YUFDN0M7aUJBQU07Z0JBQ0gsT0FBTyxFQUFpQixDQUFDO2FBQzVCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQzdGLENBQUM7SUFDTixDQUFDO0lBRUQsa0JBQWtCLENBQ2QsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsTUFBYyxFQUNkLElBQVksRUFDWixPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixVQUFVLElBQUksY0FBYzsyREFDekQsTUFBTSxxQkFBcUIsSUFBSTs7Ozs7OztNQU9wRixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUM7UUFFdkUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO1FBQ3hELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQW1CLENBQUM7YUFDN0M7aUJBQU07Z0JBQ0gsT0FBTyxFQUFpQixDQUFDO2FBQzVCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQzFGLENBQUM7SUFDTixDQUFDO0lBRUQsd0JBQXdCLENBQUMsVUFBa0IsRUFBRSxPQUFnQjtRQUN6RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7d0NBQ2tCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixVQUFVOzs7Ozs7Ozs7TUFTM0YsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFMUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO1FBQzlELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQW1CLENBQUM7YUFDN0M7aUJBQU07Z0JBQ0gsT0FBTyxFQUFpQixDQUFDO2FBQzVCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FDcEUsQ0FBQztJQUNOLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxPQUFnQjtRQUM3QixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBQy9DLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHOzhDQUN3QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7OztNQU9yRSxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBQ3RELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQXNCLENBQUM7YUFDaEQ7aUJBQU07Z0JBQ0gsT0FBTyxFQUFvQixDQUFDO2FBQy9CO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUNsRCxDQUFDO0lBQ04sQ0FBQztJQUVELFFBQVEsQ0FBQyxVQUFrQixFQUFFLE9BQWdCO1FBQ3pDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUM7UUFFakIsSUFBSSxVQUFVLElBQUksWUFBWSxFQUFFO1lBQzVCLEtBQUssR0FBRyxNQUFNLENBQUM7U0FDbEI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsS0FBSyxHQUFHLE1BQU0sQ0FBQztTQUNsQjthQUFNLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRTtZQUNuQyxLQUFLLEdBQUcsTUFBTSxDQUFDO1NBQ2xCO2FBQU07WUFDSCxLQUFLLEdBQUcsVUFBVSxDQUFDO1NBQ3RCO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFFbEIsb0JBQW9CO1FBQ3BCLDhCQUE4QjtRQUM5Qiw2QkFBNkI7UUFFN0IsSUFBSSxVQUFVLElBQUksWUFBWSxFQUFFO1lBQzVCLE1BQU0sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzFCO2FBQU0sSUFBSSxVQUFVLElBQUksWUFBWSxFQUFFO1lBQ25DLE1BQU0sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzFCO2FBQU0sSUFBSSxVQUFVLElBQUksWUFBWSxFQUFFO1lBQ25DLE1BQU0sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzFCO2FBQU07WUFDSCxNQUFNLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDekI7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRU8sdUJBQXVCLENBQUMsT0FBZ0I7UUFDNUMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDdkIsSUFBSSxDQUFDLE9BQU87Z0JBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1NBQ3ZEO0lBQ0wsQ0FBQztJQUVPLGVBQWUsQ0FBQyxPQUFnQjtRQUNwQyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN2QixPQUFPLGdCQUFnQixPQUFPLElBQUksQ0FBQztTQUN0QzthQUFNO1lBQ0gsT0FBTyxpQkFBaUIsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsMEJBQTBCLENBQUM7U0FDNUU7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxjQUFjLENBQUMsUUFBYSxFQUFFLFNBQVMsR0FBRyxXQUFXO1FBQ3pELElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN0QixJQUFJLE1BQU0sQ0FBQztRQUVYLElBQUksUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUU7WUFDeEIsU0FBUyxHQUFHLElBQUksQ0FBQztZQUNqQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxZQUFZLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDdkUsTUFBTSxHQUFHLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQ3pEO2FBQU0sSUFBSSxRQUFRLEVBQUUsTUFBTSxFQUFFO1lBQ3pCLFNBQVMsR0FBRyxJQUFJLENBQUM7WUFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFNBQVMsWUFBWSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDbEUsTUFBTSxHQUFHLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDcEQ7UUFFRCxJQUFJLFNBQVMsRUFBRTtZQUNYLE1BQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1NBQzNDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNLLGlCQUFpQixDQUFDLGNBQTZCLEVBQUUsU0FBaUI7UUFDdEUsSUFBSSxjQUFjLENBQUMsSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUNuQyxNQUFNLEdBQUcsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzNDLE9BQU8sR0FBRyxDQUFDO1NBQ2Q7UUFDRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRU8sV0FBVyxDQUFDLFVBQWtCLEVBQUUsR0FBdUIsRUFBRSxPQUFnQjtRQUM3RSxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ04sTUFBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNqRTtRQUNELE9BQU87eUJBQ1UsVUFBVSxjQUFjLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGFBQWEsR0FBRzs7O1FBR3RGLENBQUM7SUFDTCxDQUFDO0lBRU8sbUJBQW1CLENBQUMsUUFBYSxFQUFFLFNBQWlCLEVBQUUsVUFBa0IsRUFBRSxHQUF1QjtRQUNyRyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ04sTUFBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNqRTtRQUNELElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3pDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ25DLE1BQU0sYUFBYSxHQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQzdDLElBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQzVCLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxVQUFVLFlBQVksR0FBRyxpQ0FBaUMsQ0FBQyxDQUFDO2dCQUMvRSxNQUFNLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDdEU7U0FDSjtJQUNMLENBQUM7Q0FDSiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gICAgRGF0YVN0b3JlLFxuICAgIEdhdGV3YXksXG4gICAgR2F0ZXdheUZpbHRlcnNDb25maWcsXG4gICAgTW9kZWwsXG4gICAgTW9kZWxDb25maWcsXG4gICAgTm90aWZpY2F0aW9uLFxuICAgIFBpcGVsaW5lLFxuICAgIFByb3RvY29sLFxuICAgIFRTUmVhZGluZyxcbiAgICBQeXRob25SZXNvdXJjZSxcbn0gZnJvbSAnLi4vbW9kZWwvbW9kZWxzJztcbmltcG9ydCB7IG1hcCwgT2JzZXJ2YWJsZSwgc3dpdGNoTWFwLCB0YXAgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5cblxuY29uc3Qgcm91dGUxOiBudW1iZXJbXVtdID0gW1xuICAgIFsyNS43NzEwODgsIC04MC4xNjM0ODNdLFxuICAgIFsyNy40Mzk3NzUsIC04MC4zMjI5OV0sXG4gICAgWzI4LjM0OTQ2OSwgLTgwLjczMTEwNV0sXG4gICAgWzMwLjQwMTU2NCwgLTgxLjU3MTAzM10sXG4gICAgWzMyLjExNjcxNiwgLTgxLjE0NDE0N10sXG4gICAgWzMyLjg2NjUxMSwgLTc5Ljk5NTM5OV0sXG4gICAgWzM0LjE5MTIyNCwgLTc3Ljk1MjQxOV0sXG4gICAgWzM2Ljg1MDE3MiwgLTc2LjMxOTI2OV0sXG4gICAgWzM2LjkxNTAzNywgLTc2LjMyMDY0M10sXG4gICAgWzM5LjI2MjAyNSwgLTc2LjU0OTI5NF0sXG4gICAgWzM5LjkwMDkzMywgLTc1LjE0MzQ1M10sXG4gICAgWzQwLjY5MDI2MywgLTc0LjE1MjM3NV0sXG4gICAgWzQyLjI1OTk1MSwgLTcxLjc4OTI0NF0sXG5dO1xuXG5jb25zdCByb3V0ZTI6IG51bWJlcltdW10gPSBbXG4gICAgWzQ3LjQ5MjQ3MSwgLTEyMi4yNjg4OF0sXG4gICAgWzQ1LjU1MjIwNywgLTEyMi43MjI2NDhdLFxuICAgIFszOS41MzI0NiwgLTExOS43NTE1MjRdLFxuICAgIFszNy44MDM1MjgsIC0xMjIuMzEyMTM4XSxcbiAgICBbMzcuODk5MzMyLCAtMTIxLjE2OTMwN10sXG4gICAgWzM2LjI3MzE4MywgLTExNS4wNzA1MzRdLFxuICAgIFszMy43NzAzMiwgLTExOC4yNzMyODldLFxuICAgIFszNC4xMDYwMTIsIC0xMTcuMzIwMjU0XSxcbiAgICBbMzMuNTE1NTY0LCAtMTEyLjE2MDU2NF0sXG4gICAgWzMyLjEyNjQzNywgLTExMC44NDgzMzZdLFxuICAgIFszMS43NTIwODUsIC0xMDYuNDg4ODg3XSxcbiAgICBbMzUuMDQ3NTgsIC0xMDYuNjUzMzQ0XSxcbiAgICBbMzkuNzk2OTYzLCAtMTA0Ljk5NTM3NF0sXG5dO1xuXG5jb25zdCByb3V0ZTM6IG51bWJlcltdW10gPSBbXG4gICAgWzI5LjMwMjcyOSwgLTk4LjYzODc0NF0sXG4gICAgWzI5LjYzODQyMSwgLTk1LjI5MjI0NV0sXG4gICAgWzMyLjYxNTUyNSwgLTk2LjY5MzQ4NV0sXG4gICAgWzI5LjkxNzgzNiwgLTkwLjIwNTI3Ml0sXG4gICAgWzMyLjI1NjQwMywgLTkwLjE1MTU0Nl0sXG4gICAgWzM1LjA0NDg0OSwgLTkwLjE1MzAwNl0sXG4gICAgWzM4LjUyNDYyNywgLTkwLjIwOTUzNV0sXG4gICAgWzM5Ljg3MDg1MSwgLTg4LjkxMjI4NF0sXG4gICAgWzQxLjcwNTY5NCwgLTg3LjU3NzM0MV0sXG4gICAgWzQxLjkwMjM4MiwgLTg5LjEwMTkzMl0sXG4gICAgWzQ0LjI1MTI0MywgLTkxLjUwOTY2M10sXG4gICAgWzQ0Ljk3MDA2OSwgLTkzLjE3NDUyN10sXG4gICAgWzQ2Ljc1ODE4MSwgLTkyLjA5ODc0OF0sXG5dO1xuXG5jb25zdCBlbXB0eVJvdXRlOiBudW1iZXJbXVtdID0gW107XG5cbmNvbnN0IGh0dHBPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9ncmFwaHFsKy0nLFxuICAgIH0sXG59O1xuXG5jb25zdCBodHRwTXV0YXRlT3B0aW9ucyA9IHtcbiAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vcmRmJyB9LFxufTtcblxuZXhwb3J0IGNsYXNzIEdyYXBoU2VydmljZSB7XG4gICAgXG4gICAgcHJpdmF0ZSByZXF1aXJlQWNjb3VudElkID0gdHJ1ZTtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCwgcHJvdGVjdGVkIGRHcmFwaFVybDogc3RyaW5nLCBwcml2YXRlIGFjY291bnRSZXF1aXJlZDogYm9vbGVhbikge1xuICAgICAgICB0aGlzLnJlcXVpcmVBY2NvdW50SWQgPSBhY2NvdW50UmVxdWlyZWQ7XG4gICAgICAgIC8vY29uc3QgZEdyYXBoQmFzaWNBdXRoRW5hYmxlZCA9IHRoaXMuYXBwQ29uZmlnU2VydmljZS5kR3JhcGhCYXNpY0F1dGhFbmFibGVkO1xuICAgICAgICAvL2lmIChkR3JhcGhCYXNpY0F1dGhFbmFibGVkKSB7XG4gICAgICAgIC8vICAgIGNvbnN0IGRHcmFwaEJhc2ljQXV0aCA9IHRoaXMuYXBwQ29uZmlnU2VydmljZS5kR3JhcGhCYXNpY0F1dGg7XG4gICAgICAgIC8vICAgICh0aGlzLmh0dHBPcHRpb25zLmhlYWRlcnMgPSB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vZ3JhcGhxbCstJyB9KSwgeyBBdXRob3JpemF0aW9uOiBkR3JhcGhCYXNpY0F1dGggfTtcbiAgICAgICAgLy8gICAgKHRoaXMuaHR0cE11dGF0ZU9wdGlvbnMuaGVhZGVycyA9IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9yZGYnIH0pLCB7IEF1dGhvcml6YXRpb246IGRHcmFwaEJhc2ljQXV0aCB9O1xuICAgICAgICAvL31cbiAgICB9XG5cbiAgICBnZXRHYXRld2F5KGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBHZXRHYXRld2F5IHNlcnZpY2UgY2FsbGVkIGZvciAke2dhdGV3YXlOYW1lfWApO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnk/ZGVidWc9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkIGRlc2NyaXB0aW9uIGFkZHJlc3Mgcm91dGVyIHJvdXRlclBvcnRcbiAgICAgICAgZGVwbG95TmV0d29yayBsYXRpdHVkZSBsb25naXR1ZGUgYWNjZXNzVG9rZW4gdXNlcm5hbWVcbiAgICAgICAgcGxhdGZvcm0gZGV2aWNlc01ldGFkYXRhIGNyZWF0ZWR0cyB1cGRhdGVkdHNcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0R2F0ZXdheScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRHYXRld2F5cyhhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnk/ZGVidWc9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKVxuICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICB1aWQgdXVpZCBkZXNjcmlwdGlvbiBhZGRyZXNzIHJvdXRlciByb3V0ZXJQb3J0XG4gICAgICAgIGRlcGxveU5ldHdvcmsgbGF0aXR1ZGUgbG9uZ2l0dWRlIGFjY2Vzc1Rva2VuIHVzZXJuYW1lXG4gICAgICAgIHBsYXRmb3JtIGRldmljZXNNZXRhZGF0YSBjcmVhdGVkdHMgdXBkYXRlZHRzXG4gICAgICAgIG51bURldmljZXM6IGNvdW50KGdhdGV3YXlfZGV2aWNlKVxuICAgICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldEdhdGV3YXlzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgJHtyZXNwb25zZS5sZW5ndGh9IGdhdGV3YXlzYCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZUdhdGV3YXkoZ2F0ZXdheTogR2F0ZXdheSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ2dhdGV3YXknLCBnYXRld2F5LnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7Z2F0ZXdheS51aWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIHNldCB7XG4gICAgICAgICAgICAgICAgdWlkKHYpIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxhZGRyZXNzPiBcIiR7Z2F0ZXdheS5hZGRyZXNzfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHJvdXRlcj4gXCIke2dhdGV3YXkucm91dGVyfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHJvdXRlclBvcnQ+IFwiJHtnYXRld2F5LnJvdXRlclBvcnR9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8ZGVwbG95TmV0d29yaz4gXCIke2dhdGV3YXkuZGVwbG95TmV0d29ya31cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxkZXNjcmlwdGlvbj4gXCIke2dhdGV3YXkuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8bGF0aXR1ZGU+IFwiJHtnYXRld2F5LmxhdGl0dWRlfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGxvbmdpdHVkZT4gXCIke2dhdGV3YXkubG9uZ2l0dWRlfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGFjY2Vzc1Rva2VuPiBcIiR7Z2F0ZXdheS5hY2Nlc3NUb2tlbn1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDx1c2VybmFtZT4gXCIke2dhdGV3YXkudXNlcm5hbWV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cGxhdGZvcm0+IFwiJHtnYXRld2F5LnBsYXRmb3JtfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVwZGF0ZWR0cz4gXCIke2dhdGV3YXkudXBkYXRlZHRzfVwiIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlIEdhdGV3YXkgJHtnYXRld2F5LnV1aWR9ICR7Z2F0ZXdheS51aWR9YCk7XG5cbiAgICAgICAgLy8gV2l0aCB0aGUgdXBzZXJ0IGFwcHJvYWNoLCBpdCBpcyBub3QgcG9zc2libGUgdG8gc2VlIGlmIHRoZSBtdXRhdGlvbiBvY2N1cnJlZC5cbiAgICAgICAgLy8gVXNlIGEgcHJlUXVlcnkgZm9yIHRoZSBvYmplY3QgZmlyc3QgdG8gZGV0ZXJtaW5lIGlmIGl0IGV4aXN0cy5cblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlR2F0ZXdheScsICdnYXRld2F5JywgZ2F0ZXdheS51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlR2F0ZXdheScpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBnYXRld2F5ICR7Z2F0ZXdheS51dWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiAnZ2F0ZXdheSB1cGRhdGVkJyksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkR2F0ZXdheShnYXRld2F5OiBHYXRld2F5LCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5PiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKGdhdGV3YXkudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86R2F0ZXdheSA8ZGdyYXBoLnR5cGU+IFwiR2F0ZXdheVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxnYXRld2F5PiBcIlwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx0eXBlPiBcImdhdGV3YXlcIiAuXG4gICAgICAgIF86R2F0ZXdheSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHV1aWQ+IFwiJHtnYXRld2F5LnV1aWR9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGRlc2NyaXB0aW9uPiBcIiR7Z2F0ZXdheS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8YWRkcmVzcz4gXCIke2dhdGV3YXkuYWRkcmVzc31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8cm91dGVyPiBcIiR7Z2F0ZXdheS5yb3V0ZXJ9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHJvdXRlclBvcnQ+IFwiJHtnYXRld2F5LnJvdXRlclBvcnR9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGRlcGxveU5ldHdvcms+IFwiJHtnYXRld2F5LmRlcGxveU5ldHdvcmt9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGxhdGl0dWRlPiBcIiR7Z2F0ZXdheS5sYXRpdHVkZX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8bG9uZ2l0dWRlPiBcIiR7Z2F0ZXdheS5sb25naXR1ZGV9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGFjY2Vzc1Rva2VuPiBcIiR7Z2F0ZXdheS5hY2Nlc3NUb2tlbn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8dXNlcm5hbWU+IFwiJHtnYXRld2F5LnVzZXJuYW1lfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxwbGF0Zm9ybT4gXCIke2dhdGV3YXkucGxhdGZvcm19XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGNyZWF0ZWR0cz4gXCIke2dhdGV3YXkuY3JlYXRlZHRzfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx1cGRhdGVkdHM+IFwiJHtnYXRld2F5LnVwZGF0ZWR0c31cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgR2F0ZXdheSAke2dhdGV3YXkudXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkR2F0ZXdheScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdHYXRld2F5Jyk7XG4gICAgICAgICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIGdhdGV3YXkudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gZ2F0ZXdheSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGQgZ2F0ZXdheSAke2dhdGV3YXkudWlkfS8ke2dhdGV3YXkudXVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlR2F0ZXdheShnYXRld2F5VWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdnYXRld2F5JywgZ2F0ZXdheVVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtnYXRld2F5VWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBkZWxldGUge1xuICAgICAgICAgICAgICAgIHVpZCh2KSAqICogLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBHYXRld2F5ICR7Z2F0ZXdheVVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAnZGVsZXRlR2F0ZXdheScsICdnYXRld2F5JywgZ2F0ZXdheVVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdkZWxldGVHYXRld2F5JykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgJHtnYXRld2F5VWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheUFuZFByb3RvY29scyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWRcbiAgICAgICAgcHJvdG9jb2xzOiBnYXRld2F5X3Byb3RvY29sIHtcbiAgICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIHByb3RvY29sVHlwZSBicm9rZXJVUkxcbiAgICAgICAgICB0b3BpYyBjb25zdW1lckdyb3VwSWQgY29ubmVjdGlvblRpbWVvdXQgc2Vzc2lvblRpbWVvdXRcbiAgICAgICAgICBpbml0aWFsT2Zmc2V0IHJldHJ5QmFja09mZiBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdFxuICAgICAgICAgIGNvbW1pdEludGVydmFsIGhlYXJ0YmVhdEludGVydmFsIG1heGltdW1RT1NcbiAgICAgICAgICB1c2VybmFtZSBwYXNzd29yZCBlbmNyeXB0aW9uTW9kZVxuICAgICAgICAgIGNhQ2VydGlmaWNhdGUgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5XG4gICAgICAgICAgYXV0aE1vZGUgc2VydmVyQ2VydGlmaWNhdGVcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgR2V0IEdhdGV3YXkgYW5kIFByb3RvY29scyBmb3IgJHtnYXRld2F5TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0R2F0ZXdheVdpdGhQcm90b2NvbHMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgR2F0ZXdheSBhbmQgUHJvdG9jb2xzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgYWxsIGdsb2JhbCBwcm90b2NvbHMgYW5kIHRoZSBwcm90b2NvbHMgc2NvcGVkIGZvciB0aGUgZ2F0ZXdheVxuICAgICAqIEBwYXJhbSBnYXRld2F5TmFtZVxuICAgICAqL1xuICAgIGdldFByb3RvY29scyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQcm90b2NvbFtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKHByb3RvY29sKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KFxuICAgICAgICAgIGFjY291bnQsXG4gICAgICApfSBBTkQgKGVxKHNjb3BlLCBcIiR7Z2F0ZXdheU5hbWV9XCIpIE9SIGVxKHNjb3BlLCBcIkdMT0JBTFwiKSkpIHtcbiAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBwcm90b2NvbFR5cGUgYnJva2VyVVJMIHRvcGljXG4gICAgICAgIGNvbnN1bWVyR3JvdXBJZCBjb25uZWN0aW9uVGltZW91dCBzZXNzaW9uVGltZW91dCBpbml0aWFsT2Zmc2V0XG4gICAgICAgIHJldHJ5QmFja09mZiBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdCBjb21taXRJbnRlcnZhbFxuICAgICAgICBoZWFydGJlYXRJbnRlcnZhbCBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkXG4gICAgICAgIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGUgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5XG4gICAgICAgIGF1dGhNb2RlIHNlcnZlckNlcnRpZmljYXRlIHNjb3BlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFByb3RvY29scycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUHJvdG9jb2xbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcHJvdG9jb2xzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRQcm90b2NvbChnYXRld2F5VWlkOiBudW1iZXIsIHByb3RvY29sOiBQcm90b2NvbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2w+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAocHJvdG9jb2wudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UHJvdG9jb2wgPGRncmFwaC50eXBlPiBcIlByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDx0eXBlPiBcInByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwcm90b2NvbD4gXCJcIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8dXVpZD4gXCIke3Byb3RvY29sLnV1aWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjcmVhdGVkPiBcIiR7cHJvdG9jb2wuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPG1vZGlmaWVkPiBcIiR7cHJvdG9jb2wubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwcm90b2NvbFR5cGU+IFwiJHtwcm90b2NvbC5wcm90b2NvbFR5cGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxicm9rZXJVUkw+IFwiJHtwcm90b2NvbC5icm9rZXJVUkx9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDx0b3BpYz4gXCIke3Byb3RvY29sLnRvcGljfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y29uc3VtZXJHcm91cElkPiBcIiR7cHJvdG9jb2wuY29uc3VtZXJHcm91cElkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y29ubmVjdGlvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5jb25uZWN0aW9uVGltZW91dH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHNlc3Npb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuc2Vzc2lvblRpbWVvdXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxpbml0aWFsT2Zmc2V0PiBcIiR7cHJvdG9jb2wuaW5pdGlhbE9mZnNldH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHJldHJ5QmFja09mZj4gXCIke3Byb3RvY29sLnJldHJ5QmFja09mZn1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGZldGNoTWluQnl0ZXM+IFwiJHtwcm90b2NvbC5mZXRjaE1pbkJ5dGVzfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8ZmV0Y2hNYXhXYWl0PiBcIiR7cHJvdG9jb2wuZmV0Y2hNYXhXYWl0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y29tbWl0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5jb21taXRJbnRlcnZhbH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGhlYXJ0YmVhdEludGVydmFsPiBcIiR7cHJvdG9jb2wuaGVhcnRiZWF0SW50ZXJ2YWx9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxtYXhpbXVtUU9TPiBcIiR7cHJvdG9jb2wubWF4aW11bVFPU31cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHVzZXJuYW1lPiBcIiR7cHJvdG9jb2wudXNlcm5hbWV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwYXNzd29yZD4gXCIke3Byb3RvY29sLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8ZW5jcnlwdGlvbk1vZGU+IFwiJHtwcm90b2NvbC5lbmNyeXB0aW9uTW9kZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNhQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jYUNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y2xpZW50Q2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jbGllbnRDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNsaWVudEtleT4gXCIke3Byb3RvY29sLmNsaWVudEtleX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGF1dGhNb2RlPiBcIiR7cHJvdG9jb2wuYXV0aE1vZGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxzZXJ2ZXJDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLnNlcnZlckNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8c2NvcGU+IFwiJHtwcm90b2NvbC5zY29wZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgcHJvdG9jb2wgJHtwcm90b2NvbC51dWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRQcm90b2NvbCcpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdQcm90b2NvbCcpO1xuICAgICAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgICAgICBwcm90b2NvbC51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwcm90b2NvbCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGQgcHJvdG9jb2xzICR7cHJvdG9jb2wudWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVQcm90b2NvbChwcm90b2NvbDogUHJvdG9jb2wsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFByb3RvY29sPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ3Byb3RvY29sJywgcHJvdG9jb2wudWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke3Byb3RvY29sLnVpZH0pKVxuICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIG11dGF0aW9uIEBpZiAoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgIHNldCB7XG4gICAgICAgICAgICB1aWQodikgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8dXVpZD4gXCIke3Byb3RvY29sLnV1aWR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxtb2RpZmllZD4gXCIke3Byb3RvY29sLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8cHJvdG9jb2xUeXBlPiBcIiR7cHJvdG9jb2wucHJvdG9jb2xUeXBlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8YnJva2VyVVJMPiBcIiR7cHJvdG9jb2wuYnJva2VyVVJMfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8dG9waWM+IFwiJHtwcm90b2NvbC50b3BpY31cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNvbnN1bWVyR3JvdXBJZD4gXCIke3Byb3RvY29sLmNvbnN1bWVyR3JvdXBJZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNvbm5lY3Rpb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuY29ubmVjdGlvblRpbWVvdXR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzZXNzaW9uVGltZW91dD4gXCIke3Byb3RvY29sLnNlc3Npb25UaW1lb3V0fVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8aW5pdGlhbE9mZnNldD4gXCIke3Byb3RvY29sLmluaXRpYWxPZmZzZXR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxyZXRyeUJhY2tPZmY+IFwiJHtwcm90b2NvbC5yZXRyeUJhY2tPZmZ9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxmZXRjaE1pbkJ5dGVzPiBcIiR7cHJvdG9jb2wuZmV0Y2hNaW5CeXRlc31cIiAuXG4gICAgICAgICAgICB1aWQodikgPGZldGNoTWF4V2FpdD4gXCIke3Byb3RvY29sLmZldGNoTWF4V2FpdH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNvbW1pdEludGVydmFsPiBcIiR7cHJvdG9jb2wuY29tbWl0SW50ZXJ2YWx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxoZWFydGJlYXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmhlYXJ0YmVhdEludGVydmFsfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bWF4aW11bVFPUz4gXCIke3Byb3RvY29sLm1heGltdW1RT1N9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx1c2VybmFtZT4gXCIke3Byb3RvY29sLnVzZXJuYW1lfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8cGFzc3dvcmQ+IFwiJHtwcm90b2NvbC5wYXNzd29yZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGVuY3J5cHRpb25Nb2RlPiBcIiR7cHJvdG9jb2wuZW5jcnlwdGlvbk1vZGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxjYUNlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2FDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNsaWVudENlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2xpZW50Q2VydGlmaWNhdGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxjbGllbnRLZXk+IFwiJHtwcm90b2NvbC5jbGllbnRLZXl9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxhdXRoTW9kZT4gXCIke3Byb3RvY29sLmF1dGhNb2RlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8c2VydmVyQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5zZXJ2ZXJDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHNjb3BlPiBcIiR7cHJvdG9jb2wuc2NvcGV9XCIgLlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlICR7cHJvdG9jb2wudWlkfWApO1xuXG4gICAgICAgIC8vIFdpdGggdGhlIHVwc2VydCBhcHByb2FjaCwgaXQgaXMgbm90IHBvc3NpYmxlIHRvIHNlZSBpZiB0aGUgbXV0YXRpb24gb2NjdXJyZWQuXG4gICAgICAgIC8vIFVzZSBhIHByZVF1ZXJ5IGZvciB0aGUgb2JqZWN0IGZpcnN0IHRvIGRldGVybWluZSBpZiBpdCBleGlzdHMuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVQcm90b2NvbCcsICdwcm90b2NvbCcsIHByb3RvY29sLnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdGVQcm90b2NvbCcpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBwcm90b2NvbCAke3Byb3RvY29sLnVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gcHJvdG9jb2wpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGRlbGV0ZVByb3RvY29sKGdhdGV3YXlVaWQ6IG51bWJlciwgcHJvdG9jb2xVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ3Byb3RvY29sJywgcHJvdG9jb2xVaWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cHJvdG9jb2xVaWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBQcm90b2NvbCAke3Byb3RvY29sVWlkfSBmb3IgJHtnYXRld2F5VWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICdkZWxldGVQcm90b2NvbCcsICdwcm90b2NvbCcsIHByb3RvY29sVWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZVByb3RvY29sJykpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke3Byb3RvY29sVWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0RGF0YVN0b3JlcyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxEYXRhU3RvcmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhkYXRhU3RvcmUpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoXG4gICAgICAgICAgYWNjb3VudCxcbiAgICAgICl9IEFORCAoZXEoc2NvcGUsIFwiJHtnYXRld2F5TmFtZX1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSkge1xuICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIGRhdGFTdG9yZVR5cGVcbiAgICAgICAgaG9zdCBwb3J0IGRhdGFiYXNlTmFtZSB1c2VyIHBhc3N3b3JkIGFjY291bnROYW1lXG4gICAgICAgIHdhcmVob3VzZSBkYXRhYmFzZSBzY2hlbWEgYXV0aFR5cGUgdXNlcm5hbWVcbiAgICAgICAgY2xpZW50SWQgY2xpZW50U2VjcmV0IGF1dGhvcml6YXRpb25Db2RlXG4gICAgICAgIHJlZGlyZWN0VVJJIGxvZ2luVGltZW91dCB1cmwgc2NvcGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0RGF0YVN0b3JlcycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgRGF0YVN0b3JlW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIGRhdGFTdG9yZXMgZm9yIGdhdGV3YXkgJHtnYXRld2F5TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkRGF0YVN0b3JlKGdhdGV3YXlVaWQ6IG51bWJlciwgZGF0YVN0b3JlOiBEYXRhU3RvcmUsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERhdGFTdG9yZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGlmIChkYXRhU3RvcmUudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86RGF0YVN0b3JlIDxkZ3JhcGgudHlwZT4gXCJEYXRhU3RvcmVcIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx0eXBlPiBcImRhdGFTdG9yZVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFTdG9yZT4gXCJcIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1dWlkPiBcIiR7ZGF0YVN0b3JlLnV1aWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8Y3JlYXRlZD4gXCIke2RhdGFTdG9yZS5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPG1vZGlmaWVkPiBcIiR7ZGF0YVN0b3JlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFTdG9yZVR5cGU+IFwiJHtkYXRhU3RvcmUuZGF0YVN0b3JlVHlwZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxob3N0PiBcIiR7ZGF0YVN0b3JlLmhvc3R9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8cG9ydD4gXCIke2RhdGFTdG9yZS5wb3J0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFiYXNlTmFtZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXNlcj4gXCIke2RhdGFTdG9yZS51c2VyfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHBhc3N3b3JkPiBcIiR7ZGF0YVN0b3JlLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGFjY291bnROYW1lPiBcIiR7ZGF0YVN0b3JlLmFjY291bnROYW1lfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHdhcmVob3VzZT4gXCIke2RhdGFTdG9yZS53YXJlaG91c2V9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YWJhc2U+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHNjaGVtYT4gXCIke2RhdGFTdG9yZS5zY2hlbWF9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8YXV0aFR5cGU+IFwiJHtkYXRhU3RvcmUuYXV0aFR5cGV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXNlcm5hbWU+IFwiJHtkYXRhU3RvcmUudXNlcm5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8Y2xpZW50SWQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50SWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8Y2xpZW50U2VjcmV0PiBcIiR7ZGF0YVN0b3JlLmNsaWVudFNlY3JldH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhdXRob3JpemF0aW9uQ29kZT4gXCIke2RhdGFTdG9yZS5hdXRob3JpemF0aW9uQ29kZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxyZWRpcmVjdFVSST4gXCIke2RhdGFTdG9yZS5yZWRpcmVjdFVSSX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxsb2dpblRpbWVvdXQ+IFwiJHtkYXRhU3RvcmUubG9naW5UaW1lb3V0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHVybD4gXCIke2RhdGFTdG9yZS51cmx9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8c2NvcGU+IFwiJHtkYXRhU3RvcmUuc2NvcGV9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgQWRkZWQgZGF0YXN0b3JlICR7ZGF0YVN0b3JlLnV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2FkZERhdGFTdG9yZScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdEYXRhU3RvcmUnKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZGF0YVN0b3JlLnVpZCA9IGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGRhdGFTdG9yZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGQgZGF0YVN0b3JlcyAke2RhdGFTdG9yZS51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZURhdGFTdG9yZShkYXRhU3RvcmU6IERhdGFTdG9yZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8RGF0YVN0b3JlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ2RhdGFTdG9yZScsIGRhdGFTdG9yZS51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtkYXRhU3RvcmUudWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICAgIHV1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgICAgICB1aWQodikgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHV1aWQ+IFwiJHtkYXRhU3RvcmUudXVpZH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxtb2RpZmllZD4gXCIke2RhdGFTdG9yZS5tb2RpZmllZH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxkYXRhU3RvcmVUeXBlPiBcIiR7ZGF0YVN0b3JlLmRhdGFTdG9yZVR5cGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8aG9zdD4gXCIke2RhdGFTdG9yZS5ob3N0fVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHBvcnQ+IFwiJHtkYXRhU3RvcmUucG9ydH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxkYXRhYmFzZU5hbWU+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVzZXI+IFwiJHtkYXRhU3RvcmUudXNlcn1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxwYXNzd29yZD4gXCIke2RhdGFTdG9yZS5wYXNzd29yZH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxhY2NvdW50TmFtZT4gXCIke2RhdGFTdG9yZS5hY2NvdW50TmFtZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDx3YXJlaG91c2U+IFwiJHtkYXRhU3RvcmUud2FyZWhvdXNlfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGRhdGFiYXNlPiBcIiR7ZGF0YVN0b3JlLmRhdGFiYXNlTmFtZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxzY2hlbWE+IFwiJHtkYXRhU3RvcmUuc2NoZW1hfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGF1dGhUeXBlPiBcIiR7ZGF0YVN0b3JlLmF1dGhUeXBlfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVzZXJuYW1lPiBcIiR7ZGF0YVN0b3JlLnVzZXJuYW1lfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGNsaWVudElkPiBcIiR7ZGF0YVN0b3JlLmNsaWVudElkfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGNsaWVudFNlY3JldD4gXCIke2RhdGFTdG9yZS5jbGllbnRTZWNyZXR9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8YXV0aG9yaXphdGlvbkNvZGU+IFwiJHtkYXRhU3RvcmUuYXV0aG9yaXphdGlvbkNvZGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cmVkaXJlY3RVUkk+IFwiJHtkYXRhU3RvcmUucmVkaXJlY3RVUkl9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8bG9naW5UaW1lb3V0PiBcIiR7ZGF0YVN0b3JlLmxvZ2luVGltZW91dH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDx1cmw+IFwiJHtkYXRhU3RvcmUudXJsfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHNjb3BlPiBcIiR7ZGF0YVN0b3JlLnNjb3BlfVwiIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgZGF0YVN0b3JlICR7ZGF0YVN0b3JlLnVpZH1gKTtcblxuICAgICAgICAvLyBXaXRoIHRoZSB1cHNlcnQgYXBwcm9hY2gsIGl0IGlzIG5vdCBwb3NzaWJsZSB0byBzZWUgaWYgdGhlIG11dGF0aW9uIG9jY3VycmVkLlxuICAgICAgICAvLyBVc2UgYSBwcmVRdWVyeSBmb3IgdGhlIG9iamVjdCBmaXJzdCB0byBkZXRlcm1pbmUgaWYgaXQgZXhpc3RzLlxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlRGF0YVN0b3JlJywgJ2RhdGFTdG9yZScsIGRhdGFTdG9yZS51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlRGF0YVN0b3JlJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIGRhdGFTdG9yZSAke2RhdGFTdG9yZS51aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGRhdGFTdG9yZSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlRGF0YVN0b3JlKGdhdGV3YXlVaWQ6IG51bWJlciwgZGF0YVN0b3JlVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdkYXRhU3RvcmUnLCBkYXRhU3RvcmVVaWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7ZGF0YVN0b3JlVWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBkZWxldGUge1xuICAgICAgICAgICAgICAgIHVpZCh2KSAqICogLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBEZWxldGUgRGF0YVN0b3JlICR7ZGF0YVN0b3JlVWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICdkZWxldGVEYXRhU3RvcmUnLCAnZGF0YVN0b3JlJywgZGF0YVN0b3JlVWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZURhdGFTdG9yZScpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZGVsZXRlZCBkYXRhU3RvcmUgJHtkYXRhU3RvcmVVaWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke2RhdGFTdG9yZVVpZH0gZGVsZXRlZGApLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlBbmRNb2RlbHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICAgIG1vZGVsczogZ2F0ZXdheV9tb2RlbCB7XG4gICAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBuYW1lXG4gICAgICAgICAgZGVzY3JpcHRpb24gaW5wdXRUeXBlIHVybCBzY29wZVxuICAgICAgICAgIGlucHV0VGVtcGxhdGUgaGVhZGVycyBtZXRob2QgYmFzZTY0RW5jb2RlZFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBHZXQgR2F0ZXdheSBhbmQgUHJvdG9jb2xzIGZvciAke2dhdGV3YXlOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRHYXRld2F5QW5kTW9kZWxzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIGdhdGV3YXlzIGFuZCBtb2RlbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldE1vZGVscyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbFtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKG1vZGVsKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KFxuICAgICAgICAgIGFjY291bnQsXG4gICAgICApfSBBTkQgKGVxKHNjb3BlLCBcIiR7Z2F0ZXdheU5hbWV9XCIpIE9SIGVxKHNjb3BlLCBcIkdMT0JBTFwiKSkpIHtcbiAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBuYW1lXG4gICAgICAgIGRlc2NyaXB0aW9uIGlucHV0VHlwZSB1cmwgc2NvcGUgaW5wdXRUZW1wbGF0ZVxuICAgICAgICBoZWFkZXJzIG1ldGhvZCBiYXNlNjRFbmNvZGVkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldE1vZGVscycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgTW9kZWxbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgbW9kZWxzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRNb2RlbChnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsOiBNb2RlbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWw+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAobW9kZWwudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86TW9kZWwgPGRncmFwaC50eXBlPiBcIk1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDx0eXBlPiBcIm1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDxtb2RlbD4gXCJcIiAuXG4gICAgICAgIF86TW9kZWwgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8dXVpZD4gXCIke21vZGVsLnV1aWR9XCIgLlxuICAgICAgICBfOk1vZGVsIDxjcmVhdGVkPiBcIiR7bW9kZWwuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPG1vZGlmaWVkPiBcIiR7bW9kZWwubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOk1vZGVsIDxuYW1lPiBcIiR7bW9kZWwubmFtZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWwuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOk1vZGVsIDxpbnB1dFR5cGU+IFwiJHttb2RlbC5pbnB1dFR5cGV9XCIgLlxuICAgICAgICBfOk1vZGVsIDx1cmw+IFwiJHttb2RlbC51cmx9XCIgLlxuICAgICAgICBfOk1vZGVsIDxzY29wZT4gXCIke21vZGVsLnNjb3BlfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8aW5wdXRUZW1wbGF0ZT4gXCIke21vZGVsLmlucHV0VGVtcGxhdGV9XCIgLlxuICAgICAgICBfOk1vZGVsIDxoZWFkZXJzPiBcIiR7bW9kZWwuaGVhZGVyc31cIiAuXG4gICAgICAgIF86TW9kZWwgPG1ldGhvZD4gXCIke21vZGVsLm1ldGhvZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPGJhc2U2NEVuY29kZWQ+IFwiJHttb2RlbC5iYXNlNjRFbmNvZGVkfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEFkZCBtb2RlbCAke21vZGVsLnV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2FkZE1vZGVsJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ01vZGVsJyk7XG4gICAgICAgICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIG1vZGVsLnVpZCA9IGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IG1vZGVsKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZGVkIG1vZGVsICR7bW9kZWwudWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVNb2RlbChtb2RlbDogTW9kZWwsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPE1vZGVsPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ21vZGVsJywgbW9kZWwudWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke21vZGVsLnVpZH0pKVxuICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgIHVpZCh2KSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx1dWlkPiBcIiR7bW9kZWwudXVpZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPG1vZGlmaWVkPiBcIiR7bW9kZWwubW9kaWZpZWR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxuYW1lPiBcIiR7bW9kZWwubmFtZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWwuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxpbnB1dFR5cGU+IFwiJHttb2RlbC5pbnB1dFR5cGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx1cmw+IFwiJHttb2RlbC51cmx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzY29wZT4gXCIke21vZGVsLnNjb3BlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8aW5wdXRUZW1wbGF0ZT4gXCIke21vZGVsLmlucHV0VGVtcGxhdGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxoZWFkZXJzPiBcIiR7bW9kZWwuaGVhZGVyc31cIiAuXG4gICAgICAgICAgICB1aWQodikgPG1ldGhvZD4gXCIke21vZGVsLm1ldGhvZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGJhc2U2NEVuY29kZWQ+IFwiJHttb2RlbC5iYXNlNjRFbmNvZGVkfVwiIC5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgbW9kZWwgJHttb2RlbC51aWR9YCk7XG5cbiAgICAgICAgLy8gV2l0aCB0aGUgdXBzZXJ0IGFwcHJvYWNoLCBpdCBpcyBub3QgcG9zc2libGUgdG8gc2VlIGlmIHRoZSBtdXRhdGlvbiBvY2N1cnJlZC5cbiAgICAgICAgLy8gVXNlIGEgcHJlUXVlcnkgZm9yIHRoZSBvYmplY3QgZmlyc3QgdG8gZGV0ZXJtaW5lIGlmIGl0IGV4aXN0cy5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ3VwZGF0ZU1vZGVsJywgJ21vZGVsJywgbW9kZWwudWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ3VwZGF0ZU1vZGVsJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIG1vZGVsICR7bW9kZWwudWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBtb2RlbCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlTW9kZWwoZ2F0ZXdheVVpZDogbnVtYmVyLCBtb2RlbFVpZDogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnbW9kZWwnLCBtb2RlbFVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHttb2RlbFVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgZGVsZXRlIHtcbiAgICAgICAgICAgICAgICB1aWQodikgKiAqIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIE1vZGVsICR7bW9kZWxVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZU1vZGVsJywgJ21vZGVsJywgbW9kZWxVaWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlTW9kZWwnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGRlbGV0ZWQgbW9kZWwgJHttb2RlbFVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gYCR7bW9kZWxVaWR9IGRlbGV0ZWRgKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRHYXRld2F5QW5kUGlwZWxpbmVzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3Byb3RvY29sID0gYHByb3RvY29sOiBwaXBlbGluZV9wcm90b2NvbCB7XG4gICAgICAgIHVpZCB1dWlkIGJyb2tlclVSTCB0b3BpYyBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGVcbiAgICAgICAgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5IGF1dGhNb2RlIHNlcnZlckNlcnRpZmljYXRlIGNvbnN1bWVyR3JvdXBJZCBjb25uZWN0aW9uVGltZW91dFxuICAgICAgICBzZXNzaW9uVGltZW91dCByZXRyeUJhY2tPZmYgY29tbWl0SW50ZXJ2YWwgaW5pdGlhbE9mZnNldCBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdCBoZWFydGJlYXRJbnRlcnZhbFxuICAgICAgfWA7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2RhdGFzdG9yZSA9IGBkYXRhU3RvcmU6IHBpcGVsaW5lX2RhdGFzdG9yZSB7XG4gICAgICAgIHVpZCB1dWlkIGhvc3QgcG9ydCBkYXRhYmFzZU5hbWUgdXNlciBwYXNzd29yZCBhY2NvdW50TmFtZSB3YXJlaG91c2UgZGF0YWJhc2Ugc2NoZW1hIGF1dGhUeXBlXG4gICAgICAgIHVzZXJuYW1lIGNsaWVudElkIGNsaWVudFNlY3JldCBhdXRob3JpemF0aW9uQ29kZSByZWRpcmVjdFVSSSBsb2dpblRpbWVvdXQgdXJsXG4gICAgICB9YDtcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZmlsdGVyID0gJ2ZpbHRlcjogcGlwZWxpbmVfZmlsdGVyIHsgdWlkIGRldmljZU5hbWVzIH0nO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9zdHJlYW1pbmcgPVxuICAgICAgICAgICAgJ3N0cmVhbWluZzogcGlwZWxpbmVfc3RyZWFtaW5nIHsgdWlkIGRldmljZU5hbWUgaW5zdHJ1bWVudE5hbWUgZnVuY3Rpb24gd2luZG93VHlwZSB3aW5kb3dTaXplIH0nO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkIGFjY2Vzc1Rva2VuIHVzZXJuYW1lIHBsYXRmb3JtIGFkZHJlc3Mgcm91dGVyIHJvdXRlclBvcnQgZGVwbG95TmV0d29yayBkZXZpY2VzTWV0YWRhdGFcbiAgICAgICAgcGlwZWxpbmVzOiBnYXRld2F5X3BpcGVsaW5lIHtcbiAgICAgICAgICB1aWQgbmFtZSB1dWlkIHBpcGVsaW5lVHlwZSBkZXBsb3llclR5cGUgcHJvdG9jb2xUeXBlIHByb3RvY29sSWQgZGF0YVN0b3JlVHlwZVxuICAgICAgICAgIGRhdGFTdG9yZUlkIGNyZWF0ZWQgbW9kaWZpZWQgZGVzY3JpcHRpb24gc3RhdHVzIGZsb3dDb25maWd1cmF0aW9uXG4gICAgICAgICAgbG9nTGV2ZWwgc3Vic2NyaXB0aW9uVG9waWNcbiAgICAgICAgICAke3BpcGVsaW5lX3Byb3RvY29sfVxuICAgICAgICAgICR7cGlwZWxpbmVfZGF0YXN0b3JlfVxuICAgICAgICAgICR7cGlwZWxpbmVfZmlsdGVyfVxuICAgICAgICAgICR7cGlwZWxpbmVfc3RyZWFtaW5nfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBHZXQgR2F0ZXdheSBhbmQgUGlwZWxpbmVzIGZvciAke2dhdGV3YXlOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRHYXRld2F5V2l0aFBpcGVsaW5lcycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBHYXRld2F5IGFuZCBwaXBlbGluZXMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFBpcGVsaW5lcyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcGlwZWxpbmVfcHJvdG9jb2wgPSBgcHJvdG9jb2w6IHBpcGVsaW5lX3Byb3RvY29sIHtcbiAgICAgICAgICAgICAgdWlkIGJyb2tlclVSTCB0b3BpYyBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGVcbiAgICAgICAgICAgICAgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5IGF1dGhNb2RlIHNlcnZlckNlcnRpZmljYXRlIGNvbnN1bWVyR3JvdXBJZCBjb25uZWN0aW9uVGltZW91dFxuICAgICAgICAgICAgICBzZXNzaW9uVGltZW91dCByZXRyeUJhY2tPZmYgY29tbWl0SW50ZXJ2YWwgaW5pdGlhbE9mZnNldCBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdCBoZWFydGJlYXRJbnRlcnZhbFxuICB9IGA7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2RhdGFzdG9yZSA9IGBkYXRhc3RvcmU6IHBpcGVsaW5lX2RhdGFzdG9yZSB7XG4gICAgICAgICAgICAgIHVpZCBob3N0IHBvcnQgZGF0YWJhc2VOYW1lIHVzZXIgcGFzc3dvcmQgYWNjb3VudE5hbWUgd2FyZWhvdXNlIGRhdGFiYXNlIHNjaGVtYSBhdXRoVHlwZVxuICAgICAgICAgICAgICB1c2VybmFtZSBjbGllbnRJZCBjbGllbnRTZWNyZXQgYXV0aG9yaXphdGlvbkNvZGUgcmVkaXJlY3RVUkkgbG9naW5UaW1lb3V0IHVybFxuICAgICAgICAgICAgfWA7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2ZpbHRlciA9ICdmaWx0ZXI6IHBpcGVsaW5lX2ZpbHRlciB7dWlkIGRldmljZU5hbWVzfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3N0cmVhbWluZyA9XG4gICAgICAgICAgICAnc3RyZWFtaW5nOiBwaXBlbGluZV9zdHJlYW1pbmcge3VpZCBkZXZpY2VOYW1lIGluc3RydW1lbnROYW1lIGZ1bmN0aW9uIHdpbmRvd1R5cGUgd2luZG93U2l6ZX0nO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgcGlwZWxpbmVzIGFzIGdhdGV3YXlfcGlwZWxpbmUge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZCBuYW1lIHV1aWQgcGlwZWxpbmVUeXBlIGRlcGxveWVyVHlwZSBwcm90b2NvbFR5cGUgcHJvdG9jb2xJZFxuICAgICAgICBkYXRhU3RvcmVUeXBlIGRhdGFTdG9yZUlkIGNyZWF0ZWQgbW9kaWZpZWQgZGVzY3JpcHRpb24gc3RhdHVzXG4gICAgICAgIGZsb3dDb25maWd1cmF0aW9uIGxvZ0xldmVsIHN1YnNjcmlwdGlvblRvcGljXG4gICAgICAgICR7cGlwZWxpbmVfcHJvdG9jb2x9XG4gICAgICAgICR7cGlwZWxpbmVfZGF0YXN0b3JlfVxuICAgICAgICAke3BpcGVsaW5lX2ZpbHRlcn1cbiAgICAgICAgJHtwaXBlbGluZV9zdHJlYW1pbmd9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFBpcGVsaW5lcycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUGlwZWxpbmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcGlwZWxpbmVzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRQaXBlbGluZShcbiAgICAgICAgZ2F0ZXdheVVpZDogbnVtYmVyLFxuICAgICAgICBwaXBlbGluZTogUGlwZWxpbmUsXG4gICAgICAgIHRyYW5zcG9ydE9iaj86IGFueSxcbiAgICAgICAgZGF0YVN0b3JlT2JqPzogYW55LFxuICAgICAgICBmaWx0ZXJPYmo/OiBhbnksXG4gICAgICAgIHN0cmVhbWluZ09iaj86IGFueSxcbiAgICAgICAgYWNjb3VudD86IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPFBpcGVsaW5lPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKHBpcGVsaW5lLnVpZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgYWRkIHdpdGggYW4gSUQnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICBfOlBpcGVsaW5lIDxkZ3JhcGgudHlwZT4gXCJQaXBlbGluZVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxuYW1lPiBcIiR7cGlwZWxpbmUubmFtZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHV1aWQ+IFwiJHtwaXBlbGluZS5uYW1lfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8dHlwZT4gXCJwaXBlbGluZVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8cGlwZWxpbmU+IFwiXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxwaXBlbGluZVR5cGU+IFwiJHtwaXBlbGluZS5waXBlbGluZVR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXBsb3llclR5cGU+IFwiJHtwaXBlbGluZS5kZXBsb3llclR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxjcmVhdGVkPiBcIiR7cGlwZWxpbmUuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXNjcmlwdGlvbj4gXCIke3BpcGVsaW5lLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8c3RhdHVzPiBcIiR7cGlwZWxpbmUuc3RhdHVzfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGxvZ0xldmVsPiBcIiR7cGlwZWxpbmUubG9nTGV2ZWx9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxzdWJzY3JpcHRpb25Ub3BpYz4gXCIke3BpcGVsaW5lLnN1YnNjcmlwdGlvblRvcGljfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X3BpcGVsaW5lPiBfOlBpcGVsaW5lIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYGFkZCBQaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkUGlwZWxpbmUnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkID0gdGhpcy5nZXRJREZyb21SZXNwb25zZShyZXNwb25zZS5kYXRhLCAnUGlwZWxpbmUnKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcGlwZWxpbmUudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gcGlwZWxpbmUpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgYWRkZWQgcGlwZWxpbmUgJHtwaXBlbGluZS51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZVBpcGVsaW5lKHBpcGVsaW5lOiBQaXBlbGluZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmU+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncGlwZWxpbmUnLCBwaXBlbGluZS51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cGlwZWxpbmUudWlkfSkpXG4gICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICBzZXQge1xuICAgICAgICAgICAgdWlkKHYpIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICB1aWQodikgPGRlc2NyaXB0aW9uPiBcIiR7cGlwZWxpbmUuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzdGF0dXM+IFwiJHtwaXBlbGluZS5zdGF0dXN9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxtb2RpZmllZD4gXCIke3BpcGVsaW5lLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGxvZ0xldmVsPiBcIiR7cGlwZWxpbmUubG9nTGV2ZWx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzdWJzY3JpcHRpb25Ub3BpYz4gXCIke3BpcGVsaW5lLnN1YnNjcmlwdGlvblRvcGljfVwiIC5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgdXBkYXRlIFBpcGVsaW5lICR7cGlwZWxpbmUudWlkfWApO1xuXG4gICAgICAgIC8vIFdpdGggdGhlIHVwc2VydCBhcHByb2FjaCwgaXQgaXMgbm90IHBvc3NpYmxlIHRvIHNlZSBpZiB0aGUgbXV0YXRpb24gb2NjdXJyZWQuXG4gICAgICAgIC8vIFVzZSBhIHByZVF1ZXJ5IGZvciB0aGUgb2JqZWN0IGZpcnN0IHRvIGRldGVybWluZSBpZiBpdCBleGlzdHMuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVQaXBlbGluZScsICdwaXBlbGluZScsIHBpcGVsaW5lLnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdGVQaXBlbGluZScpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBwaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gcGlwZWxpbmUpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGRlbGV0ZVBpcGVsaW5lKGdhdGV3YXlVaWQ6IG51bWJlciwgcGlwZWxpbmU6IFBpcGVsaW5lLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncGlwZWxpbmUnLCBwaXBlbGluZS51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cGlwZWxpbmUudWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBkZWxldGUge1xuICAgICAgICAgICAgICAgIHVpZCh2KSAqICogLlxuICAgICAgICAgICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9waXBlbGluZT4gPCR7cGlwZWxpbmUudWlkfT4gLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBkZWxldGUgUGlwZWxpbmUgJHtwaXBlbGluZS51aWR9IHdpdGggZ2F0ZXdheSAke2dhdGV3YXlVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZVBpcGVsaW5lJywgJ3BpcGVsaW5lJywgcGlwZWxpbmUudWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZVBpcGVsaW5lJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIHBpcGVsaW5lICR7cGlwZWxpbmUudWlkfSB3aXRoIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgcGlwZWxpbmUgZGVsZXRlZGApLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBpZHMgb2YgYWxsIHRoZSBwaXBlbGluZXMgYXNzb2NpYXRlZCB3aXRoIHRoZSBzcGVjaWZpZWQgcHJvdG9jb2xcbiAgICAgKiBAcGFyYW0gcHJvdG9jb2xVaWQgLSB0aGUgdWlkIG9mIHRoZSBwcm90b2NvbFxuICAgICAqL1xuICAgIGdldFBpcGVsaW5lSWRzRnJvbVByb3RvY29sVWlkKHByb3RvY29sVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFBpcGVsaW5lW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogdWlkKCR7cHJvdG9jb2xVaWR9KSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICBwaXBlbGluZXMgYXMgfnBpcGVsaW5lX3Byb3RvY29sIHtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFBpcGVsaW5lSWRzRnJvbVByb3RvY29sVWlkJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBQaXBlbGluZVtdO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbXSBhcyBQaXBlbGluZVtdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHBpcGVsaW5lIGlkcycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgaWRzIG9mIGFsbCB0aGUgcGlwZWxpbmVzIGFzc29jaWF0ZWQgd2l0aCB0aGUgc3BlY2lmaWVkIGRhdGEgc3RvcmVcbiAgICAgKiBAcGFyYW0gZGF0YVN0b3JlVWlkIC0gdGhlIHVpZCBvZiB0aGUgZGF0YSBzdG9yZVxuICAgICAqL1xuICAgIGdldFBpcGVsaW5lSWRzRnJvbURhdGFTdG9yZVVpZChkYXRhU3RvcmVVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiB1aWQoJHtkYXRhU3RvcmVVaWR9KSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICBwaXBlbGluZXMgYXMgfnBpcGVsaW5lX2RhdGFzdG9yZSB7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmVzcChmdW5jOiB1aWQocGlwZWxpbmVzKSkge1xuICAgICAgICB1aWQgdXVpZFxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRQaXBlbGluZUlkc0Zyb21EYXRhU3RvcmVVaWQnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIFBpcGVsaW5lW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFBpcGVsaW5lW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcGlwZWxpbmUgaWRzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldE1vZGVsQ29uZmlncyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbENvbmZpZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgbW9kZWxDb25maWdzIGFzIGdhdGV3YXlfbW9kZWxjb25maWcge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChtb2RlbENvbmZpZ3MpKSB7XG4gICAgICAgIHVpZCBuYW1lIHV1aWQgZGVzY3JpcHRpb24gZGV2aWNlIHJlc291cmNlIG1vZGVsIGNyZWF0ZWQgIG1vZGlmaWVkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldE1vZGVsQ29uZmlncyBmb3IgJHtnYXRld2F5TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0TW9kZWxDb25maWdzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBNb2RlbENvbmZpZ1tdO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbXSBhcyBNb2RlbENvbmZpZ1tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIG1vZGVsQ29uZmlncyBmb3IgJHtnYXRld2F5TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkTW9kZWxDb25maWcoZ2F0ZXdheVVpZDogbnVtYmVyLCBtb2RlbENvbmZpZzogTW9kZWxDb25maWcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPE1vZGVsQ29uZmlnPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKG1vZGVsQ29uZmlnLnVpZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgYWRkIHdpdGggYW4gSUQnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICBfOk1vZGVsQ29uZmlnIDxkZ3JhcGgudHlwZT4gXCJNb2RlbENvbmZpZ1wiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxuYW1lPiBcIiR7bW9kZWxDb25maWcubmFtZX1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPHV1aWQ+IFwiJHttb2RlbENvbmZpZy5uYW1lfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8dHlwZT4gXCJtb2RlbENvbmZpZ1wiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8bW9kZWxDb25maWc+IFwiXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxkZXNjcmlwdGlvbj4gXCIke21vZGVsQ29uZmlnLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8ZGV2aWNlPiBcIiR7bW9kZWxDb25maWcuZGV2aWNlfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8cmVzb3VyY2U+IFwiJHttb2RlbENvbmZpZy5yZXNvdXJjZX1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPG1vZGVsPiBcIiR7bW9kZWxDb25maWcubW9kZWx9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxjcmVhdGVkPiBcIiR7bW9kZWxDb25maWcuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPG1vZGlmaWVkPiBcIiR7bW9kZWxDb25maWcubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfbW9kZWxjb25maWc+IF86TW9kZWxDb25maWcgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgQWRkIG1vZGVsQ29uZmlnIGZvciBnYXRld2F5ICR7Z2F0ZXdheVVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkTW9kZWxDb25maWcnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkID0gdGhpcy5nZXRJREZyb21SZXNwb25zZShyZXNwb25zZS5kYXRhLCAnTW9kZWxDb25maWcnKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgbW9kZWxDb25maWcudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gbW9kZWxDb25maWcpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgYWRkIG1vZGVsQ29uZmlnIGZvciBnYXRld2F5ICR7Z2F0ZXdheVVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlTW9kZWxDb25maWcobW9kZWxDb25maWc6IE1vZGVsQ29uZmlnLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbENvbmZpZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdtb2RlbENvbmZpZycsIG1vZGVsQ29uZmlnLnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICB1cHNlcnQge1xuICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7bW9kZWxDb25maWcudWlkfSkpXG4gICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICBzZXQge1xuICAgICAgICAgICAgdWlkKHYpIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICB1aWQodikgPG5hbWU+IFwiJHttb2RlbENvbmZpZy5uYW1lfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8dXVpZD4gXCIke21vZGVsQ29uZmlnLnV1aWR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxkZXNjcmlwdGlvbj4gXCIke21vZGVsQ29uZmlnLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y29uZERldmljZT4gXCIke21vZGVsQ29uZmlnLmRldmljZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNvbmRSZXNvdXJjZT4gXCIke21vZGVsQ29uZmlnLnJlc291cmNlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bW9kZWw+IFwiJHttb2RlbENvbmZpZy5tb2RlbH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPG1vZGlmaWVkPiBcIiR7bW9kZWxDb25maWcubW9kaWZpZWR9XCIgLlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgbW9kZWxDb25maWcgJHttb2RlbENvbmZpZy51aWR9YCk7XG5cbiAgICAgICAgLy8gV2l0aCB0aGUgdXBzZXJ0IGFwcHJvYWNoLCBpdCBpcyBub3QgcG9zc2libGUgdG8gc2VlIGlmIHRoZSBtdXRhdGlvbiBvY2N1cnJlZC5cbiAgICAgICAgLy8gVXNlIGEgcHJlUXVlcnkgZm9yIHRoZSBvYmplY3QgZmlyc3QgdG8gZGV0ZXJtaW5lIGlmIGl0IGV4aXN0cy5cblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlTW9kZWxDb25maWcnLCAnbW9kZWxDb25maWcnLCBtb2RlbENvbmZpZy51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXR1cGRhdGVNb2RlbENvbmZpZ2VNb2RlbCcpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCAgbW9kZWxDb25maWcgJHttb2RlbENvbmZpZy51aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IG1vZGVsQ29uZmlnKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVNb2RlbENvbmZpZyhnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsQ29uZmlnVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdtb2RlbENvbmZpZycsIG1vZGVsQ29uZmlnVWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke21vZGVsQ29uZmlnVWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBkZWxldGUge1xuICAgICAgICAgICAgICAgIHVpZCh2KSAqICogLlxuICAgICAgICAgICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9tb2RlbGNvbmZpZz4gPCR7bW9kZWxDb25maWdVaWR9PiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBNb2RlbENvbmZpZyAke21vZGVsQ29uZmlnVWlkfSBmb3IgZ2F0ZXdheSAke2dhdGV3YXlVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZU1vZGVsQ29uZmlnJywgJ21vZGVsQ29uZmlnJywgbW9kZWxDb25maWdVaWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlTW9kZWxDb25maWcnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGRlbGV0ZWQgbW9kZWxDb25maWcgJHttb2RlbENvbmZpZ1VpZH0gZm9yIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgJHttb2RlbENvbmZpZ1VpZH0gZGVsZXRlZGApLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEZpbHRlcnNDb25maWcoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheUZpbHRlcnNDb25maWdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIGZpbHRlcnNDb25maWcgYXMgZ2F0ZXdheV9maWx0ZXIge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChmaWx0ZXJzQ29uZmlnKSkge1xuICAgICAgICB1aWRcbiAgICAgICAgZGV2aWNlTmFtZXNcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgZ2V0RmlsdGVyc0NvbmZpZyBmb3IgJHtnYXRld2F5TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0RmlsdGVyc0NvbmZpZ3MnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIEdhdGV3YXlGaWx0ZXJzQ29uZmlnW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIEdhdGV3YXlGaWx0ZXJzQ29uZmlnW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgZmlsdGVyc0NvbmZpZyBmb3IgJHtnYXRld2F5TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkRmlsdGVyc0NvbmZpZyhcbiAgICAgICAgZ2F0ZXdheVVpZDogbnVtYmVyLFxuICAgICAgICBmaWx0ZXJzQ29uZmlnOiBHYXRld2F5RmlsdGVyc0NvbmZpZyxcbiAgICAgICAgYWNjb3VudD86IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPEdhdGV3YXlGaWx0ZXJzQ29uZmlnPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKGZpbHRlcnNDb25maWcudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86RmlsdGVyIDxkZ3JhcGgudHlwZT4gXCJmaWx0ZXJcIiAuXG4gICAgICAgIF86RmlsdGVyIDx0eXBlPiBcImZpbHRlclwiIC5cbiAgICAgICAgXzpGaWx0ZXIgPGZpbHRlcj4gXCJcIiAuXG4gICAgICAgIF86RmlsdGVyIDxkZXZpY2VOYW1lcz4gXCIke2ZpbHRlcnNDb25maWcuZGV2aWNlTmFtZXN9XCIgLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfZmlsdGVyPiBfOkZpbHRlciAuXG4gICAgICAgIDwke2FjY291bnR9PiA8YWNjb3VudD4gXzpGaWx0ZXIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgYWRkIEZpbHRlcnNDb25maWcgZm9yIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRGaWx0ZXJzQ29uZmlnJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ01vZGVsJyk7XG4gICAgICAgICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIGZpbHRlcnNDb25maWcudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gZmlsdGVyc0NvbmZpZykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGRlZCBmaWx0ZXJzQ29uZmlnIGZvciBnYXRld2F5ICR7Z2F0ZXdheVVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlRmlsdGVyc0NvbmZpZyhmaWx0ZXJzQ29uZmlnOiBHYXRld2F5RmlsdGVyc0NvbmZpZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheUZpbHRlcnNDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnZmlsdGVyQ29uZmlnJywgZmlsdGVyc0NvbmZpZy51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7ZmlsdGVyc0NvbmZpZy51aWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIHNldCB7XG4gICAgICAgICAgICAgICAgdWlkKHYpIDxkZXZpY2VOYW1lcz4gXCIke2ZpbHRlcnNDb25maWcuZGV2aWNlTmFtZXN9XCIgLlxuICAgICAgICAgICAgICAgIDwke2FjY291bnR9PiA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGB1cGRhdGUgRmlsdGVyc0NvbmZpZyAke2ZpbHRlcnNDb25maWcudWlkfWApO1xuXG4gICAgICAgIC8vIFdpdGggdGhlIHVwc2VydCBhcHByb2FjaCwgaXQgaXMgbm90IHBvc3NpYmxlIHRvIHNlZSBpZiB0aGUgbXV0YXRpb24gb2NjdXJyZWQuXG4gICAgICAgIC8vIFVzZSBhIHByZVF1ZXJ5IGZvciB0aGUgb2JqZWN0IGZpcnN0IHRvIGRldGVybWluZSBpZiBpdCBleGlzdHMuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVGaWx0ZXJzQ29uZmlnJywgJ2ZpbHRlcicsIGZpbHRlcnNDb25maWcudWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ3VwZGF0ZUZpbHRlcnNDb25maWcnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZmlsdGVyQ29uZmlnICR7ZmlsdGVyc0NvbmZpZy51aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGZpbHRlcnNDb25maWcpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBQeXRob24gUmVzb3VyY2VzLlxuICAgICAqIEBwYXJhbSBnYXRld2F5VWlkXG4gICAgICovXG4gICAgZ2V0UHl0aG9uUmVzb3VyY2VzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFB5dGhvblJlc291cmNlW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgIHtcbiAgICAgIHJlc3AoZnVuYzogdHlwZShQeXRob25SZXNvdXJjZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShcbiAgICAgICAgICBhY2NvdW50LFxuICAgICAgKX0gQU5EKGVxKHNjb3BlLCBcIiR7Z2F0ZXdheU5hbWV9XCIpIE9SIGVxKHNjb3BlLCBcIkdMT0JBTFwiKSkpIHtcbiAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBuYW1lIHR5cGUgc2NvcGUgZmlsZUNvbnRlbnQgaW5wdXRzIG91dHB1dHNcbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYGdldCBweXRob24gcmVzb3VyY2UgZnJvbSAke2dhdGV3YXlOYW1lfWApO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UHl0aG9uUmVzb3VyY2UnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFB5dGhvblJlc291cmNlW10pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZSBQeXRob24gUmVzb3VyY2UuXG4gICAgICogQHBhcmFtIFB5dGhvblJlc291cmNlXG4gICAgICovXG4gICAgdXBkYXRlUHl0aG9uUmVzb3VyY2UocHl0aG9uUmVzb3VyY2U6IFB5dGhvblJlc291cmNlLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQeXRob25SZXNvdXJjZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdweXRob25SZXNvdXJjZScsIHB5dGhvblJlc291cmNlLnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cHl0aG9uUmVzb3VyY2UudWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBzZXQge1xuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPG1vZGlmaWVkPiBcIiR7cHl0aG9uUmVzb3VyY2UubW9kaWZpZWR9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxuYW1lPiBcIiR7cHl0aG9uUmVzb3VyY2UubmFtZX1cIiAuXG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPHNjb3BlPiBcIiR7cHl0aG9uUmVzb3VyY2Uuc2NvcGV9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDx0eXBlPiBcIiR7cHl0aG9uUmVzb3VyY2UudHlwZX1cIiAuXG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPGZpbGVDb250ZW50PiBcIiR7cHl0aG9uUmVzb3VyY2UuZmlsZUNvbnRlbnR9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxpbnB1dHM+IFwiJHtweXRob25SZXNvdXJjZS5pbnB1dHN9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxvdXRwdXRzPiBcIiR7cHl0aG9uUmVzb3VyY2Uub3V0cHV0c31cIiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSBQeXRob25SZXNvdXJjZSAke3B5dGhvblJlc291cmNlLnVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlUHl0aG9uUmVzb3VyY2UnLCAncHl0aG9uUmVzb3VyY2UnLCBweXRob25SZXNvdXJjZS51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlUHl0aG9uUmVzb3VyY2UnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZmlsdGVyQ29uZmlnICR7cHl0aG9uUmVzb3VyY2UudWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBweXRob25SZXNvdXJjZSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWRkIFB5dGhvbiBSZXNvdXJjZS5cbiAgICAgKiBAcGFyYW0gUHl0aG9uUmVzb3VyY2VcbiAgICAgKi9cbiAgICBhZGRQeXRob25SZXNvdXJjZShweXRob25SZXNvdXJjZTogUHl0aG9uUmVzb3VyY2UsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFB5dGhvblJlc291cmNlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKHB5dGhvblJlc291cmNlLnVpZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgYWRkIHdpdGggYW4gSUQnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgIHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPGRncmFwaC50eXBlPiBcIlB5dGhvblJlc291cmNlXCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxweXRob25SZXNvdXJjZT4gXCJcIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPHR5cGU+IFwicHl0aG9uUmVzb3VyY2VcIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8bmFtZT4gXCIke3B5dGhvblJlc291cmNlLm5hbWV9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxjcmVhdGVkPiBcIiR7cHl0aG9uUmVzb3VyY2UuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPG1vZGlmaWVkPiBcIiR7cHl0aG9uUmVzb3VyY2UubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDx0eXBlPiBcIiR7cHl0aG9uUmVzb3VyY2UudHlwZX1cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPGZpbGVDb250ZW50PiBcIiR7cHl0aG9uUmVzb3VyY2UuZmlsZUNvbnRlbnR9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxzY29wZT4gXCIke3B5dGhvblJlc291cmNlLnNjb3BlfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8aW5wdXRzPiBcIiR7cHl0aG9uUmVzb3VyY2UuaW5wdXRzfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8b3V0cHV0cz4gXCIke3B5dGhvblJlc291cmNlLm91dHB1dHN9XCIgLlxuICAgICAgfX1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgUHl0aG9uUmVzb3VyY2UgJHtweXRob25SZXNvdXJjZS5uYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRQeXRob25SZXNvdXJjZScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdQeXRob25SZXNvdXJjZScpO1xuICAgICAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgICAgICBweXRob25SZXNvdXJjZS51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBweXRob25SZXNvdXJjZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGQgcHl0aG9uUmVzb3VyY2UgJHtweXRob25SZXNvdXJjZS51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERlbGV0ZSBQeXRob24gUmVzb3VyY2UuXG4gICAgICogQHBhcmFtIHJlc291cmNlVWlkXG4gICAgICovXG4gICAgZGVsZXRlUHl0aG9uUmVzb3VyY2UocHl0aG9uUmVzb3VyY2VVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ3B5dGhvblJlc291cmNlJywgcHl0aG9uUmVzb3VyY2VVaWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cHl0aG9uUmVzb3VyY2VVaWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYCR7cHl0aG9uUmVzb3VyY2VVaWR9IGlzIGJlaW5nIGRlbGV0ZWRgKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZVB5dGhvblJlc291cmNlJywgJ3B5dGhvblJlc291cmNlJywgcHl0aG9uUmVzb3VyY2VVaWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlUHl0aG9uUmVzb3VyY2UnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZmlsdGVyQ29uZmlnICR7cHl0aG9uUmVzb3VyY2VVaWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke3B5dGhvblJlc291cmNlVWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3MoZGV2aWNlTmFtZTogc3RyaW5nLCBpbnN0cnVtZW50TmFtZTogc3RyaW5nLCBudW1SZWFkaW5nczogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LSR7bnVtUmVhZGluZ3N9KSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldFJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRSZWFkaW5ncycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnJlc3ApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LnJlc3AgYXMgVFNSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFRTUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gY29uc29sZS5sb2coJ1Jlc3BvbnNlIGZyb20gZ2V0UmVhZGluZ3M6ICcsIHJlc3BvbnNlKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcmVhZGluZ3MgZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFJlYWRpbmdzQXQoZGV2aWNlTmFtZTogc3RyaW5nLCBpbnN0cnVtZW50TmFtZTogc3RyaW5nLCB0czogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGVxKGNyZWF0ZWQsICR7dHN9KSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRSZWFkaW5nc0F0IGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRSZWFkaW5nc0F0Jyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBUU1JlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgVFNSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcmVhZGluZ3MgZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFJlYWRpbmdzU3RhcnRpbmdBdChcbiAgICAgICAgZGV2aWNlTmFtZTogc3RyaW5nLFxuICAgICAgICBpbnN0cnVtZW50TmFtZTogc3RyaW5nLFxuICAgICAgICBmcm9tdHM6IG51bWJlcixcbiAgICAgICAgYWNjb3VudD86IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPFRTUmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhyZXNvdXJjZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRSZWFkaW5nc1N0YXJ0aW5nQXQgZm9yIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRSZWFkaW5nc1N0YXJ0aW5nQXQnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIFRTUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbXSBhcyBUU1JlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBzdGFydGVkIGF0IHJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc0JldHdlZW4oXG4gICAgICAgIGRldmljZU5hbWU6IHN0cmluZyxcbiAgICAgICAgaW5zdHJ1bWVudE5hbWU6IHN0cmluZyxcbiAgICAgICAgZnJvbXRzOiBudW1iZXIsXG4gICAgICAgIHRvdHM6IG51bWJlcixcbiAgICAgICAgYWNjb3VudD86IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPFRTUmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhyZXNvdXJjZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSBBTkQgbHQoY3JlYXRlZCwgJHt0b3RzfSkpIChmaXJzdDotNTAwKSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldFJlYWRpbmdzQmV0d2VlbiBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UmVhZGluZ3NCZXR3ZWVuJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBUU1JlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgVFNSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcmVhZGluZ3MgYmV0d2VlbiBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0TGFzdFJlYWRpbmdzRm9yRGV2aWNlKGRldmljZU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8VFNSZWFkaW5nW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhkZXZpY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1cIikpIEBub3JtYWxpemUge1xuICAgICAgICBkZXZpY2VfcmVzb3VyY2Uge1xuICAgICAgICAgIG5hbWU6IG5hbWVcbiAgICAgICAgICByZXNvdXJjZV9yZWFkaW5nIChmaXJzdDotMSkge1xuICAgICAgICAgICAgY3JlYXRlZDogY3JlYXRlZFxuICAgICAgICAgICAgdmFsdWU6IHZhbHVlXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldExhc3RSZWFkaW5nc0ZvckRldmljZSBmb3IgJHtkZXZpY2VOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRMYXN0UmVhZGluZ3NGb3JEZXZpY2UnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIFRTUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbXSBhcyBUU1JlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBsYXN0IHJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldE5vdGlmaWNhdGlvbnMoYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8Tm90aWZpY2F0aW9uW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc29sZS5sb2coJ0dldE5vdGlmaWNhdGlvbnMgc2VydmljZSBjYWxsZWQnKTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMobm90aWZpY2F0aW9uKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkgQG5vcm1hbGl6ZSB7XG4gICAgICAgIHVpZCB1dWlkOnV1aWQgY3JlYXRlZDpjcmVhdGVkIG5vdGlmeVNvdXJjZTpub3RpZnlTb3VyY2Ugbm90aWZ5RGV2aWNlOm5vdGlmeURldmljZVxuICAgICAgICBub3RpZnlSZXNvdXJjZTpub3RpZnlSZXNvdXJjZSBub3RpZnlMZXZlbDpub3RpZnlMZXZlbCB2YWx1ZTp2YWx1ZSBkZXNjcmlwdGlvbjpkZXNjcmlwdGlvblxuICAgICAgICB+Z2F0ZXdheV9ub3RpZmljYXRpb24ge1xuICAgICAgICAgIGdhdGV3YXk6IHV1aWRcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXROb3RpZmljYXRpb25zJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBOb3RpZmljYXRpb25bXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgTm90aWZpY2F0aW9uW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgbm90aWZpY2F0aW9uc2ApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSb3V0ZShkZXZpY2VOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBudW1iZXJbXVtdIHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgbGV0IHJvdXRlID0gbnVsbDtcblxuICAgICAgICBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMScpIHtcbiAgICAgICAgICAgIHJvdXRlID0gcm91dGUxO1xuICAgICAgICB9IGVsc2UgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDInKSB7XG4gICAgICAgICAgICByb3V0ZSA9IHJvdXRlMjtcbiAgICAgICAgfSBlbHNlIGlmIChkZXZpY2VOYW1lID09ICd0cmFpbi0wMDAzJykge1xuICAgICAgICAgICAgcm91dGUgPSByb3V0ZTM7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByb3V0ZSA9IGVtcHR5Um91dGU7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcm91dGU7XG4gICAgfVxuXG4gICAgZ2V0Um91dGVDZW50ZXIoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogbnVtYmVyW10ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBsZXQgY2VudGVyID0gbnVsbDtcblxuICAgICAgICAvLyAzOS4wIC05OC4wIHpvb20gNFxuICAgICAgICAvLyBFYXN0IDM0Ljc2NTU4OSAgIC03OC43MDk0ODhcbiAgICAgICAgLy8gV2VzdCA0MC40ODc0MzIgLTEyMi44MDMxMTZcblxuICAgICAgICBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMScpIHtcbiAgICAgICAgICAgIGNlbnRlciA9IFszNC4wLCAtOTguMF07XG4gICAgICAgIH0gZWxzZSBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMicpIHtcbiAgICAgICAgICAgIGNlbnRlciA9IFs0MC4wLCAtOTguMF07XG4gICAgICAgIH0gZWxzZSBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMycpIHtcbiAgICAgICAgICAgIGNlbnRlciA9IFszOS4wLCAtOTguMF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbNDIuOCwgMTIuOF07XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gY2VudGVyO1xuICAgIH1cblxuICAgIHByaXZhdGUgZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudD86IHN0cmluZykge1xuICAgICAgICBpZiAodGhpcy5yZXF1aXJlQWNjb3VudElkKSB7XG4gICAgICAgICAgICBpZiAoIWFjY291bnQpIHRocm93IG5ldyBFcnJvcignQWNjb3VudCBtdXN0IGV4aXN0Jyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIGdldEFjY291bnRRdWVyeShhY2NvdW50Pzogc3RyaW5nKSB7XG4gICAgICAgIGlmICh0aGlzLnJlcXVpcmVBY2NvdW50SWQpIHtcbiAgICAgICAgICAgIHJldHVybiBgZXEoYWNjb3VudCwgXCIke2FjY291bnR9XCIpYDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBgKGVxKGFjY291bnQsIFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiKSBPUiBub3QoaGFzKGFjY291bnQpKSlgO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGlzY292ZXJzIHRoZSBwcmVzZW5jZSBvZiBlcnJvcnMgaW4gdGhlIHJlc3BvbnNlIGZyb20gZEdyYXBoIGFuZCByZXBvcnRzIHRoZW0uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gcmVzcG9uc2UgdGhlIHJlc3BvbnNlIG9iamVjdCBmcm9tIGRHcmFwaFxuICAgICAqIEBwYXJhbSBvcGVyYXRpb24gdGhlIG9wZXJhdGlvbiB0aGF0IHdhcyBiZWluZyBwZXJmb3JtZWQgZm9yIGxvZ2dpbmcgcHVycG9zZXNcbiAgICAgKi9cbiAgICBwcml2YXRlIGNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlOiBhbnksIG9wZXJhdGlvbiA9ICdvcGVyYXRpb24nKSB7XG4gICAgICAgIGxldCBoYXNFcnJvcnMgPSBmYWxzZTtcbiAgICAgICAgbGV0IGVycm9ycztcblxuICAgICAgICBpZiAocmVzcG9uc2U/LmRhdGE/LmVycm9ycykge1xuICAgICAgICAgICAgaGFzRXJyb3JzID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke29wZXJhdGlvbn0gZmFpbGVkOiAke3Jlc3BvbnNlLmRhdGEuZXJyb3JzWzBdLm1lc3NhZ2V9YCk7XG4gICAgICAgICAgICBlcnJvcnMgPSB7IG1lc3NhZ2U6IHJlc3BvbnNlLmRhdGEuZXJyb3JzWzBdLm1lc3NhZ2UgfTtcbiAgICAgICAgfSBlbHNlIGlmIChyZXNwb25zZT8uZXJyb3JzKSB7XG4gICAgICAgICAgICBoYXNFcnJvcnMgPSB0cnVlO1xuICAgICAgICAgICAgY29uc29sZS5sb2coYCR7b3BlcmF0aW9ufSBmYWlsZWQ6ICR7cmVzcG9uc2UuZXJyb3JzWzBdLm1lc3NhZ2V9YCk7XG4gICAgICAgICAgICBlcnJvcnMgPSB7IG1lc3NhZ2U6IHJlc3BvbnNlLmVycm9yc1swXS5tZXNzYWdlIH07XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaGFzRXJyb3JzKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoSlNPTi5zdHJpbmdpZnkoZXJyb3JzKSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJZiB0aGUgb3BlcmF0aW9uIHdhcyBzdWNjZXNzZnVsLCBvYnRhaW4gYSBVSUQgZnJvbSB0aGUgcmVzcG9uc2UuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZEdyYXBoUmVzcG9uc2UgQSByZXNwb25zZSBmcm9tIGRHcmFwaFxuICAgICAqIEBwYXJhbSBvYmplY3RLZXkgdGhlIG5hbWUgb2YgdGhlIE9iamVjdCwgZm9yIGV4YW1wbGUgR2F0ZXdheSBvciBNb2RlbFxuICAgICAqIEByZXR1cm5zIGEgVUlEIGZvdW5kIGZyb20gdGhlIHJlc3BvbnNlXG4gICAgICovXG4gICAgcHJpdmF0ZSBnZXRJREZyb21SZXNwb25zZShkR3JhcGhSZXNwb25zZTogR3JhcGhSZXNwb25zZSwgb2JqZWN0S2V5OiBzdHJpbmcpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuICAgICAgICBpZiAoZEdyYXBoUmVzcG9uc2UuY29kZSA9PT0gJ1N1Y2Nlc3MnKSB7XG4gICAgICAgICAgICBjb25zdCB1aWQgPSBkR3JhcGhSZXNwb25zZS51aWRzW29iamVjdEtleV07XG4gICAgICAgICAgICByZXR1cm4gdWlkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZXRQcmVRdWVyeShvYmplY3ROYW1lOiBzdHJpbmcsIHVpZDogbnVtYmVyIHwgdW5kZWZpbmVkLCBhY2NvdW50Pzogc3RyaW5nKSB7XG4gICAgICAgIGlmICghdWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoSlNPTi5zdHJpbmdpZnkoeyBtZXNzYWdlOiAnTm8gSUQgZGVmaW5lZCcgfSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBge1xuICAgICAgICByZXNwKGZ1bmM6IGhhcygke29iamVjdE5hbWV9KSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgKHVpZCgke3VpZH0pKSkge1xuICAgICAgICAgIHVpZCB1dWlkXG4gICAgICAgIH1cbiAgICAgIH1gO1xuICAgIH1cblxuICAgIHByaXZhdGUgY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZTogYW55LCBvcGVyYXRpb246IHN0cmluZywgb2JqZWN0TmFtZTogc3RyaW5nLCB1aWQ6IG51bWJlciB8IHVuZGVmaW5lZCkge1xuICAgICAgICBpZiAoIXVpZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKEpTT04uc3RyaW5naWZ5KHsgbWVzc2FnZTogJ05vIElEIGRlZmluZWQnIH0pKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCBvcGVyYXRpb24pO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShyZXNwb25zZS5kYXRhLnJlc3ApKSB7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZUFycmF5OiBbXSA9IHJlc3BvbnNlLmRhdGEucmVzcDtcbiAgICAgICAgICAgIGlmIChyZXNwb25zZUFycmF5Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGB0aGUgJHtvYmplY3ROYW1lfSB3aXRoIElEICR7dWlkfSBkb2VzIG5vdCBleGlzdCBpbiB0aGlzIGFjY291bnRgKTtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoSlNPTi5zdHJpbmdpZnkoeyBtZXNzYWdlOiAnTm8gZXhpc3Rpbmcgb2JqZWN0JyB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR3JhcGhSZXNwb25zZSB7XG4gICAgY29kZTogc3RyaW5nO1xuICAgIG1lc3NhZ2U6IHN0cmluZztcbiAgICBxdWVyaWVzOiBhbnk7XG4gICAgdWlkczogeyBbaW5kZXg6IHN0cmluZ106IG51bWJlciB9O1xufVxuIl19