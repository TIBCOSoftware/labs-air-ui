import { map, switchMap, tap } from 'rxjs';
const route1 = [
    [25.771088, -80.163483],
    [27.439775, -80.32299],
    [28.349469, -80.731105],
    [30.401564, -81.571033],
    [32.116716, -81.144147],
    [32.866511, -79.995399],
    [34.191224, -77.952419],
    [36.850172, -76.319269],
    [36.915037, -76.320643],
    [39.262025, -76.549294],
    [39.900933, -75.143453],
    [40.690263, -74.152375],
    [42.259951, -71.789244],
];
const route2 = [
    [47.492471, -122.26888],
    [45.552207, -122.722648],
    [39.53246, -119.751524],
    [37.803528, -122.312138],
    [37.899332, -121.169307],
    [36.273183, -115.070534],
    [33.77032, -118.273289],
    [34.106012, -117.320254],
    [33.515564, -112.160564],
    [32.126437, -110.848336],
    [31.752085, -106.488887],
    [35.04758, -106.653344],
    [39.796963, -104.995374],
];
const route3 = [
    [29.302729, -98.638744],
    [29.638421, -95.292245],
    [32.615525, -96.693485],
    [29.917836, -90.205272],
    [32.256403, -90.151546],
    [35.044849, -90.153006],
    [38.524627, -90.209535],
    [39.870851, -88.912284],
    [41.705694, -87.577341],
    [41.902382, -89.101932],
    [44.251243, -91.509663],
    [44.970069, -93.174527],
    [46.758181, -92.098748],
];
const emptyRoute = [];
const httpOptions = {
    headers: {
        'Content-Type': 'application/graphql+-',
    },
};
const httpMutateOptions = {
    headers: { 'Content-Type': 'application/rdf' },
};
export class GraphService {
    constructor(http, dGraphUrl, accountRequired) {
        this.http = http;
        this.dGraphUrl = dGraphUrl;
        this.accountRequired = accountRequired;
        this.requireAccountId = true;
        this.requireAccountId = accountRequired;
        //const dGraphBasicAuthEnabled = this.appConfigService.dGraphBasicAuthEnabled;
        //if (dGraphBasicAuthEnabled) {
        //    const dGraphBasicAuth = this.appConfigService.dGraphBasicAuth;
        //    (this.httpOptions.headers = { 'Content-Type': 'application/graphql+-' }), { Authorization: dGraphBasicAuth };
        //    (this.httpMutateOptions.headers = { 'Content-Type': 'application/rdf' }), { Authorization: dGraphBasicAuth };
        //}
    }
    getGateway(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        console.log(`GetGateway service called for ${gatewayName}`);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGateway');
        }), map((response) => response.data.resp));
    }
    getGateways(account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway))
      @filter(${this.getAccountQuery(account)}) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
        numDevices: count(gateway_device)
        }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGateways');
        }), map((response) => response.data.resp), tap((response) => console.log(`fetched ${response.length} gateways`)));
    }
    updateGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('gateway', gateway.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
              var(func: uid(${gateway.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <account> "${account ? account : ''}" .
                uid(v) <address> "${gateway.address}" .
                uid(v) <router> "${gateway.router}" .
                uid(v) <routerPort> "${gateway.routerPort}" .
                uid(v) <deployNetwork> "${gateway.deployNetwork}" .
                uid(v) <description> "${gateway.description}" .
                uid(v) <latitude> "${gateway.latitude}" .
                uid(v) <longitude> "${gateway.longitude}" .
                uid(v) <accessToken> "${gateway.accessToken}" .
                uid(v) <username> "${gateway.username}" .
                uid(v) <platform> "${gateway.platform}" .
                uid(v) <updatedts> "${gateway.updatedts}" .
              }
            }
          }`;
        console.log(`Update Gateway ${gateway.uuid} ${gateway.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateGateway', 'gateway', gateway.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateGateway')), tap(() => console.log(`updated gateway ${gateway.uuid}`)), map(() => 'gateway updated'));
    }
    addGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        if (gateway.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Gateway <dgraph.type> "Gateway" .
        _:Gateway <gateway> "" .
        _:Gateway <type> "gateway" .
        _:Gateway <account> "${account ? account : ''}" .
        _:Gateway <uuid> "${gateway.uuid}" .
        _:Gateway <description> "${gateway.description}" .
        _:Gateway <address> "${gateway.address}" .
        _:Gateway <router> "${gateway.router}" .
        _:Gateway <routerPort> "${gateway.routerPort}" .
        _:Gateway <deployNetwork> "${gateway.deployNetwork}" .
        _:Gateway <latitude> "${gateway.latitude}" .
        _:Gateway <longitude> "${gateway.longitude}" .
        _:Gateway <accessToken> "${gateway.accessToken}" .
        _:Gateway <username> "${gateway.username}" .
        _:Gateway <platform> "${gateway.platform}" .
        _:Gateway <createdts> "${gateway.createdts}" .
        _:Gateway <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log(`Add Gateway ${gateway.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addGateway');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Gateway');
            if (id) {
                gateway.uid = id;
            }
        }), map((response) => (response.data.resp = gateway)), tap(() => console.log(`add gateway ${gateway.uid}/${gateway.uuid}`)));
    }
    deleteGateway(gatewayUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('gateway', gatewayUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${gatewayUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Gateway ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteGateway', 'gateway', gatewayUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteGateway')), tap(() => console.log(`deleted gateway ${gatewayUid}`)), map(() => `${gatewayUid} deleted`));
    }
    getGatewayAndProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid
        protocols: gateway_protocol {
          uid uuid created modified protocolType brokerURL
          topic consumerGroupId connectionTimeout sessionTimeout
          initialOffset retryBackOff fetchMinBytes fetchMaxWait
          commitInterval heartbeatInterval maximumQOS
          username password encryptionMode
          caCertificate clientCertificate clientKey
          authMode serverCertificate
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayWithProtocols');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and Protocols for ${gatewayName}`)));
    }
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayName
     */
    getProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(protocol)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified protocolType brokerURL topic
        consumerGroupId connectionTimeout sessionTimeout initialOffset
        retryBackOff fetchMinBytes fetchMaxWait commitInterval
        heartbeatInterval maximumQOS username password
        encryptionMode caCertificate clientCertificate clientKey
        authMode serverCertificate scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getProtocols');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched protocols for ${gatewayName}`)));
    }
    addProtocol(gatewayUid, protocol, account) {
        this.ensureAccountAuthorized(account);
        if (protocol.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Protocol <dgraph.type> "Protocol" .
        _:Protocol <type> "protocol" .
        _:Protocol <protocol> "" .
        _:Protocol <account> "${account ? account : ''}" .
        _:Protocol <uuid> "${protocol.uuid}" .
        _:Protocol <created> "${protocol.created}" .
        _:Protocol <modified> "${protocol.modified}" .
        _:Protocol <protocolType> "${protocol.protocolType}" .
        _:Protocol <brokerURL> "${protocol.brokerURL}" .
        _:Protocol <topic> "${protocol.topic}" .
        _:Protocol <consumerGroupId> "${protocol.consumerGroupId}" .
        _:Protocol <connectionTimeout> "${protocol.connectionTimeout}" .
        _:Protocol <sessionTimeout> "${protocol.sessionTimeout}" .
        _:Protocol <initialOffset> "${protocol.initialOffset}" .
        _:Protocol <retryBackOff> "${protocol.retryBackOff}" .
        _:Protocol <fetchMinBytes> "${protocol.fetchMinBytes}" .
        _:Protocol <fetchMaxWait> "${protocol.fetchMaxWait}" .
        _:Protocol <commitInterval> "${protocol.commitInterval}" .
        _:Protocol <heartbeatInterval> "${protocol.heartbeatInterval}" .
        _:Protocol <maximumQOS> "${protocol.maximumQOS}" .
        _:Protocol <username> "${protocol.username}" .
        _:Protocol <password> "${protocol.password}" .
        _:Protocol <encryptionMode> "${protocol.encryptionMode}" .
        _:Protocol <caCertificate> "${protocol.caCertificate}" .
        _:Protocol <clientCertificate> "${protocol.clientCertificate}" .
        _:Protocol <clientKey> "${protocol.clientKey}" .
        _:Protocol <authMode> "${protocol.authMode}" .
        _:Protocol <serverCertificate> "${protocol.serverCertificate}" .
        _:Protocol <scope> "${protocol.scope}" .
      }
    }`;
        console.log(`Add protocol ${protocol.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addProtocol');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Protocol');
            if (id) {
                protocol.uid = id;
            }
        }), map((response) => (response.data.resp = protocol)), tap(() => console.log(`add protocols ${protocol.uid}`)));
    }
    updateProtocol(protocol, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('protocol', protocol.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${protocol.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if (eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <uuid> "${protocol.uuid}" .
            uid(v) <modified> "${protocol.modified}" .
            uid(v) <protocolType> "${protocol.protocolType}" .
            uid(v) <brokerURL> "${protocol.brokerURL}" .
            uid(v) <topic> "${protocol.topic}" .
            uid(v) <consumerGroupId> "${protocol.consumerGroupId}" .
            uid(v) <connectionTimeout> "${protocol.connectionTimeout}" .
            uid(v) <sessionTimeout> "${protocol.sessionTimeout}" .
            uid(v) <initialOffset> "${protocol.initialOffset}" .
            uid(v) <retryBackOff> "${protocol.retryBackOff}" .
            uid(v) <fetchMinBytes> "${protocol.fetchMinBytes}" .
            uid(v) <fetchMaxWait> "${protocol.fetchMaxWait}" .
            uid(v) <commitInterval> "${protocol.commitInterval}" .
            uid(v) <heartbeatInterval> "${protocol.heartbeatInterval}" .
            uid(v) <maximumQOS> "${protocol.maximumQOS}" .
            uid(v) <username> "${protocol.username}" .
            uid(v) <password> "${protocol.password}" .
            uid(v) <encryptionMode> "${protocol.encryptionMode}" .
            uid(v) <caCertificate> "${protocol.caCertificate}" .
            uid(v) <clientCertificate> "${protocol.clientCertificate}" .
            uid(v) <clientKey> "${protocol.clientKey}" .
            uid(v) <authMode> "${protocol.authMode}" .
            uid(v) <serverCertificate> "${protocol.serverCertificate}" .
            uid(v) <scope> "${protocol.scope}" .
          }
        }
    }`;
        console.log(`Update ${protocol.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateProtocol', 'protocol', protocol.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateProtocol')), tap(() => console.log(`updated protocol ${protocol.uid}`)), map(() => protocol));
    }
    deleteProtocol(gatewayUid, protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('protocol', protocolUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${protocolUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Protocol ${protocolUid} for ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteProtocol', 'protocol', protocolUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteProtocol')), map(() => `${protocolUid} deleted`));
    }
    getDataStores(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(dataStore)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified dataStoreType
        host port databaseName user password accountName
        warehouse database schema authType username
        clientId clientSecret authorizationCode
        redirectURI loginTimeout url scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getDataStores');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched dataStores for gateway ${gatewayName}`)));
    }
    addDataStore(gatewayUid, dataStore, account) {
        this.ensureAccountAuthorized(account);
        if (dataStore.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:DataStore <dgraph.type> "DataStore" .
        _:DataStore <type> "dataStore" .
        _:DataStore <dataStore> "" .
        _:DataStore <account> "${account ? account : ''}" .
        _:DataStore <uuid> "${dataStore.uuid}" .
        _:DataStore <created> "${dataStore.created}" .
        _:DataStore <modified> "${dataStore.modified}" .
        _:DataStore <dataStoreType> "${dataStore.dataStoreType}" .
        _:DataStore <host> "${dataStore.host}" .
        _:DataStore <port> "${dataStore.port}" .
        _:DataStore <databaseName> "${dataStore.databaseName}" .
        _:DataStore <user> "${dataStore.user}" .
        _:DataStore <password> "${dataStore.password}" .
        _:DataStore <accountName> "${dataStore.accountName}" .
        _:DataStore <warehouse> "${dataStore.warehouse}" .
        _:DataStore <database> "${dataStore.databaseName}" .
        _:DataStore <schema> "${dataStore.schema}" .
        _:DataStore <authType> "${dataStore.authType}" .
        _:DataStore <username> "${dataStore.username}" .
        _:DataStore <clientId> "${dataStore.clientId}" .
        _:DataStore <clientSecret> "${dataStore.clientSecret}" .
        _:DataStore <authorizationCode> "${dataStore.authorizationCode}" .
        _:DataStore <redirectURI> "${dataStore.redirectURI}" .
        _:DataStore <loginTimeout> "${dataStore.loginTimeout}" .
        _:DataStore <url> "${dataStore.url}" .
        _:DataStore <scope> "${dataStore.scope}" .
      }
    }`;
        console.log(`Added datastore ${dataStore.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addDataStore');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'DataStore');
            if (id) {
                dataStore.uid = id;
            }
        }), map((response) => (response.data.resp = dataStore)), tap(() => console.log(`add dataStores ${dataStore.uid}`)));
    }
    updateDataStore(dataStore, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('dataStore', dataStore.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${dataStore.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
                uuid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <account> "${account ? account : ''}" .
                uid(v) <uuid> "${dataStore.uuid}" .
                uid(v) <modified> "${dataStore.modified}" .
                uid(v) <dataStoreType> "${dataStore.dataStoreType}" .
                uid(v) <host> "${dataStore.host}" .
                uid(v) <port> "${dataStore.port}" .
                uid(v) <databaseName> "${dataStore.databaseName}" .
                uid(v) <user> "${dataStore.user}" .
                uid(v) <password> "${dataStore.password}" .
                uid(v) <accountName> "${dataStore.accountName}" .
                uid(v) <warehouse> "${dataStore.warehouse}" .
                uid(v) <database> "${dataStore.databaseName}" .
                uid(v) <schema> "${dataStore.schema}" .
                uid(v) <authType> "${dataStore.authType}" .
                uid(v) <username> "${dataStore.username}" .
                uid(v) <clientId> "${dataStore.clientId}" .
                uid(v) <clientSecret> "${dataStore.clientSecret}" .
                uid(v) <authorizationCode> "${dataStore.authorizationCode}" .
                uid(v) <redirectURI> "${dataStore.redirectURI}" .
                uid(v) <loginTimeout> "${dataStore.loginTimeout}" .
                uid(v) <url> "${dataStore.url}" .
                uid(v) <scope> "${dataStore.scope}" .
              }
            }
          }`;
        console.log(`Update dataStore ${dataStore.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateDataStore', 'dataStore', dataStore.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateDataStore')), tap(() => console.log(`updated dataStore ${dataStore.uid}`)), map(() => dataStore));
    }
    deleteDataStore(gatewayUid, dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('dataStore', dataStoreUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${dataStoreUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete DataStore ${dataStoreUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteDataStore', 'dataStore', dataStoreUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteDataStore')), tap(() => console.log(`deleted dataStore ${dataStoreUid}`)), map(() => `${dataStoreUid} deleted`));
    }
    getGatewayAndModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid
        models: gateway_model {
          uid uuid created modified name
          description inputType url scope
          inputTemplate headers method base64Encoded
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayAndModels');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched gateways and models for ${gatewayName}`)));
    }
    getModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(model)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified name
        description inputType url scope inputTemplate
        headers method base64Encoded
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getModels');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched models for ${gatewayName}`)));
    }
    addModel(gatewayUid, model, account) {
        this.ensureAccountAuthorized(account);
        if (model.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Model <dgraph.type> "Model" .
        _:Model <type> "model" .
        _:Model <model> "" .
        _:Model <account> "${account ? account : ''}" .
        _:Model <uuid> "${model.uuid}" .
        _:Model <created> "${model.created}" .
        _:Model <modified> "${model.modified}" .
        _:Model <name> "${model.name}" .
        _:Model <description> "${model.description}" .
        _:Model <inputType> "${model.inputType}" .
        _:Model <url> "${model.url}" .
        _:Model <scope> "${model.scope}" .
        _:Model <inputTemplate> "${model.inputTemplate}" .
        _:Model <headers> "${model.headers}" .
        _:Model <method> "${model.method}" .
        _:Model <base64Encoded> "${model.base64Encoded}" .
      }
    }`;
        console.log(`Add model ${model.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addModel');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Model');
            if (id) {
                model.uid = id;
            }
        }), map((response) => (response.data.resp = model)), tap(() => console.log(`added model ${model.uid}`)));
    }
    updateModel(model, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('model', model.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${model.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <uuid> "${model.uuid}" .
            uid(v) <modified> "${model.modified}" .
            uid(v) <name> "${model.name}" .
            uid(v) <description> "${model.description}" .
            uid(v) <inputType> "${model.inputType}" .
            uid(v) <url> "${model.url}" .
            uid(v) <scope> "${model.scope}" .
            uid(v) <inputTemplate> "${model.inputTemplate}" .
            uid(v) <headers> "${model.headers}" .
            uid(v) <method> "${model.method}" .
            uid(v) <base64Encoded> "${model.base64Encoded}" .
          }
        }
        }`;
        console.log(`Update model ${model.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateModel', 'model', model.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateModel')), tap(() => console.log(`updated model ${model.uid}`)), map(() => model));
    }
    deleteModel(gatewayUid, modelUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('model', modelUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${modelUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Model ${modelUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteModel', 'model', modelUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteModel')), tap(() => console.log(`deleted model ${modelUid}`)), map(() => `${modelUid} deleted`));
    }
    getGatewayAndPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
        uid uuid brokerURL topic maximumQOS username password encryptionMode caCertificate
        clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
        sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
      }`;
        const pipeline_datastore = `dataStore: pipeline_datastore {
        uid uuid host port databaseName user password accountName warehouse database schema authType
        username clientId clientSecret authorizationCode redirectURI loginTimeout url
      }`;
        const pipeline_filter = 'filter: pipeline_filter { uid deviceNames }';
        const pipeline_streaming = 'streaming: pipeline_streaming { uid deviceName instrumentName function windowType windowSize }';
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid accessToken username platform address router routerPort deployNetwork devicesMetadata
        pipelines: gateway_pipeline {
          uid name uuid pipelineType deployerType protocolType protocolId dataStoreType
          dataStoreId created modified description status flowConfiguration
          logLevel subscriptionTopic
          ${pipeline_protocol}
          ${pipeline_datastore}
          ${pipeline_filter}
          ${pipeline_streaming}
        }
      }
    }`;
        console.log(`Get Gateway and Pipelines for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayWithPipelines');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and pipelines for ${gatewayName}`)));
    }
    getPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
              uid brokerURL topic maximumQOS username password encryptionMode caCertificate
              clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
              sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
  } `;
        const pipeline_datastore = `datastore: pipeline_datastore {
              uid host port databaseName user password accountName warehouse database schema authType
              username clientId clientSecret authorizationCode redirectURI loginTimeout url
            }`;
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        pipelines as gateway_pipeline {
        }
      }
      resp(func: uid(pipelines)) {
        uid name uuid pipelineType deployerType protocolType protocolId
        dataStoreType dataStoreId created modified description status
        flowConfiguration logLevel subscriptionTopic
        ${pipeline_protocol}
        ${pipeline_datastore}
        ${pipeline_filter}
        ${pipeline_streaming}
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPipelines');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched pipelines for ${gatewayName}`)));
    }
    addPipeline(gatewayUid, pipeline, transportObj, dataStoreObj, filterObj, streamingObj, account) {
        this.ensureAccountAuthorized(account);
        if (pipeline.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Pipeline <dgraph.type> "Pipeline" .
        _:Pipeline <account> "${account ? account : ''}" .
        _:Pipeline <name> "${pipeline.name}" .
        _:Pipeline <uuid> "${pipeline.name}" .
        _:Pipeline <type> "pipeline" .
        _:Pipeline <pipeline> "" .
        _:Pipeline <pipelineType> "${pipeline.pipelineType}" .
        _:Pipeline <deployerType> "${pipeline.deployerType}" .
        _:Pipeline <created> "${pipeline.created}" .
        _:Pipeline <modified> "${pipeline.modified}" .
        _:Pipeline <description> "${pipeline.description}" .
        _:Pipeline <status> "${pipeline.status}" .
        _:Pipeline <flowConfiguration> "${pipeline.flowConfiguration}" .
        _:Pipeline <logLevel> "${pipeline.logLevel}" .
        _:Pipeline <subscriptionTopic> "${pipeline.subscriptionTopic}" .
        <${gatewayUid}> <gateway_pipeline> _:Pipeline .
      }
    }`;
        console.log(`add Pipeline ${pipeline.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addPipeline');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Pipeline');
            if (id) {
                pipeline.uid = id;
            }
        }), map((response) => (response.data.resp = pipeline)), tap(() => console.log(`added pipeline ${pipeline.uid}`)));
    }
    updatePipeline(pipeline, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pipeline', pipeline.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${pipeline.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <description> "${pipeline.description}" .
            uid(v) <status> "${pipeline.status}" .
            uid(v) <modified> "${pipeline.modified}" .
            uid(v) <flowConfiguration> "${pipeline.flowConfiguration}" .
            uid(v) <logLevel> "${pipeline.logLevel}" .
            uid(v) <subscriptionTopic> "${pipeline.subscriptionTopic}" .
          }
        }
      }`;
        console.log(`update Pipeline ${pipeline.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updatePipeline', 'pipeline', pipeline.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatePipeline')), tap(() => console.log(`updated pipeline ${pipeline.uid}`)), map(() => pipeline));
    }
    deletePipeline(gatewayUid, pipeline, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pipeline', pipeline.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${pipeline.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
                <${gatewayUid}> <gateway_pipeline> <${pipeline.uid}> .
              }
            }
          }`;
        console.log(`delete Pipeline ${pipeline.uid} with gateway ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deletePipeline', 'pipeline', pipeline.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deletePipeline')), tap(() => console.log(`deleted pipeline ${pipeline.uid} with gateway ${gatewayUid}`)), map(() => `pipeline deleted`));
    }
    /**
     * Get ids of all the pipelines associated with the specified protocol
     * @param protocolUid - the uid of the protocol
     */
    getPipelineIdsFromProtocolUid(protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${protocolUid})) @filter(${this.getAccountQuery(account)}) {
        pipelines as ~pipeline_protocol {
        }
      }

      resp(func: uid(pipelines)) {
        uid uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPipelineIdsFromProtocolUid');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log('fetched pipeline ids')));
    }
    /**
     * Get ids of all the pipelines associated with the specified data store
     * @param dataStoreUid - the uid of the data store
     */
    getPipelineIdsFromDataStoreUid(dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${dataStoreUid})) @filter(${this.getAccountQuery(account)}) {
        pipelines as ~pipeline_datastore {
        }
      }

      resp(func: uid(pipelines)) {
        uid uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPipelineIdsFromDataStoreUid');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log('fetched pipeline ids')));
    }
    getModelConfigs(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        modelConfigs as gateway_modelconfig {
        }
      }
      resp(func: uid(modelConfigs)) {
        uid name uuid description device resource model created  modified
      }
    }`;
        console.log(`getModelConfigs for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getModelConfigs');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched modelConfigs for ${gatewayName}`)));
    }
    addModelConfig(gatewayUid, modelConfig, account) {
        this.ensureAccountAuthorized(account);
        if (modelConfig.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:ModelConfig <dgraph.type> "ModelConfig" .
        _:ModelConfig <account> "${account ? account : ''}" .
        _:ModelConfig <name> "${modelConfig.name}" .
        _:ModelConfig <uuid> "${modelConfig.name}" .
        _:ModelConfig <type> "modelConfig" .
        _:ModelConfig <modelConfig> "" .
        _:ModelConfig <description> "${modelConfig.description}" .
        _:ModelConfig <device> "${modelConfig.device}" .
        _:ModelConfig <resource> "${modelConfig.resource}" .
        _:ModelConfig <model> "${modelConfig.model}" .
        _:ModelConfig <created> "${modelConfig.created}" .
        _:ModelConfig <modified> "${modelConfig.modified}" .
        <${gatewayUid}> <gateway_modelconfig> _:ModelConfig .
      }
    }`;
        console.log(`Add modelConfig for gateway ${gatewayUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addModelConfig');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'ModelConfig');
            if (id) {
                modelConfig.uid = id;
            }
        }), map((response) => (response.data.resp = modelConfig)), tap(() => console.log(`add modelConfig for gateway ${gatewayUid}`)));
    }
    updateModelConfig(modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('modelConfig', modelConfig.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
          query {
          var(func: uid(${modelConfig.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <name> "${modelConfig.name}" .
            uid(v) <uuid> "${modelConfig.uuid}" .
            uid(v) <description> "${modelConfig.description}" .
            uid(v) <condDevice> "${modelConfig.device}" .
            uid(v) <condResource> "${modelConfig.resource}" .
            uid(v) <model> "${modelConfig.model}" .
            uid(v) <modified> "${modelConfig.modified}" .
          }
        }
      }`;
        console.log(`Update modelConfig ${modelConfig.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateModelConfig', 'modelConfig', modelConfig.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatupdateModelConfigeModel')), tap(() => console.log(`updated  modelConfig ${modelConfig.uid}`)), map(() => modelConfig));
    }
    deleteModelConfig(gatewayUid, modelConfigUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('modelConfig', modelConfigUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${modelConfigUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
                <${gatewayUid}> <gateway_modelconfig> <${modelConfigUid}> .
              }
            }
          }`;
        console.log(`Delete ModelConfig ${modelConfigUid} for gateway ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteModelConfig', 'modelConfig', modelConfigUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteModelConfig')), tap(() => console.log(`deleted modelConfig ${modelConfigUid} for gateway ${gatewayUid}`)), map(() => `${modelConfigUid} deleted`));
    }
    getFiltersConfig(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        filtersConfig as gateway_filter {
        }
      }
      resp(func: uid(filtersConfig)) {
        uid
        deviceNames
      }
    }`;
        console.log(`getFiltersConfig for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getFiltersConfigs');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched filtersConfig for ${gatewayName}`)));
    }
    addFiltersConfig(gatewayUid, filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        if (filtersConfig.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Filter <dgraph.type> "filter" .
        _:Filter <type> "filter" .
        _:Filter <filter> "" .
        _:Filter <deviceNames> "${filtersConfig.deviceNames}" .
        <${gatewayUid}> <gateway_filter> _:Filter .
        <${account}> <account> _:Filter .
      }
    }`;
        console.log(`add FiltersConfig for gateway ${gatewayUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addFiltersConfig');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Model');
            if (id) {
                filtersConfig.uid = id;
            }
        }), map((response) => (response.data.resp = filtersConfig)), tap(() => console.log(`added filtersConfig for gateway ${gatewayUid}`)));
    }
    updateFiltersConfig(filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('filterConfig', filtersConfig.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${filtersConfig.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <deviceNames> "${filtersConfig.deviceNames}" .
                <${account}> <account> "${account ? account : ''}" .
              }
            }
          }`;
        console.log(`update FiltersConfig ${filtersConfig.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateFiltersConfig', 'filter', filtersConfig.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateFiltersConfig')), tap(() => console.log(`updated filterConfig ${filtersConfig.uid}`)), map(() => filtersConfig));
    }
    /**
     * Get Python Resources.
     * @param gatewayUid
     */
    getPythonResources(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `
    {
      resp(func: type(PythonResource)) @filter(${this.getAccountQuery(account)} AND(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified name type scope fileContent
      }
    }`;
        console.log(`get python resource from ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPythonResource');
        }), map((response) => response.data.resp));
    }
    /**
     * Update Python Resource.
     * @param PythonResource
     */
    updatePythonResource(pythonResource, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pythonResource', pythonResource.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
              var(func: uid(${pythonResource.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                <${pythonResource.uid}> <account> "${account ? account : ''}" .
                <${pythonResource.uid}> <modified> "${pythonResource.modified}" .
                <${pythonResource.uid}> <name> "${pythonResource.name}" .
                <${pythonResource.uid}> <scope> "${pythonResource.scope}" .
                <${pythonResource.uid}> <type> "${pythonResource.type}" .
                <${pythonResource.uid}> <fileContent> "${pythonResource.fileContent}" .
              }
            }
        }`;
        console.log(`Update PythonResource ${pythonResource.uid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updatePythonResource', 'pythonResource', pythonResource.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatePythonResource')), tap(() => console.log(`updated filterConfig ${pythonResource.uid}`)), map(() => pythonResource));
    }
    /**
     * Add Python Resource.
     * @param PythonResource
     */
    addPythonResource(pythonResource, account) {
        this.ensureAccountAuthorized(account);
        if (pythonResource.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = ` {
      set {
        _:PythonResource <dgraph.type> "PythonResource" .
        _:PythonResource <pythonResource> "" .
        _:PythonResource <type> "pythonResource" .
        _:PythonResource <account> "${account ? account : ''}" .
        _:PythonResource <name> "${pythonResource.name}" .
        _:PythonResource <created> "${pythonResource.created}" .
        _:PythonResource <modified> "${pythonResource.modified}" .
        _:PythonResource <type> "${pythonResource.type}" .
        _:PythonResource <fileContent> "${pythonResource.fileContent}" .
        _:PythonResource <scope> "${pythonResource.scope}" .
      }}`;
        console.log(`Add PythonResource ${pythonResource.name}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addPythonResource');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'PythonResource');
            if (id) {
                pythonResource.uid = id;
            }
        }), map((response) => (response.data.resp = pythonResource)), tap(() => console.log(`add pythonResource ${pythonResource.uid}`)));
    }
    /**
     * Delete Python Resource.
     * @param resourceUid
     */
    deletePythonResource(pythonResourceUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pythonResource', pythonResourceUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `upsert {
            query {
              var(func: uid(${pythonResourceUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`${pythonResourceUid} is being deleted`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deletePythonResource', 'pythonResource', pythonResourceUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deletePythonResource')), tap(() => console.log(`updated filterConfig ${pythonResourceUid}`)), map(() => `${pythonResourceUid} deleted`));
    }
    getReadings(deviceName, instrumentName, numReadings, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading (first:-${numReadings}) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadings for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadings');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap((response) => console.log('Response from getReadings: ', response)), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsAt(deviceName, instrumentName, ts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(eq(created, ${ts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsAt for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsAt');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsStartingAt(deviceName, instrumentName, fromts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsStartingAt for for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsStartingAt');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched started at readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsBetween(deviceName, instrumentName, fromts, tots, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsBetween for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsBetween');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched readings between for ${deviceName}, ${instrumentName}`)));
    }
    getLastReadingsForDevice(deviceName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(device)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}")) @normalize {
        device_resource {
          name: name
          resource_reading (first:-1) {
            created: created
            value: value
          }
        }
      }
    }`;
        console.log(`getLastReadingsForDevice for ${deviceName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getLastReadingsForDevice');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched last readings for ${deviceName}`)));
    }
    getNotifications(account) {
        this.ensureAccountAuthorized(account);
        console.log('GetNotifications service called');
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(notification)) @filter(${this.getAccountQuery(account)}) @normalize {
        uid uuid:uuid created:created notifySource:notifySource notifyDevice:notifyDevice
        notifyResource:notifyResource notifyLevel:notifyLevel value:value description:description
        ~gateway_notification {
          gateway: uuid
        }
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getNotifications');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched notifications`)));
    }
    getRoute(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let route = null;
        if (deviceName == 'train-0001') {
            route = route1;
        }
        else if (deviceName == 'train-0002') {
            route = route2;
        }
        else if (deviceName == 'train-0003') {
            route = route3;
        }
        else {
            route = emptyRoute;
        }
        return route;
    }
    getRouteCenter(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let center = null;
        // 39.0 -98.0 zoom 4
        // East 34.765589   -78.709488
        // West 40.487432 -122.803116
        if (deviceName == 'train-0001') {
            center = [34.0, -98.0];
        }
        else if (deviceName == 'train-0002') {
            center = [40.0, -98.0];
        }
        else if (deviceName == 'train-0003') {
            center = [39.0, -98.0];
        }
        else {
            center = [42.8, 12.8];
        }
        return center;
    }
    ensureAccountAuthorized(account) {
        if (this.requireAccountId) {
            if (!account)
                throw new Error('Account must exist');
        }
    }
    getAccountQuery(account) {
        if (this.requireAccountId) {
            return `eq(account, "${account}")`;
        }
        else {
            return `(eq(account, "${account ? account : ''}") OR not(has(account)))`;
        }
    }
    /**
     * Discovers the presence of errors in the response from dGraph and reports them.
     *
     * @param response the response object from dGraph
     * @param operation the operation that was being performed for logging purposes
     */
    checkForErrors(response, operation = 'operation') {
        let hasErrors = false;
        let errors;
        if (response?.data?.errors) {
            hasErrors = true;
            console.log(`${operation} failed: ${response.data.errors[0].message}`);
            errors = { message: response.data.errors[0].message };
        }
        else if (response?.errors) {
            hasErrors = true;
            console.log(`${operation} failed: ${response.errors[0].message}`);
            errors = { message: response.errors[0].message };
        }
        if (hasErrors) {
            throw new Error(JSON.stringify(errors));
        }
    }
    /**
     * If the operation was successful, obtain a UID from the response.
     *
     * @param dGraphResponse A response from dGraph
     * @param objectKey the name of the Object, for example Gateway or Model
     * @returns a UID found from the response
     */
    getIDFromResponse(dGraphResponse, objectKey) {
        if (dGraphResponse.code === 'Success') {
            const uid = dGraphResponse.uids[objectKey];
            return uid;
        }
        return undefined;
    }
    getPreQuery(objectName, uid, account) {
        if (!uid) {
            throw new Error(JSON.stringify({ message: 'No ID defined' }));
        }
        return `{
        resp(func: has(${objectName})) @filter(${this.getAccountQuery(account)} AND (uid(${uid}))) {
          uid uuid
        }
      }`;
    }
    confirmObjectExists(response, operation, objectName, uid) {
        if (!uid) {
            throw new Error(JSON.stringify({ message: 'No ID defined' }));
        }
        this.checkForErrors(response, operation);
        if (Array.isArray(response.data.resp)) {
            const responseArray = response.data.resp;
            if (responseArray.length === 0) {
                console.log(`the ${objectName} with ID ${uid} does not exist in this account`);
                throw new Error(JSON.stringify({ message: 'No existing object' }));
            }
        }
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL2xhYnMtYWlyLWdyYXBoLWNsaWVudC9zcmMvYXBpL2dyYXBoLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBWUEsT0FBTyxFQUFFLEdBQUcsRUFBYyxTQUFTLEVBQUUsR0FBRyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBSXZELE1BQU0sTUFBTSxHQUFlO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsUUFBUSxDQUFDO0lBQ3RCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0NBQzFCLENBQUM7QUFFRixNQUFNLE1BQU0sR0FBZTtJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQztDQUMzQixDQUFDO0FBRUYsTUFBTSxNQUFNLEdBQWU7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7Q0FDMUIsQ0FBQztBQUVGLE1BQU0sVUFBVSxHQUFlLEVBQUUsQ0FBQztBQUVsQyxNQUFNLFdBQVcsR0FBRztJQUNoQixPQUFPLEVBQUU7UUFDTCxjQUFjLEVBQUUsdUJBQXVCO0tBQzFDO0NBQ0osQ0FBQztBQUVGLE1BQU0saUJBQWlCLEdBQUc7SUFDdEIsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGlCQUFpQixFQUFFO0NBQ2pELENBQUM7QUFFRixNQUFNLE9BQU8sWUFBWTtJQUlyQixZQUFvQixJQUFnQixFQUFZLFNBQWlCLEVBQVUsZUFBd0I7UUFBL0UsU0FBSSxHQUFKLElBQUksQ0FBWTtRQUFZLGNBQVMsR0FBVCxTQUFTLENBQVE7UUFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBUztRQUYzRixxQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFHNUIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLGVBQWUsQ0FBQztRQUN4Qyw4RUFBOEU7UUFDOUUsK0JBQStCO1FBQy9CLG9FQUFvRTtRQUNwRSxtSEFBbUg7UUFDbkgsbUhBQW1IO1FBQ25ILEdBQUc7SUFDUCxDQUFDO0lBRUQsVUFBVSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDNUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFDNUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxtQkFBbUIsQ0FBQztRQUNqRCxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7O01BSzdGLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLENBQ3JELENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQWdCO1FBQ3hCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLG1CQUFtQixDQUFDO1FBQ2pELE1BQU0sS0FBSyxHQUFHOztnQkFFTixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O01BTXZDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLFFBQVEsQ0FBQyxNQUFNLFdBQVcsQ0FBQyxDQUFDLENBQ3hFLENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLE9BQWdCLEVBQUUsT0FBZ0I7UUFDNUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFbkUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLE9BQU8sQ0FBQyxHQUFHO3dCQUNqQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O29DQU1qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtvQ0FDdEIsT0FBTyxDQUFDLE9BQU87bUNBQ2hCLE9BQU8sQ0FBQyxNQUFNO3VDQUNWLE9BQU8sQ0FBQyxVQUFVOzBDQUNmLE9BQU8sQ0FBQyxhQUFhO3dDQUN2QixPQUFPLENBQUMsV0FBVztxQ0FDdEIsT0FBTyxDQUFDLFFBQVE7c0NBQ2YsT0FBTyxDQUFDLFNBQVM7d0NBQ2YsT0FBTyxDQUFDLFdBQVc7cUNBQ3RCLE9BQU8sQ0FBQyxRQUFRO3FDQUNoQixPQUFPLENBQUMsUUFBUTtzQ0FDZixPQUFPLENBQUMsU0FBUzs7O1lBRzNDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixPQUFPLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRTdELGdGQUFnRjtRQUNoRixpRUFBaUU7UUFFakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQzlGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQyxFQUNqRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFDekQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixDQUFDLENBQy9CLENBQUM7SUFDTixDQUFDO0lBRUQsVUFBVSxDQUFDLE9BQWdCLEVBQUUsT0FBZ0I7UUFDekMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNiLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OytCQUtTLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUN6QixPQUFPLENBQUMsSUFBSTttQ0FDTCxPQUFPLENBQUMsV0FBVzsrQkFDdkIsT0FBTyxDQUFDLE9BQU87OEJBQ2hCLE9BQU8sQ0FBQyxNQUFNO2tDQUNWLE9BQU8sQ0FBQyxVQUFVO3FDQUNmLE9BQU8sQ0FBQyxhQUFhO2dDQUMxQixPQUFPLENBQUMsUUFBUTtpQ0FDZixPQUFPLENBQUMsU0FBUzttQ0FDZixPQUFPLENBQUMsV0FBVztnQ0FDdEIsT0FBTyxDQUFDLFFBQVE7Z0NBQ2hCLE9BQU8sQ0FBQyxRQUFRO2lDQUNmLE9BQU8sQ0FBQyxTQUFTO2lDQUNqQixPQUFPLENBQUMsU0FBUzs7TUFFNUMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUUzQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztZQUM1RCxJQUFJLEVBQUUsRUFBRTtnQkFDSixPQUFPLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUNwQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUNqRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLE9BQU8sQ0FBQyxHQUFHLElBQUksT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FDdkUsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsVUFBa0IsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRWxFLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs4QkFHUSxVQUFVO3dCQUNoQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFFTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRTVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQyxDQUFDLEVBQzdGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQyxFQUNqRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUN2RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxVQUFVLFVBQVUsQ0FBQyxDQUNyQyxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsV0FBVzs7Ozs7Ozs7Ozs7O01BWTdGLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRTVELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUseUJBQXlCLENBQUMsQ0FBQztRQUM3RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUM3RSxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILFlBQVksQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQzlDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzswQ0FDb0IsSUFBSSxDQUFDLGVBQWUsQ0FDcEQsT0FBTyxDQUNWLG9CQUFvQixXQUFXOzs7Ozs7OztNQVFoQyxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBa0IsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUNqRSxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxVQUFrQixFQUFFLFFBQWtCLEVBQUUsT0FBZ0I7UUFDaEUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksUUFBUSxDQUFDLEdBQUcsRUFBRTtZQUNkLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7O2dDQUtVLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzZCQUN6QixRQUFRLENBQUMsSUFBSTtnQ0FDVixRQUFRLENBQUMsT0FBTztpQ0FDZixRQUFRLENBQUMsUUFBUTtxQ0FDYixRQUFRLENBQUMsWUFBWTtrQ0FDeEIsUUFBUSxDQUFDLFNBQVM7OEJBQ3RCLFFBQVEsQ0FBQyxLQUFLO3dDQUNKLFFBQVEsQ0FBQyxlQUFlOzBDQUN0QixRQUFRLENBQUMsaUJBQWlCO3VDQUM3QixRQUFRLENBQUMsY0FBYztzQ0FDeEIsUUFBUSxDQUFDLGFBQWE7cUNBQ3ZCLFFBQVEsQ0FBQyxZQUFZO3NDQUNwQixRQUFRLENBQUMsYUFBYTtxQ0FDdkIsUUFBUSxDQUFDLFlBQVk7dUNBQ25CLFFBQVEsQ0FBQyxjQUFjOzBDQUNwQixRQUFRLENBQUMsaUJBQWlCO21DQUNqQyxRQUFRLENBQUMsVUFBVTtpQ0FDckIsUUFBUSxDQUFDLFFBQVE7aUNBQ2pCLFFBQVEsQ0FBQyxRQUFRO3VDQUNYLFFBQVEsQ0FBQyxjQUFjO3NDQUN4QixRQUFRLENBQUMsYUFBYTswQ0FDbEIsUUFBUSxDQUFDLGlCQUFpQjtrQ0FDbEMsUUFBUSxDQUFDLFNBQVM7aUNBQ25CLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7OEJBQ3RDLFFBQVEsQ0FBQyxLQUFLOztNQUV0QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFN0MsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDN0QsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osUUFBUSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7YUFDckI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQzFELENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFFBQWtCLEVBQUUsT0FBZ0I7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFckUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzBCQUdJLFFBQVEsQ0FBQyxHQUFHO29CQUNsQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O2dDQU1qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs2QkFDekIsUUFBUSxDQUFDLElBQUk7aUNBQ1QsUUFBUSxDQUFDLFFBQVE7cUNBQ2IsUUFBUSxDQUFDLFlBQVk7a0NBQ3hCLFFBQVEsQ0FBQyxTQUFTOzhCQUN0QixRQUFRLENBQUMsS0FBSzt3Q0FDSixRQUFRLENBQUMsZUFBZTswQ0FDdEIsUUFBUSxDQUFDLGlCQUFpQjt1Q0FDN0IsUUFBUSxDQUFDLGNBQWM7c0NBQ3hCLFFBQVEsQ0FBQyxhQUFhO3FDQUN2QixRQUFRLENBQUMsWUFBWTtzQ0FDcEIsUUFBUSxDQUFDLGFBQWE7cUNBQ3ZCLFFBQVEsQ0FBQyxZQUFZO3VDQUNuQixRQUFRLENBQUMsY0FBYzswQ0FDcEIsUUFBUSxDQUFDLGlCQUFpQjttQ0FDakMsUUFBUSxDQUFDLFVBQVU7aUNBQ3JCLFFBQVEsQ0FBQyxRQUFRO2lDQUNqQixRQUFRLENBQUMsUUFBUTt1Q0FDWCxRQUFRLENBQUMsY0FBYztzQ0FDeEIsUUFBUSxDQUFDLGFBQWE7MENBQ2xCLFFBQVEsQ0FBQyxpQkFBaUI7a0NBQ2xDLFFBQVEsQ0FBQyxTQUFTO2lDQUNuQixRQUFRLENBQUMsUUFBUTswQ0FDUixRQUFRLENBQUMsaUJBQWlCOzhCQUN0QyxRQUFRLENBQUMsS0FBSzs7O01BR3RDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFdEMsZ0ZBQWdGO1FBQ2hGLGlFQUFpRTtRQUNqRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUNqRyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxFQUNsRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFDMUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUN0QixDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLFdBQW1CLEVBQUUsT0FBZ0I7UUFDcEUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUVwRSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsV0FBVzt3QkFDakIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7OztZQVN6QyxDQUFDO1FBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsV0FBVyxRQUFRLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFaEUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxXQUFXLENBQUMsQ0FBQyxFQUNoRyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxFQUNsRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxXQUFXLFVBQVUsQ0FBQyxDQUN0QyxDQUFDO0lBQ04sQ0FBQztJQUVELGFBQWEsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzsyQ0FDcUIsSUFBSSxDQUFDLGVBQWUsQ0FDckQsT0FBTyxDQUNWLG9CQUFvQixXQUFXOzs7Ozs7O01BT2hDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFtQixDQUFDLEVBQ3BELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQzFFLENBQUM7SUFDTixDQUFDO0lBRUQsWUFBWSxDQUFDLFVBQWtCLEVBQUUsU0FBb0IsRUFBRSxPQUFnQjtRQUNuRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsSUFBSSxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7aUNBS1csT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7OEJBQ3pCLFNBQVMsQ0FBQyxJQUFJO2lDQUNYLFNBQVMsQ0FBQyxPQUFPO2tDQUNoQixTQUFTLENBQUMsUUFBUTt1Q0FDYixTQUFTLENBQUMsYUFBYTs4QkFDaEMsU0FBUyxDQUFDLElBQUk7OEJBQ2QsU0FBUyxDQUFDLElBQUk7c0NBQ04sU0FBUyxDQUFDLFlBQVk7OEJBQzlCLFNBQVMsQ0FBQyxJQUFJO2tDQUNWLFNBQVMsQ0FBQyxRQUFRO3FDQUNmLFNBQVMsQ0FBQyxXQUFXO21DQUN2QixTQUFTLENBQUMsU0FBUztrQ0FDcEIsU0FBUyxDQUFDLFlBQVk7Z0NBQ3hCLFNBQVMsQ0FBQyxNQUFNO2tDQUNkLFNBQVMsQ0FBQyxRQUFRO2tDQUNsQixTQUFTLENBQUMsUUFBUTtrQ0FDbEIsU0FBUyxDQUFDLFFBQVE7c0NBQ2QsU0FBUyxDQUFDLFlBQVk7MkNBQ2pCLFNBQVMsQ0FBQyxpQkFBaUI7cUNBQ2pDLFNBQVMsQ0FBQyxXQUFXO3NDQUNwQixTQUFTLENBQUMsWUFBWTs2QkFDL0IsU0FBUyxDQUFDLEdBQUc7K0JBQ1gsU0FBUyxDQUFDLEtBQUs7O01BRXhDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUVqRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQztZQUM5RCxJQUFJLEVBQUUsRUFBRTtnQkFDSixTQUFTLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUN0QjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FDNUQsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsU0FBb0IsRUFBRSxPQUFnQjtRQUNsRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUV2RSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBRXRELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsU0FBUyxDQUFDLEdBQUc7d0JBQ25CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7O29DQU9qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtpQ0FDekIsU0FBUyxDQUFDLElBQUk7cUNBQ1YsU0FBUyxDQUFDLFFBQVE7MENBQ2IsU0FBUyxDQUFDLGFBQWE7aUNBQ2hDLFNBQVMsQ0FBQyxJQUFJO2lDQUNkLFNBQVMsQ0FBQyxJQUFJO3lDQUNOLFNBQVMsQ0FBQyxZQUFZO2lDQUM5QixTQUFTLENBQUMsSUFBSTtxQ0FDVixTQUFTLENBQUMsUUFBUTt3Q0FDZixTQUFTLENBQUMsV0FBVztzQ0FDdkIsU0FBUyxDQUFDLFNBQVM7cUNBQ3BCLFNBQVMsQ0FBQyxZQUFZO21DQUN4QixTQUFTLENBQUMsTUFBTTtxQ0FDZCxTQUFTLENBQUMsUUFBUTtxQ0FDbEIsU0FBUyxDQUFDLFFBQVE7cUNBQ2xCLFNBQVMsQ0FBQyxRQUFRO3lDQUNkLFNBQVMsQ0FBQyxZQUFZOzhDQUNqQixTQUFTLENBQUMsaUJBQWlCO3dDQUNqQyxTQUFTLENBQUMsV0FBVzt5Q0FDcEIsU0FBUyxDQUFDLFlBQVk7Z0NBQy9CLFNBQVMsQ0FBQyxHQUFHO2tDQUNYLFNBQVMsQ0FBQyxLQUFLOzs7WUFHckMsQ0FBQztRQUVMLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRWpELGdGQUFnRjtRQUNoRixpRUFBaUU7UUFDakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDcEcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQzVELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FDdkIsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsVUFBa0IsRUFBRSxZQUFvQixFQUFFLE9BQWdCO1FBQ3RFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsRUFBRSxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFdEUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLFlBQVk7d0JBQ2xCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7WUFTekMsQ0FBQztRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFlBQVksRUFBRSxDQUFDLENBQUM7UUFFaEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQyxFQUNuRyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsWUFBWSxFQUFFLENBQUMsQ0FBQyxFQUMzRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxZQUFZLFVBQVUsQ0FBQyxDQUN2QyxDQUFDO0lBQ04sQ0FBQztJQUVELG1CQUFtQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDckQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsV0FBVzs7Ozs7Ozs7TUFRN0YsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1FBQ3pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQzNFLENBQUM7SUFDTixDQUFDO0lBRUQsU0FBUyxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDM0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3VDQUNpQixJQUFJLENBQUMsZUFBZSxDQUNqRCxPQUFPLENBQ1Ysb0JBQW9CLFdBQVc7Ozs7O01BS2hDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFlLENBQUMsRUFDaEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FDOUQsQ0FBQztJQUNOLENBQUM7SUFFRCxRQUFRLENBQUMsVUFBa0IsRUFBRSxLQUFZLEVBQUUsT0FBZ0I7UUFDdkQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksS0FBSyxDQUFDLEdBQUcsRUFBRTtZQUNYLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OzZCQUtPLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzBCQUN6QixLQUFLLENBQUMsSUFBSTs2QkFDUCxLQUFLLENBQUMsT0FBTzs4QkFDWixLQUFLLENBQUMsUUFBUTswQkFDbEIsS0FBSyxDQUFDLElBQUk7aUNBQ0gsS0FBSyxDQUFDLFdBQVc7K0JBQ25CLEtBQUssQ0FBQyxTQUFTO3lCQUNyQixLQUFLLENBQUMsR0FBRzsyQkFDUCxLQUFLLENBQUMsS0FBSzttQ0FDSCxLQUFLLENBQUMsYUFBYTs2QkFDekIsS0FBSyxDQUFDLE9BQU87NEJBQ2QsS0FBSyxDQUFDLE1BQU07bUNBQ0wsS0FBSyxDQUFDLGFBQWE7O01BRWhELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFdkMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDMUQsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osS0FBSyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7YUFDbEI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFDL0MsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUNyRCxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxLQUFZLEVBQUUsT0FBZ0I7UUFDdEMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFL0QsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzBCQUdJLEtBQUssQ0FBQyxHQUFHO29CQUNmLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Z0NBTWpCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzZCQUN6QixLQUFLLENBQUMsSUFBSTtpQ0FDTixLQUFLLENBQUMsUUFBUTs2QkFDbEIsS0FBSyxDQUFDLElBQUk7b0NBQ0gsS0FBSyxDQUFDLFdBQVc7a0NBQ25CLEtBQUssQ0FBQyxTQUFTOzRCQUNyQixLQUFLLENBQUMsR0FBRzs4QkFDUCxLQUFLLENBQUMsS0FBSztzQ0FDSCxLQUFLLENBQUMsYUFBYTtnQ0FDekIsS0FBSyxDQUFDLE9BQU87K0JBQ2QsS0FBSyxDQUFDLE1BQU07c0NBQ0wsS0FBSyxDQUFDLGFBQWE7OztVQUcvQyxDQUFDO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFekMsZ0ZBQWdGO1FBQ2hGLGlFQUFpRTtRQUNqRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsYUFBYSxFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDeEYsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDLEVBQy9ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQ25CLENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLFVBQWtCLEVBQUUsUUFBZ0IsRUFBRSxPQUFnQjtRQUM5RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRTlELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs4QkFHUSxRQUFRO3dCQUNkLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7WUFTekMsQ0FBQztRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFFeEMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGFBQWEsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFDdkYsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDLEVBQy9ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFFBQVEsVUFBVSxDQUFDLENBQ25DLENBQUM7SUFDTixDQUFDO0lBRUQsc0JBQXNCLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUN4RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxpQkFBaUIsR0FBRzs7OztRQUkxQixDQUFDO1FBQ0QsTUFBTSxrQkFBa0IsR0FBRzs7O1FBRzNCLENBQUM7UUFDRCxNQUFNLGVBQWUsR0FBRyw2Q0FBNkMsQ0FBQztRQUN0RSxNQUFNLGtCQUFrQixHQUNwQixnR0FBZ0csQ0FBQztRQUVyRyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7OztZQU12RixpQkFBaUI7WUFDakIsa0JBQWtCO1lBQ2xCLGVBQWU7WUFDZixrQkFBa0I7OztNQUd4QixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUU1RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLHlCQUF5QixDQUFDLENBQUM7UUFDN0QsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWlCLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FDN0UsQ0FBQztJQUNOLENBQUM7SUFFRCxZQUFZLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxpQkFBaUIsR0FBRzs7OztLQUk3QixDQUFDO1FBQ0UsTUFBTSxrQkFBa0IsR0FBRzs7O2NBR3JCLENBQUM7UUFDUCxNQUFNLGVBQWUsR0FBRywyQ0FBMkMsQ0FBQztRQUNwRSxNQUFNLGtCQUFrQixHQUNwQiw4RkFBOEYsQ0FBQztRQUVuRyxNQUFNLEtBQUssR0FBRzt3Q0FDa0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7Ozs7O1VBUXhGLGlCQUFpQjtVQUNqQixrQkFBa0I7VUFDbEIsZUFBZTtVQUNmLGtCQUFrQjs7TUFFdEIsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWtCLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FDakUsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQ1AsVUFBa0IsRUFDbEIsUUFBa0IsRUFDbEIsWUFBa0IsRUFDbEIsWUFBa0IsRUFDbEIsU0FBZSxFQUNmLFlBQWtCLEVBQ2xCLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxJQUFJLFFBQVEsQ0FBQyxHQUFHLEVBQUU7WUFDZCxNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDNUM7UUFFRCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7Z0NBR1UsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7NkJBQ3pCLFFBQVEsQ0FBQyxJQUFJOzZCQUNiLFFBQVEsQ0FBQyxJQUFJOzs7cUNBR0wsUUFBUSxDQUFDLFlBQVk7cUNBQ3JCLFFBQVEsQ0FBQyxZQUFZO2dDQUMxQixRQUFRLENBQUMsT0FBTztpQ0FDZixRQUFRLENBQUMsUUFBUTtvQ0FDZCxRQUFRLENBQUMsV0FBVzsrQkFDekIsUUFBUSxDQUFDLE1BQU07MENBQ0osUUFBUSxDQUFDLGlCQUFpQjtpQ0FDbkMsUUFBUSxDQUFDLFFBQVE7MENBQ1IsUUFBUSxDQUFDLGlCQUFpQjtXQUN6RCxVQUFVOztNQUVmLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUU1QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztZQUM3RCxJQUFJLEVBQUUsRUFBRTtnQkFDSixRQUFRLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUNyQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FDM0QsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsUUFBa0IsRUFBRSxPQUFnQjtRQUMvQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUVyRSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7MEJBR0ksUUFBUSxDQUFDLEdBQUc7b0JBQ2xCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Z0NBTWpCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO29DQUNsQixRQUFRLENBQUMsV0FBVzsrQkFDekIsUUFBUSxDQUFDLE1BQU07aUNBQ2IsUUFBUSxDQUFDLFFBQVE7MENBQ1IsUUFBUSxDQUFDLGlCQUFpQjtpQ0FDbkMsUUFBUSxDQUFDLFFBQVE7MENBQ1IsUUFBUSxDQUFDLGlCQUFpQjs7O1FBRzVELENBQUM7UUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUUvQyxnRkFBZ0Y7UUFDaEYsaUVBQWlFO1FBQ2pFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQ2pHLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLEVBQ2xFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUMxRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQ3RCLENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFVBQWtCLEVBQUUsUUFBa0IsRUFBRSxPQUFnQjtRQUNuRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUVyRSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsUUFBUSxDQUFDLEdBQUc7d0JBQ2xCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7O21CQU9sQyxVQUFVLHlCQUF5QixRQUFRLENBQUMsR0FBRzs7O1lBR3RELENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixRQUFRLENBQUMsR0FBRyxpQkFBaUIsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUUxRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUNqRyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxFQUNsRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsUUFBUSxDQUFDLEdBQUcsaUJBQWlCLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFDckYsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQ2hDLENBQUM7SUFDTixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsNkJBQTZCLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUMvRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7c0JBQ0EsV0FBVyxjQUFjLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7OztNQVF0RSxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDO1FBQ25FLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQWtCLENBQUM7YUFDNUM7aUJBQU07Z0JBQ0gsT0FBTyxFQUFnQixDQUFDO2FBQzNCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUNqRCxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILDhCQUE4QixDQUFDLFlBQW9CLEVBQUUsT0FBZ0I7UUFDakUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3NCQUNBLFlBQVksY0FBYyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7TUFRdkUsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0NBQWdDLENBQUMsQ0FBQztRQUNwRSxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7Z0JBQ3JCLE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxJQUFrQixDQUFDO2FBQzVDO2lCQUFNO2dCQUNILE9BQU8sRUFBZ0IsQ0FBQzthQUMzQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FDakQsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUNqRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7d0NBQ2tCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7O01BTzVGLENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRWxELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUNyRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7Z0JBQ3JCLE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxJQUFxQixDQUFDO2FBQy9DO2lCQUFNO2dCQUNILE9BQU8sRUFBbUIsQ0FBQzthQUM5QjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQ3BFLENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFVBQWtCLEVBQUUsV0FBd0IsRUFBRSxPQUFnQjtRQUN6RSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsSUFBSSxXQUFXLENBQUMsR0FBRyxFQUFFO1lBQ2pCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7OzttQ0FHYSxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FDekIsV0FBVyxDQUFDLElBQUk7Z0NBQ2hCLFdBQVcsQ0FBQyxJQUFJOzs7dUNBR1QsV0FBVyxDQUFDLFdBQVc7a0NBQzVCLFdBQVcsQ0FBQyxNQUFNO29DQUNoQixXQUFXLENBQUMsUUFBUTtpQ0FDdkIsV0FBVyxDQUFDLEtBQUs7bUNBQ2YsV0FBVyxDQUFDLE9BQU87b0NBQ2xCLFdBQVcsQ0FBQyxRQUFRO1dBQzdDLFVBQVU7O01BRWYsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFekQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDcEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQztZQUNoRSxJQUFJLEVBQUUsRUFBRTtnQkFDSixXQUFXLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUN4QjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUMsQ0FBQyxFQUNyRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUN0RSxDQUFDO0lBQ04sQ0FBQztJQUVELGlCQUFpQixDQUFDLFdBQXdCLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFM0UsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzBCQUdJLFdBQVcsQ0FBQyxHQUFHO29CQUNyQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O2dDQU1qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs2QkFDekIsV0FBVyxDQUFDLElBQUk7NkJBQ2hCLFdBQVcsQ0FBQyxJQUFJO29DQUNULFdBQVcsQ0FBQyxXQUFXO21DQUN4QixXQUFXLENBQUMsTUFBTTtxQ0FDaEIsV0FBVyxDQUFDLFFBQVE7OEJBQzNCLFdBQVcsQ0FBQyxLQUFLO2lDQUNkLFdBQVcsQ0FBQyxRQUFROzs7UUFHN0MsQ0FBQztRQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRXJELGdGQUFnRjtRQUNoRixpRUFBaUU7UUFFakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLG1CQUFtQixFQUFFLGFBQWEsRUFBRSxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDMUcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLDhCQUE4QixDQUFDLENBQUMsRUFDaEYsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ2pFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FDekIsQ0FBQztJQUNOLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxVQUFrQixFQUFFLGNBQXNCLEVBQUUsT0FBZ0I7UUFDMUUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLGNBQWMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUUxRSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsY0FBYzt3QkFDcEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7bUJBT2xDLFVBQVUsNEJBQTRCLGNBQWM7OztZQUczRCxDQUFDO1FBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsY0FBYyxnQkFBZ0IsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUU5RSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsbUJBQW1CLEVBQUUsYUFBYSxFQUFFLGNBQWMsQ0FBQyxDQUFDLEVBQ3pHLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDLEVBQ3JFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixjQUFjLGdCQUFnQixVQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQ3pGLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLGNBQWMsVUFBVSxDQUFDLENBQ3pDLENBQUM7SUFDTixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUNsRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7d0NBQ2tCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7OztNQVE1RixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUVuRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLG1CQUFtQixDQUFDLENBQUM7UUFDdkQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBOEIsQ0FBQzthQUN4RDtpQkFBTTtnQkFDSCxPQUFPLEVBQTRCLENBQUM7YUFDdkM7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUNyRSxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUNaLFVBQWtCLEVBQ2xCLGFBQW1DLEVBQ25DLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxJQUFJLGFBQWEsQ0FBQyxHQUFHLEVBQUU7WUFDbkIsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7a0NBS1ksYUFBYSxDQUFDLFdBQVc7V0FDaEQsVUFBVTtXQUNWLE9BQU87O01BRVosQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFM0QsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMxRCxJQUFJLEVBQUUsRUFBRTtnQkFDSixhQUFhLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUMxQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsQ0FBQyxFQUN2RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUMxRSxDQUFDO0lBQ04sQ0FBQztJQUVELG1CQUFtQixDQUFDLGFBQW1DLEVBQUUsT0FBZ0I7UUFDckUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLGFBQWEsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFOUUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLGFBQWEsQ0FBQyxHQUFHO3dCQUN2QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O3dDQU1iLGFBQWEsQ0FBQyxXQUFXO21CQUM5QyxPQUFPLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs7O1lBR3BELENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixhQUFhLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUV6RCxnRkFBZ0Y7UUFDaEYsaUVBQWlFO1FBQ2pFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxxQkFBcUIsRUFBRSxRQUFRLEVBQUUsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQ3pHLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDLEVBQ3ZFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixhQUFhLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQzNCLENBQUM7SUFDTixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsa0JBQWtCLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUNwRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7O2lEQUUyQixJQUFJLENBQUMsZUFBZSxDQUMzRCxPQUFPLENBQ1YsbUJBQW1CLFdBQVc7OztNQUcvQixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUN2RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLG1CQUFtQixDQUFDLENBQUM7UUFDdkQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQXdCLENBQUMsQ0FDNUQsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCxvQkFBb0IsQ0FBQyxjQUE4QixFQUFFLE9BQWdCO1FBQ2pFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFakYsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLGNBQWMsQ0FBQyxHQUFHO3dCQUN4QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O21CQU1sQyxjQUFjLENBQUMsR0FBRyxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7bUJBQ3hELGNBQWMsQ0FBQyxHQUFHLGlCQUFpQixjQUFjLENBQUMsUUFBUTttQkFDMUQsY0FBYyxDQUFDLEdBQUcsYUFBYSxjQUFjLENBQUMsSUFBSTttQkFDbEQsY0FBYyxDQUFDLEdBQUcsY0FBYyxjQUFjLENBQUMsS0FBSzttQkFDcEQsY0FBYyxDQUFDLEdBQUcsYUFBYSxjQUFjLENBQUMsSUFBSTttQkFDbEQsY0FBYyxDQUFDLEdBQUcsb0JBQW9CLGNBQWMsQ0FBQyxXQUFXOzs7VUFHekUsQ0FBQztRQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLGNBQWMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRTNELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxzQkFBc0IsRUFBRSxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDbkgsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLHNCQUFzQixDQUFDLENBQUMsRUFDeEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLGNBQWMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ3BFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsQ0FDNUIsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCxpQkFBaUIsQ0FBQyxjQUE4QixFQUFFLE9BQWdCO1FBQzlELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxJQUFJLGNBQWMsQ0FBQyxHQUFHLEVBQUU7WUFDcEIsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVDO1FBQ0QsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7c0NBS2dCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO21DQUN6QixjQUFjLENBQUMsSUFBSTtzQ0FDaEIsY0FBYyxDQUFDLE9BQU87dUNBQ3JCLGNBQWMsQ0FBQyxRQUFRO21DQUMzQixjQUFjLENBQUMsSUFBSTswQ0FDWixjQUFjLENBQUMsV0FBVztvQ0FDaEMsY0FBYyxDQUFDLEtBQUs7U0FDL0MsQ0FBQztRQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLGNBQWMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRXpELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1FBQ3ZELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztZQUNuRSxJQUFJLEVBQUUsRUFBRTtnQkFDSixjQUFjLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUMzQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxjQUFjLENBQUMsQ0FBQyxFQUN4RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FDckUsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCxvQkFBb0IsQ0FBQyxpQkFBeUIsRUFBRSxPQUFnQjtRQUM1RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUVoRixNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs4QkFFUSxpQkFBaUI7d0JBQ3ZCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7WUFTekMsQ0FBQztRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxpQkFBaUIsbUJBQW1CLENBQUMsQ0FBQztRQUNyRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsc0JBQXNCLEVBQUUsZ0JBQWdCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNsSCxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsc0JBQXNCLENBQUMsQ0FBQyxFQUN4RSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLGlCQUFpQixVQUFVLENBQUMsQ0FDNUMsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxjQUFzQixFQUFFLFdBQW1CLEVBQUUsT0FBZ0I7UUFDekYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsVUFBVSxJQUFJLGNBQWM7K0NBQ3JFLFdBQVc7Ozs7Ozs7TUFPcEQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDO1FBRWhFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBbUIsQ0FBQzthQUM3QztpQkFBTTtnQkFDSCxPQUFPLEVBQWlCLENBQUM7YUFDNUI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFDdkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQ2xGLENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxFQUFVLEVBQUUsT0FBZ0I7UUFDbEYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsVUFBVSxJQUFJLGNBQWM7MkRBQ3pELEVBQUU7Ozs7Ozs7TUFPdkQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDO1FBRWxFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFDbkQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBbUIsQ0FBQzthQUM3QztpQkFBTTtnQkFDSCxPQUFPLEVBQWlCLENBQUM7YUFDNUI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FDbEYsQ0FBQztJQUNOLENBQUM7SUFFRCxxQkFBcUIsQ0FDakIsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsTUFBYyxFQUNkLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVUsSUFBSSxjQUFjOzJEQUN6RCxNQUFNOzs7Ozs7O01BTzNELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQztRQUU5RSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLHVCQUF1QixDQUFDLENBQUM7UUFDM0QsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBbUIsQ0FBQzthQUM3QztpQkFBTTtnQkFDSCxPQUFPLEVBQWlCLENBQUM7YUFDNUI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FDN0YsQ0FBQztJQUNOLENBQUM7SUFFRCxrQkFBa0IsQ0FDZCxVQUFrQixFQUNsQixjQUFzQixFQUN0QixNQUFjLEVBQ2QsSUFBWSxFQUNaLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVUsSUFBSSxjQUFjOzJEQUN6RCxNQUFNLHFCQUFxQixJQUFJOzs7Ozs7O01BT3BGLENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQztRQUV2RSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLG9CQUFvQixDQUFDLENBQUM7UUFDeEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBbUIsQ0FBQzthQUM3QztpQkFBTTtnQkFDSCxPQUFPLEVBQWlCLENBQUM7YUFDNUI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FDMUYsQ0FBQztJQUNOLENBQUM7SUFFRCx3QkFBd0IsQ0FBQyxVQUFrQixFQUFFLE9BQWdCO1FBQ3pELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt3Q0FDa0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVU7Ozs7Ozs7OztNQVMzRixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUUxRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLDBCQUEwQixDQUFDLENBQUM7UUFDOUQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBbUIsQ0FBQzthQUM3QztpQkFBTTtnQkFDSCxPQUFPLEVBQWlCLENBQUM7YUFDNUI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUNwRSxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUFDLE9BQWdCO1FBQzdCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFDL0MsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7OENBQ3dCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7O01BT3JFLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBc0IsQ0FBQzthQUNoRDtpQkFBTTtnQkFDSCxPQUFPLEVBQW9CLENBQUM7YUFDL0I7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQ2xELENBQUM7SUFDTixDQUFDO0lBRUQsUUFBUSxDQUFDLFVBQWtCLEVBQUUsT0FBZ0I7UUFDekMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQztRQUVqQixJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDNUIsS0FBSyxHQUFHLE1BQU0sQ0FBQztTQUNsQjthQUFNLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRTtZQUNuQyxLQUFLLEdBQUcsTUFBTSxDQUFDO1NBQ2xCO2FBQU0sSUFBSSxVQUFVLElBQUksWUFBWSxFQUFFO1lBQ25DLEtBQUssR0FBRyxNQUFNLENBQUM7U0FDbEI7YUFBTTtZQUNILEtBQUssR0FBRyxVQUFVLENBQUM7U0FDdEI7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQsY0FBYyxDQUFDLFVBQWtCLEVBQUUsT0FBZ0I7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztRQUVsQixvQkFBb0I7UUFDcEIsOEJBQThCO1FBQzlCLDZCQUE2QjtRQUU3QixJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDNUIsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTTtZQUNILE1BQU0sR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztTQUN6QjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxPQUFnQjtRQUM1QyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN2QixJQUFJLENBQUMsT0FBTztnQkFBRSxNQUFNLElBQUksS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7U0FDdkQ7SUFDTCxDQUFDO0lBRU8sZUFBZSxDQUFDLE9BQWdCO1FBQ3BDLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3ZCLE9BQU8sZ0JBQWdCLE9BQU8sSUFBSSxDQUFDO1NBQ3RDO2FBQU07WUFDSCxPQUFPLGlCQUFpQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSwwQkFBMEIsQ0FBQztTQUM1RTtJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLGNBQWMsQ0FBQyxRQUFhLEVBQUUsU0FBUyxHQUFHLFdBQVc7UUFDekQsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksTUFBTSxDQUFDO1FBRVgsSUFBSSxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRTtZQUN4QixTQUFTLEdBQUcsSUFBSSxDQUFDO1lBQ2pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUN2RSxNQUFNLEdBQUcsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDekQ7YUFBTSxJQUFJLFFBQVEsRUFBRSxNQUFNLEVBQUU7WUFDekIsU0FBUyxHQUFHLElBQUksQ0FBQztZQUNqQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxZQUFZLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUNsRSxNQUFNLEdBQUcsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUNwRDtRQUVELElBQUksU0FBUyxFQUFFO1lBQ1gsTUFBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7U0FDM0M7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssaUJBQWlCLENBQUMsY0FBNkIsRUFBRSxTQUFpQjtRQUN0RSxJQUFJLGNBQWMsQ0FBQyxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQ25DLE1BQU0sR0FBRyxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDM0MsT0FBTyxHQUFHLENBQUM7U0FDZDtRQUNELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFTyxXQUFXLENBQUMsVUFBa0IsRUFBRSxHQUF1QixFQUFFLE9BQWdCO1FBQzdFLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDTixNQUFNLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ2pFO1FBQ0QsT0FBTzt5QkFDVSxVQUFVLGNBQWMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHOzs7UUFHdEYsQ0FBQztJQUNMLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxRQUFhLEVBQUUsU0FBaUIsRUFBRSxVQUFrQixFQUFFLEdBQXVCO1FBQ3JHLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDTixNQUFNLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ2pFO1FBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDekMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbkMsTUFBTSxhQUFhLEdBQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDN0MsSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDNUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLFVBQVUsWUFBWSxHQUFHLGlDQUFpQyxDQUFDLENBQUM7Z0JBQy9FLE1BQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUN0RTtTQUNKO0lBQ0wsQ0FBQztDQUNKIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgICBEYXRhU3RvcmUsXG4gICAgR2F0ZXdheSxcbiAgICBHYXRld2F5RmlsdGVyc0NvbmZpZyxcbiAgICBNb2RlbCxcbiAgICBNb2RlbENvbmZpZyxcbiAgICBOb3RpZmljYXRpb24sXG4gICAgUGlwZWxpbmUsXG4gICAgUHJvdG9jb2wsXG4gICAgVFNSZWFkaW5nLFxuICAgIFB5dGhvblJlc291cmNlLFxufSBmcm9tICcuLi9tb2RlbC9tb2RlbHMnO1xuaW1wb3J0IHsgbWFwLCBPYnNlcnZhYmxlLCBzd2l0Y2hNYXAsIHRhcCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcblxuXG5jb25zdCByb3V0ZTE6IG51bWJlcltdW10gPSBbXG4gICAgWzI1Ljc3MTA4OCwgLTgwLjE2MzQ4M10sXG4gICAgWzI3LjQzOTc3NSwgLTgwLjMyMjk5XSxcbiAgICBbMjguMzQ5NDY5LCAtODAuNzMxMTA1XSxcbiAgICBbMzAuNDAxNTY0LCAtODEuNTcxMDMzXSxcbiAgICBbMzIuMTE2NzE2LCAtODEuMTQ0MTQ3XSxcbiAgICBbMzIuODY2NTExLCAtNzkuOTk1Mzk5XSxcbiAgICBbMzQuMTkxMjI0LCAtNzcuOTUyNDE5XSxcbiAgICBbMzYuODUwMTcyLCAtNzYuMzE5MjY5XSxcbiAgICBbMzYuOTE1MDM3LCAtNzYuMzIwNjQzXSxcbiAgICBbMzkuMjYyMDI1LCAtNzYuNTQ5Mjk0XSxcbiAgICBbMzkuOTAwOTMzLCAtNzUuMTQzNDUzXSxcbiAgICBbNDAuNjkwMjYzLCAtNzQuMTUyMzc1XSxcbiAgICBbNDIuMjU5OTUxLCAtNzEuNzg5MjQ0XSxcbl07XG5cbmNvbnN0IHJvdXRlMjogbnVtYmVyW11bXSA9IFtcbiAgICBbNDcuNDkyNDcxLCAtMTIyLjI2ODg4XSxcbiAgICBbNDUuNTUyMjA3LCAtMTIyLjcyMjY0OF0sXG4gICAgWzM5LjUzMjQ2LCAtMTE5Ljc1MTUyNF0sXG4gICAgWzM3LjgwMzUyOCwgLTEyMi4zMTIxMzhdLFxuICAgIFszNy44OTkzMzIsIC0xMjEuMTY5MzA3XSxcbiAgICBbMzYuMjczMTgzLCAtMTE1LjA3MDUzNF0sXG4gICAgWzMzLjc3MDMyLCAtMTE4LjI3MzI4OV0sXG4gICAgWzM0LjEwNjAxMiwgLTExNy4zMjAyNTRdLFxuICAgIFszMy41MTU1NjQsIC0xMTIuMTYwNTY0XSxcbiAgICBbMzIuMTI2NDM3LCAtMTEwLjg0ODMzNl0sXG4gICAgWzMxLjc1MjA4NSwgLTEwNi40ODg4ODddLFxuICAgIFszNS4wNDc1OCwgLTEwNi42NTMzNDRdLFxuICAgIFszOS43OTY5NjMsIC0xMDQuOTk1Mzc0XSxcbl07XG5cbmNvbnN0IHJvdXRlMzogbnVtYmVyW11bXSA9IFtcbiAgICBbMjkuMzAyNzI5LCAtOTguNjM4NzQ0XSxcbiAgICBbMjkuNjM4NDIxLCAtOTUuMjkyMjQ1XSxcbiAgICBbMzIuNjE1NTI1LCAtOTYuNjkzNDg1XSxcbiAgICBbMjkuOTE3ODM2LCAtOTAuMjA1MjcyXSxcbiAgICBbMzIuMjU2NDAzLCAtOTAuMTUxNTQ2XSxcbiAgICBbMzUuMDQ0ODQ5LCAtOTAuMTUzMDA2XSxcbiAgICBbMzguNTI0NjI3LCAtOTAuMjA5NTM1XSxcbiAgICBbMzkuODcwODUxLCAtODguOTEyMjg0XSxcbiAgICBbNDEuNzA1Njk0LCAtODcuNTc3MzQxXSxcbiAgICBbNDEuOTAyMzgyLCAtODkuMTAxOTMyXSxcbiAgICBbNDQuMjUxMjQzLCAtOTEuNTA5NjYzXSxcbiAgICBbNDQuOTcwMDY5LCAtOTMuMTc0NTI3XSxcbiAgICBbNDYuNzU4MTgxLCAtOTIuMDk4NzQ4XSxcbl07XG5cbmNvbnN0IGVtcHR5Um91dGU6IG51bWJlcltdW10gPSBbXTtcblxuY29uc3QgaHR0cE9wdGlvbnMgPSB7XG4gICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2dyYXBocWwrLScsXG4gICAgfSxcbn07XG5cbmNvbnN0IGh0dHBNdXRhdGVPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9yZGYnIH0sXG59O1xuXG5leHBvcnQgY2xhc3MgR3JhcGhTZXJ2aWNlIHtcbiAgICBcbiAgICBwcml2YXRlIHJlcXVpcmVBY2NvdW50SWQgPSB0cnVlO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LCBwcm90ZWN0ZWQgZEdyYXBoVXJsOiBzdHJpbmcsIHByaXZhdGUgYWNjb3VudFJlcXVpcmVkOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMucmVxdWlyZUFjY291bnRJZCA9IGFjY291bnRSZXF1aXJlZDtcbiAgICAgICAgLy9jb25zdCBkR3JhcGhCYXNpY0F1dGhFbmFibGVkID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aEVuYWJsZWQ7XG4gICAgICAgIC8vaWYgKGRHcmFwaEJhc2ljQXV0aEVuYWJsZWQpIHtcbiAgICAgICAgLy8gICAgY29uc3QgZEdyYXBoQmFzaWNBdXRoID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aDtcbiAgICAgICAgLy8gICAgKHRoaXMuaHR0cE9wdGlvbnMuaGVhZGVycyA9IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9ncmFwaHFsKy0nIH0pLCB7IEF1dGhvcml6YXRpb246IGRHcmFwaEJhc2ljQXV0aCB9O1xuICAgICAgICAvLyAgICAodGhpcy5odHRwTXV0YXRlT3B0aW9ucy5oZWFkZXJzID0geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3JkZicgfSksIHsgQXV0aG9yaXphdGlvbjogZEdyYXBoQmFzaWNBdXRoIH07XG4gICAgICAgIC8vfVxuICAgIH1cblxuICAgIGdldEdhdGV3YXkoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc29sZS5sb2coYEdldEdhdGV3YXkgc2VydmljZSBjYWxsZWQgZm9yICR7Z2F0ZXdheU5hbWV9YCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeT9kZWJ1Zz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWQgZGVzY3JpcHRpb24gYWRkcmVzcyByb3V0ZXIgcm91dGVyUG9ydFxuICAgICAgICBkZXBsb3lOZXR3b3JrIGxhdGl0dWRlIGxvbmdpdHVkZSBhY2Nlc3NUb2tlbiB1c2VybmFtZVxuICAgICAgICBwbGF0Zm9ybSBkZXZpY2VzTWV0YWRhdGEgY3JlYXRlZHRzIHVwZGF0ZWR0c1xuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRHYXRld2F5Jyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlzKGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeT9kZWJ1Zz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpXG4gICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgIHVpZCB1dWlkIGRlc2NyaXB0aW9uIGFkZHJlc3Mgcm91dGVyIHJvdXRlclBvcnRcbiAgICAgICAgZGVwbG95TmV0d29yayBsYXRpdHVkZSBsb25naXR1ZGUgYWNjZXNzVG9rZW4gdXNlcm5hbWVcbiAgICAgICAgcGxhdGZvcm0gZGV2aWNlc01ldGFkYXRhIGNyZWF0ZWR0cyB1cGRhdGVkdHNcbiAgICAgICAgbnVtRGV2aWNlczogY291bnQoZ2F0ZXdheV9kZXZpY2UpXG4gICAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0R2F0ZXdheXMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCAke3Jlc3BvbnNlLmxlbmd0aH0gZ2F0ZXdheXNgKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlR2F0ZXdheShnYXRld2F5OiBHYXRld2F5LCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnZ2F0ZXdheScsIGdhdGV3YXkudWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtnYXRld2F5LnVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgICAgICB1aWQodikgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGFkZHJlc3M+IFwiJHtnYXRld2F5LmFkZHJlc3N9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cm91dGVyPiBcIiR7Z2F0ZXdheS5yb3V0ZXJ9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cm91dGVyUG9ydD4gXCIke2dhdGV3YXkucm91dGVyUG9ydH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxkZXBsb3lOZXR3b3JrPiBcIiR7Z2F0ZXdheS5kZXBsb3lOZXR3b3JrfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGRlc2NyaXB0aW9uPiBcIiR7Z2F0ZXdheS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxsYXRpdHVkZT4gXCIke2dhdGV3YXkubGF0aXR1ZGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8bG9uZ2l0dWRlPiBcIiR7Z2F0ZXdheS5sb25naXR1ZGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8YWNjZXNzVG9rZW4+IFwiJHtnYXRld2F5LmFjY2Vzc1Rva2VufVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVzZXJuYW1lPiBcIiR7Z2F0ZXdheS51c2VybmFtZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxwbGF0Zm9ybT4gXCIke2dhdGV3YXkucGxhdGZvcm19XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8dXBkYXRlZHRzPiBcIiR7Z2F0ZXdheS51cGRhdGVkdHN9XCIgLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgR2F0ZXdheSAke2dhdGV3YXkudXVpZH0gJHtnYXRld2F5LnVpZH1gKTtcblxuICAgICAgICAvLyBXaXRoIHRoZSB1cHNlcnQgYXBwcm9hY2gsIGl0IGlzIG5vdCBwb3NzaWJsZSB0byBzZWUgaWYgdGhlIG11dGF0aW9uIG9jY3VycmVkLlxuICAgICAgICAvLyBVc2UgYSBwcmVRdWVyeSBmb3IgdGhlIG9iamVjdCBmaXJzdCB0byBkZXRlcm1pbmUgaWYgaXQgZXhpc3RzLlxuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVHYXRld2F5JywgJ2dhdGV3YXknLCBnYXRld2F5LnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdGVHYXRld2F5JykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIGdhdGV3YXkgJHtnYXRld2F5LnV1aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+ICdnYXRld2F5IHVwZGF0ZWQnKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRHYXRld2F5KGdhdGV3YXk6IEdhdGV3YXksIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXk+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAoZ2F0ZXdheS51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpHYXRld2F5IDxkZ3JhcGgudHlwZT4gXCJHYXRld2F5XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGdhdGV3YXk+IFwiXCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHR5cGU+IFwiZ2F0ZXdheVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8dXVpZD4gXCIke2dhdGV3YXkudXVpZH1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8ZGVzY3JpcHRpb24+IFwiJHtnYXRld2F5LmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxhZGRyZXNzPiBcIiR7Z2F0ZXdheS5hZGRyZXNzfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxyb3V0ZXI+IFwiJHtnYXRld2F5LnJvdXRlcn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8cm91dGVyUG9ydD4gXCIke2dhdGV3YXkucm91dGVyUG9ydH1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8ZGVwbG95TmV0d29yaz4gXCIke2dhdGV3YXkuZGVwbG95TmV0d29ya31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8bGF0aXR1ZGU+IFwiJHtnYXRld2F5LmxhdGl0dWRlfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxsb25naXR1ZGU+IFwiJHtnYXRld2F5LmxvbmdpdHVkZX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8YWNjZXNzVG9rZW4+IFwiJHtnYXRld2F5LmFjY2Vzc1Rva2VufVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx1c2VybmFtZT4gXCIke2dhdGV3YXkudXNlcm5hbWV9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHBsYXRmb3JtPiBcIiR7Z2F0ZXdheS5wbGF0Zm9ybX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8Y3JlYXRlZHRzPiBcIiR7Z2F0ZXdheS5jcmVhdGVkdHN9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHVwZGF0ZWR0cz4gXCIke2dhdGV3YXkudXBkYXRlZHRzfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEFkZCBHYXRld2F5ICR7Z2F0ZXdheS51dWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRHYXRld2F5Jyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ0dhdGV3YXknKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZ2F0ZXdheS51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBnYXRld2F5KSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBnYXRld2F5ICR7Z2F0ZXdheS51aWR9LyR7Z2F0ZXdheS51dWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVHYXRld2F5KGdhdGV3YXlVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ2dhdGV3YXknLCBnYXRld2F5VWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke2dhdGV3YXlVaWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIEdhdGV3YXkgJHtnYXRld2F5VWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICdkZWxldGVHYXRld2F5JywgJ2dhdGV3YXknLCBnYXRld2F5VWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZUdhdGV3YXknKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGRlbGV0ZWQgZ2F0ZXdheSAke2dhdGV3YXlVaWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke2dhdGV3YXlVaWR9IGRlbGV0ZWRgKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRHYXRld2F5QW5kUHJvdG9jb2xzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhnYXRld2F5KSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICB1aWQgdXVpZFxuICAgICAgICBwcm90b2NvbHM6IGdhdGV3YXlfcHJvdG9jb2wge1xuICAgICAgICAgIHVpZCB1dWlkIGNyZWF0ZWQgbW9kaWZpZWQgcHJvdG9jb2xUeXBlIGJyb2tlclVSTFxuICAgICAgICAgIHRvcGljIGNvbnN1bWVyR3JvdXBJZCBjb25uZWN0aW9uVGltZW91dCBzZXNzaW9uVGltZW91dFxuICAgICAgICAgIGluaXRpYWxPZmZzZXQgcmV0cnlCYWNrT2ZmIGZldGNoTWluQnl0ZXMgZmV0Y2hNYXhXYWl0XG4gICAgICAgICAgY29tbWl0SW50ZXJ2YWwgaGVhcnRiZWF0SW50ZXJ2YWwgbWF4aW11bVFPU1xuICAgICAgICAgIHVzZXJuYW1lIHBhc3N3b3JkIGVuY3J5cHRpb25Nb2RlXG4gICAgICAgICAgY2FDZXJ0aWZpY2F0ZSBjbGllbnRDZXJ0aWZpY2F0ZSBjbGllbnRLZXlcbiAgICAgICAgICBhdXRoTW9kZSBzZXJ2ZXJDZXJ0aWZpY2F0ZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBHZXQgR2F0ZXdheSBhbmQgUHJvdG9jb2xzIGZvciAke2dhdGV3YXlOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRHYXRld2F5V2l0aFByb3RvY29scycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBHYXRld2F5IGFuZCBQcm90b2NvbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhbGwgZ2xvYmFsIHByb3RvY29scyBhbmQgdGhlIHByb3RvY29scyBzY29wZWQgZm9yIHRoZSBnYXRld2F5XG4gICAgICogQHBhcmFtIGdhdGV3YXlOYW1lXG4gICAgICovXG4gICAgZ2V0UHJvdG9jb2xzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFByb3RvY29sW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMocHJvdG9jb2wpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoXG4gICAgICAgICAgYWNjb3VudCxcbiAgICAgICl9IEFORCAoZXEoc2NvcGUsIFwiJHtnYXRld2F5TmFtZX1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSkge1xuICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIHByb3RvY29sVHlwZSBicm9rZXJVUkwgdG9waWNcbiAgICAgICAgY29uc3VtZXJHcm91cElkIGNvbm5lY3Rpb25UaW1lb3V0IHNlc3Npb25UaW1lb3V0IGluaXRpYWxPZmZzZXRcbiAgICAgICAgcmV0cnlCYWNrT2ZmIGZldGNoTWluQnl0ZXMgZmV0Y2hNYXhXYWl0IGNvbW1pdEludGVydmFsXG4gICAgICAgIGhlYXJ0YmVhdEludGVydmFsIG1heGltdW1RT1MgdXNlcm5hbWUgcGFzc3dvcmRcbiAgICAgICAgZW5jcnlwdGlvbk1vZGUgY2FDZXJ0aWZpY2F0ZSBjbGllbnRDZXJ0aWZpY2F0ZSBjbGllbnRLZXlcbiAgICAgICAgYXV0aE1vZGUgc2VydmVyQ2VydGlmaWNhdGUgc2NvcGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UHJvdG9jb2xzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBQcm90b2NvbFtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBwcm90b2NvbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZFByb3RvY29sKGdhdGV3YXlVaWQ6IG51bWJlciwgcHJvdG9jb2w6IFByb3RvY29sLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQcm90b2NvbD4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGlmIChwcm90b2NvbC51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpQcm90b2NvbCA8ZGdyYXBoLnR5cGU+IFwiUHJvdG9jb2xcIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHR5cGU+IFwicHJvdG9jb2xcIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHByb3RvY29sPiBcIlwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDx1dWlkPiBcIiR7cHJvdG9jb2wudXVpZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNyZWF0ZWQ+IFwiJHtwcm90b2NvbC5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8bW9kaWZpZWQ+IFwiJHtwcm90b2NvbC5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHByb3RvY29sVHlwZT4gXCIke3Byb3RvY29sLnByb3RvY29sVHlwZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGJyb2tlclVSTD4gXCIke3Byb3RvY29sLmJyb2tlclVSTH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHRvcGljPiBcIiR7cHJvdG9jb2wudG9waWN9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjb25zdW1lckdyb3VwSWQ+IFwiJHtwcm90b2NvbC5jb25zdW1lckdyb3VwSWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjb25uZWN0aW9uVGltZW91dD4gXCIke3Byb3RvY29sLmNvbm5lY3Rpb25UaW1lb3V0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8c2Vzc2lvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5zZXNzaW9uVGltZW91dH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGluaXRpYWxPZmZzZXQ+IFwiJHtwcm90b2NvbC5pbml0aWFsT2Zmc2V0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8cmV0cnlCYWNrT2ZmPiBcIiR7cHJvdG9jb2wucmV0cnlCYWNrT2ZmfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8ZmV0Y2hNaW5CeXRlcz4gXCIke3Byb3RvY29sLmZldGNoTWluQnl0ZXN9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxmZXRjaE1heFdhaXQ+IFwiJHtwcm90b2NvbC5mZXRjaE1heFdhaXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjb21taXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmNvbW1pdEludGVydmFsfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8aGVhcnRiZWF0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5oZWFydGJlYXRJbnRlcnZhbH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPG1heGltdW1RT1M+IFwiJHtwcm90b2NvbC5tYXhpbXVtUU9TfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8dXNlcm5hbWU+IFwiJHtwcm90b2NvbC51c2VybmFtZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHBhc3N3b3JkPiBcIiR7cHJvdG9jb2wucGFzc3dvcmR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxlbmNyeXB0aW9uTW9kZT4gXCIke3Byb3RvY29sLmVuY3J5cHRpb25Nb2RlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y2FDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLmNhQ2VydGlmaWNhdGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjbGllbnRDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLmNsaWVudENlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y2xpZW50S2V5PiBcIiR7cHJvdG9jb2wuY2xpZW50S2V5fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8YXV0aE1vZGU+IFwiJHtwcm90b2NvbC5hdXRoTW9kZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHNlcnZlckNlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuc2VydmVyQ2VydGlmaWNhdGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxzY29wZT4gXCIke3Byb3RvY29sLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEFkZCBwcm90b2NvbCAke3Byb3RvY29sLnV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2FkZFByb3RvY29sJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ1Byb3RvY29sJyk7XG4gICAgICAgICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHByb3RvY29sLnVpZCA9IGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IHByb3RvY29sKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBwcm90b2NvbHMgJHtwcm90b2NvbC51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZVByb3RvY29sKHByb3RvY29sOiBQcm90b2NvbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2w+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncHJvdG9jb2wnLCBwcm90b2NvbC51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cHJvdG9jb2wudWlkfSkpXG4gICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbXV0YXRpb24gQGlmIChlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgIHVpZCh2KSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx1dWlkPiBcIiR7cHJvdG9jb2wudXVpZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPG1vZGlmaWVkPiBcIiR7cHJvdG9jb2wubW9kaWZpZWR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxwcm90b2NvbFR5cGU+IFwiJHtwcm90b2NvbC5wcm90b2NvbFR5cGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxicm9rZXJVUkw+IFwiJHtwcm90b2NvbC5icm9rZXJVUkx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx0b3BpYz4gXCIke3Byb3RvY29sLnRvcGljfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y29uc3VtZXJHcm91cElkPiBcIiR7cHJvdG9jb2wuY29uc3VtZXJHcm91cElkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y29ubmVjdGlvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5jb25uZWN0aW9uVGltZW91dH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHNlc3Npb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuc2Vzc2lvblRpbWVvdXR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxpbml0aWFsT2Zmc2V0PiBcIiR7cHJvdG9jb2wuaW5pdGlhbE9mZnNldH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHJldHJ5QmFja09mZj4gXCIke3Byb3RvY29sLnJldHJ5QmFja09mZn1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGZldGNoTWluQnl0ZXM+IFwiJHtwcm90b2NvbC5mZXRjaE1pbkJ5dGVzfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8ZmV0Y2hNYXhXYWl0PiBcIiR7cHJvdG9jb2wuZmV0Y2hNYXhXYWl0fVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y29tbWl0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5jb21taXRJbnRlcnZhbH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGhlYXJ0YmVhdEludGVydmFsPiBcIiR7cHJvdG9jb2wuaGVhcnRiZWF0SW50ZXJ2YWx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxtYXhpbXVtUU9TPiBcIiR7cHJvdG9jb2wubWF4aW11bVFPU31cIiAuXG4gICAgICAgICAgICB1aWQodikgPHVzZXJuYW1lPiBcIiR7cHJvdG9jb2wudXNlcm5hbWV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxwYXNzd29yZD4gXCIke3Byb3RvY29sLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8ZW5jcnlwdGlvbk1vZGU+IFwiJHtwcm90b2NvbC5lbmNyeXB0aW9uTW9kZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNhQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jYUNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y2xpZW50Q2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jbGllbnRDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNsaWVudEtleT4gXCIke3Byb3RvY29sLmNsaWVudEtleX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGF1dGhNb2RlPiBcIiR7cHJvdG9jb2wuYXV0aE1vZGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzZXJ2ZXJDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLnNlcnZlckNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8c2NvcGU+IFwiJHtwcm90b2NvbC5zY29wZX1cIiAuXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgJHtwcm90b2NvbC51aWR9YCk7XG5cbiAgICAgICAgLy8gV2l0aCB0aGUgdXBzZXJ0IGFwcHJvYWNoLCBpdCBpcyBub3QgcG9zc2libGUgdG8gc2VlIGlmIHRoZSBtdXRhdGlvbiBvY2N1cnJlZC5cbiAgICAgICAgLy8gVXNlIGEgcHJlUXVlcnkgZm9yIHRoZSBvYmplY3QgZmlyc3QgdG8gZGV0ZXJtaW5lIGlmIGl0IGV4aXN0cy5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ3VwZGF0ZVByb3RvY29sJywgJ3Byb3RvY29sJywgcHJvdG9jb2wudWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ3VwZGF0ZVByb3RvY29sJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIHByb3RvY29sICR7cHJvdG9jb2wudWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBwcm90b2NvbCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlUHJvdG9jb2woZ2F0ZXdheVVpZDogbnVtYmVyLCBwcm90b2NvbFVpZDogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncHJvdG9jb2wnLCBwcm90b2NvbFVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtwcm90b2NvbFVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgZGVsZXRlIHtcbiAgICAgICAgICAgICAgICB1aWQodikgKiAqIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIFByb3RvY29sICR7cHJvdG9jb2xVaWR9IGZvciAke2dhdGV3YXlVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZVByb3RvY29sJywgJ3Byb3RvY29sJywgcHJvdG9jb2xVaWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlUHJvdG9jb2wnKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gYCR7cHJvdG9jb2xVaWR9IGRlbGV0ZWRgKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXREYXRhU3RvcmVzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERhdGFTdG9yZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGRhdGFTdG9yZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShcbiAgICAgICAgICBhY2NvdW50LFxuICAgICAgKX0gQU5EIChlcShzY29wZSwgXCIke2dhdGV3YXlOYW1lfVwiKSBPUiBlcShzY29wZSwgXCJHTE9CQUxcIikpKSB7XG4gICAgICAgIHVpZCB1dWlkIGNyZWF0ZWQgbW9kaWZpZWQgZGF0YVN0b3JlVHlwZVxuICAgICAgICBob3N0IHBvcnQgZGF0YWJhc2VOYW1lIHVzZXIgcGFzc3dvcmQgYWNjb3VudE5hbWVcbiAgICAgICAgd2FyZWhvdXNlIGRhdGFiYXNlIHNjaGVtYSBhdXRoVHlwZSB1c2VybmFtZVxuICAgICAgICBjbGllbnRJZCBjbGllbnRTZWNyZXQgYXV0aG9yaXphdGlvbkNvZGVcbiAgICAgICAgcmVkaXJlY3RVUkkgbG9naW5UaW1lb3V0IHVybCBzY29wZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXREYXRhU3RvcmVzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBEYXRhU3RvcmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgZGF0YVN0b3JlcyBmb3IgZ2F0ZXdheSAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGREYXRhU3RvcmUoZ2F0ZXdheVVpZDogbnVtYmVyLCBkYXRhU3RvcmU6IERhdGFTdG9yZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8RGF0YVN0b3JlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKGRhdGFTdG9yZS51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpEYXRhU3RvcmUgPGRncmFwaC50eXBlPiBcIkRhdGFTdG9yZVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHR5cGU+IFwiZGF0YVN0b3JlXCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YVN0b3JlPiBcIlwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHV1aWQ+IFwiJHtkYXRhU3RvcmUudXVpZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjcmVhdGVkPiBcIiR7ZGF0YVN0b3JlLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8bW9kaWZpZWQ+IFwiJHtkYXRhU3RvcmUubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YVN0b3JlVHlwZT4gXCIke2RhdGFTdG9yZS5kYXRhU3RvcmVUeXBlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGhvc3Q+IFwiJHtkYXRhU3RvcmUuaG9zdH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxwb3J0PiBcIiR7ZGF0YVN0b3JlLnBvcnR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YWJhc2VOYW1lPiBcIiR7ZGF0YVN0b3JlLmRhdGFiYXNlTmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1c2VyPiBcIiR7ZGF0YVN0b3JlLnVzZXJ9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8cGFzc3dvcmQ+IFwiJHtkYXRhU3RvcmUucGFzc3dvcmR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8YWNjb3VudE5hbWU+IFwiJHtkYXRhU3RvcmUuYWNjb3VudE5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8d2FyZWhvdXNlPiBcIiR7ZGF0YVN0b3JlLndhcmVob3VzZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxkYXRhYmFzZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8c2NoZW1hPiBcIiR7ZGF0YVN0b3JlLnNjaGVtYX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhdXRoVHlwZT4gXCIke2RhdGFTdG9yZS5hdXRoVHlwZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1c2VybmFtZT4gXCIke2RhdGFTdG9yZS51c2VybmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjbGllbnRJZD4gXCIke2RhdGFTdG9yZS5jbGllbnRJZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjbGllbnRTZWNyZXQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50U2VjcmV0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGF1dGhvcml6YXRpb25Db2RlPiBcIiR7ZGF0YVN0b3JlLmF1dGhvcml6YXRpb25Db2RlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHJlZGlyZWN0VVJJPiBcIiR7ZGF0YVN0b3JlLnJlZGlyZWN0VVJJfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGxvZ2luVGltZW91dD4gXCIke2RhdGFTdG9yZS5sb2dpblRpbWVvdXR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXJsPiBcIiR7ZGF0YVN0b3JlLnVybH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxzY29wZT4gXCIke2RhdGFTdG9yZS5zY29wZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGRlZCBkYXRhc3RvcmUgJHtkYXRhU3RvcmUudXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkRGF0YVN0b3JlJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ0RhdGFTdG9yZScpO1xuICAgICAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgICAgICBkYXRhU3RvcmUudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gZGF0YVN0b3JlKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBkYXRhU3RvcmVzICR7ZGF0YVN0b3JlLnVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlRGF0YVN0b3JlKGRhdGFTdG9yZTogRGF0YVN0b3JlLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxEYXRhU3RvcmU+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnZGF0YVN0b3JlJywgZGF0YVN0b3JlLnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke2RhdGFTdG9yZS51aWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgICAgdXVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBzZXQge1xuICAgICAgICAgICAgICAgIHVpZCh2KSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8dXVpZD4gXCIke2RhdGFTdG9yZS51dWlkfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPG1vZGlmaWVkPiBcIiR7ZGF0YVN0b3JlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGRhdGFTdG9yZVR5cGU+IFwiJHtkYXRhU3RvcmUuZGF0YVN0b3JlVHlwZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxob3N0PiBcIiR7ZGF0YVN0b3JlLmhvc3R9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cG9ydD4gXCIke2RhdGFTdG9yZS5wb3J0fVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGRhdGFiYXNlTmFtZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8dXNlcj4gXCIke2RhdGFTdG9yZS51c2VyfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHBhc3N3b3JkPiBcIiR7ZGF0YVN0b3JlLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGFjY291bnROYW1lPiBcIiR7ZGF0YVN0b3JlLmFjY291bnROYW1lfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHdhcmVob3VzZT4gXCIke2RhdGFTdG9yZS53YXJlaG91c2V9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8ZGF0YWJhc2U+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHNjaGVtYT4gXCIke2RhdGFTdG9yZS5zY2hlbWF9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8YXV0aFR5cGU+IFwiJHtkYXRhU3RvcmUuYXV0aFR5cGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8dXNlcm5hbWU+IFwiJHtkYXRhU3RvcmUudXNlcm5hbWV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8Y2xpZW50SWQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50SWR9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8Y2xpZW50U2VjcmV0PiBcIiR7ZGF0YVN0b3JlLmNsaWVudFNlY3JldH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxhdXRob3JpemF0aW9uQ29kZT4gXCIke2RhdGFTdG9yZS5hdXRob3JpemF0aW9uQ29kZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxyZWRpcmVjdFVSST4gXCIke2RhdGFTdG9yZS5yZWRpcmVjdFVSSX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxsb2dpblRpbWVvdXQ+IFwiJHtkYXRhU3RvcmUubG9naW5UaW1lb3V0fVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVybD4gXCIke2RhdGFTdG9yZS51cmx9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8c2NvcGU+IFwiJHtkYXRhU3RvcmUuc2NvcGV9XCIgLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSBkYXRhU3RvcmUgJHtkYXRhU3RvcmUudWlkfWApO1xuXG4gICAgICAgIC8vIFdpdGggdGhlIHVwc2VydCBhcHByb2FjaCwgaXQgaXMgbm90IHBvc3NpYmxlIHRvIHNlZSBpZiB0aGUgbXV0YXRpb24gb2NjdXJyZWQuXG4gICAgICAgIC8vIFVzZSBhIHByZVF1ZXJ5IGZvciB0aGUgb2JqZWN0IGZpcnN0IHRvIGRldGVybWluZSBpZiBpdCBleGlzdHMuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVEYXRhU3RvcmUnLCAnZGF0YVN0b3JlJywgZGF0YVN0b3JlLnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdGVEYXRhU3RvcmUnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZGF0YVN0b3JlICR7ZGF0YVN0b3JlLnVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gZGF0YVN0b3JlKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVEYXRhU3RvcmUoZ2F0ZXdheVVpZDogbnVtYmVyLCBkYXRhU3RvcmVVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ2RhdGFTdG9yZScsIGRhdGFTdG9yZVVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtkYXRhU3RvcmVVaWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBEYXRhU3RvcmUgJHtkYXRhU3RvcmVVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZURhdGFTdG9yZScsICdkYXRhU3RvcmUnLCBkYXRhU3RvcmVVaWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlRGF0YVN0b3JlJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIGRhdGFTdG9yZSAke2RhdGFTdG9yZVVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gYCR7ZGF0YVN0b3JlVWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheUFuZE1vZGVscyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWRcbiAgICAgICAgbW9kZWxzOiBnYXRld2F5X21vZGVsIHtcbiAgICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIG5hbWVcbiAgICAgICAgICBkZXNjcmlwdGlvbiBpbnB1dFR5cGUgdXJsIHNjb3BlXG4gICAgICAgICAgaW5wdXRUZW1wbGF0ZSBoZWFkZXJzIG1ldGhvZCBiYXNlNjRFbmNvZGVkXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEdldCBHYXRld2F5IGFuZCBQcm90b2NvbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldEdhdGV3YXlBbmRNb2RlbHMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgZ2F0ZXdheXMgYW5kIG1vZGVscyBmb3IgJHtnYXRld2F5TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0TW9kZWxzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPE1vZGVsW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMobW9kZWwpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoXG4gICAgICAgICAgYWNjb3VudCxcbiAgICAgICl9IEFORCAoZXEoc2NvcGUsIFwiJHtnYXRld2F5TmFtZX1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSkge1xuICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIG5hbWVcbiAgICAgICAgZGVzY3JpcHRpb24gaW5wdXRUeXBlIHVybCBzY29wZSBpbnB1dFRlbXBsYXRlXG4gICAgICAgIGhlYWRlcnMgbWV0aG9kIGJhc2U2NEVuY29kZWRcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0TW9kZWxzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBNb2RlbFtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBtb2RlbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZE1vZGVsKGdhdGV3YXlVaWQ6IG51bWJlciwgbW9kZWw6IE1vZGVsLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbD4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGlmIChtb2RlbC51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpNb2RlbCA8ZGdyYXBoLnR5cGU+IFwiTW9kZWxcIiAuXG4gICAgICAgIF86TW9kZWwgPHR5cGU+IFwibW9kZWxcIiAuXG4gICAgICAgIF86TW9kZWwgPG1vZGVsPiBcIlwiIC5cbiAgICAgICAgXzpNb2RlbCA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOk1vZGVsIDx1dWlkPiBcIiR7bW9kZWwudXVpZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPGNyZWF0ZWQ+IFwiJHttb2RlbC5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8bW9kaWZpZWQ+IFwiJHttb2RlbC5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPG5hbWU+IFwiJHttb2RlbC5uYW1lfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8ZGVzY3JpcHRpb24+IFwiJHttb2RlbC5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIF86TW9kZWwgPGlucHV0VHlwZT4gXCIke21vZGVsLmlucHV0VHlwZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPHVybD4gXCIke21vZGVsLnVybH1cIiAuXG4gICAgICAgIF86TW9kZWwgPHNjb3BlPiBcIiR7bW9kZWwuc2NvcGV9XCIgLlxuICAgICAgICBfOk1vZGVsIDxpbnB1dFRlbXBsYXRlPiBcIiR7bW9kZWwuaW5wdXRUZW1wbGF0ZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPGhlYWRlcnM+IFwiJHttb2RlbC5oZWFkZXJzfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8bWV0aG9kPiBcIiR7bW9kZWwubWV0aG9kfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8YmFzZTY0RW5jb2RlZD4gXCIke21vZGVsLmJhc2U2NEVuY29kZWR9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgQWRkIG1vZGVsICR7bW9kZWwudXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkTW9kZWwnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkID0gdGhpcy5nZXRJREZyb21SZXNwb25zZShyZXNwb25zZS5kYXRhLCAnTW9kZWwnKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgbW9kZWwudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gbW9kZWwpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgYWRkZWQgbW9kZWwgJHttb2RlbC51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZU1vZGVsKG1vZGVsOiBNb2RlbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWw+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnbW9kZWwnLCBtb2RlbC51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7bW9kZWwudWlkfSkpXG4gICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICBzZXQge1xuICAgICAgICAgICAgdWlkKHYpIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICB1aWQodikgPHV1aWQ+IFwiJHttb2RlbC51dWlkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bW9kaWZpZWQ+IFwiJHttb2RlbC5tb2RpZmllZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPG5hbWU+IFwiJHttb2RlbC5uYW1lfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8ZGVzY3JpcHRpb24+IFwiJHttb2RlbC5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGlucHV0VHlwZT4gXCIke21vZGVsLmlucHV0VHlwZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHVybD4gXCIke21vZGVsLnVybH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHNjb3BlPiBcIiR7bW9kZWwuc2NvcGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxpbnB1dFRlbXBsYXRlPiBcIiR7bW9kZWwuaW5wdXRUZW1wbGF0ZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGhlYWRlcnM+IFwiJHttb2RlbC5oZWFkZXJzfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bWV0aG9kPiBcIiR7bW9kZWwubWV0aG9kfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8YmFzZTY0RW5jb2RlZD4gXCIke21vZGVsLmJhc2U2NEVuY29kZWR9XCIgLlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSBtb2RlbCAke21vZGVsLnVpZH1gKTtcblxuICAgICAgICAvLyBXaXRoIHRoZSB1cHNlcnQgYXBwcm9hY2gsIGl0IGlzIG5vdCBwb3NzaWJsZSB0byBzZWUgaWYgdGhlIG11dGF0aW9uIG9jY3VycmVkLlxuICAgICAgICAvLyBVc2UgYSBwcmVRdWVyeSBmb3IgdGhlIG9iamVjdCBmaXJzdCB0byBkZXRlcm1pbmUgaWYgaXQgZXhpc3RzLlxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlTW9kZWwnLCAnbW9kZWwnLCBtb2RlbC51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlTW9kZWwnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgbW9kZWwgJHttb2RlbC51aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IG1vZGVsKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVNb2RlbChnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdtb2RlbCcsIG1vZGVsVWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke21vZGVsVWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBkZWxldGUge1xuICAgICAgICAgICAgICAgIHVpZCh2KSAqICogLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBEZWxldGUgTW9kZWwgJHttb2RlbFVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAnZGVsZXRlTW9kZWwnLCAnbW9kZWwnLCBtb2RlbFVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdkZWxldGVNb2RlbCcpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZGVsZXRlZCBtb2RlbCAke21vZGVsVWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgJHttb2RlbFVpZH0gZGVsZXRlZGApLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlBbmRQaXBlbGluZXMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcGlwZWxpbmVfcHJvdG9jb2wgPSBgcHJvdG9jb2w6IHBpcGVsaW5lX3Byb3RvY29sIHtcbiAgICAgICAgdWlkIHV1aWQgYnJva2VyVVJMIHRvcGljIG1heGltdW1RT1MgdXNlcm5hbWUgcGFzc3dvcmQgZW5jcnlwdGlvbk1vZGUgY2FDZXJ0aWZpY2F0ZVxuICAgICAgICBjbGllbnRDZXJ0aWZpY2F0ZSBjbGllbnRLZXkgYXV0aE1vZGUgc2VydmVyQ2VydGlmaWNhdGUgY29uc3VtZXJHcm91cElkIGNvbm5lY3Rpb25UaW1lb3V0XG4gICAgICAgIHNlc3Npb25UaW1lb3V0IHJldHJ5QmFja09mZiBjb21taXRJbnRlcnZhbCBpbml0aWFsT2Zmc2V0IGZldGNoTWluQnl0ZXMgZmV0Y2hNYXhXYWl0IGhlYXJ0YmVhdEludGVydmFsXG4gICAgICB9YDtcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZGF0YXN0b3JlID0gYGRhdGFTdG9yZTogcGlwZWxpbmVfZGF0YXN0b3JlIHtcbiAgICAgICAgdWlkIHV1aWQgaG9zdCBwb3J0IGRhdGFiYXNlTmFtZSB1c2VyIHBhc3N3b3JkIGFjY291bnROYW1lIHdhcmVob3VzZSBkYXRhYmFzZSBzY2hlbWEgYXV0aFR5cGVcbiAgICAgICAgdXNlcm5hbWUgY2xpZW50SWQgY2xpZW50U2VjcmV0IGF1dGhvcml6YXRpb25Db2RlIHJlZGlyZWN0VVJJIGxvZ2luVGltZW91dCB1cmxcbiAgICAgIH1gO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9maWx0ZXIgPSAnZmlsdGVyOiBwaXBlbGluZV9maWx0ZXIgeyB1aWQgZGV2aWNlTmFtZXMgfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3N0cmVhbWluZyA9XG4gICAgICAgICAgICAnc3RyZWFtaW5nOiBwaXBlbGluZV9zdHJlYW1pbmcgeyB1aWQgZGV2aWNlTmFtZSBpbnN0cnVtZW50TmFtZSBmdW5jdGlvbiB3aW5kb3dUeXBlIHdpbmRvd1NpemUgfSc7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWQgYWNjZXNzVG9rZW4gdXNlcm5hbWUgcGxhdGZvcm0gYWRkcmVzcyByb3V0ZXIgcm91dGVyUG9ydCBkZXBsb3lOZXR3b3JrIGRldmljZXNNZXRhZGF0YVxuICAgICAgICBwaXBlbGluZXM6IGdhdGV3YXlfcGlwZWxpbmUge1xuICAgICAgICAgIHVpZCBuYW1lIHV1aWQgcGlwZWxpbmVUeXBlIGRlcGxveWVyVHlwZSBwcm90b2NvbFR5cGUgcHJvdG9jb2xJZCBkYXRhU3RvcmVUeXBlXG4gICAgICAgICAgZGF0YVN0b3JlSWQgY3JlYXRlZCBtb2RpZmllZCBkZXNjcmlwdGlvbiBzdGF0dXMgZmxvd0NvbmZpZ3VyYXRpb25cbiAgICAgICAgICBsb2dMZXZlbCBzdWJzY3JpcHRpb25Ub3BpY1xuICAgICAgICAgICR7cGlwZWxpbmVfcHJvdG9jb2x9XG4gICAgICAgICAgJHtwaXBlbGluZV9kYXRhc3RvcmV9XG4gICAgICAgICAgJHtwaXBlbGluZV9maWx0ZXJ9XG4gICAgICAgICAgJHtwaXBlbGluZV9zdHJlYW1pbmd9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEdldCBHYXRld2F5IGFuZCBQaXBlbGluZXMgZm9yICR7Z2F0ZXdheU5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldEdhdGV3YXlXaXRoUGlwZWxpbmVzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIEdhdGV3YXkgYW5kIHBpcGVsaW5lcyBmb3IgJHtnYXRld2F5TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UGlwZWxpbmVzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFBpcGVsaW5lW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBwaXBlbGluZV9wcm90b2NvbCA9IGBwcm90b2NvbDogcGlwZWxpbmVfcHJvdG9jb2wge1xuICAgICAgICAgICAgICB1aWQgYnJva2VyVVJMIHRvcGljIG1heGltdW1RT1MgdXNlcm5hbWUgcGFzc3dvcmQgZW5jcnlwdGlvbk1vZGUgY2FDZXJ0aWZpY2F0ZVxuICAgICAgICAgICAgICBjbGllbnRDZXJ0aWZpY2F0ZSBjbGllbnRLZXkgYXV0aE1vZGUgc2VydmVyQ2VydGlmaWNhdGUgY29uc3VtZXJHcm91cElkIGNvbm5lY3Rpb25UaW1lb3V0XG4gICAgICAgICAgICAgIHNlc3Npb25UaW1lb3V0IHJldHJ5QmFja09mZiBjb21taXRJbnRlcnZhbCBpbml0aWFsT2Zmc2V0IGZldGNoTWluQnl0ZXMgZmV0Y2hNYXhXYWl0IGhlYXJ0YmVhdEludGVydmFsXG4gIH0gYDtcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZGF0YXN0b3JlID0gYGRhdGFzdG9yZTogcGlwZWxpbmVfZGF0YXN0b3JlIHtcbiAgICAgICAgICAgICAgdWlkIGhvc3QgcG9ydCBkYXRhYmFzZU5hbWUgdXNlciBwYXNzd29yZCBhY2NvdW50TmFtZSB3YXJlaG91c2UgZGF0YWJhc2Ugc2NoZW1hIGF1dGhUeXBlXG4gICAgICAgICAgICAgIHVzZXJuYW1lIGNsaWVudElkIGNsaWVudFNlY3JldCBhdXRob3JpemF0aW9uQ29kZSByZWRpcmVjdFVSSSBsb2dpblRpbWVvdXQgdXJsXG4gICAgICAgICAgICB9YDtcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZmlsdGVyID0gJ2ZpbHRlcjogcGlwZWxpbmVfZmlsdGVyIHt1aWQgZGV2aWNlTmFtZXN9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfc3RyZWFtaW5nID1cbiAgICAgICAgICAgICdzdHJlYW1pbmc6IHBpcGVsaW5lX3N0cmVhbWluZyB7dWlkIGRldmljZU5hbWUgaW5zdHJ1bWVudE5hbWUgZnVuY3Rpb24gd2luZG93VHlwZSB3aW5kb3dTaXplfSc7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhnYXRld2F5KSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICBwaXBlbGluZXMgYXMgZ2F0ZXdheV9waXBlbGluZSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHBpcGVsaW5lcykpIHtcbiAgICAgICAgdWlkIG5hbWUgdXVpZCBwaXBlbGluZVR5cGUgZGVwbG95ZXJUeXBlIHByb3RvY29sVHlwZSBwcm90b2NvbElkXG4gICAgICAgIGRhdGFTdG9yZVR5cGUgZGF0YVN0b3JlSWQgY3JlYXRlZCBtb2RpZmllZCBkZXNjcmlwdGlvbiBzdGF0dXNcbiAgICAgICAgZmxvd0NvbmZpZ3VyYXRpb24gbG9nTGV2ZWwgc3Vic2NyaXB0aW9uVG9waWNcbiAgICAgICAgJHtwaXBlbGluZV9wcm90b2NvbH1cbiAgICAgICAgJHtwaXBlbGluZV9kYXRhc3RvcmV9XG4gICAgICAgICR7cGlwZWxpbmVfZmlsdGVyfVxuICAgICAgICAke3BpcGVsaW5lX3N0cmVhbWluZ31cbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UGlwZWxpbmVzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBQaXBlbGluZVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBwaXBlbGluZXMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZFBpcGVsaW5lKFxuICAgICAgICBnYXRld2F5VWlkOiBudW1iZXIsXG4gICAgICAgIHBpcGVsaW5lOiBQaXBlbGluZSxcbiAgICAgICAgdHJhbnNwb3J0T2JqPzogYW55LFxuICAgICAgICBkYXRhU3RvcmVPYmo/OiBhbnksXG4gICAgICAgIGZpbHRlck9iaj86IGFueSxcbiAgICAgICAgc3RyZWFtaW5nT2JqPzogYW55LFxuICAgICAgICBhY2NvdW50Pzogc3RyaW5nLFxuICAgICk6IE9ic2VydmFibGU8UGlwZWxpbmU+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAocGlwZWxpbmUudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UGlwZWxpbmUgPGRncmFwaC50eXBlPiBcIlBpcGVsaW5lXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPG5hbWU+IFwiJHtwaXBlbGluZS5uYW1lfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8dXVpZD4gXCIke3BpcGVsaW5lLm5hbWV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDx0eXBlPiBcInBpcGVsaW5lXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxwaXBlbGluZT4gXCJcIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHBpcGVsaW5lVHlwZT4gXCIke3BpcGVsaW5lLnBpcGVsaW5lVHlwZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGRlcGxveWVyVHlwZT4gXCIke3BpcGVsaW5lLmRlcGxveWVyVHlwZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGNyZWF0ZWQ+IFwiJHtwaXBlbGluZS5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8bW9kaWZpZWQ+IFwiJHtwaXBlbGluZS5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGRlc2NyaXB0aW9uPiBcIiR7cGlwZWxpbmUuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxzdGF0dXM+IFwiJHtwaXBlbGluZS5zdGF0dXN9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxmbG93Q29uZmlndXJhdGlvbj4gXCIke3BpcGVsaW5lLmZsb3dDb25maWd1cmF0aW9ufVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8bG9nTGV2ZWw+IFwiJHtwaXBlbGluZS5sb2dMZXZlbH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHN1YnNjcmlwdGlvblRvcGljPiBcIiR7cGlwZWxpbmUuc3Vic2NyaXB0aW9uVG9waWN9XCIgLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfcGlwZWxpbmU+IF86UGlwZWxpbmUgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgYWRkIFBpcGVsaW5lICR7cGlwZWxpbmUudWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRQaXBlbGluZScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdQaXBlbGluZScpO1xuICAgICAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgICAgICBwaXBlbGluZS51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwaXBlbGluZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGRlZCBwaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlUGlwZWxpbmUocGlwZWxpbmU6IFBpcGVsaW5lLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdwaXBlbGluZScsIHBpcGVsaW5lLnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtwaXBlbGluZS51aWR9KSlcbiAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgIHNldCB7XG4gICAgICAgICAgICB1aWQodikgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8ZGVzY3JpcHRpb24+IFwiJHtwaXBlbGluZS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHN0YXR1cz4gXCIke3BpcGVsaW5lLnN0YXR1c31cIiAuXG4gICAgICAgICAgICB1aWQodikgPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxmbG93Q29uZmlndXJhdGlvbj4gXCIke3BpcGVsaW5lLmZsb3dDb25maWd1cmF0aW9ufVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bG9nTGV2ZWw+IFwiJHtwaXBlbGluZS5sb2dMZXZlbH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHN1YnNjcmlwdGlvblRvcGljPiBcIiR7cGlwZWxpbmUuc3Vic2NyaXB0aW9uVG9waWN9XCIgLlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGB1cGRhdGUgUGlwZWxpbmUgJHtwaXBlbGluZS51aWR9YCk7XG5cbiAgICAgICAgLy8gV2l0aCB0aGUgdXBzZXJ0IGFwcHJvYWNoLCBpdCBpcyBub3QgcG9zc2libGUgdG8gc2VlIGlmIHRoZSBtdXRhdGlvbiBvY2N1cnJlZC5cbiAgICAgICAgLy8gVXNlIGEgcHJlUXVlcnkgZm9yIHRoZSBvYmplY3QgZmlyc3QgdG8gZGV0ZXJtaW5lIGlmIGl0IGV4aXN0cy5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ3VwZGF0ZVBpcGVsaW5lJywgJ3BpcGVsaW5lJywgcGlwZWxpbmUudWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ3VwZGF0ZVBpcGVsaW5lJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIHBpcGVsaW5lICR7cGlwZWxpbmUudWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBwaXBlbGluZSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlUGlwZWxpbmUoZ2F0ZXdheVVpZDogbnVtYmVyLCBwaXBlbGluZTogUGlwZWxpbmUsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdwaXBlbGluZScsIHBpcGVsaW5lLnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtwaXBlbGluZS51aWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X3BpcGVsaW5lPiA8JHtwaXBlbGluZS51aWR9PiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYGRlbGV0ZSBQaXBlbGluZSAke3BpcGVsaW5lLnVpZH0gd2l0aCBnYXRld2F5ICR7Z2F0ZXdheVVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAnZGVsZXRlUGlwZWxpbmUnLCAncGlwZWxpbmUnLCBwaXBlbGluZS51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlUGlwZWxpbmUnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGRlbGV0ZWQgcGlwZWxpbmUgJHtwaXBlbGluZS51aWR9IHdpdGggZ2F0ZXdheSAke2dhdGV3YXlVaWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGBwaXBlbGluZSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGlkcyBvZiBhbGwgdGhlIHBpcGVsaW5lcyBhc3NvY2lhdGVkIHdpdGggdGhlIHNwZWNpZmllZCBwcm90b2NvbFxuICAgICAqIEBwYXJhbSBwcm90b2NvbFVpZCAtIHRoZSB1aWQgb2YgdGhlIHByb3RvY29sXG4gICAgICovXG4gICAgZ2V0UGlwZWxpbmVJZHNGcm9tUHJvdG9jb2xVaWQocHJvdG9jb2xVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiB1aWQoJHtwcm90b2NvbFVpZH0pKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgIHBpcGVsaW5lcyBhcyB+cGlwZWxpbmVfcHJvdG9jb2wge1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHJlc3AoZnVuYzogdWlkKHBpcGVsaW5lcykpIHtcbiAgICAgICAgdWlkIHV1aWRcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UGlwZWxpbmVJZHNGcm9tUHJvdG9jb2xVaWQnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIFBpcGVsaW5lW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFBpcGVsaW5lW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcGlwZWxpbmUgaWRzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBpZHMgb2YgYWxsIHRoZSBwaXBlbGluZXMgYXNzb2NpYXRlZCB3aXRoIHRoZSBzcGVjaWZpZWQgZGF0YSBzdG9yZVxuICAgICAqIEBwYXJhbSBkYXRhU3RvcmVVaWQgLSB0aGUgdWlkIG9mIHRoZSBkYXRhIHN0b3JlXG4gICAgICovXG4gICAgZ2V0UGlwZWxpbmVJZHNGcm9tRGF0YVN0b3JlVWlkKGRhdGFTdG9yZVVpZDogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IHVpZCgke2RhdGFTdG9yZVVpZH0pKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgIHBpcGVsaW5lcyBhcyB+cGlwZWxpbmVfZGF0YXN0b3JlIHtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFBpcGVsaW5lSWRzRnJvbURhdGFTdG9yZVVpZCcpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnJlc3ApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LnJlc3AgYXMgUGlwZWxpbmVbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgUGlwZWxpbmVbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBwaXBlbGluZSBpZHMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0TW9kZWxDb25maWdzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPE1vZGVsQ29uZmlnW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhnYXRld2F5KSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICBtb2RlbENvbmZpZ3MgYXMgZ2F0ZXdheV9tb2RlbGNvbmZpZyB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKG1vZGVsQ29uZmlncykpIHtcbiAgICAgICAgdWlkIG5hbWUgdXVpZCBkZXNjcmlwdGlvbiBkZXZpY2UgcmVzb3VyY2UgbW9kZWwgY3JlYXRlZCAgbW9kaWZpZWRcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgZ2V0TW9kZWxDb25maWdzIGZvciAke2dhdGV3YXlOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRNb2RlbENvbmZpZ3MnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIE1vZGVsQ29uZmlnW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIE1vZGVsQ29uZmlnW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgbW9kZWxDb25maWdzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRNb2RlbENvbmZpZyhnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsQ29uZmlnOiBNb2RlbENvbmZpZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWxDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAobW9kZWxDb25maWcudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86TW9kZWxDb25maWcgPGRncmFwaC50eXBlPiBcIk1vZGVsQ29uZmlnXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPG5hbWU+IFwiJHttb2RlbENvbmZpZy5uYW1lfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8dXVpZD4gXCIke21vZGVsQ29uZmlnLm5hbWV9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDx0eXBlPiBcIm1vZGVsQ29uZmlnXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxtb2RlbENvbmZpZz4gXCJcIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWxDb25maWcuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxkZXZpY2U+IFwiJHttb2RlbENvbmZpZy5kZXZpY2V9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxyZXNvdXJjZT4gXCIke21vZGVsQ29uZmlnLnJlc291cmNlfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8bW9kZWw+IFwiJHttb2RlbENvbmZpZy5tb2RlbH1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPGNyZWF0ZWQ+IFwiJHttb2RlbENvbmZpZy5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8bW9kaWZpZWQ+IFwiJHttb2RlbENvbmZpZy5tb2RpZmllZH1cIiAuXG4gICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9tb2RlbGNvbmZpZz4gXzpNb2RlbENvbmZpZyAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgbW9kZWxDb25maWcgZm9yIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRNb2RlbENvbmZpZycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdNb2RlbENvbmZpZycpO1xuICAgICAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgICAgICBtb2RlbENvbmZpZy51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBtb2RlbENvbmZpZykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGQgbW9kZWxDb25maWcgZm9yIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVNb2RlbENvbmZpZyhtb2RlbENvbmZpZzogTW9kZWxDb25maWcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPE1vZGVsQ29uZmlnPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ21vZGVsQ29uZmlnJywgbW9kZWxDb25maWcudWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgcXVlcnkge1xuICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHttb2RlbENvbmZpZy51aWR9KSlcbiAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgIHNldCB7XG4gICAgICAgICAgICB1aWQodikgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bmFtZT4gXCIke21vZGVsQ29uZmlnLm5hbWV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx1dWlkPiBcIiR7bW9kZWxDb25maWcudXVpZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWxDb25maWcuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxjb25kRGV2aWNlPiBcIiR7bW9kZWxDb25maWcuZGV2aWNlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y29uZFJlc291cmNlPiBcIiR7bW9kZWxDb25maWcucmVzb3VyY2V9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxtb2RlbD4gXCIke21vZGVsQ29uZmlnLm1vZGVsfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bW9kaWZpZWQ+IFwiJHttb2RlbENvbmZpZy5tb2RpZmllZH1cIiAuXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSBtb2RlbENvbmZpZyAke21vZGVsQ29uZmlnLnVpZH1gKTtcblxuICAgICAgICAvLyBXaXRoIHRoZSB1cHNlcnQgYXBwcm9hY2gsIGl0IGlzIG5vdCBwb3NzaWJsZSB0byBzZWUgaWYgdGhlIG11dGF0aW9uIG9jY3VycmVkLlxuICAgICAgICAvLyBVc2UgYSBwcmVRdWVyeSBmb3IgdGhlIG9iamVjdCBmaXJzdCB0byBkZXRlcm1pbmUgaWYgaXQgZXhpc3RzLlxuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVNb2RlbENvbmZpZycsICdtb2RlbENvbmZpZycsIG1vZGVsQ29uZmlnLnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdHVwZGF0ZU1vZGVsQ29uZmlnZU1vZGVsJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkICBtb2RlbENvbmZpZyAke21vZGVsQ29uZmlnLnVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gbW9kZWxDb25maWcpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGRlbGV0ZU1vZGVsQ29uZmlnKGdhdGV3YXlVaWQ6IG51bWJlciwgbW9kZWxDb25maWdVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ21vZGVsQ29uZmlnJywgbW9kZWxDb25maWdVaWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7bW9kZWxDb25maWdVaWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X21vZGVsY29uZmlnPiA8JHttb2RlbENvbmZpZ1VpZH0+IC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIE1vZGVsQ29uZmlnICR7bW9kZWxDb25maWdVaWR9IGZvciBnYXRld2F5ICR7Z2F0ZXdheVVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAnZGVsZXRlTW9kZWxDb25maWcnLCAnbW9kZWxDb25maWcnLCBtb2RlbENvbmZpZ1VpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdkZWxldGVNb2RlbENvbmZpZycpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZGVsZXRlZCBtb2RlbENvbmZpZyAke21vZGVsQ29uZmlnVWlkfSBmb3IgZ2F0ZXdheSAke2dhdGV3YXlVaWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke21vZGVsQ29uZmlnVWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0RmlsdGVyc0NvbmZpZyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5RmlsdGVyc0NvbmZpZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgZmlsdGVyc0NvbmZpZyBhcyBnYXRld2F5X2ZpbHRlciB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKGZpbHRlcnNDb25maWcpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICBkZXZpY2VOYW1lc1xuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRGaWx0ZXJzQ29uZmlnIGZvciAke2dhdGV3YXlOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRGaWx0ZXJzQ29uZmlncycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnJlc3ApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LnJlc3AgYXMgR2F0ZXdheUZpbHRlcnNDb25maWdbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgR2F0ZXdheUZpbHRlcnNDb25maWdbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBmaWx0ZXJzQ29uZmlnIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRGaWx0ZXJzQ29uZmlnKFxuICAgICAgICBnYXRld2F5VWlkOiBudW1iZXIsXG4gICAgICAgIGZpbHRlcnNDb25maWc6IEdhdGV3YXlGaWx0ZXJzQ29uZmlnLFxuICAgICAgICBhY2NvdW50Pzogc3RyaW5nLFxuICAgICk6IE9ic2VydmFibGU8R2F0ZXdheUZpbHRlcnNDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAoZmlsdGVyc0NvbmZpZy51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpGaWx0ZXIgPGRncmFwaC50eXBlPiBcImZpbHRlclwiIC5cbiAgICAgICAgXzpGaWx0ZXIgPHR5cGU+IFwiZmlsdGVyXCIgLlxuICAgICAgICBfOkZpbHRlciA8ZmlsdGVyPiBcIlwiIC5cbiAgICAgICAgXzpGaWx0ZXIgPGRldmljZU5hbWVzPiBcIiR7ZmlsdGVyc0NvbmZpZy5kZXZpY2VOYW1lc31cIiAuXG4gICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9maWx0ZXI+IF86RmlsdGVyIC5cbiAgICAgICAgPCR7YWNjb3VudH0+IDxhY2NvdW50PiBfOkZpbHRlciAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBhZGQgRmlsdGVyc0NvbmZpZyBmb3IgZ2F0ZXdheSAke2dhdGV3YXlVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2FkZEZpbHRlcnNDb25maWcnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkID0gdGhpcy5nZXRJREZyb21SZXNwb25zZShyZXNwb25zZS5kYXRhLCAnTW9kZWwnKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyc0NvbmZpZy51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBmaWx0ZXJzQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZGVkIGZpbHRlcnNDb25maWcgZm9yIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVGaWx0ZXJzQ29uZmlnKGZpbHRlcnNDb25maWc6IEdhdGV3YXlGaWx0ZXJzQ29uZmlnLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5RmlsdGVyc0NvbmZpZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdmaWx0ZXJDb25maWcnLCBmaWx0ZXJzQ29uZmlnLnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtmaWx0ZXJzQ29uZmlnLnVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgICAgICB1aWQodikgPGRldmljZU5hbWVzPiBcIiR7ZmlsdGVyc0NvbmZpZy5kZXZpY2VOYW1lc31cIiAuXG4gICAgICAgICAgICAgICAgPCR7YWNjb3VudH0+IDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYHVwZGF0ZSBGaWx0ZXJzQ29uZmlnICR7ZmlsdGVyc0NvbmZpZy51aWR9YCk7XG5cbiAgICAgICAgLy8gV2l0aCB0aGUgdXBzZXJ0IGFwcHJvYWNoLCBpdCBpcyBub3QgcG9zc2libGUgdG8gc2VlIGlmIHRoZSBtdXRhdGlvbiBvY2N1cnJlZC5cbiAgICAgICAgLy8gVXNlIGEgcHJlUXVlcnkgZm9yIHRoZSBvYmplY3QgZmlyc3QgdG8gZGV0ZXJtaW5lIGlmIGl0IGV4aXN0cy5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ3VwZGF0ZUZpbHRlcnNDb25maWcnLCAnZmlsdGVyJywgZmlsdGVyc0NvbmZpZy51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlRmlsdGVyc0NvbmZpZycpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBmaWx0ZXJDb25maWcgJHtmaWx0ZXJzQ29uZmlnLnVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gZmlsdGVyc0NvbmZpZyksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IFB5dGhvbiBSZXNvdXJjZXMuXG4gICAgICogQHBhcmFtIGdhdGV3YXlVaWRcbiAgICAgKi9cbiAgICBnZXRQeXRob25SZXNvdXJjZXMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHl0aG9uUmVzb3VyY2VbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAge1xuICAgICAgcmVzcChmdW5jOiB0eXBlKFB5dGhvblJlc291cmNlKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KFxuICAgICAgICAgIGFjY291bnQsXG4gICAgICApfSBBTkQoZXEoc2NvcGUsIFwiJHtnYXRld2F5TmFtZX1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSkge1xuICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIG5hbWUgdHlwZSBzY29wZSBmaWxlQ29udGVudFxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgZ2V0IHB5dGhvbiByZXNvdXJjZSBmcm9tICR7Z2F0ZXdheU5hbWV9YCk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRQeXRob25SZXNvdXJjZScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUHl0aG9uUmVzb3VyY2VbXSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIFB5dGhvbiBSZXNvdXJjZS5cbiAgICAgKiBAcGFyYW0gUHl0aG9uUmVzb3VyY2VcbiAgICAgKi9cbiAgICB1cGRhdGVQeXRob25SZXNvdXJjZShweXRob25SZXNvdXJjZTogUHl0aG9uUmVzb3VyY2UsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFB5dGhvblJlc291cmNlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ3B5dGhvblJlc291cmNlJywgcHl0aG9uUmVzb3VyY2UudWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtweXRob25SZXNvdXJjZS51aWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIHNldCB7XG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgICAgICA8JHtweXRob25SZXNvdXJjZS51aWR9PiA8bW9kaWZpZWQ+IFwiJHtweXRob25SZXNvdXJjZS5tb2RpZmllZH1cIiAuXG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPG5hbWU+IFwiJHtweXRob25SZXNvdXJjZS5uYW1lfVwiIC5cbiAgICAgICAgICAgICAgICA8JHtweXRob25SZXNvdXJjZS51aWR9PiA8c2NvcGU+IFwiJHtweXRob25SZXNvdXJjZS5zY29wZX1cIiAuXG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPHR5cGU+IFwiJHtweXRob25SZXNvdXJjZS50eXBlfVwiIC5cbiAgICAgICAgICAgICAgICA8JHtweXRob25SZXNvdXJjZS51aWR9PiA8ZmlsZUNvbnRlbnQ+IFwiJHtweXRob25SZXNvdXJjZS5maWxlQ29udGVudH1cIiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSBQeXRob25SZXNvdXJjZSAke3B5dGhvblJlc291cmNlLnVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlUHl0aG9uUmVzb3VyY2UnLCAncHl0aG9uUmVzb3VyY2UnLCBweXRob25SZXNvdXJjZS51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlUHl0aG9uUmVzb3VyY2UnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZmlsdGVyQ29uZmlnICR7cHl0aG9uUmVzb3VyY2UudWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBweXRob25SZXNvdXJjZSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWRkIFB5dGhvbiBSZXNvdXJjZS5cbiAgICAgKiBAcGFyYW0gUHl0aG9uUmVzb3VyY2VcbiAgICAgKi9cbiAgICBhZGRQeXRob25SZXNvdXJjZShweXRob25SZXNvdXJjZTogUHl0aG9uUmVzb3VyY2UsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFB5dGhvblJlc291cmNlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKHB5dGhvblJlc291cmNlLnVpZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgYWRkIHdpdGggYW4gSUQnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgIHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPGRncmFwaC50eXBlPiBcIlB5dGhvblJlc291cmNlXCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxweXRob25SZXNvdXJjZT4gXCJcIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPHR5cGU+IFwicHl0aG9uUmVzb3VyY2VcIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8bmFtZT4gXCIke3B5dGhvblJlc291cmNlLm5hbWV9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxjcmVhdGVkPiBcIiR7cHl0aG9uUmVzb3VyY2UuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPG1vZGlmaWVkPiBcIiR7cHl0aG9uUmVzb3VyY2UubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDx0eXBlPiBcIiR7cHl0aG9uUmVzb3VyY2UudHlwZX1cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPGZpbGVDb250ZW50PiBcIiR7cHl0aG9uUmVzb3VyY2UuZmlsZUNvbnRlbnR9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxzY29wZT4gXCIke3B5dGhvblJlc291cmNlLnNjb3BlfVwiIC5cbiAgICAgIH19YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgQWRkIFB5dGhvblJlc291cmNlICR7cHl0aG9uUmVzb3VyY2UubmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkUHl0aG9uUmVzb3VyY2UnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkID0gdGhpcy5nZXRJREZyb21SZXNwb25zZShyZXNwb25zZS5kYXRhLCAnUHl0aG9uUmVzb3VyY2UnKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcHl0aG9uUmVzb3VyY2UudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gcHl0aG9uUmVzb3VyY2UpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgYWRkIHB5dGhvblJlc291cmNlICR7cHl0aG9uUmVzb3VyY2UudWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEZWxldGUgUHl0aG9uIFJlc291cmNlLlxuICAgICAqIEBwYXJhbSByZXNvdXJjZVVpZFxuICAgICAqL1xuICAgIGRlbGV0ZVB5dGhvblJlc291cmNlKHB5dGhvblJlc291cmNlVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdweXRob25SZXNvdXJjZScsIHB5dGhvblJlc291cmNlVWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke3B5dGhvblJlc291cmNlVWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBkZWxldGUge1xuICAgICAgICAgICAgICAgIHVpZCh2KSAqICogLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGAke3B5dGhvblJlc291cmNlVWlkfSBpcyBiZWluZyBkZWxldGVkYCk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICdkZWxldGVQeXRob25SZXNvdXJjZScsICdweXRob25SZXNvdXJjZScsIHB5dGhvblJlc291cmNlVWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZVB5dGhvblJlc291cmNlJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIGZpbHRlckNvbmZpZyAke3B5dGhvblJlc291cmNlVWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgJHtweXRob25SZXNvdXJjZVVpZH0gZGVsZXRlZGApLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFJlYWRpbmdzKGRldmljZU5hbWU6IHN0cmluZywgaW5zdHJ1bWVudE5hbWU6IHN0cmluZywgbnVtUmVhZGluZ3M6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8VFNSZWFkaW5nW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKHJlc291cmNlKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7XG4gICAgICAgIHJlYWRpbmdzIGFzIHJlc291cmNlX3JlYWRpbmcgKGZpcnN0Oi0ke251bVJlYWRpbmdzfSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRSZWFkaW5ncyBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UmVhZGluZ3MnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIFRTUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbXSBhcyBUU1JlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IGNvbnNvbGUubG9nKCdSZXNwb25zZSBmcm9tIGdldFJlYWRpbmdzOiAnLCByZXNwb25zZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc0F0KGRldmljZU5hbWU6IHN0cmluZywgaW5zdHJ1bWVudE5hbWU6IHN0cmluZywgdHM6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8VFNSZWFkaW5nW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKHJlc291cmNlKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7XG4gICAgICAgIHJlYWRpbmdzIGFzIHJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihlcShjcmVhdGVkLCAke3RzfSkpIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocmVhZGluZ3MpLCBvcmRlcmFzYzpjcmVhdGVkKSB7XG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgdmFsdWVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgZ2V0UmVhZGluZ3NBdCBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UmVhZGluZ3NBdCcpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnJlc3ApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LnJlc3AgYXMgVFNSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFRTUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc1N0YXJ0aW5nQXQoXG4gICAgICAgIGRldmljZU5hbWU6IHN0cmluZyxcbiAgICAgICAgaW5zdHJ1bWVudE5hbWU6IHN0cmluZyxcbiAgICAgICAgZnJvbXRzOiBudW1iZXIsXG4gICAgICAgIGFjY291bnQ/OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocmVhZGluZ3MpLCBvcmRlcmFzYzpjcmVhdGVkKSB7XG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgdmFsdWVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgZ2V0UmVhZGluZ3NTdGFydGluZ0F0IGZvciBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UmVhZGluZ3NTdGFydGluZ0F0Jyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBUU1JlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgVFNSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgc3RhcnRlZCBhdCByZWFkaW5ncyBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3NCZXR3ZWVuKFxuICAgICAgICBkZXZpY2VOYW1lOiBzdHJpbmcsXG4gICAgICAgIGluc3RydW1lbnROYW1lOiBzdHJpbmcsXG4gICAgICAgIGZyb210czogbnVtYmVyLFxuICAgICAgICB0b3RzOiBudW1iZXIsXG4gICAgICAgIGFjY291bnQ/OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkgQU5EIGx0KGNyZWF0ZWQsICR7dG90c30pKSAoZmlyc3Q6LTUwMCkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRSZWFkaW5nc0JldHdlZW4gZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFJlYWRpbmdzQmV0d2VlbicpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnJlc3ApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LnJlc3AgYXMgVFNSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFRTUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHJlYWRpbmdzIGJldHdlZW4gZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldExhc3RSZWFkaW5nc0ZvckRldmljZShkZXZpY2VOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRTUmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZGV2aWNlKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2RldmljZU5hbWV9XCIpKSBAbm9ybWFsaXplIHtcbiAgICAgICAgZGV2aWNlX3Jlc291cmNlIHtcbiAgICAgICAgICBuYW1lOiBuYW1lXG4gICAgICAgICAgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LTEpIHtcbiAgICAgICAgICAgIGNyZWF0ZWQ6IGNyZWF0ZWRcbiAgICAgICAgICAgIHZhbHVlOiB2YWx1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRMYXN0UmVhZGluZ3NGb3JEZXZpY2UgZm9yICR7ZGV2aWNlTmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0TGFzdFJlYWRpbmdzRm9yRGV2aWNlJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBUU1JlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgVFNSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgbGFzdCByZWFkaW5ncyBmb3IgJHtkZXZpY2VOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXROb3RpZmljYXRpb25zKGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPE5vdGlmaWNhdGlvbltdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnNvbGUubG9nKCdHZXROb3RpZmljYXRpb25zIHNlcnZpY2UgY2FsbGVkJyk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKG5vdGlmaWNhdGlvbikpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIEBub3JtYWxpemUge1xuICAgICAgICB1aWQgdXVpZDp1dWlkIGNyZWF0ZWQ6Y3JlYXRlZCBub3RpZnlTb3VyY2U6bm90aWZ5U291cmNlIG5vdGlmeURldmljZTpub3RpZnlEZXZpY2VcbiAgICAgICAgbm90aWZ5UmVzb3VyY2U6bm90aWZ5UmVzb3VyY2Ugbm90aWZ5TGV2ZWw6bm90aWZ5TGV2ZWwgdmFsdWU6dmFsdWUgZGVzY3JpcHRpb246ZGVzY3JpcHRpb25cbiAgICAgICAgfmdhdGV3YXlfbm90aWZpY2F0aW9uIHtcbiAgICAgICAgICBnYXRld2F5OiB1dWlkXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0Tm90aWZpY2F0aW9ucycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnJlc3ApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LnJlc3AgYXMgTm90aWZpY2F0aW9uW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIE5vdGlmaWNhdGlvbltdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIG5vdGlmaWNhdGlvbnNgKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0Um91dGUoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogbnVtYmVyW11bXSB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGxldCByb3V0ZSA9IG51bGw7XG5cbiAgICAgICAgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDEnKSB7XG4gICAgICAgICAgICByb3V0ZSA9IHJvdXRlMTtcbiAgICAgICAgfSBlbHNlIGlmIChkZXZpY2VOYW1lID09ICd0cmFpbi0wMDAyJykge1xuICAgICAgICAgICAgcm91dGUgPSByb3V0ZTI7XG4gICAgICAgIH0gZWxzZSBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMycpIHtcbiAgICAgICAgICAgIHJvdXRlID0gcm91dGUzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcm91dGUgPSBlbXB0eVJvdXRlO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJvdXRlO1xuICAgIH1cblxuICAgIGdldFJvdXRlQ2VudGVyKGRldmljZU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IG51bWJlcltdIHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgbGV0IGNlbnRlciA9IG51bGw7XG5cbiAgICAgICAgLy8gMzkuMCAtOTguMCB6b29tIDRcbiAgICAgICAgLy8gRWFzdCAzNC43NjU1ODkgICAtNzguNzA5NDg4XG4gICAgICAgIC8vIFdlc3QgNDAuNDg3NDMyIC0xMjIuODAzMTE2XG5cbiAgICAgICAgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDEnKSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbMzQuMCwgLTk4LjBdO1xuICAgICAgICB9IGVsc2UgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDInKSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbNDAuMCwgLTk4LjBdO1xuICAgICAgICB9IGVsc2UgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDMnKSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbMzkuMCwgLTk4LjBdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2VudGVyID0gWzQyLjgsIDEyLjhdO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGNlbnRlcjtcbiAgICB9XG5cbiAgICBwcml2YXRlIGVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQ/OiBzdHJpbmcpIHtcbiAgICAgICAgaWYgKHRoaXMucmVxdWlyZUFjY291bnRJZCkge1xuICAgICAgICAgICAgaWYgKCFhY2NvdW50KSB0aHJvdyBuZXcgRXJyb3IoJ0FjY291bnQgbXVzdCBleGlzdCcpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZXRBY2NvdW50UXVlcnkoYWNjb3VudD86IHN0cmluZykge1xuICAgICAgICBpZiAodGhpcy5yZXF1aXJlQWNjb3VudElkKSB7XG4gICAgICAgICAgICByZXR1cm4gYGVxKGFjY291bnQsIFwiJHthY2NvdW50fVwiKWA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gYChlcShhY2NvdW50LCBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIikgT1Igbm90KGhhcyhhY2NvdW50KSkpYDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERpc2NvdmVycyB0aGUgcHJlc2VuY2Ugb2YgZXJyb3JzIGluIHRoZSByZXNwb25zZSBmcm9tIGRHcmFwaCBhbmQgcmVwb3J0cyB0aGVtLlxuICAgICAqXG4gICAgICogQHBhcmFtIHJlc3BvbnNlIHRoZSByZXNwb25zZSBvYmplY3QgZnJvbSBkR3JhcGhcbiAgICAgKiBAcGFyYW0gb3BlcmF0aW9uIHRoZSBvcGVyYXRpb24gdGhhdCB3YXMgYmVpbmcgcGVyZm9ybWVkIGZvciBsb2dnaW5nIHB1cnBvc2VzXG4gICAgICovXG4gICAgcHJpdmF0ZSBjaGVja0ZvckVycm9ycyhyZXNwb25zZTogYW55LCBvcGVyYXRpb24gPSAnb3BlcmF0aW9uJykge1xuICAgICAgICBsZXQgaGFzRXJyb3JzID0gZmFsc2U7XG4gICAgICAgIGxldCBlcnJvcnM7XG5cbiAgICAgICAgaWYgKHJlc3BvbnNlPy5kYXRhPy5lcnJvcnMpIHtcbiAgICAgICAgICAgIGhhc0Vycm9ycyA9IHRydWU7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgJHtvcGVyYXRpb259IGZhaWxlZDogJHtyZXNwb25zZS5kYXRhLmVycm9yc1swXS5tZXNzYWdlfWApO1xuICAgICAgICAgICAgZXJyb3JzID0geyBtZXNzYWdlOiByZXNwb25zZS5kYXRhLmVycm9yc1swXS5tZXNzYWdlIH07XG4gICAgICAgIH0gZWxzZSBpZiAocmVzcG9uc2U/LmVycm9ycykge1xuICAgICAgICAgICAgaGFzRXJyb3JzID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke29wZXJhdGlvbn0gZmFpbGVkOiAke3Jlc3BvbnNlLmVycm9yc1swXS5tZXNzYWdlfWApO1xuICAgICAgICAgICAgZXJyb3JzID0geyBtZXNzYWdlOiByZXNwb25zZS5lcnJvcnNbMF0ubWVzc2FnZSB9O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGhhc0Vycm9ycykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKEpTT04uc3RyaW5naWZ5KGVycm9ycykpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSWYgdGhlIG9wZXJhdGlvbiB3YXMgc3VjY2Vzc2Z1bCwgb2J0YWluIGEgVUlEIGZyb20gdGhlIHJlc3BvbnNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIGRHcmFwaFJlc3BvbnNlIEEgcmVzcG9uc2UgZnJvbSBkR3JhcGhcbiAgICAgKiBAcGFyYW0gb2JqZWN0S2V5IHRoZSBuYW1lIG9mIHRoZSBPYmplY3QsIGZvciBleGFtcGxlIEdhdGV3YXkgb3IgTW9kZWxcbiAgICAgKiBAcmV0dXJucyBhIFVJRCBmb3VuZCBmcm9tIHRoZSByZXNwb25zZVxuICAgICAqL1xuICAgIHByaXZhdGUgZ2V0SURGcm9tUmVzcG9uc2UoZEdyYXBoUmVzcG9uc2U6IEdyYXBoUmVzcG9uc2UsIG9iamVjdEtleTogc3RyaW5nKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgaWYgKGRHcmFwaFJlc3BvbnNlLmNvZGUgPT09ICdTdWNjZXNzJykge1xuICAgICAgICAgICAgY29uc3QgdWlkID0gZEdyYXBoUmVzcG9uc2UudWlkc1tvYmplY3RLZXldO1xuICAgICAgICAgICAgcmV0dXJuIHVpZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIHByaXZhdGUgZ2V0UHJlUXVlcnkob2JqZWN0TmFtZTogc3RyaW5nLCB1aWQ6IG51bWJlciB8IHVuZGVmaW5lZCwgYWNjb3VudD86IHN0cmluZykge1xuICAgICAgICBpZiAoIXVpZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKEpTT04uc3RyaW5naWZ5KHsgbWVzc2FnZTogJ05vIElEIGRlZmluZWQnIH0pKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYHtcbiAgICAgICAgcmVzcChmdW5jOiBoYXMoJHtvYmplY3ROYW1lfSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EICh1aWQoJHt1aWR9KSkpIHtcbiAgICAgICAgICB1aWQgdXVpZFxuICAgICAgICB9XG4gICAgICB9YDtcbiAgICB9XG5cbiAgICBwcml2YXRlIGNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2U6IGFueSwgb3BlcmF0aW9uOiBzdHJpbmcsIG9iamVjdE5hbWU6IHN0cmluZywgdWlkOiBudW1iZXIgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgaWYgKCF1aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihKU09OLnN0cmluZ2lmeSh7IG1lc3NhZ2U6ICdObyBJRCBkZWZpbmVkJyB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgb3BlcmF0aW9uKTtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocmVzcG9uc2UuZGF0YS5yZXNwKSkge1xuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2VBcnJheTogW10gPSByZXNwb25zZS5kYXRhLnJlc3A7XG4gICAgICAgICAgICBpZiAocmVzcG9uc2VBcnJheS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgdGhlICR7b2JqZWN0TmFtZX0gd2l0aCBJRCAke3VpZH0gZG9lcyBub3QgZXhpc3QgaW4gdGhpcyBhY2NvdW50YCk7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKEpTT04uc3RyaW5naWZ5KHsgbWVzc2FnZTogJ05vIGV4aXN0aW5nIG9iamVjdCcgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIEdyYXBoUmVzcG9uc2Uge1xuICAgIGNvZGU6IHN0cmluZztcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgcXVlcmllczogYW55O1xuICAgIHVpZHM6IHsgW2luZGV4OiBzdHJpbmddOiBudW1iZXIgfTtcbn1cbiJdfQ==