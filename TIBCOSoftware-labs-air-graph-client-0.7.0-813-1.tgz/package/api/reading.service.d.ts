import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TSReading } from '../model/tSReading';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ReadingService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Get the last TSReadings
     * Get the last TSReadings for a device
     * @param deviceName The name of the Device
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getLastReadingsForDevice(deviceName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<TSReading>>;
    getLastReadingsForDevice(deviceName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<TSReading>>>;
    getLastReadingsForDevice(deviceName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<TSReading>>>;
    /**
     * Get the TSReadings
     * Get the TSReadings for the Device and Instrument
     * @param deviceName The name of the Device
     * @param instrumentName The name of the Instrument
     * @param numReadings The number of readings
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getReadings(deviceName: string, instrumentName: string, numReadings: number, observe?: 'body', reportProgress?: boolean): Observable<Array<TSReading>>;
    getReadings(deviceName: string, instrumentName: string, numReadings: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<TSReading>>>;
    getReadings(deviceName: string, instrumentName: string, numReadings: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<TSReading>>>;
    /**
     * Get the TSReadings at timestamp
     * Get the TSReadings at timestamp for the Device and Instrument
     * @param deviceName The name of the Device
     * @param instrumentName The name of the Instrument
     * @param timestamp The timestamp to get readings at
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getReadingsAt(deviceName: string, instrumentName: string, timestamp: number, observe?: 'body', reportProgress?: boolean): Observable<Array<TSReading>>;
    getReadingsAt(deviceName: string, instrumentName: string, timestamp: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<TSReading>>>;
    getReadingsAt(deviceName: string, instrumentName: string, timestamp: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<TSReading>>>;
    /**
     * Get the TSReadings between timestamps
     * Get the TSReadings starting at timestamp and ending at another timestamp for the Device and Instrument
     * @param deviceName The name of the Device
     * @param instrumentName The name of the Instrument
     * @param fromTimestamp The timestamp to get readings from
     * @param toTimestamp The timestamp to get readings to
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getReadingsBetween(deviceName: string, instrumentName: string, fromTimestamp: number, toTimestamp: number, observe?: 'body', reportProgress?: boolean): Observable<Array<TSReading>>;
    getReadingsBetween(deviceName: string, instrumentName: string, fromTimestamp: number, toTimestamp: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<TSReading>>>;
    getReadingsBetween(deviceName: string, instrumentName: string, fromTimestamp: number, toTimestamp: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<TSReading>>>;
    /**
     * Get the TSReadings starting at timestamp
     * Get the TSReadings starting at timestamp for the Device and Instrument
     * @param deviceName The name of the Device
     * @param instrumentName The name of the Instrument
     * @param fromTimestamp The timestamp to get readings at
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getReadingsStartingAt(deviceName: string, instrumentName: string, fromTimestamp: number, observe?: 'body', reportProgress?: boolean): Observable<Array<TSReading>>;
    getReadingsStartingAt(deviceName: string, instrumentName: string, fromTimestamp: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<TSReading>>>;
    getReadingsStartingAt(deviceName: string, instrumentName: string, fromTimestamp: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<TSReading>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadingService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReadingService>;
}
