import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class RouteService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Get the Route
     * Get the Route associated with the Device Name
     * @param deviceName The name of the Device
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getRoute(deviceName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<number>>;
    getRoute(deviceName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<number>>>;
    getRoute(deviceName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<number>>>;
    /**
     * Get the Route Center
     * Get the Route Center associated with the Device Name
     * @param deviceName The name of the Device
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getRouteCenter(deviceName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<number>>;
    getRouteCenter(deviceName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<number>>>;
    getRouteCenter(deviceName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<number>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RouteService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RouteService>;
}
