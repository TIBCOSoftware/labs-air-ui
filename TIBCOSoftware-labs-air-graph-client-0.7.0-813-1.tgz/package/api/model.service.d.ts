import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Gateway } from '../model/gateway';
import { Model } from '../model/model';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ModelService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a Model
     * Add the Model to a Gateway
     * @param body
     * @param gatewayUid The Uid of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addModel(body: Model, gatewayUid: number, observe?: 'body', reportProgress?: boolean): Observable<Model>;
    addModel(body: Model, gatewayUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Model>>;
    addModel(body: Model, gatewayUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Model>>;
    /**
     * Delete a Model from a Gateway
     * Delete a Model from an existing Gateway
     * @param gatewayUid GatewayUid to reference
     * @param modelUid ModelUid to delete
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteModel(gatewayUid: number, modelUid: number, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deleteModel(gatewayUid: number, modelUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deleteModel(gatewayUid: number, modelUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the Gateway and its Models
     * Get the Gateway and the associated Models
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGatewayAndModels(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Gateway>>;
    getGatewayAndModels(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Gateway>>>;
    getGatewayAndModels(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Gateway>>>;
    /**
     * Get the Models for a Gateway
     * Get the Gateway and the associated Models
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getModels(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Model>>;
    getModels(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Model>>>;
    getModels(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Model>>>;
    /**
     * Update a Model
     * Update a Model
     * @param body The Model to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateModel(body: Model, observe?: 'body', reportProgress?: boolean): Observable<Model>;
    updateModel(body: Model, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Model>>;
    updateModel(body: Model, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Model>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ModelService>;
}
