import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ModelConfig } from '../model/modelConfig';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ModelConfigService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a ModelConfig
     * Add the ModelConfig to a Gateway
     * @param body
     * @param gatewayUid The Uid of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addModelConfig(body: ModelConfig, gatewayUid: number, observe?: 'body', reportProgress?: boolean): Observable<ModelConfig>;
    addModelConfig(body: ModelConfig, gatewayUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ModelConfig>>;
    addModelConfig(body: ModelConfig, gatewayUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ModelConfig>>;
    /**
     *  Delete the ModelConfig with the Uid
     * Delete the ModelConfig from the Gateway if it exists
     * @param gatewayUid The UID of the Gateway to be deleted
     * @param modelConfigUid The UID of the ModelConfig to be deleted
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteModelConfig(gatewayUid: number, modelConfigUid: number, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deleteModelConfig(gatewayUid: number, modelConfigUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deleteModelConfig(gatewayUid: number, modelConfigUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the ModeConfig
     * Get the ModelConfig associated with the Gateway
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getModelConfigs(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<ModelConfig>>;
    getModelConfigs(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ModelConfig>>>;
    getModelConfigs(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ModelConfig>>>;
    /**
     * Update a ModelConfig
     * Update a ModelConfig
     * @param body The ModelConfig to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateModelConfig(body: ModelConfig, observe?: 'body', reportProgress?: boolean): Observable<ModelConfig>;
    updateModelConfig(body: ModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ModelConfig>>;
    updateModelConfig(body: ModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelConfigService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ModelConfigService>;
}
