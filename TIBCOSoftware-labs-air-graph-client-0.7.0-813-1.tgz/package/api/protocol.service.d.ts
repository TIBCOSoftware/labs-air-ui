import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Gateway } from '../model/gateway';
import { Protocol } from '../model/protocol';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ProtocolService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a Protocol to an existing Gateway
     * Add a Protocol to an existing Gateway if it exists
     * @param body
     * @param gatewayUid The Uid of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addProtocol(body: Protocol, gatewayUid: number, observe?: 'body', reportProgress?: boolean): Observable<Protocol>;
    addProtocol(body: Protocol, gatewayUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Protocol>>;
    addProtocol(body: Protocol, gatewayUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Protocol>>;
    /**
     * Delete a Protocol from a Gateway
     * Delete a Protocol from an existing Gateway
     * @param gatewayUid GatewayUid to reference
     * @param protocolUid ProtocolUid to delete
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteProtocol(gatewayUid: number, protocolUid: number, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deleteProtocol(gatewayUid: number, protocolUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deleteProtocol(gatewayUid: number, protocolUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the all Gateways and Protocols
     * Get all of the known Gateways with their Protocols
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGatewayAndProtocols(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Gateway>>;
    getGatewayAndProtocols(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Gateway>>>;
    getGatewayAndProtocols(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Gateway>>>;
    /**
     * Get the all Protocols for a Gateway
     * Get all of the known Protocols for a Gateway
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getProtocols(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Protocol>>;
    getProtocols(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Protocol>>>;
    getProtocols(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Protocol>>>;
    /**
     * Update a Protocol
     * Update a Protocol
     * @param body The Protocol to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateProtocol(body: Protocol, observe?: 'body', reportProgress?: boolean): Observable<Protocol>;
    updateProtocol(body: Protocol, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Protocol>>;
    updateProtocol(body: Protocol, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Protocol>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProtocolService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProtocolService>;
}
