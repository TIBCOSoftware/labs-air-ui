import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GatewayFiltersConfig } from '../model/gatewayFiltersConfig';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class FilterConfigService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a GatewayFiltersConfig
     * Add the GatewayFiltersConfig to a Gateway
     * @param body
     * @param gatewayUid The Uid of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addFiltersConfig(body: GatewayFiltersConfig, gatewayUid: number, observe?: 'body', reportProgress?: boolean): Observable<GatewayFiltersConfig>;
    addFiltersConfig(body: GatewayFiltersConfig, gatewayUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GatewayFiltersConfig>>;
    addFiltersConfig(body: GatewayFiltersConfig, gatewayUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GatewayFiltersConfig>>;
    /**
     * Get the GatewayFiltersConfig
     * Get the GatewayFiltersConfig associated with the Gateway
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getFiltersConfig(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GatewayFiltersConfig>>;
    getFiltersConfig(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GatewayFiltersConfig>>>;
    getFiltersConfig(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GatewayFiltersConfig>>>;
    /**
     * Update a GatewayFiltersConfig
     * Update a GatewayFiltersConfig
     * @param body The GatewayFiltersConfig to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateFiltersConfig(body: GatewayFiltersConfig, observe?: 'body', reportProgress?: boolean): Observable<GatewayFiltersConfig>;
    updateFiltersConfig(body: GatewayFiltersConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GatewayFiltersConfig>>;
    updateFiltersConfig(body: GatewayFiltersConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GatewayFiltersConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterConfigService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FilterConfigService>;
}
