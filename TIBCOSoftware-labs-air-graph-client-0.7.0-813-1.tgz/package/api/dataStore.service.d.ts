import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DataStore } from '../model/dataStore';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class DataStoreService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a DataStore
     * Add the DataStores to a Gateway
     * @param body
     * @param gatewayUid The Uid of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addDataStore(body: DataStore, gatewayUid: number, observe?: 'body', reportProgress?: boolean): Observable<DataStore>;
    addDataStore(body: DataStore, gatewayUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DataStore>>;
    addDataStore(body: DataStore, gatewayUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DataStore>>;
    /**
     * Delete a DataStore from a Gateway
     * Delete a DataStore from an existing Gateway
     * @param gatewayUid GatewayUid to reference
     * @param dataStoreUid DataStoreUid to delete
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteDataStore(gatewayUid: number, dataStoreUid: number, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deleteDataStore(gatewayUid: number, dataStoreUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deleteDataStore(gatewayUid: number, dataStoreUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get DataStores
     * Get the DataStores for a Gateway
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDataStores(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<DataStore>>;
    getDataStores(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<DataStore>>>;
    getDataStores(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<DataStore>>>;
    /**
     * Update a DataStore
     * Update a DataStore
     * @param body The DataStore to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateDataStore(body: DataStore, observe?: 'body', reportProgress?: boolean): Observable<DataStore>;
    updateDataStore(body: DataStore, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DataStore>>;
    updateDataStore(body: DataStore, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DataStore>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataStoreService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DataStoreService>;
}
