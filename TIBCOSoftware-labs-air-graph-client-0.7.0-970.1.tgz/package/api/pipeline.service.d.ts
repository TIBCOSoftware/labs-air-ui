import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Gateway } from '../model/gateway';
import { Pipeline } from '../model/pipeline';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class PipelineService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a Pipeline
     * Add the Pipeline to a Gateway
     * @param body The Pipeline to add
     * @param gatewayUuid The UUID of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addPipeline(body: Pipeline, gatewayUuid: number, observe?: 'body', reportProgress?: boolean): Observable<Pipeline>;
    addPipeline(body: Pipeline, gatewayUuid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Pipeline>>;
    addPipeline(body: Pipeline, gatewayUuid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Pipeline>>;
    /**
     * Delete the Pipeline with the UUID
     * Delete the Pipeline with the UUID if it exists
     * @param gatewayUuid The UUID of the Gateway to be reference
     * @param pipelineUuid The UUID of the Gateway to be reference
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deletePipeline(gatewayUuid: number, pipelineUuid: number, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deletePipeline(gatewayUuid: number, pipelineUuid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deletePipeline(gatewayUuid: number, pipelineUuid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the Gateways with the Pipeline
     * Get the Gateways and the associated Pipeline
     * @param gatewayUuid The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGatewayAndPipelines(gatewayUuid: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Gateway>>;
    getGatewayAndPipelines(gatewayUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Gateway>>>;
    getGatewayAndPipelines(gatewayUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Gateway>>>;
    /**
     * Get the Pipeline
     * Get the Pipeline associated with the Gateway
     * @param gatewayUuid The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPipelines(gatewayUuid: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Pipeline>>;
    getPipelines(gatewayUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Pipeline>>>;
    getPipelines(gatewayUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Pipeline>>>;
    /**
     * Update a Pipeline
     * Update a Pipeline
     * @param body The Pipeline to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updatePipeline(body: Pipeline, observe?: 'body', reportProgress?: boolean): Observable<Pipeline>;
    updatePipeline(body: Pipeline, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Pipeline>>;
    updatePipeline(body: Pipeline, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Pipeline>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PipelineService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PipelineService>;
}
