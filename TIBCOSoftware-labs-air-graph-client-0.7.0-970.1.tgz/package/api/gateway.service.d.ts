import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Gateway } from '../model/gateway';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GatewayService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a new Gateway
     * Adds a new Gateway
     * @param body The Gateway to add
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addGateway(body: Gateway, observe?: 'body', reportProgress?: boolean): Observable<Gateway>;
    addGateway(body: Gateway, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Gateway>>;
    addGateway(body: Gateway, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Gateway>>;
    /**
     *  Delete the Gateway with the UUid
     * Delete the Gateway with the UUid if it exists
     * @param gatewayUuid The UUID of the Gateway to be deleted
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGateway(gatewayUuid: number, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deleteGateway(gatewayUuid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deleteGateway(gatewayUuid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the Gateways by uuid
     * Get the Gateways by uuid
     * @param gatewayUuid The UUID of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGateway(gatewayUuid: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Gateway>>;
    getGateway(gatewayUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Gateway>>>;
    getGateway(gatewayUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Gateway>>>;
    /**
     * Get the all Gateways
     * Get all of the known Gateways
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGateways(observe?: 'body', reportProgress?: boolean): Observable<Array<Gateway>>;
    getGateways(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Gateway>>>;
    getGateways(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Gateway>>>;
    /**
     * Update an existing Gateway
     * Update an existing Gateway if it exists
     * @param body The Gateway to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGateway(body: Gateway, observe?: 'body', reportProgress?: boolean): Observable<string>;
    updateGateway(body: Gateway, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    updateGateway(body: Gateway, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GatewayService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GatewayService>;
}
