import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PythonResource } from '../model/pythonResource';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class PythonResourceService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a python resource to an existing Gateway
     * Add a python resource to an existing Gateway if it exists
     * @param body
     * @param gatewayUuid The UUID of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addPythonResource(body: PythonResource, gatewayUuid: string, observe?: 'body', reportProgress?: boolean): Observable<PythonResource>;
    addPythonResource(body: PythonResource, gatewayUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PythonResource>>;
    addPythonResource(body: PythonResource, gatewayUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PythonResource>>;
    /**
     * Delete a resource from a Gateway
     * Delete a resource from an existing Gateway
     * @param pythonResourceUuid pythonResourceUuid to delete
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deletePythonResource(pythonResourceUuid: string, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deletePythonResource(pythonResourceUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deletePythonResource(pythonResourceUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the all python resources for a Gateway
     * Get all of the known python resources for a Gateway
     * @param gatewayUuid The UUID of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPythonResources(gatewayUuid: string, observe?: 'body', reportProgress?: boolean): Observable<Array<PythonResource>>;
    getPythonResources(gatewayUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<PythonResource>>>;
    getPythonResources(gatewayUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<PythonResource>>>;
    /**
     * Update a python resource
     * Update a python resource
     * @param body The python resource to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updatePythonResource(body: PythonResource, observe?: 'body', reportProgress?: boolean): Observable<PythonResource>;
    updatePythonResource(body: PythonResource, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PythonResource>>;
    updatePythonResource(body: PythonResource, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PythonResource>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PythonResourceService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PythonResourceService>;
}
