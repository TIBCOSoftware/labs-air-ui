import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Notification } from '../model/notification';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class NotificationService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a Notification
     * Add the Notification
     * @param body
     * @param gatewayUuid The UUID of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addNotification(body: Notification, gatewayUuid: string, observe?: 'body', reportProgress?: boolean): Observable<Notification>;
    addNotification(body: Notification, gatewayUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Notification>>;
    addNotification(body: Notification, gatewayUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Notification>>;
    /**
     * Delete a Notification from a Gateway
     * Delete a Notification from an existing Gateway
     * @param gatewayUuid gatewayUuid to reference
     * @param notificationUuid notificationUuid to reference
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteNotification(gatewayUuid: number, notificationUuid: string, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deleteNotification(gatewayUuid: number, notificationUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deleteNotification(gatewayUuid: number, notificationUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the Notifications
     * Get the Notifications
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getNotifications(observe?: 'body', reportProgress?: boolean): Observable<Array<Notification>>;
    getNotifications(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Notification>>>;
    getNotifications(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Notification>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotificationService>;
}
