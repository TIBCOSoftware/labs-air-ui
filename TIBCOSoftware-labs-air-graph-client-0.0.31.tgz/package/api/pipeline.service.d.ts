import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Gateway } from '../model/gateway';
import { Pipeline } from '../model/pipeline';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class PipelineService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a Pipeline
     * Add the Pipeline to a Gateway
     * @param body The Pipeline to add
     * @param gatewayUid The Uid of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addPipeline(body: Pipeline, gatewayUid: number, observe?: 'body', reportProgress?: boolean): Observable<Pipeline>;
    addPipeline(body: Pipeline, gatewayUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Pipeline>>;
    addPipeline(body: Pipeline, gatewayUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Pipeline>>;
    /**
     *  Delete the Pipeline with the Uid
     * Delete the Pipeline with the Uid if it exists
     * @param body
     * @param gatewayUid The UID of the Gateway to be reference
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deletePipeline(body: Pipeline, gatewayUid: number, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deletePipeline(body: Pipeline, gatewayUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deletePipeline(body: Pipeline, gatewayUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the Gateways with the Pipeline
     * Get the Gateways and the associated Pipeline
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGatewayAndPipelines(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Gateway>>;
    getGatewayAndPipelines(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Gateway>>>;
    getGatewayAndPipelines(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Gateway>>>;
    /**
     * Get the Pipelines associated with a DataStore Uid
     * Get the Pipelines association with a DataStore Uid
     * @param dataStoreUid The DataStore Uid to be referenced
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPipelineIdsFromDataStoreUid(dataStoreUid: number, observe?: 'body', reportProgress?: boolean): Observable<Array<Pipeline>>;
    getPipelineIdsFromDataStoreUid(dataStoreUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Pipeline>>>;
    getPipelineIdsFromDataStoreUid(dataStoreUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Pipeline>>>;
    /**
     * Get the Pipelines associated with a Protocol Uid
     * Get the Pipelines association with a Protocol Uid
     * @param protocolUid The Protocol Uid to be referenced
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPipelineIdsFromProtocolUid(protocolUid: number, observe?: 'body', reportProgress?: boolean): Observable<Array<Pipeline>>;
    getPipelineIdsFromProtocolUid(protocolUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Pipeline>>>;
    getPipelineIdsFromProtocolUid(protocolUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Pipeline>>>;
    /**
     * Get the Pipeline
     * Get the Pipeline associated with the Gateway
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPipelines(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Pipeline>>;
    getPipelines(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Pipeline>>>;
    getPipelines(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Pipeline>>>;
    /**
     * Update a Pipeline
     * Update a Pipeline
     * @param body The Pipeline to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updatePipeline(body: Pipeline, observe?: 'body', reportProgress?: boolean): Observable<Pipeline>;
    updatePipeline(body: Pipeline, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Pipeline>>;
    updatePipeline(body: Pipeline, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Pipeline>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PipelineService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PipelineService>;
}
