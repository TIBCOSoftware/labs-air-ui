import { map, switchMap, tap } from 'rxjs';
const httpOptions = {
    headers: {
        'Content-Type': 'application/graphql+-',
    },
};
const httpMutateOptions = {
    headers: { 'Content-Type': 'application/rdf' },
};
export class GraphService {
    constructor(http, dGraphUrl, accountRequired) {
        this.http = http;
        this.requireAccountId = true;
        this.dGraphUrl = dGraphUrl;
        this.requireAccountId = accountRequired;
        //const dGraphBasicAuthEnabled = this.appConfigService.dGraphBasicAuthEnabled;
        //if (dGraphBasicAuthEnabled) {
        //    const dGraphBasicAuth = this.appConfigService.dGraphBasicAuth;
        //    (this.httpOptions.headers = { 'Content-Type': 'application/graphql+-' }), { Authorization: dGraphBasicAuth };
        //    (this.httpMutateOptions.headers = { 'Content-Type': 'application/rdf' }), { Authorization: dGraphBasicAuth };
        //}
    }
    getGateway(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        console.log(`GetGateway service called for ${gatewayUuid}`);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayUuid}")) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGateway');
        }), map((response) => response.data.resp));
    }
    getGateways(account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway))
      @filter(${this.getAccountQuery(account)}) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
        numDevices: count(gateway_device)
        }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGateways');
        }), map((response) => response.data.resp), tap((response) => console.log(`fetched ${response.length} gateways`)));
    }
    updateGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('gateway', gateway.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
              var(func: uid(${gateway.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <account> "${account ? account : ''}" .
                uid(v) <address> "${gateway.address}" .
                uid(v) <router> "${gateway.router}" .
                uid(v) <routerPort> "${gateway.routerPort}" .
                uid(v) <deployNetwork> "${gateway.deployNetwork}" .
                uid(v) <description> "${gateway.description}" .
                uid(v) <latitude> "${gateway.latitude}" .
                uid(v) <longitude> "${gateway.longitude}" .
                uid(v) <accessToken> "${gateway.accessToken}" .
                uid(v) <username> "${gateway.username}" .
                uid(v) <platform> "${gateway.platform}" .
                uid(v) <updatedts> "${gateway.updatedts}" .
              }
            }
          }`;
        console.log(`Update Gateway ${gateway.uuid} ${gateway.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateGateway', 'gateway', gateway.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateGateway')), tap(() => console.log(`updated gateway ${gateway.uuid}`)), map(() => 'gateway updated'));
    }
    addGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        if (gateway.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Gateway <dgraph.type> "Gateway" .
        _:Gateway <gateway> "" .
        _:Gateway <type> "gateway" .
        _:Gateway <account> "${account ? account : ''}" .
        _:Gateway <uuid> "${gateway.uuid}" .
        _:Gateway <description> "${gateway.description}" .
        _:Gateway <address> "${gateway.address}" .
        _:Gateway <router> "${gateway.router}" .
        _:Gateway <routerPort> "${gateway.routerPort}" .
        _:Gateway <deployNetwork> "${gateway.deployNetwork}" .
        _:Gateway <latitude> "${gateway.latitude}" .
        _:Gateway <longitude> "${gateway.longitude}" .
        _:Gateway <accessToken> "${gateway.accessToken}" .
        _:Gateway <username> "${gateway.username}" .
        _:Gateway <platform> "${gateway.platform}" .
        _:Gateway <createdts> "${gateway.createdts}" .
        _:Gateway <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log(`Add Gateway ${gateway.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addGateway');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Gateway');
            if (id) {
                gateway.uid = id;
            }
        }), map((response) => (response.data.resp = gateway)), tap(() => console.log(`add gateway ${gateway.uid}/${gateway.uuid}`)));
    }
    deleteGateway(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('gateway', gatewayUuid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${gatewayUuid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Gateway ${gatewayUuid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteGateway', 'gateway', gatewayUuid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteGateway')), tap(() => console.log(`deleted gateway ${gatewayUuid}`)), map(() => `${gatewayUuid} deleted`));
    }
    getGatewayAndProtocols(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayUuid}")) {
        uid uuid
        protocols: gateway_protocol {
          uid uuid created modified protocolType brokerURL
          topic consumerGroupId connectionTimeout sessionTimeout
          initialOffset retryBackOff fetchMinBytes fetchMaxWait
          commitInterval heartbeatInterval maximumQOS
          username password encryptionMode
          caCertificate clientCertificate clientKey
          authMode serverCertificate
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayUuid}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayWithProtocols');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and Protocols for ${gatewayUuid}`)));
    }
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayUuid
     * @param account
     */
    getProtocols(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(protocol)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayUuid}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified protocolType brokerURL topic
        consumerGroupId connectionTimeout sessionTimeout initialOffset
        retryBackOff fetchMinBytes fetchMaxWait commitInterval
        heartbeatInterval maximumQOS username password
        encryptionMode caCertificate clientCertificate clientKey
        authMode serverCertificate scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getProtocols');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched protocols for ${gatewayUuid}`)));
    }
    addProtocol(gatewayUid, protocol, account) {
        this.ensureAccountAuthorized(account);
        if (protocol.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Protocol <dgraph.type> "Protocol" .
        _:Protocol <type> "protocol" .
        _:Protocol <protocol> "" .
        _:Protocol <account> "${account ? account : ''}" .
        _:Protocol <uuid> "${protocol.uuid}" .
        _:Protocol <created> "${protocol.created}" .
        _:Protocol <modified> "${protocol.modified}" .
        _:Protocol <protocolType> "${protocol.protocolType}" .
        _:Protocol <brokerURL> "${protocol.brokerURL}" .
        _:Protocol <topic> "${protocol.topic}" .
        _:Protocol <consumerGroupId> "${protocol.consumerGroupId}" .
        _:Protocol <connectionTimeout> "${protocol.connectionTimeout}" .
        _:Protocol <sessionTimeout> "${protocol.sessionTimeout}" .
        _:Protocol <initialOffset> "${protocol.initialOffset}" .
        _:Protocol <retryBackOff> "${protocol.retryBackOff}" .
        _:Protocol <fetchMinBytes> "${protocol.fetchMinBytes}" .
        _:Protocol <fetchMaxWait> "${protocol.fetchMaxWait}" .
        _:Protocol <commitInterval> "${protocol.commitInterval}" .
        _:Protocol <heartbeatInterval> "${protocol.heartbeatInterval}" .
        _:Protocol <maximumQOS> "${protocol.maximumQOS}" .
        _:Protocol <username> "${protocol.username}" .
        _:Protocol <password> "${protocol.password}" .
        _:Protocol <encryptionMode> "${protocol.encryptionMode}" .
        _:Protocol <caCertificate> "${protocol.caCertificate}" .
        _:Protocol <clientCertificate> "${protocol.clientCertificate}" .
        _:Protocol <clientKey> "${protocol.clientKey}" .
        _:Protocol <authMode> "${protocol.authMode}" .
        _:Protocol <serverCertificate> "${protocol.serverCertificate}" .
        _:Protocol <scope> "${protocol.scope}" .
      }
    }`;
        console.log(`Add protocol ${protocol.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addProtocol');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Protocol');
            if (id) {
                protocol.uid = id;
            }
        }), map((response) => (response.data.resp = protocol)), tap(() => console.log(`add protocols ${protocol.uid}`)));
    }
    updateProtocol(protocol, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('protocol', protocol.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${protocol.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if (eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <uuid> "${protocol.uuid}" .
            uid(v) <modified> "${protocol.modified}" .
            uid(v) <protocolType> "${protocol.protocolType}" .
            uid(v) <brokerURL> "${protocol.brokerURL}" .
            uid(v) <topic> "${protocol.topic}" .
            uid(v) <consumerGroupId> "${protocol.consumerGroupId}" .
            uid(v) <connectionTimeout> "${protocol.connectionTimeout}" .
            uid(v) <sessionTimeout> "${protocol.sessionTimeout}" .
            uid(v) <initialOffset> "${protocol.initialOffset}" .
            uid(v) <retryBackOff> "${protocol.retryBackOff}" .
            uid(v) <fetchMinBytes> "${protocol.fetchMinBytes}" .
            uid(v) <fetchMaxWait> "${protocol.fetchMaxWait}" .
            uid(v) <commitInterval> "${protocol.commitInterval}" .
            uid(v) <heartbeatInterval> "${protocol.heartbeatInterval}" .
            uid(v) <maximumQOS> "${protocol.maximumQOS}" .
            uid(v) <username> "${protocol.username}" .
            uid(v) <password> "${protocol.password}" .
            uid(v) <encryptionMode> "${protocol.encryptionMode}" .
            uid(v) <caCertificate> "${protocol.caCertificate}" .
            uid(v) <clientCertificate> "${protocol.clientCertificate}" .
            uid(v) <clientKey> "${protocol.clientKey}" .
            uid(v) <authMode> "${protocol.authMode}" .
            uid(v) <serverCertificate> "${protocol.serverCertificate}" .
            uid(v) <scope> "${protocol.scope}" .
          }
        }
    }`;
        console.log(`Update ${protocol.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateProtocol', 'protocol', protocol.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateProtocol')), tap(() => console.log(`updated protocol ${protocol.uid}`)), map(() => protocol));
    }
    deleteProtocol(gatewayUid, protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('protocol', protocolUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${protocolUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Protocol ${protocolUid} for ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteProtocol', 'protocol', protocolUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteProtocol')), map(() => `${protocolUid} deleted`));
    }
    getDataStores(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(dataStore)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayUuid}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified dataStoreType
        host port databaseName user password accountName
        warehouse database schema authType username
        clientId clientSecret authorizationCode
        redirectURI loginTimeout url scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getDataStores');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched dataStores for gateway ${gatewayUuid}`)));
    }
    addDataStore(gatewayUid, dataStore, account) {
        this.ensureAccountAuthorized(account);
        if (dataStore.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:DataStore <dgraph.type> "DataStore" .
        _:DataStore <type> "dataStore" .
        _:DataStore <dataStore> "" .
        _:DataStore <account> "${account ? account : ''}" .
        _:DataStore <uuid> "${dataStore.uuid}" .
        _:DataStore <created> "${dataStore.created}" .
        _:DataStore <modified> "${dataStore.modified}" .
        _:DataStore <dataStoreType> "${dataStore.dataStoreType}" .
        _:DataStore <host> "${dataStore.host}" .
        _:DataStore <port> "${dataStore.port}" .
        _:DataStore <databaseName> "${dataStore.databaseName}" .
        _:DataStore <user> "${dataStore.user}" .
        _:DataStore <password> "${dataStore.password}" .
        _:DataStore <accountName> "${dataStore.accountName}" .
        _:DataStore <warehouse> "${dataStore.warehouse}" .
        _:DataStore <database> "${dataStore.databaseName}" .
        _:DataStore <schema> "${dataStore.schema}" .
        _:DataStore <authType> "${dataStore.authType}" .
        _:DataStore <username> "${dataStore.username}" .
        _:DataStore <clientId> "${dataStore.clientId}" .
        _:DataStore <clientSecret> "${dataStore.clientSecret}" .
        _:DataStore <authorizationCode> "${dataStore.authorizationCode}" .
        _:DataStore <redirectURI> "${dataStore.redirectURI}" .
        _:DataStore <loginTimeout> "${dataStore.loginTimeout}" .
        _:DataStore <url> "${dataStore.url}" .
        _:DataStore <scope> "${dataStore.scope}" .
      }
    }`;
        console.log(`Added datastore ${dataStore.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addDataStore');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'DataStore');
            if (id) {
                dataStore.uid = id;
            }
        }), map((response) => (response.data.resp = dataStore)), tap(() => console.log(`add dataStores ${dataStore.uid}`)));
    }
    updateDataStore(dataStore, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('dataStore', dataStore.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${dataStore.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
                uuid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <account> "${account ? account : ''}" .
                uid(v) <uuid> "${dataStore.uuid}" .
                uid(v) <modified> "${dataStore.modified}" .
                uid(v) <dataStoreType> "${dataStore.dataStoreType}" .
                uid(v) <host> "${dataStore.host}" .
                uid(v) <port> "${dataStore.port}" .
                uid(v) <databaseName> "${dataStore.databaseName}" .
                uid(v) <user> "${dataStore.user}" .
                uid(v) <password> "${dataStore.password}" .
                uid(v) <accountName> "${dataStore.accountName}" .
                uid(v) <warehouse> "${dataStore.warehouse}" .
                uid(v) <database> "${dataStore.databaseName}" .
                uid(v) <schema> "${dataStore.schema}" .
                uid(v) <authType> "${dataStore.authType}" .
                uid(v) <username> "${dataStore.username}" .
                uid(v) <clientId> "${dataStore.clientId}" .
                uid(v) <clientSecret> "${dataStore.clientSecret}" .
                uid(v) <authorizationCode> "${dataStore.authorizationCode}" .
                uid(v) <redirectURI> "${dataStore.redirectURI}" .
                uid(v) <loginTimeout> "${dataStore.loginTimeout}" .
                uid(v) <url> "${dataStore.url}" .
                uid(v) <scope> "${dataStore.scope}" .
              }
            }
          }`;
        console.log(`Update dataStore ${dataStore.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateDataStore', 'dataStore', dataStore.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateDataStore')), tap(() => console.log(`updated dataStore ${dataStore.uid}`)), map(() => dataStore));
    }
    deleteDataStore(gatewayUuid, dataStoreUuid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('dataStore', dataStoreUuid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${dataStoreUuid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete DataStore ${dataStoreUuid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteDataStore', 'dataStore', dataStoreUuid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteDataStore')), tap(() => console.log(`deleted dataStore ${dataStoreUuid}`)), map(() => `${dataStoreUuid} deleted`));
    }
    getGatewayAndRestEndpoints(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid
        models: gateway_model {
          uid uuid created modified name
          description inputType url scope
          inputTemplate headers method base64Encoded
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayAndModels');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched gateways and models for ${gatewayName}`)));
    }
    getRestEndpoints(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(model)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified name
        description inputType url scope inputTemplate
        headers method base64Encoded
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getModels');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched models for ${gatewayName}`)));
    }
    addRestEndpoint(gatewayUid, model, account) {
        this.ensureAccountAuthorized(account);
        if (model.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Model <dgraph.type> "Model" .
        _:Model <type> "model" .
        _:Model <model> "" .
        _:Model <account> "${account ? account : ''}" .
        _:Model <uuid> "${model.uuid}" .
        _:Model <created> "${model.created}" .
        _:Model <modified> "${model.modified}" .
        _:Model <name> "${model.name}" .
        _:Model <description> "${model.description}" .
        _:Model <inputType> "${model.inputType}" .
        _:Model <url> "${model.url}" .
        _:Model <scope> "${model.scope}" .
        _:Model <inputTemplate> "${model.inputTemplate}" .
        _:Model <headers> "${model.headers}" .
        _:Model <method> "${model.method}" .
        _:Model <base64Encoded> "${model.base64Encoded}" .
      }
    }`;
        console.log(`Add model ${model.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addModel');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Model');
            if (id) {
                model.uid = id;
            }
        }), map((response) => (response.data.resp = model)), tap(() => console.log(`added model ${model.uid}`)));
    }
    updateRestEndpoint(model, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('model', model.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${model.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <uuid> "${model.uuid}" .
            uid(v) <modified> "${model.modified}" .
            uid(v) <name> "${model.name}" .
            uid(v) <description> "${model.description}" .
            uid(v) <inputType> "${model.inputType}" .
            uid(v) <url> "${model.url}" .
            uid(v) <scope> "${model.scope}" .
            uid(v) <inputTemplate> "${model.inputTemplate}" .
            uid(v) <headers> "${model.headers}" .
            uid(v) <method> "${model.method}" .
            uid(v) <base64Encoded> "${model.base64Encoded}" .
          }
        }
        }`;
        console.log(`Update model ${model.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateModel', 'model', model.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateModel')), tap(() => console.log(`updated model ${model.uid}`)), map(() => model));
    }
    deleteRestEndpoint(gatewayUid, modelUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('model', modelUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${modelUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Model ${modelUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteModel', 'model', modelUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteModel')), tap(() => console.log(`deleted model ${modelUid}`)), map(() => `${modelUid} deleted`));
    }
    getGatewayAndPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
        uid uuid brokerURL topic maximumQOS username password encryptionMode caCertificate
        clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
        sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
      }`;
        const pipeline_datastore = `dataStore: pipeline_datastore {
        uid uuid host port databaseName user password accountName warehouse database schema authType
        username clientId clientSecret authorizationCode redirectURI loginTimeout url
      }`;
        const pipeline_filter = 'filter: pipeline_filter { uid deviceNames }';
        const pipeline_streaming = 'streaming: pipeline_streaming { uid deviceName instrumentName function windowType windowSize }';
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid accessToken username platform address router routerPort deployNetwork devicesMetadata
        pipelines: gateway_pipeline {
          uid name uuid pipelineType deployerType protocolType protocolId dataStoreType
          dataStoreId created modified description status flowConfiguration
          logLevel subscriptionTopic
          ${pipeline_protocol}
          ${pipeline_datastore}
          ${pipeline_filter}
          ${pipeline_streaming}
        }
      }
    }`;
        console.log(`Get Gateway and Pipelines for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayWithPipelines');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and pipelines for ${gatewayName}`)));
    }
    getPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
              uid brokerURL topic maximumQOS username password encryptionMode caCertificate
              clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
              sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
  } `;
        const pipeline_datastore = `datastore: pipeline_datastore {
              uid host port databaseName user password accountName warehouse database schema authType
              username clientId clientSecret authorizationCode redirectURI loginTimeout url
            }`;
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        pipelines as gateway_pipeline {
        }
      }
      resp(func: uid(pipelines)) {
        uid name uuid pipelineType deployerType protocolType protocolId
        dataStoreType dataStoreId created modified description status
        flowConfiguration logLevel subscriptionTopic
        ${pipeline_protocol}
        ${pipeline_datastore}
        ${pipeline_filter}
        ${pipeline_streaming}
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPipelines');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched pipelines for ${gatewayName}`)));
    }
    addPipeline(gatewayUid, pipeline, transportObj, dataStoreObj, filterObj, streamingObj, account) {
        this.ensureAccountAuthorized(account);
        if (pipeline.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Pipeline <dgraph.type> "Pipeline" .
        _:Pipeline <account> "${account ? account : ''}" .
        _:Pipeline <name> "${pipeline.name}" .
        _:Pipeline <uuid> "${pipeline.name}" .
        _:Pipeline <type> "pipeline" .
        _:Pipeline <pipeline> "" .
        _:Pipeline <pipelineType> "${pipeline.pipelineType}" .
        _:Pipeline <deployerType> "${pipeline.deployerType}" .
        _:Pipeline <created> "${pipeline.created}" .
        _:Pipeline <modified> "${pipeline.modified}" .
        _:Pipeline <description> "${pipeline.description}" .
        _:Pipeline <status> "${pipeline.status}" .
        _:Pipeline <flowConfiguration> "${pipeline.flowConfiguration}" .
        _:Pipeline <logLevel> "${pipeline.logLevel}" .
        _:Pipeline <subscriptionTopic> "${pipeline.subscriptionTopic}" .
        _:Pipeline <pipeline.requirement> "${pipeline.requirement}" .
        _:Pipeline <configurationFile> "${pipeline.configurationFile}" .
        <${gatewayUid}> <gateway_pipeline> _:Pipeline .
      }
    }`;
        console.log(`add Pipeline ${pipeline.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addPipeline');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Pipeline');
            if (id) {
                pipeline.uid = id;
            }
        }), map((response) => (response.data.resp = pipeline)), tap(() => console.log(`added pipeline ${pipeline.uid}`)));
    }
    updatePipeline(pipeline, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pipeline', pipeline.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${pipeline.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <description> "${pipeline.description}" .
            uid(v) <status> "${pipeline.status}" .
            uid(v) <modified> "${pipeline.modified}" .
            uid(v) <flowConfiguration> "${pipeline.flowConfiguration}" .
            uid(v) <logLevel> "${pipeline.logLevel}" .
            uid(v) <subscriptionTopic> "${pipeline.subscriptionTopic}" .
          }
        }
      }`;
        console.log(`update Pipeline ${pipeline.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updatePipeline', 'pipeline', pipeline.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatePipeline')), tap(() => console.log(`updated pipeline ${pipeline.uid}`)), map(() => pipeline));
    }
    deletePipeline(gatewayUid, pipelineId, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pipeline', pipelineId, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${pipelineId}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
                <${gatewayUid}> <gateway_pipeline> <${pipelineId}> .
              }
            }
          }`;
        console.log(`delete Pipeline ${pipelineId} with gateway ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deletePipeline', 'pipeline', pipelineId)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deletePipeline')), tap(() => console.log(`deleted pipeline ${pipelineId} with gateway ${gatewayUid}`)), map(() => `pipeline deleted`));
    }
    /**
     * Get Python Resources.
     * @param gatewayUid
     */
    getPythonResources(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `
    {
      resp(func: type(PythonResource)) @filter(${this.getAccountQuery(account)} AND(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified name type scope fileContent inputs outputs filePath
      }
    }`;
        console.log(`get python resource from ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPythonResource');
        }), map((response) => response.data.resp));
    }
    /**
     * Update Python Resource.
     * @param PythonResource
     */
    updatePythonResource(pythonResource, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pythonResource', pythonResource.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
              var(func: uid(${pythonResource.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                <${pythonResource.uid}> <account> "${account ? account : ''}" .
                <${pythonResource.uid}> <modified> "${pythonResource.modified}" .
                <${pythonResource.uid}> <name> "${pythonResource.name}" .
                <${pythonResource.uid}> <scope> "${pythonResource.scope}" .
                <${pythonResource.uid}> <type> "${pythonResource.type}" .
                <${pythonResource.uid}> <fileContent> "${pythonResource.fileContent}" .
                <${pythonResource.uid}> <inputs> "${pythonResource.inputs}" .
                <${pythonResource.uid}> <outputs> "${pythonResource.outputs}" .
                <${pythonResource.uid}> <filePath> "${pythonResource.filePath}" .
              }
            }
        }`;
        console.log(`Update PythonResource ${pythonResource.uid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updatePythonResource', 'pythonResource', pythonResource.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatePythonResource')), tap(() => console.log(`updated filterConfig ${pythonResource.uid}`)), map(() => pythonResource));
    }
    /**
     * Add Python Resource.
     * @param PythonResource
     */
    addPythonResource(gatewayUuid, pythonResource, account) {
        this.ensureAccountAuthorized(account);
        if (pythonResource.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = ` {
      set {
        _:PythonResource <dgraph.type> "PythonResource" .
        _:PythonResource <pythonResource> "" .
        _:PythonResource <type> "pythonResource" .
        _:PythonResource <account> "${account ? account : ''}" .
        _:PythonResource <name> "${pythonResource.name}" .
        _:PythonResource <created> "${pythonResource.created}" .
        _:PythonResource <modified> "${pythonResource.modified}" .
        _:PythonResource <type> "${pythonResource.type}" .
        _:PythonResource <fileContent> "${pythonResource.fileContent}" .
        _:PythonResource <scope> "${pythonResource.scope}" .
        _:PythonResource <inputs> "${pythonResource.inputs}" .
        _:PythonResource <outputs> "${pythonResource.outputs}" .
        _:PythonResource <filePath> "${pythonResource.filePath}" .
      }}`;
        console.log(`Add PythonResource ${pythonResource.name}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addPythonResource');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'PythonResource');
            if (id) {
                pythonResource.uid = id;
            }
        }), map((response) => (response.data.resp = pythonResource)), tap(() => console.log(`add pythonResource ${pythonResource.uid}`)));
    }
    /**
     * Delete Python Resource.
     * @param resourceUid
     */
    deletePythonResource(pythonResourceUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pythonResource', pythonResourceUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `upsert {
            query {
              var(func: uid(${pythonResourceUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`${pythonResourceUid} is being deleted`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deletePythonResource', 'pythonResource', pythonResourceUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deletePythonResource')), tap(() => console.log(`updated filterConfig ${pythonResourceUid}`)), map(() => `${pythonResourceUid} deleted`));
    }
    getReadings(gatewayUuid, deviceName, instrumentName, numReadings, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading (first:-${numReadings}) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadings for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadings');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap((response) => console.log('Response from getReadings: ', response)), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsAt(deviceName, instrumentName, ts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(eq(created, ${ts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsAt for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsAt');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsStartingAt(deviceName, instrumentName, fromts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsStartingAt for for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsStartingAt');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched started at readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsBetween(gatewayUuid, deviceName, instrumentName, fromts, tots, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsBetween for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsBetween');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched readings between for ${deviceName}, ${instrumentName}`)));
    }
    getLastReadingsForDevice(deviceName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(device)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}")) @normalize {
        device_resource {
          name: name
          resource_reading (first:-1) {
            created: created
            value: value
          }
        }
      }
    }`;
        console.log(`getLastReadingsForDevice for ${deviceName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getLastReadingsForDevice');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched last readings for ${deviceName}`)));
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    addReading(gatewayUuid, deviceName, instrumentName, reading, accountId) {
        throw new Error('Only supports GraphQL graph service');
    }
    getNotifications(account) {
        this.ensureAccountAuthorized(account);
        console.log('GetNotifications service called');
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(notification)) @filter(${this.getAccountQuery(account)}) @normalize {
        uid uuid:uuid created:created notifySource:notifySource notifyDevice:notifyDevice
        notifyResource:notifyResource notifyLevel:notifyLevel value:value description:description
        ~gateway_notification {
          gateway: uuid
        }
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getNotifications');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched notifications`)));
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    addNotification(gatewayUuid, notification, accountId) {
        throw new Error('Only supports GraphQL graph service');
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    deleteNotification(gatewayUuid, notificationUuid, accountId) {
        throw new Error('Only supports GraphQL graph service');
    }
    ensureAccountAuthorized(account) {
        if (this.requireAccountId) {
            if (!account)
                throw new Error('Account must exist');
        }
    }
    getAccountQuery(account) {
        if (this.requireAccountId) {
            return `eq(account, "${account}")`;
        }
        else {
            return `(eq(account, "${account ? account : ''}") OR not(has(account)))`;
        }
    }
    /**
     * Discovers the presence of errors in the response from dGraph and reports them.
     *
     * @param response the response object from dGraph
     * @param operation the operation that was being performed for logging purposes
     */
    checkForErrors(response, operation = 'operation') {
        let hasErrors = false;
        let errors;
        if (response?.data?.errors) {
            hasErrors = true;
            console.log(`${operation} failed: ${response.data.errors[0].message}`);
            errors = { message: response.data.errors[0].message };
        }
        else if (response?.errors) {
            hasErrors = true;
            console.log(`${operation} failed: ${response.errors[0].message}`);
            errors = { message: response.errors[0].message };
        }
        if (hasErrors) {
            throw new Error(JSON.stringify(errors));
        }
    }
    /**
     * If the operation was successful, obtain a UID from the response.
     *
     * @param dGraphResponse A response from dGraph
     * @param objectKey the name of the Object, for example Gateway or Model
     * @returns a UID found from the response
     */
    getIDFromResponse(dGraphResponse, objectKey) {
        if (dGraphResponse.code === 'Success') {
            const uid = dGraphResponse.uids[objectKey];
            return uid;
        }
        return undefined;
    }
    getPreQuery(objectName, uid, account) {
        if (!uid) {
            throw new Error(JSON.stringify({ message: 'No ID defined' }));
        }
        return `{
        resp(func: has(${objectName})) @filter(${this.getAccountQuery(account)} AND (uid(${uid}))) {
          uid uuid
        }
      }`;
    }
    confirmObjectExists(response, operation, objectName, uid) {
        if (!uid) {
            throw new Error(JSON.stringify({ message: 'No ID defined' }));
        }
        this.checkForErrors(response, operation);
        if (Array.isArray(response.data.resp)) {
            const responseArray = response.data.resp;
            if (responseArray.length === 0) {
                console.log(`the ${objectName} with ID ${uid} does not exist in this account`);
                throw new Error(JSON.stringify({ message: 'No existing object' }));
            }
        }
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL2xhYnMtYWlyLWdyYXBoLWNsaWVudC9zcmMvYXBpL2dyYXBoLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxFQUFFLEdBQUcsRUFBYyxTQUFTLEVBQUUsR0FBRyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBSXZELE1BQU0sV0FBVyxHQUFHO0lBQ2hCLE9BQU8sRUFBRTtRQUNMLGNBQWMsRUFBRSx1QkFBdUI7S0FDMUM7Q0FDSixDQUFDO0FBRUYsTUFBTSxpQkFBaUIsR0FBRztJQUN0QixPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsaUJBQWlCLEVBQUU7Q0FDakQsQ0FBQztBQUVGLE1BQU0sT0FBZ0IsWUFBWTtJQUs5QixZQUFzQixJQUFnQixFQUFFLFNBQWlCLEVBQUUsZUFBd0I7UUFBN0QsU0FBSSxHQUFKLElBQUksQ0FBWTtRQUg1QixxQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFJOUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFDM0IsSUFBSSxDQUFDLGdCQUFnQixHQUFHLGVBQWUsQ0FBQztRQUN4Qyw4RUFBOEU7UUFDOUUsK0JBQStCO1FBQy9CLG9FQUFvRTtRQUNwRSxtSEFBbUg7UUFDbkgsbUhBQW1IO1FBQ25ILEdBQUc7SUFDUCxDQUFDO0lBRUQsVUFBVSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDNUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFDNUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxtQkFBbUIsQ0FBQztRQUNqRCxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7O01BSzdGLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLENBQ3JELENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQWdCO1FBQ3hCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLG1CQUFtQixDQUFDO1FBQ2pELE1BQU0sS0FBSyxHQUFHOztnQkFFTixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O01BTXZDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLFFBQVEsQ0FBQyxNQUFNLFdBQVcsQ0FBQyxDQUFDLENBQ3hFLENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLE9BQWdCLEVBQUUsT0FBZ0I7UUFDNUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFbkUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLE9BQU8sQ0FBQyxHQUFHO3dCQUNqQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O29DQU1qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtvQ0FDdEIsT0FBTyxDQUFDLE9BQU87bUNBQ2hCLE9BQU8sQ0FBQyxNQUFNO3VDQUNWLE9BQU8sQ0FBQyxVQUFVOzBDQUNmLE9BQU8sQ0FBQyxhQUFhO3dDQUN2QixPQUFPLENBQUMsV0FBVztxQ0FDdEIsT0FBTyxDQUFDLFFBQVE7c0NBQ2YsT0FBTyxDQUFDLFNBQVM7d0NBQ2YsT0FBTyxDQUFDLFdBQVc7cUNBQ3RCLE9BQU8sQ0FBQyxRQUFRO3FDQUNoQixPQUFPLENBQUMsUUFBUTtzQ0FDZixPQUFPLENBQUMsU0FBUzs7O1lBRzNDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixPQUFPLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRTdELGdGQUFnRjtRQUNoRixpRUFBaUU7UUFFakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQzlGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQyxFQUNqRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFDekQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixDQUFDLENBQy9CLENBQUM7SUFDTixDQUFDO0lBRUQsVUFBVSxDQUFDLE9BQWdCLEVBQUUsT0FBZ0I7UUFDekMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNiLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OytCQUtTLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUN6QixPQUFPLENBQUMsSUFBSTttQ0FDTCxPQUFPLENBQUMsV0FBVzsrQkFDdkIsT0FBTyxDQUFDLE9BQU87OEJBQ2hCLE9BQU8sQ0FBQyxNQUFNO2tDQUNWLE9BQU8sQ0FBQyxVQUFVO3FDQUNmLE9BQU8sQ0FBQyxhQUFhO2dDQUMxQixPQUFPLENBQUMsUUFBUTtpQ0FDZixPQUFPLENBQUMsU0FBUzttQ0FDZixPQUFPLENBQUMsV0FBVztnQ0FDdEIsT0FBTyxDQUFDLFFBQVE7Z0NBQ2hCLE9BQU8sQ0FBQyxRQUFRO2lDQUNmLE9BQU8sQ0FBQyxTQUFTO2lDQUNqQixPQUFPLENBQUMsU0FBUzs7TUFFNUMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUUzQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztZQUM1RCxJQUFJLEVBQUUsRUFBRTtnQkFDSixPQUFPLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUNwQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUNqRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLE9BQU8sQ0FBQyxHQUFHLElBQUksT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FDdkUsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUMvQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRW5FLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs4QkFHUSxXQUFXO3dCQUNqQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFFTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRTdDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDLEVBQzlGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQyxFQUNqRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUN4RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxXQUFXLFVBQVUsQ0FBQyxDQUN0QyxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsV0FBVzs7Ozs7Ozs7Ozs7O01BWTdGLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRTVELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUseUJBQXlCLENBQUMsQ0FBQztRQUM3RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUM3RSxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxZQUFZLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7MENBQ29CLElBQUksQ0FBQyxlQUFlLENBQ3BELE9BQU8sQ0FDVixvQkFBb0IsV0FBVzs7Ozs7Ozs7TUFRaEMsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWtCLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FDakUsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxRQUFrQixFQUFFLE9BQWdCO1FBQ2hFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxJQUFJLFFBQVEsQ0FBQyxHQUFHLEVBQUU7WUFDZCxNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDNUM7UUFFRCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OztnQ0FLVSxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs2QkFDekIsUUFBUSxDQUFDLElBQUk7Z0NBQ1YsUUFBUSxDQUFDLE9BQU87aUNBQ2YsUUFBUSxDQUFDLFFBQVE7cUNBQ2IsUUFBUSxDQUFDLFlBQVk7a0NBQ3hCLFFBQVEsQ0FBQyxTQUFTOzhCQUN0QixRQUFRLENBQUMsS0FBSzt3Q0FDSixRQUFRLENBQUMsZUFBZTswQ0FDdEIsUUFBUSxDQUFDLGlCQUFpQjt1Q0FDN0IsUUFBUSxDQUFDLGNBQWM7c0NBQ3hCLFFBQVEsQ0FBQyxhQUFhO3FDQUN2QixRQUFRLENBQUMsWUFBWTtzQ0FDcEIsUUFBUSxDQUFDLGFBQWE7cUNBQ3ZCLFFBQVEsQ0FBQyxZQUFZO3VDQUNuQixRQUFRLENBQUMsY0FBYzswQ0FDcEIsUUFBUSxDQUFDLGlCQUFpQjttQ0FDakMsUUFBUSxDQUFDLFVBQVU7aUNBQ3JCLFFBQVEsQ0FBQyxRQUFRO2lDQUNqQixRQUFRLENBQUMsUUFBUTt1Q0FDWCxRQUFRLENBQUMsY0FBYztzQ0FDeEIsUUFBUSxDQUFDLGFBQWE7MENBQ2xCLFFBQVEsQ0FBQyxpQkFBaUI7a0NBQ2xDLFFBQVEsQ0FBQyxTQUFTO2lDQUNuQixRQUFRLENBQUMsUUFBUTswQ0FDUixRQUFRLENBQUMsaUJBQWlCOzhCQUN0QyxRQUFRLENBQUMsS0FBSzs7TUFFdEMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRTdDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQzdELElBQUksRUFBRSxFQUFFO2dCQUNKLFFBQVEsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO2FBQ3JCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUMxRCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxRQUFrQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXJFLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7OzswQkFHSSxRQUFRLENBQUMsR0FBRztvQkFDbEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7OztnQ0FNakIsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7NkJBQ3pCLFFBQVEsQ0FBQyxJQUFJO2lDQUNULFFBQVEsQ0FBQyxRQUFRO3FDQUNiLFFBQVEsQ0FBQyxZQUFZO2tDQUN4QixRQUFRLENBQUMsU0FBUzs4QkFDdEIsUUFBUSxDQUFDLEtBQUs7d0NBQ0osUUFBUSxDQUFDLGVBQWU7MENBQ3RCLFFBQVEsQ0FBQyxpQkFBaUI7dUNBQzdCLFFBQVEsQ0FBQyxjQUFjO3NDQUN4QixRQUFRLENBQUMsYUFBYTtxQ0FDdkIsUUFBUSxDQUFDLFlBQVk7c0NBQ3BCLFFBQVEsQ0FBQyxhQUFhO3FDQUN2QixRQUFRLENBQUMsWUFBWTt1Q0FDbkIsUUFBUSxDQUFDLGNBQWM7MENBQ3BCLFFBQVEsQ0FBQyxpQkFBaUI7bUNBQ2pDLFFBQVEsQ0FBQyxVQUFVO2lDQUNyQixRQUFRLENBQUMsUUFBUTtpQ0FDakIsUUFBUSxDQUFDLFFBQVE7dUNBQ1gsUUFBUSxDQUFDLGNBQWM7c0NBQ3hCLFFBQVEsQ0FBQyxhQUFhOzBDQUNsQixRQUFRLENBQUMsaUJBQWlCO2tDQUNsQyxRQUFRLENBQUMsU0FBUztpQ0FDbkIsUUFBUSxDQUFDLFFBQVE7MENBQ1IsUUFBUSxDQUFDLGlCQUFpQjs4QkFDdEMsUUFBUSxDQUFDLEtBQUs7OztNQUd0QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRXRDLGdGQUFnRjtRQUNoRixpRUFBaUU7UUFDakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDakcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGdCQUFnQixDQUFDLENBQUMsRUFDbEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQzFELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FDdEIsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxXQUFtQixFQUFFLE9BQWdCO1FBQ3BFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFcEUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLFdBQVc7d0JBQ2pCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7WUFTekMsQ0FBQztRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLFdBQVcsUUFBUSxVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRWhFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsV0FBVyxDQUFDLENBQUMsRUFDaEcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGdCQUFnQixDQUFDLENBQUMsRUFDbEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsV0FBVyxVQUFVLENBQUMsQ0FDdEMsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUMvQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7MkNBQ3FCLElBQUksQ0FBQyxlQUFlLENBQ3JELE9BQU8sQ0FDVixvQkFBb0IsV0FBVzs7Ozs7OztNQU9oQyxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQztRQUNuRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUMxRSxDQUFDO0lBQ04sQ0FBQztJQUVELFlBQVksQ0FBQyxVQUFrQixFQUFFLFNBQW9CLEVBQUUsT0FBZ0I7UUFDbkUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksU0FBUyxDQUFDLEdBQUcsRUFBRTtZQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7O2lDQUtXLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzhCQUN6QixTQUFTLENBQUMsSUFBSTtpQ0FDWCxTQUFTLENBQUMsT0FBTztrQ0FDaEIsU0FBUyxDQUFDLFFBQVE7dUNBQ2IsU0FBUyxDQUFDLGFBQWE7OEJBQ2hDLFNBQVMsQ0FBQyxJQUFJOzhCQUNkLFNBQVMsQ0FBQyxJQUFJO3NDQUNOLFNBQVMsQ0FBQyxZQUFZOzhCQUM5QixTQUFTLENBQUMsSUFBSTtrQ0FDVixTQUFTLENBQUMsUUFBUTtxQ0FDZixTQUFTLENBQUMsV0FBVzttQ0FDdkIsU0FBUyxDQUFDLFNBQVM7a0NBQ3BCLFNBQVMsQ0FBQyxZQUFZO2dDQUN4QixTQUFTLENBQUMsTUFBTTtrQ0FDZCxTQUFTLENBQUMsUUFBUTtrQ0FDbEIsU0FBUyxDQUFDLFFBQVE7a0NBQ2xCLFNBQVMsQ0FBQyxRQUFRO3NDQUNkLFNBQVMsQ0FBQyxZQUFZOzJDQUNqQixTQUFTLENBQUMsaUJBQWlCO3FDQUNqQyxTQUFTLENBQUMsV0FBVztzQ0FDcEIsU0FBUyxDQUFDLFlBQVk7NkJBQy9CLFNBQVMsQ0FBQyxHQUFHOytCQUNYLFNBQVMsQ0FBQyxLQUFLOztNQUV4QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFakQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDOUQsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osU0FBUyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7YUFDdEI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQzVELENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFNBQW9CLEVBQUUsT0FBZ0I7UUFDbEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFdkUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUV0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLFNBQVMsQ0FBQyxHQUFHO3dCQUNuQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7OztvQ0FPakIsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7aUNBQ3pCLFNBQVMsQ0FBQyxJQUFJO3FDQUNWLFNBQVMsQ0FBQyxRQUFROzBDQUNiLFNBQVMsQ0FBQyxhQUFhO2lDQUNoQyxTQUFTLENBQUMsSUFBSTtpQ0FDZCxTQUFTLENBQUMsSUFBSTt5Q0FDTixTQUFTLENBQUMsWUFBWTtpQ0FDOUIsU0FBUyxDQUFDLElBQUk7cUNBQ1YsU0FBUyxDQUFDLFFBQVE7d0NBQ2YsU0FBUyxDQUFDLFdBQVc7c0NBQ3ZCLFNBQVMsQ0FBQyxTQUFTO3FDQUNwQixTQUFTLENBQUMsWUFBWTttQ0FDeEIsU0FBUyxDQUFDLE1BQU07cUNBQ2QsU0FBUyxDQUFDLFFBQVE7cUNBQ2xCLFNBQVMsQ0FBQyxRQUFRO3FDQUNsQixTQUFTLENBQUMsUUFBUTt5Q0FDZCxTQUFTLENBQUMsWUFBWTs4Q0FDakIsU0FBUyxDQUFDLGlCQUFpQjt3Q0FDakMsU0FBUyxDQUFDLFdBQVc7eUNBQ3BCLFNBQVMsQ0FBQyxZQUFZO2dDQUMvQixTQUFTLENBQUMsR0FBRztrQ0FDWCxTQUFTLENBQUMsS0FBSzs7O1lBR3JDLENBQUM7UUFFTCxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUVqRCxnRkFBZ0Y7UUFDaEYsaUVBQWlFO1FBQ2pFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQ3BHLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUM1RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQ3ZCLENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFdBQW1CLEVBQUUsYUFBcUIsRUFBRSxPQUFnQjtRQUN4RSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXZFLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs4QkFHUSxhQUFhO3dCQUNuQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixhQUFhLEVBQUUsQ0FBQyxDQUFDO1FBRWpELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFDcEcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLGFBQWEsRUFBRSxDQUFDLENBQUMsRUFDNUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsYUFBYSxVQUFVLENBQUMsQ0FDeEMsQ0FBQztJQUNOLENBQUM7SUFFRCwwQkFBMEIsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQzVELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7Ozs7O01BUTdGLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRTVELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUscUJBQXFCLENBQUMsQ0FBQztRQUN6RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUMzRSxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDbEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3VDQUNpQixJQUFJLENBQUMsZUFBZSxDQUNqRCxPQUFPLENBQ1Ysb0JBQW9CLFdBQVc7Ozs7O01BS2hDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFzQixDQUFDLEVBQ3ZELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQzlELENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFVBQWtCLEVBQUUsS0FBbUIsRUFBRSxPQUFnQjtRQUNyRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsSUFBSSxLQUFLLENBQUMsR0FBRyxFQUFFO1lBQ1gsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7NkJBS08sT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7MEJBQ3pCLEtBQUssQ0FBQyxJQUFJOzZCQUNQLEtBQUssQ0FBQyxPQUFPOzhCQUNaLEtBQUssQ0FBQyxRQUFROzBCQUNsQixLQUFLLENBQUMsSUFBSTtpQ0FDSCxLQUFLLENBQUMsV0FBVzsrQkFDbkIsS0FBSyxDQUFDLFNBQVM7eUJBQ3JCLEtBQUssQ0FBQyxHQUFHOzJCQUNQLEtBQUssQ0FBQyxLQUFLO21DQUNILEtBQUssQ0FBQyxhQUFhOzZCQUN6QixLQUFLLENBQUMsT0FBTzs0QkFDZCxLQUFLLENBQUMsTUFBTTttQ0FDTCxLQUFLLENBQUMsYUFBYTs7TUFFaEQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUV2QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMxRCxJQUFJLEVBQUUsRUFBRTtnQkFDSixLQUFLLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUNsQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUMvQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQ3JELENBQUM7SUFDTixDQUFDO0lBRUQsa0JBQWtCLENBQUMsS0FBbUIsRUFBRSxPQUFnQjtRQUNwRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUUvRCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7MEJBR0ksS0FBSyxDQUFDLEdBQUc7b0JBQ2YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7OztnQ0FNakIsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7NkJBQ3pCLEtBQUssQ0FBQyxJQUFJO2lDQUNOLEtBQUssQ0FBQyxRQUFROzZCQUNsQixLQUFLLENBQUMsSUFBSTtvQ0FDSCxLQUFLLENBQUMsV0FBVztrQ0FDbkIsS0FBSyxDQUFDLFNBQVM7NEJBQ3JCLEtBQUssQ0FBQyxHQUFHOzhCQUNQLEtBQUssQ0FBQyxLQUFLO3NDQUNILEtBQUssQ0FBQyxhQUFhO2dDQUN6QixLQUFLLENBQUMsT0FBTzsrQkFDZCxLQUFLLENBQUMsTUFBTTtzQ0FDTCxLQUFLLENBQUMsYUFBYTs7O1VBRy9DLENBQUM7UUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUV6QyxnRkFBZ0Y7UUFDaEYsaUVBQWlFO1FBQ2pFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUN4RixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFDL0QsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ3BELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FDbkIsQ0FBQztJQUNOLENBQUM7SUFFRCxrQkFBa0IsQ0FBQyxVQUFrQixFQUFFLFFBQWdCLEVBQUUsT0FBZ0I7UUFDckUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUU5RCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsUUFBUTt3QkFDZCxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBRXhDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ3ZGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQyxFQUMvRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsUUFBUSxFQUFFLENBQUMsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxRQUFRLFVBQVUsQ0FBQyxDQUNuQyxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0saUJBQWlCLEdBQUc7Ozs7UUFJMUIsQ0FBQztRQUNELE1BQU0sa0JBQWtCLEdBQUc7OztRQUczQixDQUFDO1FBQ0QsTUFBTSxlQUFlLEdBQUcsNkNBQTZDLENBQUM7UUFDdEUsTUFBTSxrQkFBa0IsR0FDcEIsZ0dBQWdHLENBQUM7UUFFckcsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7WUFNdkYsaUJBQWlCO1lBQ2pCLGtCQUFrQjtZQUNsQixlQUFlO1lBQ2Ysa0JBQWtCOzs7TUFHeEIsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSx5QkFBeUIsQ0FBQyxDQUFDO1FBQzdELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQzdFLENBQUM7SUFDTixDQUFDO0lBRUQsWUFBWSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDOUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0saUJBQWlCLEdBQUc7Ozs7S0FJN0IsQ0FBQztRQUNFLE1BQU0sa0JBQWtCLEdBQUc7OztjQUdyQixDQUFDO1FBQ1AsTUFBTSxlQUFlLEdBQUcsMkNBQTJDLENBQUM7UUFDcEUsTUFBTSxrQkFBa0IsR0FDcEIsOEZBQThGLENBQUM7UUFFbkcsTUFBTSxLQUFLLEdBQUc7d0NBQ2tCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7OztVQVF4RixpQkFBaUI7VUFDakIsa0JBQWtCO1VBQ2xCLGVBQWU7VUFDZixrQkFBa0I7O01BRXRCLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFrQixDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQ2pFLENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUNQLFVBQWtCLEVBQ2xCLFFBQWtCLEVBQ2xCLFlBQWtCLEVBQ2xCLFlBQWtCLEVBQ2xCLFNBQWUsRUFDZixZQUFrQixFQUNsQixPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsSUFBSSxRQUFRLENBQUMsR0FBRyxFQUFFO1lBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7O2dDQUdVLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzZCQUN6QixRQUFRLENBQUMsSUFBSTs2QkFDYixRQUFRLENBQUMsSUFBSTs7O3FDQUdMLFFBQVEsQ0FBQyxZQUFZO3FDQUNyQixRQUFRLENBQUMsWUFBWTtnQ0FDMUIsUUFBUSxDQUFDLE9BQU87aUNBQ2YsUUFBUSxDQUFDLFFBQVE7b0NBQ2QsUUFBUSxDQUFDLFdBQVc7K0JBQ3pCLFFBQVEsQ0FBQyxNQUFNOzBDQUNKLFFBQVEsQ0FBQyxpQkFBaUI7aUNBQ25DLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7NkNBQ3ZCLFFBQVEsQ0FBQyxXQUFXOzBDQUN2QixRQUFRLENBQUMsaUJBQWlCO1dBQ3pELFVBQVU7O01BRWYsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRTVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQzdELElBQUksRUFBRSxFQUFFO2dCQUNKLFFBQVEsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO2FBQ3JCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUMzRCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxRQUFrQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXJFLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7OzswQkFHSSxRQUFRLENBQUMsR0FBRztvQkFDbEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7OztnQ0FNakIsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0NBQ2xCLFFBQVEsQ0FBQyxXQUFXOytCQUN6QixRQUFRLENBQUMsTUFBTTtpQ0FDYixRQUFRLENBQUMsUUFBUTswQ0FDUixRQUFRLENBQUMsaUJBQWlCO2lDQUNuQyxRQUFRLENBQUMsUUFBUTswQ0FDUixRQUFRLENBQUMsaUJBQWlCOzs7UUFHNUQsQ0FBQztRQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRS9DLGdGQUFnRjtRQUNoRixpRUFBaUU7UUFDakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDakcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGdCQUFnQixDQUFDLENBQUMsRUFDbEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQzFELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FDdEIsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxVQUFrQixFQUFFLE9BQWdCO1FBQ25FLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFbkUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLFVBQVU7d0JBQ2hCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7O21CQU9sQyxVQUFVLHlCQUF5QixVQUFVOzs7WUFHcEQsQ0FBQztRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLFVBQVUsaUJBQWlCLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFeEUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQyxFQUMvRixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxFQUNsRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsVUFBVSxpQkFBaUIsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUNuRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsa0JBQWtCLENBQUMsQ0FDaEMsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCxrQkFBa0IsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQ3BELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzs7aURBRTJCLElBQUksQ0FBQyxlQUFlLENBQzNELE9BQU8sQ0FDVixtQkFBbUIsV0FBVzs7O01BRy9CLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztRQUN2RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBd0IsQ0FBQyxDQUM1RCxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILG9CQUFvQixDQUFDLGNBQThCLEVBQUUsT0FBZ0I7UUFDakUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsY0FBYyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUVqRixNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsY0FBYyxDQUFDLEdBQUc7d0JBQ3hCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7bUJBTWxDLGNBQWMsQ0FBQyxHQUFHLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTttQkFDeEQsY0FBYyxDQUFDLEdBQUcsaUJBQWlCLGNBQWMsQ0FBQyxRQUFRO21CQUMxRCxjQUFjLENBQUMsR0FBRyxhQUFhLGNBQWMsQ0FBQyxJQUFJO21CQUNsRCxjQUFjLENBQUMsR0FBRyxjQUFjLGNBQWMsQ0FBQyxLQUFLO21CQUNwRCxjQUFjLENBQUMsR0FBRyxhQUFhLGNBQWMsQ0FBQyxJQUFJO21CQUNsRCxjQUFjLENBQUMsR0FBRyxvQkFBb0IsY0FBYyxDQUFDLFdBQVc7bUJBQ2hFLGNBQWMsQ0FBQyxHQUFHLGVBQWUsY0FBYyxDQUFDLE1BQU07bUJBQ3RELGNBQWMsQ0FBQyxHQUFHLGdCQUFnQixjQUFjLENBQUMsT0FBTzttQkFDeEQsY0FBYyxDQUFDLEdBQUcsaUJBQWlCLGNBQWMsQ0FBQyxRQUFROzs7VUFHbkUsQ0FBQztRQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLGNBQWMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRTNELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxzQkFBc0IsRUFBRSxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDbkgsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLHNCQUFzQixDQUFDLENBQUMsRUFDeEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLGNBQWMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ3BFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsQ0FDNUIsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCxpQkFBaUIsQ0FBQyxXQUFtQixFQUFFLGNBQThCLEVBQUUsT0FBZ0I7UUFDbkYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksY0FBYyxDQUFDLEdBQUcsRUFBRTtZQUNwQixNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDNUM7UUFDRCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OztzQ0FLZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7bUNBQ3pCLGNBQWMsQ0FBQyxJQUFJO3NDQUNoQixjQUFjLENBQUMsT0FBTzt1Q0FDckIsY0FBYyxDQUFDLFFBQVE7bUNBQzNCLGNBQWMsQ0FBQyxJQUFJOzBDQUNaLGNBQWMsQ0FBQyxXQUFXO29DQUNoQyxjQUFjLENBQUMsS0FBSztxQ0FDbkIsY0FBYyxDQUFDLE1BQU07c0NBQ3BCLGNBQWMsQ0FBQyxPQUFPO3VDQUNyQixjQUFjLENBQUMsUUFBUTtTQUNyRCxDQUFDO1FBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsY0FBYyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFekQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLG1CQUFtQixDQUFDLENBQUM7UUFDdkQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ25FLElBQUksRUFBRSxFQUFFO2dCQUNKLGNBQWMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO2FBQzNCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLGNBQWMsQ0FBQyxDQUFDLEVBQ3hELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixjQUFjLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUNyRSxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILG9CQUFvQixDQUFDLGlCQUF5QixFQUFFLE9BQWdCO1FBQzVELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRWhGLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7OzhCQUVRLGlCQUFpQjt3QkFDdkIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7OztZQVN6QyxDQUFDO1FBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLGlCQUFpQixtQkFBbUIsQ0FBQyxDQUFDO1FBQ3JELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxzQkFBc0IsRUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ2xILFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDLEVBQ3hFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixpQkFBaUIsRUFBRSxDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsaUJBQWlCLFVBQVUsQ0FBQyxDQUM1QyxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FDUCxXQUFtQixFQUNuQixVQUFrQixFQUNsQixjQUFzQixFQUN0QixXQUFtQixFQUNuQixPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixVQUFVLElBQUksY0FBYzsrQ0FDckUsV0FBVzs7Ozs7OztNQU9wRCxDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUM7UUFFaEUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7Z0JBQ3JCLE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxJQUFpQixDQUFDO2FBQzNDO2lCQUFNO2dCQUNILE9BQU8sRUFBZSxDQUFDO2FBQzFCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ3ZFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUNsRixDQUFDO0lBQ04sQ0FBQztJQUVELGFBQWEsQ0FBQyxVQUFrQixFQUFFLGNBQXNCLEVBQUUsRUFBVSxFQUFFLE9BQWdCO1FBQ2xGLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVUsSUFBSSxjQUFjOzJEQUN6RCxFQUFFOzs7Ozs7O01BT3ZELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQztRQUVsRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQWlCLENBQUM7YUFDM0M7aUJBQU07Z0JBQ0gsT0FBTyxFQUFlLENBQUM7YUFDMUI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FDbEYsQ0FBQztJQUNOLENBQUM7SUFFRCxxQkFBcUIsQ0FBQyxVQUFrQixFQUFFLGNBQXNCLEVBQUUsTUFBYyxFQUFFLE9BQWdCO1FBQzlGLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVUsSUFBSSxjQUFjOzJEQUN6RCxNQUFNOzs7Ozs7O01BTzNELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQztRQUU5RSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLHVCQUF1QixDQUFDLENBQUM7UUFDM0QsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBaUIsQ0FBQzthQUMzQztpQkFBTTtnQkFDSCxPQUFPLEVBQWUsQ0FBQzthQUMxQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUM3RixDQUFDO0lBQ04sQ0FBQztJQUVELGtCQUFrQixDQUNkLFdBQW1CLEVBQ25CLFVBQWtCLEVBQ2xCLGNBQXNCLEVBQ3RCLE1BQWMsRUFDZCxJQUFZLEVBQ1osT0FBZ0I7UUFFaEIsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsVUFBVSxJQUFJLGNBQWM7MkRBQ3pELE1BQU0scUJBQXFCLElBQUk7Ozs7Ozs7TUFPcEYsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDO1FBRXZFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztRQUN4RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7Z0JBQ3JCLE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxJQUFpQixDQUFDO2FBQzNDO2lCQUFNO2dCQUNILE9BQU8sRUFBZSxDQUFDO2FBQzFCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQzFGLENBQUM7SUFDTixDQUFDO0lBRUQsd0JBQXdCLENBQUMsVUFBa0IsRUFBRSxPQUFnQjtRQUN6RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7d0NBQ2tCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixVQUFVOzs7Ozs7Ozs7TUFTM0YsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFMUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO1FBQzlELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQWlCLENBQUM7YUFDM0M7aUJBQU07Z0JBQ0gsT0FBTyxFQUFlLENBQUM7YUFDMUI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUNwRSxDQUFDO0lBQ04sQ0FBQztJQUVELDZEQUE2RDtJQUM3RCxVQUFVLENBQ04sV0FBbUIsRUFDbkIsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsT0FBa0IsRUFDbEIsU0FBaUI7UUFFakIsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxPQUFnQjtRQUM3QixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBQy9DLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHOzhDQUN3QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7OztNQU9yRSxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBQ3RELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQXNCLENBQUM7YUFDaEQ7aUJBQU07Z0JBQ0gsT0FBTyxFQUFvQixDQUFDO2FBQy9CO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUNsRCxDQUFDO0lBQ04sQ0FBQztJQUVELDZEQUE2RDtJQUM3RCxlQUFlLENBQUMsV0FBbUIsRUFBRSxZQUEwQixFQUFFLFNBQWlCO1FBQzlFLE1BQU0sSUFBSSxLQUFLLENBQUMscUNBQXFDLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBRUQsNkRBQTZEO0lBQzdELGtCQUFrQixDQUFDLFdBQW1CLEVBQUUsZ0JBQXdCLEVBQUUsU0FBaUI7UUFDL0UsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCx1QkFBdUIsQ0FBQyxPQUFnQjtRQUNwQyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN2QixJQUFJLENBQUMsT0FBTztnQkFBRSxNQUFNLElBQUksS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7U0FDdkQ7SUFDTCxDQUFDO0lBRUQsZUFBZSxDQUFDLE9BQWdCO1FBQzVCLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3ZCLE9BQU8sZ0JBQWdCLE9BQU8sSUFBSSxDQUFDO1NBQ3RDO2FBQU07WUFDSCxPQUFPLGlCQUFpQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSwwQkFBMEIsQ0FBQztTQUM1RTtJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGNBQWMsQ0FBQyxRQUFhLEVBQUUsU0FBUyxHQUFHLFdBQVc7UUFDakQsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksTUFBTSxDQUFDO1FBRVgsSUFBSSxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRTtZQUN4QixTQUFTLEdBQUcsSUFBSSxDQUFDO1lBQ2pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUN2RSxNQUFNLEdBQUcsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDekQ7YUFBTSxJQUFJLFFBQVEsRUFBRSxNQUFNLEVBQUU7WUFDekIsU0FBUyxHQUFHLElBQUksQ0FBQztZQUNqQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxZQUFZLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUNsRSxNQUFNLEdBQUcsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUNwRDtRQUVELElBQUksU0FBUyxFQUFFO1lBQ1gsTUFBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7U0FDM0M7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsaUJBQWlCLENBQUMsY0FBNkIsRUFBRSxTQUFpQjtRQUM5RCxJQUFJLGNBQWMsQ0FBQyxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQ25DLE1BQU0sR0FBRyxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDM0MsT0FBTyxHQUFHLENBQUM7U0FDZDtRQUNELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxHQUFnQyxFQUFFLE9BQWdCO1FBQzlFLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDTixNQUFNLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ2pFO1FBQ0QsT0FBTzt5QkFDVSxVQUFVLGNBQWMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHOzs7UUFHdEYsQ0FBQztJQUNMLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxRQUFhLEVBQUUsU0FBaUIsRUFBRSxVQUFrQixFQUFFLEdBQWdDO1FBQ3RHLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDTixNQUFNLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ2pFO1FBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDekMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbkMsTUFBTSxhQUFhLEdBQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDN0MsSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDNUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLFVBQVUsWUFBWSxHQUFHLGlDQUFpQyxDQUFDLENBQUM7Z0JBQy9FLE1BQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUN0RTtTQUNKO0lBQ0wsQ0FBQztDQUNKIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGF0YVN0b3JlLCBHYXRld2F5LCBSZXN0RW5kcG9pbnQsIE5vdGlmaWNhdGlvbiwgUGlwZWxpbmUsIFByb3RvY29sLCBQeXRob25SZXNvdXJjZSwgUmVhZGluZyB9IGZyb20gJy4uL21vZGVsL21vZGVscyc7XG5pbXBvcnQgeyBtYXAsIE9ic2VydmFibGUsIHN3aXRjaE1hcCwgdGFwIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuXG5cbmNvbnN0IGh0dHBPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9ncmFwaHFsKy0nLFxuICAgIH0sXG59O1xuXG5jb25zdCBodHRwTXV0YXRlT3B0aW9ucyA9IHtcbiAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vcmRmJyB9LFxufTtcblxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEdyYXBoU2VydmljZSB7XG4gICAgXG4gICAgcHJvdGVjdGVkIHJlcXVpcmVBY2NvdW50SWQgPSB0cnVlO1xuICAgIHByb3RlY3RlZCBkR3JhcGhVcmw6IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBodHRwOiBIdHRwQ2xpZW50LCBkR3JhcGhVcmw6IHN0cmluZywgYWNjb3VudFJlcXVpcmVkOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuZEdyYXBoVXJsID0gZEdyYXBoVXJsO1xuICAgICAgICB0aGlzLnJlcXVpcmVBY2NvdW50SWQgPSBhY2NvdW50UmVxdWlyZWQ7XG4gICAgICAgIC8vY29uc3QgZEdyYXBoQmFzaWNBdXRoRW5hYmxlZCA9IHRoaXMuYXBwQ29uZmlnU2VydmljZS5kR3JhcGhCYXNpY0F1dGhFbmFibGVkO1xuICAgICAgICAvL2lmIChkR3JhcGhCYXNpY0F1dGhFbmFibGVkKSB7XG4gICAgICAgIC8vICAgIGNvbnN0IGRHcmFwaEJhc2ljQXV0aCA9IHRoaXMuYXBwQ29uZmlnU2VydmljZS5kR3JhcGhCYXNpY0F1dGg7XG4gICAgICAgIC8vICAgICh0aGlzLmh0dHBPcHRpb25zLmhlYWRlcnMgPSB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vZ3JhcGhxbCstJyB9KSwgeyBBdXRob3JpemF0aW9uOiBkR3JhcGhCYXNpY0F1dGggfTtcbiAgICAgICAgLy8gICAgKHRoaXMuaHR0cE11dGF0ZU9wdGlvbnMuaGVhZGVycyA9IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9yZGYnIH0pLCB7IEF1dGhvcml6YXRpb246IGRHcmFwaEJhc2ljQXV0aCB9O1xuICAgICAgICAvL31cbiAgICB9XG5cbiAgICBnZXRHYXRld2F5KGdhdGV3YXlVdWlkOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBHZXRHYXRld2F5IHNlcnZpY2UgY2FsbGVkIGZvciAke2dhdGV3YXlVdWlkfWApO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnk/ZGVidWc9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheVV1aWR9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkIGRlc2NyaXB0aW9uIGFkZHJlc3Mgcm91dGVyIHJvdXRlclBvcnRcbiAgICAgICAgZGVwbG95TmV0d29yayBsYXRpdHVkZSBsb25naXR1ZGUgYWNjZXNzVG9rZW4gdXNlcm5hbWVcbiAgICAgICAgcGxhdGZvcm0gZGV2aWNlc01ldGFkYXRhIGNyZWF0ZWR0cyB1cGRhdGVkdHNcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0R2F0ZXdheScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRHYXRld2F5cyhhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnk/ZGVidWc9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKVxuICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICB1aWQgdXVpZCBkZXNjcmlwdGlvbiBhZGRyZXNzIHJvdXRlciByb3V0ZXJQb3J0XG4gICAgICAgIGRlcGxveU5ldHdvcmsgbGF0aXR1ZGUgbG9uZ2l0dWRlIGFjY2Vzc1Rva2VuIHVzZXJuYW1lXG4gICAgICAgIHBsYXRmb3JtIGRldmljZXNNZXRhZGF0YSBjcmVhdGVkdHMgdXBkYXRlZHRzXG4gICAgICAgIG51bURldmljZXM6IGNvdW50KGdhdGV3YXlfZGV2aWNlKVxuICAgICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldEdhdGV3YXlzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgJHtyZXNwb25zZS5sZW5ndGh9IGdhdGV3YXlzYCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZUdhdGV3YXkoZ2F0ZXdheTogR2F0ZXdheSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ2dhdGV3YXknLCBnYXRld2F5LnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7Z2F0ZXdheS51aWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIHNldCB7XG4gICAgICAgICAgICAgICAgdWlkKHYpIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxhZGRyZXNzPiBcIiR7Z2F0ZXdheS5hZGRyZXNzfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHJvdXRlcj4gXCIke2dhdGV3YXkucm91dGVyfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHJvdXRlclBvcnQ+IFwiJHtnYXRld2F5LnJvdXRlclBvcnR9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8ZGVwbG95TmV0d29yaz4gXCIke2dhdGV3YXkuZGVwbG95TmV0d29ya31cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxkZXNjcmlwdGlvbj4gXCIke2dhdGV3YXkuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8bGF0aXR1ZGU+IFwiJHtnYXRld2F5LmxhdGl0dWRlfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGxvbmdpdHVkZT4gXCIke2dhdGV3YXkubG9uZ2l0dWRlfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGFjY2Vzc1Rva2VuPiBcIiR7Z2F0ZXdheS5hY2Nlc3NUb2tlbn1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDx1c2VybmFtZT4gXCIke2dhdGV3YXkudXNlcm5hbWV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cGxhdGZvcm0+IFwiJHtnYXRld2F5LnBsYXRmb3JtfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVwZGF0ZWR0cz4gXCIke2dhdGV3YXkudXBkYXRlZHRzfVwiIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlIEdhdGV3YXkgJHtnYXRld2F5LnV1aWR9ICR7Z2F0ZXdheS51aWR9YCk7XG5cbiAgICAgICAgLy8gV2l0aCB0aGUgdXBzZXJ0IGFwcHJvYWNoLCBpdCBpcyBub3QgcG9zc2libGUgdG8gc2VlIGlmIHRoZSBtdXRhdGlvbiBvY2N1cnJlZC5cbiAgICAgICAgLy8gVXNlIGEgcHJlUXVlcnkgZm9yIHRoZSBvYmplY3QgZmlyc3QgdG8gZGV0ZXJtaW5lIGlmIGl0IGV4aXN0cy5cblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlR2F0ZXdheScsICdnYXRld2F5JywgZ2F0ZXdheS51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlR2F0ZXdheScpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBnYXRld2F5ICR7Z2F0ZXdheS51dWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiAnZ2F0ZXdheSB1cGRhdGVkJyksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkR2F0ZXdheShnYXRld2F5OiBHYXRld2F5LCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5PiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKGdhdGV3YXkudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86R2F0ZXdheSA8ZGdyYXBoLnR5cGU+IFwiR2F0ZXdheVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxnYXRld2F5PiBcIlwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx0eXBlPiBcImdhdGV3YXlcIiAuXG4gICAgICAgIF86R2F0ZXdheSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHV1aWQ+IFwiJHtnYXRld2F5LnV1aWR9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGRlc2NyaXB0aW9uPiBcIiR7Z2F0ZXdheS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8YWRkcmVzcz4gXCIke2dhdGV3YXkuYWRkcmVzc31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8cm91dGVyPiBcIiR7Z2F0ZXdheS5yb3V0ZXJ9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHJvdXRlclBvcnQ+IFwiJHtnYXRld2F5LnJvdXRlclBvcnR9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGRlcGxveU5ldHdvcms+IFwiJHtnYXRld2F5LmRlcGxveU5ldHdvcmt9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGxhdGl0dWRlPiBcIiR7Z2F0ZXdheS5sYXRpdHVkZX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8bG9uZ2l0dWRlPiBcIiR7Z2F0ZXdheS5sb25naXR1ZGV9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGFjY2Vzc1Rva2VuPiBcIiR7Z2F0ZXdheS5hY2Nlc3NUb2tlbn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8dXNlcm5hbWU+IFwiJHtnYXRld2F5LnVzZXJuYW1lfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxwbGF0Zm9ybT4gXCIke2dhdGV3YXkucGxhdGZvcm19XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGNyZWF0ZWR0cz4gXCIke2dhdGV3YXkuY3JlYXRlZHRzfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx1cGRhdGVkdHM+IFwiJHtnYXRld2F5LnVwZGF0ZWR0c31cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgR2F0ZXdheSAke2dhdGV3YXkudXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkR2F0ZXdheScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdHYXRld2F5Jyk7XG4gICAgICAgICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIGdhdGV3YXkudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gZ2F0ZXdheSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGQgZ2F0ZXdheSAke2dhdGV3YXkudWlkfS8ke2dhdGV3YXkudXVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlR2F0ZXdheShnYXRld2F5VXVpZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnZ2F0ZXdheScsIGdhdGV3YXlVdWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke2dhdGV3YXlVdWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBkZWxldGUge1xuICAgICAgICAgICAgICAgIHVpZCh2KSAqICogLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBHYXRld2F5ICR7Z2F0ZXdheVV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZUdhdGV3YXknLCAnZ2F0ZXdheScsIGdhdGV3YXlVdWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZUdhdGV3YXknKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGRlbGV0ZWQgZ2F0ZXdheSAke2dhdGV3YXlVdWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgJHtnYXRld2F5VXVpZH0gZGVsZXRlZGApLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlBbmRQcm90b2NvbHMoZ2F0ZXdheVV1aWQ6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheVV1aWR9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICAgIHByb3RvY29sczogZ2F0ZXdheV9wcm90b2NvbCB7XG4gICAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBwcm90b2NvbFR5cGUgYnJva2VyVVJMXG4gICAgICAgICAgdG9waWMgY29uc3VtZXJHcm91cElkIGNvbm5lY3Rpb25UaW1lb3V0IHNlc3Npb25UaW1lb3V0XG4gICAgICAgICAgaW5pdGlhbE9mZnNldCByZXRyeUJhY2tPZmYgZmV0Y2hNaW5CeXRlcyBmZXRjaE1heFdhaXRcbiAgICAgICAgICBjb21taXRJbnRlcnZhbCBoZWFydGJlYXRJbnRlcnZhbCBtYXhpbXVtUU9TXG4gICAgICAgICAgdXNlcm5hbWUgcGFzc3dvcmQgZW5jcnlwdGlvbk1vZGVcbiAgICAgICAgICBjYUNlcnRpZmljYXRlIGNsaWVudENlcnRpZmljYXRlIGNsaWVudEtleVxuICAgICAgICAgIGF1dGhNb2RlIHNlcnZlckNlcnRpZmljYXRlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEdldCBHYXRld2F5IGFuZCBQcm90b2NvbHMgZm9yICR7Z2F0ZXdheVV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldEdhdGV3YXlXaXRoUHJvdG9jb2xzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIEdhdGV3YXkgYW5kIFByb3RvY29scyBmb3IgJHtnYXRld2F5VXVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGFsbCBnbG9iYWwgcHJvdG9jb2xzIGFuZCB0aGUgcHJvdG9jb2xzIHNjb3BlZCBmb3IgdGhlIGdhdGV3YXlcbiAgICAgKiBAcGFyYW0gZ2F0ZXdheVV1aWRcbiAgICAgKiBAcGFyYW0gYWNjb3VudFxuICAgICAqL1xuICAgIGdldFByb3RvY29scyhnYXRld2F5VXVpZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQcm90b2NvbFtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKHByb3RvY29sKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KFxuICAgICAgICAgIGFjY291bnQsXG4gICAgICApfSBBTkQgKGVxKHNjb3BlLCBcIiR7Z2F0ZXdheVV1aWR9XCIpIE9SIGVxKHNjb3BlLCBcIkdMT0JBTFwiKSkpIHtcbiAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBwcm90b2NvbFR5cGUgYnJva2VyVVJMIHRvcGljXG4gICAgICAgIGNvbnN1bWVyR3JvdXBJZCBjb25uZWN0aW9uVGltZW91dCBzZXNzaW9uVGltZW91dCBpbml0aWFsT2Zmc2V0XG4gICAgICAgIHJldHJ5QmFja09mZiBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdCBjb21taXRJbnRlcnZhbFxuICAgICAgICBoZWFydGJlYXRJbnRlcnZhbCBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkXG4gICAgICAgIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGUgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5XG4gICAgICAgIGF1dGhNb2RlIHNlcnZlckNlcnRpZmljYXRlIHNjb3BlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFByb3RvY29scycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUHJvdG9jb2xbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcHJvdG9jb2xzIGZvciAke2dhdGV3YXlVdWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRQcm90b2NvbChnYXRld2F5VWlkOiBzdHJpbmcsIHByb3RvY29sOiBQcm90b2NvbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2w+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAocHJvdG9jb2wudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UHJvdG9jb2wgPGRncmFwaC50eXBlPiBcIlByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDx0eXBlPiBcInByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwcm90b2NvbD4gXCJcIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8dXVpZD4gXCIke3Byb3RvY29sLnV1aWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjcmVhdGVkPiBcIiR7cHJvdG9jb2wuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPG1vZGlmaWVkPiBcIiR7cHJvdG9jb2wubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwcm90b2NvbFR5cGU+IFwiJHtwcm90b2NvbC5wcm90b2NvbFR5cGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxicm9rZXJVUkw+IFwiJHtwcm90b2NvbC5icm9rZXJVUkx9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDx0b3BpYz4gXCIke3Byb3RvY29sLnRvcGljfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y29uc3VtZXJHcm91cElkPiBcIiR7cHJvdG9jb2wuY29uc3VtZXJHcm91cElkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y29ubmVjdGlvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5jb25uZWN0aW9uVGltZW91dH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHNlc3Npb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuc2Vzc2lvblRpbWVvdXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxpbml0aWFsT2Zmc2V0PiBcIiR7cHJvdG9jb2wuaW5pdGlhbE9mZnNldH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHJldHJ5QmFja09mZj4gXCIke3Byb3RvY29sLnJldHJ5QmFja09mZn1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGZldGNoTWluQnl0ZXM+IFwiJHtwcm90b2NvbC5mZXRjaE1pbkJ5dGVzfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8ZmV0Y2hNYXhXYWl0PiBcIiR7cHJvdG9jb2wuZmV0Y2hNYXhXYWl0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y29tbWl0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5jb21taXRJbnRlcnZhbH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGhlYXJ0YmVhdEludGVydmFsPiBcIiR7cHJvdG9jb2wuaGVhcnRiZWF0SW50ZXJ2YWx9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxtYXhpbXVtUU9TPiBcIiR7cHJvdG9jb2wubWF4aW11bVFPU31cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHVzZXJuYW1lPiBcIiR7cHJvdG9jb2wudXNlcm5hbWV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwYXNzd29yZD4gXCIke3Byb3RvY29sLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8ZW5jcnlwdGlvbk1vZGU+IFwiJHtwcm90b2NvbC5lbmNyeXB0aW9uTW9kZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNhQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jYUNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y2xpZW50Q2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jbGllbnRDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNsaWVudEtleT4gXCIke3Byb3RvY29sLmNsaWVudEtleX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGF1dGhNb2RlPiBcIiR7cHJvdG9jb2wuYXV0aE1vZGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxzZXJ2ZXJDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLnNlcnZlckNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8c2NvcGU+IFwiJHtwcm90b2NvbC5zY29wZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgcHJvdG9jb2wgJHtwcm90b2NvbC51dWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRQcm90b2NvbCcpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdQcm90b2NvbCcpO1xuICAgICAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgICAgICBwcm90b2NvbC51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwcm90b2NvbCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGQgcHJvdG9jb2xzICR7cHJvdG9jb2wudWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVQcm90b2NvbChwcm90b2NvbDogUHJvdG9jb2wsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFByb3RvY29sPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ3Byb3RvY29sJywgcHJvdG9jb2wudWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke3Byb3RvY29sLnVpZH0pKVxuICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIG11dGF0aW9uIEBpZiAoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgIHNldCB7XG4gICAgICAgICAgICB1aWQodikgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8dXVpZD4gXCIke3Byb3RvY29sLnV1aWR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxtb2RpZmllZD4gXCIke3Byb3RvY29sLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8cHJvdG9jb2xUeXBlPiBcIiR7cHJvdG9jb2wucHJvdG9jb2xUeXBlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8YnJva2VyVVJMPiBcIiR7cHJvdG9jb2wuYnJva2VyVVJMfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8dG9waWM+IFwiJHtwcm90b2NvbC50b3BpY31cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNvbnN1bWVyR3JvdXBJZD4gXCIke3Byb3RvY29sLmNvbnN1bWVyR3JvdXBJZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNvbm5lY3Rpb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuY29ubmVjdGlvblRpbWVvdXR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzZXNzaW9uVGltZW91dD4gXCIke3Byb3RvY29sLnNlc3Npb25UaW1lb3V0fVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8aW5pdGlhbE9mZnNldD4gXCIke3Byb3RvY29sLmluaXRpYWxPZmZzZXR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxyZXRyeUJhY2tPZmY+IFwiJHtwcm90b2NvbC5yZXRyeUJhY2tPZmZ9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxmZXRjaE1pbkJ5dGVzPiBcIiR7cHJvdG9jb2wuZmV0Y2hNaW5CeXRlc31cIiAuXG4gICAgICAgICAgICB1aWQodikgPGZldGNoTWF4V2FpdD4gXCIke3Byb3RvY29sLmZldGNoTWF4V2FpdH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNvbW1pdEludGVydmFsPiBcIiR7cHJvdG9jb2wuY29tbWl0SW50ZXJ2YWx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxoZWFydGJlYXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmhlYXJ0YmVhdEludGVydmFsfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bWF4aW11bVFPUz4gXCIke3Byb3RvY29sLm1heGltdW1RT1N9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx1c2VybmFtZT4gXCIke3Byb3RvY29sLnVzZXJuYW1lfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8cGFzc3dvcmQ+IFwiJHtwcm90b2NvbC5wYXNzd29yZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGVuY3J5cHRpb25Nb2RlPiBcIiR7cHJvdG9jb2wuZW5jcnlwdGlvbk1vZGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxjYUNlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2FDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNsaWVudENlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2xpZW50Q2VydGlmaWNhdGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxjbGllbnRLZXk+IFwiJHtwcm90b2NvbC5jbGllbnRLZXl9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxhdXRoTW9kZT4gXCIke3Byb3RvY29sLmF1dGhNb2RlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8c2VydmVyQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5zZXJ2ZXJDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHNjb3BlPiBcIiR7cHJvdG9jb2wuc2NvcGV9XCIgLlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlICR7cHJvdG9jb2wudWlkfWApO1xuXG4gICAgICAgIC8vIFdpdGggdGhlIHVwc2VydCBhcHByb2FjaCwgaXQgaXMgbm90IHBvc3NpYmxlIHRvIHNlZSBpZiB0aGUgbXV0YXRpb24gb2NjdXJyZWQuXG4gICAgICAgIC8vIFVzZSBhIHByZVF1ZXJ5IGZvciB0aGUgb2JqZWN0IGZpcnN0IHRvIGRldGVybWluZSBpZiBpdCBleGlzdHMuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVQcm90b2NvbCcsICdwcm90b2NvbCcsIHByb3RvY29sLnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdGVQcm90b2NvbCcpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBwcm90b2NvbCAke3Byb3RvY29sLnVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gcHJvdG9jb2wpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGRlbGV0ZVByb3RvY29sKGdhdGV3YXlVaWQ6IHN0cmluZywgcHJvdG9jb2xVaWQ6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ3Byb3RvY29sJywgcHJvdG9jb2xVaWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cHJvdG9jb2xVaWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBQcm90b2NvbCAke3Byb3RvY29sVWlkfSBmb3IgJHtnYXRld2F5VWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICdkZWxldGVQcm90b2NvbCcsICdwcm90b2NvbCcsIHByb3RvY29sVWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZVByb3RvY29sJykpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke3Byb3RvY29sVWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0RGF0YVN0b3JlcyhnYXRld2F5VXVpZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxEYXRhU3RvcmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhkYXRhU3RvcmUpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoXG4gICAgICAgICAgYWNjb3VudCxcbiAgICAgICl9IEFORCAoZXEoc2NvcGUsIFwiJHtnYXRld2F5VXVpZH1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSkge1xuICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIGRhdGFTdG9yZVR5cGVcbiAgICAgICAgaG9zdCBwb3J0IGRhdGFiYXNlTmFtZSB1c2VyIHBhc3N3b3JkIGFjY291bnROYW1lXG4gICAgICAgIHdhcmVob3VzZSBkYXRhYmFzZSBzY2hlbWEgYXV0aFR5cGUgdXNlcm5hbWVcbiAgICAgICAgY2xpZW50SWQgY2xpZW50U2VjcmV0IGF1dGhvcml6YXRpb25Db2RlXG4gICAgICAgIHJlZGlyZWN0VVJJIGxvZ2luVGltZW91dCB1cmwgc2NvcGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0RGF0YVN0b3JlcycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgRGF0YVN0b3JlW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIGRhdGFTdG9yZXMgZm9yIGdhdGV3YXkgJHtnYXRld2F5VXVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkRGF0YVN0b3JlKGdhdGV3YXlVaWQ6IHN0cmluZywgZGF0YVN0b3JlOiBEYXRhU3RvcmUsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERhdGFTdG9yZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGlmIChkYXRhU3RvcmUudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86RGF0YVN0b3JlIDxkZ3JhcGgudHlwZT4gXCJEYXRhU3RvcmVcIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx0eXBlPiBcImRhdGFTdG9yZVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFTdG9yZT4gXCJcIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1dWlkPiBcIiR7ZGF0YVN0b3JlLnV1aWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8Y3JlYXRlZD4gXCIke2RhdGFTdG9yZS5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPG1vZGlmaWVkPiBcIiR7ZGF0YVN0b3JlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFTdG9yZVR5cGU+IFwiJHtkYXRhU3RvcmUuZGF0YVN0b3JlVHlwZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxob3N0PiBcIiR7ZGF0YVN0b3JlLmhvc3R9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8cG9ydD4gXCIke2RhdGFTdG9yZS5wb3J0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFiYXNlTmFtZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXNlcj4gXCIke2RhdGFTdG9yZS51c2VyfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHBhc3N3b3JkPiBcIiR7ZGF0YVN0b3JlLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGFjY291bnROYW1lPiBcIiR7ZGF0YVN0b3JlLmFjY291bnROYW1lfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHdhcmVob3VzZT4gXCIke2RhdGFTdG9yZS53YXJlaG91c2V9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YWJhc2U+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHNjaGVtYT4gXCIke2RhdGFTdG9yZS5zY2hlbWF9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8YXV0aFR5cGU+IFwiJHtkYXRhU3RvcmUuYXV0aFR5cGV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXNlcm5hbWU+IFwiJHtkYXRhU3RvcmUudXNlcm5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8Y2xpZW50SWQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50SWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8Y2xpZW50U2VjcmV0PiBcIiR7ZGF0YVN0b3JlLmNsaWVudFNlY3JldH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhdXRob3JpemF0aW9uQ29kZT4gXCIke2RhdGFTdG9yZS5hdXRob3JpemF0aW9uQ29kZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxyZWRpcmVjdFVSST4gXCIke2RhdGFTdG9yZS5yZWRpcmVjdFVSSX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxsb2dpblRpbWVvdXQ+IFwiJHtkYXRhU3RvcmUubG9naW5UaW1lb3V0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHVybD4gXCIke2RhdGFTdG9yZS51cmx9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8c2NvcGU+IFwiJHtkYXRhU3RvcmUuc2NvcGV9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgQWRkZWQgZGF0YXN0b3JlICR7ZGF0YVN0b3JlLnV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2FkZERhdGFTdG9yZScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdEYXRhU3RvcmUnKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZGF0YVN0b3JlLnVpZCA9IGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGRhdGFTdG9yZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGQgZGF0YVN0b3JlcyAke2RhdGFTdG9yZS51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZURhdGFTdG9yZShkYXRhU3RvcmU6IERhdGFTdG9yZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8RGF0YVN0b3JlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ2RhdGFTdG9yZScsIGRhdGFTdG9yZS51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtkYXRhU3RvcmUudWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICAgIHV1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgICAgICB1aWQodikgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHV1aWQ+IFwiJHtkYXRhU3RvcmUudXVpZH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxtb2RpZmllZD4gXCIke2RhdGFTdG9yZS5tb2RpZmllZH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxkYXRhU3RvcmVUeXBlPiBcIiR7ZGF0YVN0b3JlLmRhdGFTdG9yZVR5cGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8aG9zdD4gXCIke2RhdGFTdG9yZS5ob3N0fVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHBvcnQ+IFwiJHtkYXRhU3RvcmUucG9ydH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxkYXRhYmFzZU5hbWU+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVzZXI+IFwiJHtkYXRhU3RvcmUudXNlcn1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxwYXNzd29yZD4gXCIke2RhdGFTdG9yZS5wYXNzd29yZH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxhY2NvdW50TmFtZT4gXCIke2RhdGFTdG9yZS5hY2NvdW50TmFtZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDx3YXJlaG91c2U+IFwiJHtkYXRhU3RvcmUud2FyZWhvdXNlfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGRhdGFiYXNlPiBcIiR7ZGF0YVN0b3JlLmRhdGFiYXNlTmFtZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxzY2hlbWE+IFwiJHtkYXRhU3RvcmUuc2NoZW1hfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGF1dGhUeXBlPiBcIiR7ZGF0YVN0b3JlLmF1dGhUeXBlfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVzZXJuYW1lPiBcIiR7ZGF0YVN0b3JlLnVzZXJuYW1lfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGNsaWVudElkPiBcIiR7ZGF0YVN0b3JlLmNsaWVudElkfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGNsaWVudFNlY3JldD4gXCIke2RhdGFTdG9yZS5jbGllbnRTZWNyZXR9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8YXV0aG9yaXphdGlvbkNvZGU+IFwiJHtkYXRhU3RvcmUuYXV0aG9yaXphdGlvbkNvZGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cmVkaXJlY3RVUkk+IFwiJHtkYXRhU3RvcmUucmVkaXJlY3RVUkl9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8bG9naW5UaW1lb3V0PiBcIiR7ZGF0YVN0b3JlLmxvZ2luVGltZW91dH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDx1cmw+IFwiJHtkYXRhU3RvcmUudXJsfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHNjb3BlPiBcIiR7ZGF0YVN0b3JlLnNjb3BlfVwiIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgZGF0YVN0b3JlICR7ZGF0YVN0b3JlLnVpZH1gKTtcblxuICAgICAgICAvLyBXaXRoIHRoZSB1cHNlcnQgYXBwcm9hY2gsIGl0IGlzIG5vdCBwb3NzaWJsZSB0byBzZWUgaWYgdGhlIG11dGF0aW9uIG9jY3VycmVkLlxuICAgICAgICAvLyBVc2UgYSBwcmVRdWVyeSBmb3IgdGhlIG9iamVjdCBmaXJzdCB0byBkZXRlcm1pbmUgaWYgaXQgZXhpc3RzLlxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlRGF0YVN0b3JlJywgJ2RhdGFTdG9yZScsIGRhdGFTdG9yZS51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlRGF0YVN0b3JlJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIGRhdGFTdG9yZSAke2RhdGFTdG9yZS51aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGRhdGFTdG9yZSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlRGF0YVN0b3JlKGdhdGV3YXlVdWlkOiBzdHJpbmcsIGRhdGFTdG9yZVV1aWQ6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ2RhdGFTdG9yZScsIGRhdGFTdG9yZVV1aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7ZGF0YVN0b3JlVXVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgZGVsZXRlIHtcbiAgICAgICAgICAgICAgICB1aWQodikgKiAqIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIERhdGFTdG9yZSAke2RhdGFTdG9yZVV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZURhdGFTdG9yZScsICdkYXRhU3RvcmUnLCBkYXRhU3RvcmVVdWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZURhdGFTdG9yZScpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZGVsZXRlZCBkYXRhU3RvcmUgJHtkYXRhU3RvcmVVdWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgJHtkYXRhU3RvcmVVdWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheUFuZFJlc3RFbmRwb2ludHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICAgIG1vZGVsczogZ2F0ZXdheV9tb2RlbCB7XG4gICAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBuYW1lXG4gICAgICAgICAgZGVzY3JpcHRpb24gaW5wdXRUeXBlIHVybCBzY29wZVxuICAgICAgICAgIGlucHV0VGVtcGxhdGUgaGVhZGVycyBtZXRob2QgYmFzZTY0RW5jb2RlZFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBHZXQgR2F0ZXdheSBhbmQgUHJvdG9jb2xzIGZvciAke2dhdGV3YXlOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRHYXRld2F5QW5kTW9kZWxzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIGdhdGV3YXlzIGFuZCBtb2RlbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFJlc3RFbmRwb2ludHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UmVzdEVuZHBvaW50W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMobW9kZWwpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoXG4gICAgICAgICAgYWNjb3VudCxcbiAgICAgICl9IEFORCAoZXEoc2NvcGUsIFwiJHtnYXRld2F5TmFtZX1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSkge1xuICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIG5hbWVcbiAgICAgICAgZGVzY3JpcHRpb24gaW5wdXRUeXBlIHVybCBzY29wZSBpbnB1dFRlbXBsYXRlXG4gICAgICAgIGhlYWRlcnMgbWV0aG9kIGJhc2U2NEVuY29kZWRcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0TW9kZWxzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBSZXN0RW5kcG9pbnRbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgbW9kZWxzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRSZXN0RW5kcG9pbnQoZ2F0ZXdheVVpZDogc3RyaW5nLCBtb2RlbDogUmVzdEVuZHBvaW50LCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxSZXN0RW5kcG9pbnQ+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAobW9kZWwudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86TW9kZWwgPGRncmFwaC50eXBlPiBcIk1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDx0eXBlPiBcIm1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDxtb2RlbD4gXCJcIiAuXG4gICAgICAgIF86TW9kZWwgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8dXVpZD4gXCIke21vZGVsLnV1aWR9XCIgLlxuICAgICAgICBfOk1vZGVsIDxjcmVhdGVkPiBcIiR7bW9kZWwuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPG1vZGlmaWVkPiBcIiR7bW9kZWwubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOk1vZGVsIDxuYW1lPiBcIiR7bW9kZWwubmFtZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWwuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOk1vZGVsIDxpbnB1dFR5cGU+IFwiJHttb2RlbC5pbnB1dFR5cGV9XCIgLlxuICAgICAgICBfOk1vZGVsIDx1cmw+IFwiJHttb2RlbC51cmx9XCIgLlxuICAgICAgICBfOk1vZGVsIDxzY29wZT4gXCIke21vZGVsLnNjb3BlfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8aW5wdXRUZW1wbGF0ZT4gXCIke21vZGVsLmlucHV0VGVtcGxhdGV9XCIgLlxuICAgICAgICBfOk1vZGVsIDxoZWFkZXJzPiBcIiR7bW9kZWwuaGVhZGVyc31cIiAuXG4gICAgICAgIF86TW9kZWwgPG1ldGhvZD4gXCIke21vZGVsLm1ldGhvZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPGJhc2U2NEVuY29kZWQ+IFwiJHttb2RlbC5iYXNlNjRFbmNvZGVkfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEFkZCBtb2RlbCAke21vZGVsLnV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2FkZE1vZGVsJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ01vZGVsJyk7XG4gICAgICAgICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIG1vZGVsLnVpZCA9IGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IG1vZGVsKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZGVkIG1vZGVsICR7bW9kZWwudWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVSZXN0RW5kcG9pbnQobW9kZWw6IFJlc3RFbmRwb2ludCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UmVzdEVuZHBvaW50PiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ21vZGVsJywgbW9kZWwudWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke21vZGVsLnVpZH0pKVxuICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgIHVpZCh2KSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx1dWlkPiBcIiR7bW9kZWwudXVpZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPG1vZGlmaWVkPiBcIiR7bW9kZWwubW9kaWZpZWR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxuYW1lPiBcIiR7bW9kZWwubmFtZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWwuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxpbnB1dFR5cGU+IFwiJHttb2RlbC5pbnB1dFR5cGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx1cmw+IFwiJHttb2RlbC51cmx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzY29wZT4gXCIke21vZGVsLnNjb3BlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8aW5wdXRUZW1wbGF0ZT4gXCIke21vZGVsLmlucHV0VGVtcGxhdGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxoZWFkZXJzPiBcIiR7bW9kZWwuaGVhZGVyc31cIiAuXG4gICAgICAgICAgICB1aWQodikgPG1ldGhvZD4gXCIke21vZGVsLm1ldGhvZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGJhc2U2NEVuY29kZWQ+IFwiJHttb2RlbC5iYXNlNjRFbmNvZGVkfVwiIC5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgbW9kZWwgJHttb2RlbC51aWR9YCk7XG5cbiAgICAgICAgLy8gV2l0aCB0aGUgdXBzZXJ0IGFwcHJvYWNoLCBpdCBpcyBub3QgcG9zc2libGUgdG8gc2VlIGlmIHRoZSBtdXRhdGlvbiBvY2N1cnJlZC5cbiAgICAgICAgLy8gVXNlIGEgcHJlUXVlcnkgZm9yIHRoZSBvYmplY3QgZmlyc3QgdG8gZGV0ZXJtaW5lIGlmIGl0IGV4aXN0cy5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ3VwZGF0ZU1vZGVsJywgJ21vZGVsJywgbW9kZWwudWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ3VwZGF0ZU1vZGVsJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIG1vZGVsICR7bW9kZWwudWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBtb2RlbCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlUmVzdEVuZHBvaW50KGdhdGV3YXlVaWQ6IHN0cmluZywgbW9kZWxVaWQ6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ21vZGVsJywgbW9kZWxVaWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7bW9kZWxVaWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBNb2RlbCAke21vZGVsVWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICdkZWxldGVNb2RlbCcsICdtb2RlbCcsIG1vZGVsVWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZU1vZGVsJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIG1vZGVsICR7bW9kZWxVaWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke21vZGVsVWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheUFuZFBpcGVsaW5lcyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBwaXBlbGluZV9wcm90b2NvbCA9IGBwcm90b2NvbDogcGlwZWxpbmVfcHJvdG9jb2wge1xuICAgICAgICB1aWQgdXVpZCBicm9rZXJVUkwgdG9waWMgbWF4aW11bVFPUyB1c2VybmFtZSBwYXNzd29yZCBlbmNyeXB0aW9uTW9kZSBjYUNlcnRpZmljYXRlXG4gICAgICAgIGNsaWVudENlcnRpZmljYXRlIGNsaWVudEtleSBhdXRoTW9kZSBzZXJ2ZXJDZXJ0aWZpY2F0ZSBjb25zdW1lckdyb3VwSWQgY29ubmVjdGlvblRpbWVvdXRcbiAgICAgICAgc2Vzc2lvblRpbWVvdXQgcmV0cnlCYWNrT2ZmIGNvbW1pdEludGVydmFsIGluaXRpYWxPZmZzZXQgZmV0Y2hNaW5CeXRlcyBmZXRjaE1heFdhaXQgaGVhcnRiZWF0SW50ZXJ2YWxcbiAgICAgIH1gO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9kYXRhc3RvcmUgPSBgZGF0YVN0b3JlOiBwaXBlbGluZV9kYXRhc3RvcmUge1xuICAgICAgICB1aWQgdXVpZCBob3N0IHBvcnQgZGF0YWJhc2VOYW1lIHVzZXIgcGFzc3dvcmQgYWNjb3VudE5hbWUgd2FyZWhvdXNlIGRhdGFiYXNlIHNjaGVtYSBhdXRoVHlwZVxuICAgICAgICB1c2VybmFtZSBjbGllbnRJZCBjbGllbnRTZWNyZXQgYXV0aG9yaXphdGlvbkNvZGUgcmVkaXJlY3RVUkkgbG9naW5UaW1lb3V0IHVybFxuICAgICAgfWA7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2ZpbHRlciA9ICdmaWx0ZXI6IHBpcGVsaW5lX2ZpbHRlciB7IHVpZCBkZXZpY2VOYW1lcyB9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfc3RyZWFtaW5nID1cbiAgICAgICAgICAgICdzdHJlYW1pbmc6IHBpcGVsaW5lX3N0cmVhbWluZyB7IHVpZCBkZXZpY2VOYW1lIGluc3RydW1lbnROYW1lIGZ1bmN0aW9uIHdpbmRvd1R5cGUgd2luZG93U2l6ZSB9JztcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhnYXRld2F5KSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICB1aWQgdXVpZCBhY2Nlc3NUb2tlbiB1c2VybmFtZSBwbGF0Zm9ybSBhZGRyZXNzIHJvdXRlciByb3V0ZXJQb3J0IGRlcGxveU5ldHdvcmsgZGV2aWNlc01ldGFkYXRhXG4gICAgICAgIHBpcGVsaW5lczogZ2F0ZXdheV9waXBlbGluZSB7XG4gICAgICAgICAgdWlkIG5hbWUgdXVpZCBwaXBlbGluZVR5cGUgZGVwbG95ZXJUeXBlIHByb3RvY29sVHlwZSBwcm90b2NvbElkIGRhdGFTdG9yZVR5cGVcbiAgICAgICAgICBkYXRhU3RvcmVJZCBjcmVhdGVkIG1vZGlmaWVkIGRlc2NyaXB0aW9uIHN0YXR1cyBmbG93Q29uZmlndXJhdGlvblxuICAgICAgICAgIGxvZ0xldmVsIHN1YnNjcmlwdGlvblRvcGljXG4gICAgICAgICAgJHtwaXBlbGluZV9wcm90b2NvbH1cbiAgICAgICAgICAke3BpcGVsaW5lX2RhdGFzdG9yZX1cbiAgICAgICAgICAke3BpcGVsaW5lX2ZpbHRlcn1cbiAgICAgICAgICAke3BpcGVsaW5lX3N0cmVhbWluZ31cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgR2V0IEdhdGV3YXkgYW5kIFBpcGVsaW5lcyBmb3IgJHtnYXRld2F5TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0R2F0ZXdheVdpdGhQaXBlbGluZXMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgR2F0ZXdheSBhbmQgcGlwZWxpbmVzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRQaXBlbGluZXMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3Byb3RvY29sID0gYHByb3RvY29sOiBwaXBlbGluZV9wcm90b2NvbCB7XG4gICAgICAgICAgICAgIHVpZCBicm9rZXJVUkwgdG9waWMgbWF4aW11bVFPUyB1c2VybmFtZSBwYXNzd29yZCBlbmNyeXB0aW9uTW9kZSBjYUNlcnRpZmljYXRlXG4gICAgICAgICAgICAgIGNsaWVudENlcnRpZmljYXRlIGNsaWVudEtleSBhdXRoTW9kZSBzZXJ2ZXJDZXJ0aWZpY2F0ZSBjb25zdW1lckdyb3VwSWQgY29ubmVjdGlvblRpbWVvdXRcbiAgICAgICAgICAgICAgc2Vzc2lvblRpbWVvdXQgcmV0cnlCYWNrT2ZmIGNvbW1pdEludGVydmFsIGluaXRpYWxPZmZzZXQgZmV0Y2hNaW5CeXRlcyBmZXRjaE1heFdhaXQgaGVhcnRiZWF0SW50ZXJ2YWxcbiAgfSBgO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9kYXRhc3RvcmUgPSBgZGF0YXN0b3JlOiBwaXBlbGluZV9kYXRhc3RvcmUge1xuICAgICAgICAgICAgICB1aWQgaG9zdCBwb3J0IGRhdGFiYXNlTmFtZSB1c2VyIHBhc3N3b3JkIGFjY291bnROYW1lIHdhcmVob3VzZSBkYXRhYmFzZSBzY2hlbWEgYXV0aFR5cGVcbiAgICAgICAgICAgICAgdXNlcm5hbWUgY2xpZW50SWQgY2xpZW50U2VjcmV0IGF1dGhvcml6YXRpb25Db2RlIHJlZGlyZWN0VVJJIGxvZ2luVGltZW91dCB1cmxcbiAgICAgICAgICAgIH1gO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9maWx0ZXIgPSAnZmlsdGVyOiBwaXBlbGluZV9maWx0ZXIge3VpZCBkZXZpY2VOYW1lc30nO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9zdHJlYW1pbmcgPVxuICAgICAgICAgICAgJ3N0cmVhbWluZzogcGlwZWxpbmVfc3RyZWFtaW5nIHt1aWQgZGV2aWNlTmFtZSBpbnN0cnVtZW50TmFtZSBmdW5jdGlvbiB3aW5kb3dUeXBlIHdpbmRvd1NpemV9JztcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHBpcGVsaW5lcyBhcyBnYXRld2F5X3BpcGVsaW5lIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocGlwZWxpbmVzKSkge1xuICAgICAgICB1aWQgbmFtZSB1dWlkIHBpcGVsaW5lVHlwZSBkZXBsb3llclR5cGUgcHJvdG9jb2xUeXBlIHByb3RvY29sSWRcbiAgICAgICAgZGF0YVN0b3JlVHlwZSBkYXRhU3RvcmVJZCBjcmVhdGVkIG1vZGlmaWVkIGRlc2NyaXB0aW9uIHN0YXR1c1xuICAgICAgICBmbG93Q29uZmlndXJhdGlvbiBsb2dMZXZlbCBzdWJzY3JpcHRpb25Ub3BpY1xuICAgICAgICAke3BpcGVsaW5lX3Byb3RvY29sfVxuICAgICAgICAke3BpcGVsaW5lX2RhdGFzdG9yZX1cbiAgICAgICAgJHtwaXBlbGluZV9maWx0ZXJ9XG4gICAgICAgICR7cGlwZWxpbmVfc3RyZWFtaW5nfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRQaXBlbGluZXMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFBpcGVsaW5lW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHBpcGVsaW5lcyBmb3IgJHtnYXRld2F5TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkUGlwZWxpbmUoXG4gICAgICAgIGdhdGV3YXlVaWQ6IHN0cmluZyxcbiAgICAgICAgcGlwZWxpbmU6IFBpcGVsaW5lLFxuICAgICAgICB0cmFuc3BvcnRPYmo/OiBhbnksXG4gICAgICAgIGRhdGFTdG9yZU9iaj86IGFueSxcbiAgICAgICAgZmlsdGVyT2JqPzogYW55LFxuICAgICAgICBzdHJlYW1pbmdPYmo/OiBhbnksXG4gICAgICAgIGFjY291bnQ/OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxQaXBlbGluZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGlmIChwaXBlbGluZS51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpQaXBlbGluZSA8ZGdyYXBoLnR5cGU+IFwiUGlwZWxpbmVcIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8bmFtZT4gXCIke3BpcGVsaW5lLm5hbWV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDx1dWlkPiBcIiR7cGlwZWxpbmUubmFtZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHR5cGU+IFwicGlwZWxpbmVcIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHBpcGVsaW5lPiBcIlwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8cGlwZWxpbmVUeXBlPiBcIiR7cGlwZWxpbmUucGlwZWxpbmVUeXBlfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8ZGVwbG95ZXJUeXBlPiBcIiR7cGlwZWxpbmUuZGVwbG95ZXJUeXBlfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8Y3JlYXRlZD4gXCIke3BpcGVsaW5lLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxtb2RpZmllZD4gXCIke3BpcGVsaW5lLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8ZGVzY3JpcHRpb24+IFwiJHtwaXBlbGluZS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHN0YXR1cz4gXCIke3BpcGVsaW5lLnN0YXR1c31cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGZsb3dDb25maWd1cmF0aW9uPiBcIiR7cGlwZWxpbmUuZmxvd0NvbmZpZ3VyYXRpb259XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxsb2dMZXZlbD4gXCIke3BpcGVsaW5lLmxvZ0xldmVsfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8c3Vic2NyaXB0aW9uVG9waWM+IFwiJHtwaXBlbGluZS5zdWJzY3JpcHRpb25Ub3BpY31cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHBpcGVsaW5lLnJlcXVpcmVtZW50PiBcIiR7cGlwZWxpbmUucmVxdWlyZW1lbnR9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxjb25maWd1cmF0aW9uRmlsZT4gXCIke3BpcGVsaW5lLmNvbmZpZ3VyYXRpb25GaWxlfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X3BpcGVsaW5lPiBfOlBpcGVsaW5lIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYGFkZCBQaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkUGlwZWxpbmUnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkID0gdGhpcy5nZXRJREZyb21SZXNwb25zZShyZXNwb25zZS5kYXRhLCAnUGlwZWxpbmUnKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcGlwZWxpbmUudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gcGlwZWxpbmUpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgYWRkZWQgcGlwZWxpbmUgJHtwaXBlbGluZS51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZVBpcGVsaW5lKHBpcGVsaW5lOiBQaXBlbGluZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmU+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncGlwZWxpbmUnLCBwaXBlbGluZS51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cGlwZWxpbmUudWlkfSkpXG4gICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICBzZXQge1xuICAgICAgICAgICAgdWlkKHYpIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICB1aWQodikgPGRlc2NyaXB0aW9uPiBcIiR7cGlwZWxpbmUuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzdGF0dXM+IFwiJHtwaXBlbGluZS5zdGF0dXN9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxtb2RpZmllZD4gXCIke3BpcGVsaW5lLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGxvZ0xldmVsPiBcIiR7cGlwZWxpbmUubG9nTGV2ZWx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzdWJzY3JpcHRpb25Ub3BpYz4gXCIke3BpcGVsaW5lLnN1YnNjcmlwdGlvblRvcGljfVwiIC5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgdXBkYXRlIFBpcGVsaW5lICR7cGlwZWxpbmUudWlkfWApO1xuXG4gICAgICAgIC8vIFdpdGggdGhlIHVwc2VydCBhcHByb2FjaCwgaXQgaXMgbm90IHBvc3NpYmxlIHRvIHNlZSBpZiB0aGUgbXV0YXRpb24gb2NjdXJyZWQuXG4gICAgICAgIC8vIFVzZSBhIHByZVF1ZXJ5IGZvciB0aGUgb2JqZWN0IGZpcnN0IHRvIGRldGVybWluZSBpZiBpdCBleGlzdHMuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVQaXBlbGluZScsICdwaXBlbGluZScsIHBpcGVsaW5lLnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdGVQaXBlbGluZScpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBwaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gcGlwZWxpbmUpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGRlbGV0ZVBpcGVsaW5lKGdhdGV3YXlVaWQ6IHN0cmluZywgcGlwZWxpbmVJZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncGlwZWxpbmUnLCBwaXBlbGluZUlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke3BpcGVsaW5lSWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X3BpcGVsaW5lPiA8JHtwaXBlbGluZUlkfT4gLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBkZWxldGUgUGlwZWxpbmUgJHtwaXBlbGluZUlkfSB3aXRoIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICdkZWxldGVQaXBlbGluZScsICdwaXBlbGluZScsIHBpcGVsaW5lSWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlUGlwZWxpbmUnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGRlbGV0ZWQgcGlwZWxpbmUgJHtwaXBlbGluZUlkfSB3aXRoIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgcGlwZWxpbmUgZGVsZXRlZGApLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBQeXRob24gUmVzb3VyY2VzLlxuICAgICAqIEBwYXJhbSBnYXRld2F5VWlkXG4gICAgICovXG4gICAgZ2V0UHl0aG9uUmVzb3VyY2VzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFB5dGhvblJlc291cmNlW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgIHtcbiAgICAgIHJlc3AoZnVuYzogdHlwZShQeXRob25SZXNvdXJjZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShcbiAgICAgICAgICBhY2NvdW50LFxuICAgICAgKX0gQU5EKGVxKHNjb3BlLCBcIiR7Z2F0ZXdheU5hbWV9XCIpIE9SIGVxKHNjb3BlLCBcIkdMT0JBTFwiKSkpIHtcbiAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBuYW1lIHR5cGUgc2NvcGUgZmlsZUNvbnRlbnQgaW5wdXRzIG91dHB1dHMgZmlsZVBhdGhcbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYGdldCBweXRob24gcmVzb3VyY2UgZnJvbSAke2dhdGV3YXlOYW1lfWApO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UHl0aG9uUmVzb3VyY2UnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFB5dGhvblJlc291cmNlW10pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZSBQeXRob24gUmVzb3VyY2UuXG4gICAgICogQHBhcmFtIFB5dGhvblJlc291cmNlXG4gICAgICovXG4gICAgdXBkYXRlUHl0aG9uUmVzb3VyY2UocHl0aG9uUmVzb3VyY2U6IFB5dGhvblJlc291cmNlLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQeXRob25SZXNvdXJjZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdweXRob25SZXNvdXJjZScsIHB5dGhvblJlc291cmNlLnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cHl0aG9uUmVzb3VyY2UudWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBzZXQge1xuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPG1vZGlmaWVkPiBcIiR7cHl0aG9uUmVzb3VyY2UubW9kaWZpZWR9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxuYW1lPiBcIiR7cHl0aG9uUmVzb3VyY2UubmFtZX1cIiAuXG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPHNjb3BlPiBcIiR7cHl0aG9uUmVzb3VyY2Uuc2NvcGV9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDx0eXBlPiBcIiR7cHl0aG9uUmVzb3VyY2UudHlwZX1cIiAuXG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPGZpbGVDb250ZW50PiBcIiR7cHl0aG9uUmVzb3VyY2UuZmlsZUNvbnRlbnR9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxpbnB1dHM+IFwiJHtweXRob25SZXNvdXJjZS5pbnB1dHN9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxvdXRwdXRzPiBcIiR7cHl0aG9uUmVzb3VyY2Uub3V0cHV0c31cIiAuXG4gICAgICAgICAgICAgICAgPCR7cHl0aG9uUmVzb3VyY2UudWlkfT4gPGZpbGVQYXRoPiBcIiR7cHl0aG9uUmVzb3VyY2UuZmlsZVBhdGh9XCIgLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgUHl0aG9uUmVzb3VyY2UgJHtweXRob25SZXNvdXJjZS51aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ3VwZGF0ZVB5dGhvblJlc291cmNlJywgJ3B5dGhvblJlc291cmNlJywgcHl0aG9uUmVzb3VyY2UudWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ3VwZGF0ZVB5dGhvblJlc291cmNlJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIGZpbHRlckNvbmZpZyAke3B5dGhvblJlc291cmNlLnVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gcHl0aG9uUmVzb3VyY2UpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFkZCBQeXRob24gUmVzb3VyY2UuXG4gICAgICogQHBhcmFtIFB5dGhvblJlc291cmNlXG4gICAgICovXG4gICAgYWRkUHl0aG9uUmVzb3VyY2UoZ2F0ZXdheVV1aWQ6IHN0cmluZywgcHl0aG9uUmVzb3VyY2U6IFB5dGhvblJlc291cmNlLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQeXRob25SZXNvdXJjZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGlmIChweXRob25SZXNvdXJjZS51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYCB7XG4gICAgICBzZXQge1xuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxkZ3JhcGgudHlwZT4gXCJQeXRob25SZXNvdXJjZVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8cHl0aG9uUmVzb3VyY2U+IFwiXCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDx0eXBlPiBcInB5dGhvblJlc291cmNlXCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPG5hbWU+IFwiJHtweXRob25SZXNvdXJjZS5uYW1lfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8Y3JlYXRlZD4gXCIke3B5dGhvblJlc291cmNlLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxtb2RpZmllZD4gXCIke3B5dGhvblJlc291cmNlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8dHlwZT4gXCIke3B5dGhvblJlc291cmNlLnR5cGV9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxmaWxlQ29udGVudD4gXCIke3B5dGhvblJlc291cmNlLmZpbGVDb250ZW50fVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8c2NvcGU+IFwiJHtweXRob25SZXNvdXJjZS5zY29wZX1cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPGlucHV0cz4gXCIke3B5dGhvblJlc291cmNlLmlucHV0c31cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPG91dHB1dHM+IFwiJHtweXRob25SZXNvdXJjZS5vdXRwdXRzfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8ZmlsZVBhdGg+IFwiJHtweXRob25SZXNvdXJjZS5maWxlUGF0aH1cIiAuXG4gICAgICB9fWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYEFkZCBQeXRob25SZXNvdXJjZSAke3B5dGhvblJlc291cmNlLm5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2FkZFB5dGhvblJlc291cmNlJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ1B5dGhvblJlc291cmNlJyk7XG4gICAgICAgICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHB5dGhvblJlc291cmNlLnVpZCA9IGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IHB5dGhvblJlc291cmNlKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBweXRob25SZXNvdXJjZSAke3B5dGhvblJlc291cmNlLnVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGVsZXRlIFB5dGhvbiBSZXNvdXJjZS5cbiAgICAgKiBAcGFyYW0gcmVzb3VyY2VVaWRcbiAgICAgKi9cbiAgICBkZWxldGVQeXRob25SZXNvdXJjZShweXRob25SZXNvdXJjZVVpZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncHl0aG9uUmVzb3VyY2UnLCBweXRob25SZXNvdXJjZVVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtweXRob25SZXNvdXJjZVVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgZGVsZXRlIHtcbiAgICAgICAgICAgICAgICB1aWQodikgKiAqIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgJHtweXRob25SZXNvdXJjZVVpZH0gaXMgYmVpbmcgZGVsZXRlZGApO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAnZGVsZXRlUHl0aG9uUmVzb3VyY2UnLCAncHl0aG9uUmVzb3VyY2UnLCBweXRob25SZXNvdXJjZVVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdkZWxldGVQeXRob25SZXNvdXJjZScpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBmaWx0ZXJDb25maWcgJHtweXRob25SZXNvdXJjZVVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gYCR7cHl0aG9uUmVzb3VyY2VVaWR9IGRlbGV0ZWRgKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5ncyhcbiAgICAgICAgZ2F0ZXdheVV1aWQ6IHN0cmluZyxcbiAgICAgICAgZGV2aWNlTmFtZTogc3RyaW5nLFxuICAgICAgICBpbnN0cnVtZW50TmFtZTogc3RyaW5nLFxuICAgICAgICBudW1SZWFkaW5nczogbnVtYmVyLFxuICAgICAgICBhY2NvdW50Pzogc3RyaW5nLFxuICAgICk6IE9ic2VydmFibGU8UmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhyZXNvdXJjZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIChmaXJzdDotJHtudW1SZWFkaW5nc30pIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocmVhZGluZ3MpLCBvcmRlcmFzYzpjcmVhdGVkKSB7XG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgdmFsdWVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgZ2V0UmVhZGluZ3MgZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFJlYWRpbmdzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFJlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IGNvbnNvbGUubG9nKCdSZXNwb25zZSBmcm9tIGdldFJlYWRpbmdzOiAnLCByZXNwb25zZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc0F0KGRldmljZU5hbWU6IHN0cmluZywgaW5zdHJ1bWVudE5hbWU6IHN0cmluZywgdHM6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhyZXNvdXJjZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEoY3JlYXRlZCwgJHt0c30pKSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldFJlYWRpbmdzQXQgZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFJlYWRpbmdzQXQnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIFJlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc1N0YXJ0aW5nQXQoZGV2aWNlTmFtZTogc3RyaW5nLCBpbnN0cnVtZW50TmFtZTogc3RyaW5nLCBmcm9tdHM6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhyZXNvdXJjZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRSZWFkaW5nc1N0YXJ0aW5nQXQgZm9yIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRSZWFkaW5nc1N0YXJ0aW5nQXQnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIFJlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHN0YXJ0ZWQgYXQgcmVhZGluZ3MgZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFJlYWRpbmdzQmV0d2VlbihcbiAgICAgICAgZ2F0ZXdheVV1aWQ6IHN0cmluZyxcbiAgICAgICAgZGV2aWNlTmFtZTogc3RyaW5nLFxuICAgICAgICBpbnN0cnVtZW50TmFtZTogc3RyaW5nLFxuICAgICAgICBmcm9tdHM6IG51bWJlcixcbiAgICAgICAgdG90czogbnVtYmVyLFxuICAgICAgICBhY2NvdW50Pzogc3RyaW5nLFxuICAgICk6IE9ic2VydmFibGU8UmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhyZXNvdXJjZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSBBTkQgbHQoY3JlYXRlZCwgJHt0b3RzfSkpIChmaXJzdDotNTAwKSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldFJlYWRpbmdzQmV0d2VlbiBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UmVhZGluZ3NCZXR3ZWVuJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFJlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCByZWFkaW5ncyBiZXR3ZWVuIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRMYXN0UmVhZGluZ3NGb3JEZXZpY2UoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxSZWFkaW5nW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhkZXZpY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1cIikpIEBub3JtYWxpemUge1xuICAgICAgICBkZXZpY2VfcmVzb3VyY2Uge1xuICAgICAgICAgIG5hbWU6IG5hbWVcbiAgICAgICAgICByZXNvdXJjZV9yZWFkaW5nIChmaXJzdDotMSkge1xuICAgICAgICAgICAgY3JlYXRlZDogY3JlYXRlZFxuICAgICAgICAgICAgdmFsdWU6IHZhbHVlXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldExhc3RSZWFkaW5nc0ZvckRldmljZSBmb3IgJHtkZXZpY2VOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRMYXN0UmVhZGluZ3NGb3JEZXZpY2UnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIFJlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIGxhc3QgcmVhZGluZ3MgZm9yICR7ZGV2aWNlTmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgIGFkZFJlYWRpbmcoXG4gICAgICAgIGdhdGV3YXlVdWlkOiBzdHJpbmcsXG4gICAgICAgIGRldmljZU5hbWU6IHN0cmluZyxcbiAgICAgICAgaW5zdHJ1bWVudE5hbWU6IHN0cmluZyxcbiAgICAgICAgcmVhZGluZzogUmVhZGluZ1tdLFxuICAgICAgICBhY2NvdW50SWQ6IHN0cmluZyxcbiAgICApOiBQcm9taXNlPFJlYWRpbmdbXT4ge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ09ubHkgc3VwcG9ydHMgR3JhcGhRTCBncmFwaCBzZXJ2aWNlJyk7XG4gICAgfVxuXG4gICAgZ2V0Tm90aWZpY2F0aW9ucyhhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxOb3RpZmljYXRpb25bXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zb2xlLmxvZygnR2V0Tm90aWZpY2F0aW9ucyBzZXJ2aWNlIGNhbGxlZCcpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhub3RpZmljYXRpb24pKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSBAbm9ybWFsaXplIHtcbiAgICAgICAgdWlkIHV1aWQ6dXVpZCBjcmVhdGVkOmNyZWF0ZWQgbm90aWZ5U291cmNlOm5vdGlmeVNvdXJjZSBub3RpZnlEZXZpY2U6bm90aWZ5RGV2aWNlXG4gICAgICAgIG5vdGlmeVJlc291cmNlOm5vdGlmeVJlc291cmNlIG5vdGlmeUxldmVsOm5vdGlmeUxldmVsIHZhbHVlOnZhbHVlIGRlc2NyaXB0aW9uOmRlc2NyaXB0aW9uXG4gICAgICAgIH5nYXRld2F5X25vdGlmaWNhdGlvbiB7XG4gICAgICAgICAgZ2F0ZXdheTogdXVpZFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldE5vdGlmaWNhdGlvbnMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5yZXNwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5yZXNwIGFzIE5vdGlmaWNhdGlvbltdO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbXSBhcyBOb3RpZmljYXRpb25bXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBub3RpZmljYXRpb25zYCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgICBhZGROb3RpZmljYXRpb24oZ2F0ZXdheVV1aWQ6IHN0cmluZywgbm90aWZpY2F0aW9uOiBOb3RpZmljYXRpb24sIGFjY291bnRJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxOb3RpZmljYXRpb24+IHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdPbmx5IHN1cHBvcnRzIEdyYXBoUUwgZ3JhcGggc2VydmljZScpO1xuICAgIH1cblxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgICBkZWxldGVOb3RpZmljYXRpb24oZ2F0ZXdheVV1aWQ6IHN0cmluZywgbm90aWZpY2F0aW9uVXVpZDogc3RyaW5nLCBhY2NvdW50SWQ6IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignT25seSBzdXBwb3J0cyBHcmFwaFFMIGdyYXBoIHNlcnZpY2UnKTtcbiAgICB9XG5cbiAgICBlbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50Pzogc3RyaW5nKSB7XG4gICAgICAgIGlmICh0aGlzLnJlcXVpcmVBY2NvdW50SWQpIHtcbiAgICAgICAgICAgIGlmICghYWNjb3VudCkgdGhyb3cgbmV3IEVycm9yKCdBY2NvdW50IG11c3QgZXhpc3QnKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldEFjY291bnRRdWVyeShhY2NvdW50Pzogc3RyaW5nKSB7XG4gICAgICAgIGlmICh0aGlzLnJlcXVpcmVBY2NvdW50SWQpIHtcbiAgICAgICAgICAgIHJldHVybiBgZXEoYWNjb3VudCwgXCIke2FjY291bnR9XCIpYDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBgKGVxKGFjY291bnQsIFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiKSBPUiBub3QoaGFzKGFjY291bnQpKSlgO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGlzY292ZXJzIHRoZSBwcmVzZW5jZSBvZiBlcnJvcnMgaW4gdGhlIHJlc3BvbnNlIGZyb20gZEdyYXBoIGFuZCByZXBvcnRzIHRoZW0uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gcmVzcG9uc2UgdGhlIHJlc3BvbnNlIG9iamVjdCBmcm9tIGRHcmFwaFxuICAgICAqIEBwYXJhbSBvcGVyYXRpb24gdGhlIG9wZXJhdGlvbiB0aGF0IHdhcyBiZWluZyBwZXJmb3JtZWQgZm9yIGxvZ2dpbmcgcHVycG9zZXNcbiAgICAgKi9cbiAgICBjaGVja0ZvckVycm9ycyhyZXNwb25zZTogYW55LCBvcGVyYXRpb24gPSAnb3BlcmF0aW9uJykge1xuICAgICAgICBsZXQgaGFzRXJyb3JzID0gZmFsc2U7XG4gICAgICAgIGxldCBlcnJvcnM7XG5cbiAgICAgICAgaWYgKHJlc3BvbnNlPy5kYXRhPy5lcnJvcnMpIHtcbiAgICAgICAgICAgIGhhc0Vycm9ycyA9IHRydWU7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgJHtvcGVyYXRpb259IGZhaWxlZDogJHtyZXNwb25zZS5kYXRhLmVycm9yc1swXS5tZXNzYWdlfWApO1xuICAgICAgICAgICAgZXJyb3JzID0geyBtZXNzYWdlOiByZXNwb25zZS5kYXRhLmVycm9yc1swXS5tZXNzYWdlIH07XG4gICAgICAgIH0gZWxzZSBpZiAocmVzcG9uc2U/LmVycm9ycykge1xuICAgICAgICAgICAgaGFzRXJyb3JzID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke29wZXJhdGlvbn0gZmFpbGVkOiAke3Jlc3BvbnNlLmVycm9yc1swXS5tZXNzYWdlfWApO1xuICAgICAgICAgICAgZXJyb3JzID0geyBtZXNzYWdlOiByZXNwb25zZS5lcnJvcnNbMF0ubWVzc2FnZSB9O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGhhc0Vycm9ycykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKEpTT04uc3RyaW5naWZ5KGVycm9ycykpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSWYgdGhlIG9wZXJhdGlvbiB3YXMgc3VjY2Vzc2Z1bCwgb2J0YWluIGEgVUlEIGZyb20gdGhlIHJlc3BvbnNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIGRHcmFwaFJlc3BvbnNlIEEgcmVzcG9uc2UgZnJvbSBkR3JhcGhcbiAgICAgKiBAcGFyYW0gb2JqZWN0S2V5IHRoZSBuYW1lIG9mIHRoZSBPYmplY3QsIGZvciBleGFtcGxlIEdhdGV3YXkgb3IgTW9kZWxcbiAgICAgKiBAcmV0dXJucyBhIFVJRCBmb3VuZCBmcm9tIHRoZSByZXNwb25zZVxuICAgICAqL1xuICAgIGdldElERnJvbVJlc3BvbnNlKGRHcmFwaFJlc3BvbnNlOiBHcmFwaFJlc3BvbnNlLCBvYmplY3RLZXk6IHN0cmluZyk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIGlmIChkR3JhcGhSZXNwb25zZS5jb2RlID09PSAnU3VjY2VzcycpIHtcbiAgICAgICAgICAgIGNvbnN0IHVpZCA9IGRHcmFwaFJlc3BvbnNlLnVpZHNbb2JqZWN0S2V5XTtcbiAgICAgICAgICAgIHJldHVybiB1aWQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICBnZXRQcmVRdWVyeShvYmplY3ROYW1lOiBzdHJpbmcsIHVpZDogc3RyaW5nIHwgbnVtYmVyIHwgdW5kZWZpbmVkLCBhY2NvdW50Pzogc3RyaW5nKSB7XG4gICAgICAgIGlmICghdWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoSlNPTi5zdHJpbmdpZnkoeyBtZXNzYWdlOiAnTm8gSUQgZGVmaW5lZCcgfSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBge1xuICAgICAgICByZXNwKGZ1bmM6IGhhcygke29iamVjdE5hbWV9KSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgKHVpZCgke3VpZH0pKSkge1xuICAgICAgICAgIHVpZCB1dWlkXG4gICAgICAgIH1cbiAgICAgIH1gO1xuICAgIH1cblxuICAgIGNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2U6IGFueSwgb3BlcmF0aW9uOiBzdHJpbmcsIG9iamVjdE5hbWU6IHN0cmluZywgdWlkOiBudW1iZXIgfCBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgaWYgKCF1aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihKU09OLnN0cmluZ2lmeSh7IG1lc3NhZ2U6ICdObyBJRCBkZWZpbmVkJyB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgb3BlcmF0aW9uKTtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocmVzcG9uc2UuZGF0YS5yZXNwKSkge1xuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2VBcnJheTogW10gPSByZXNwb25zZS5kYXRhLnJlc3A7XG4gICAgICAgICAgICBpZiAocmVzcG9uc2VBcnJheS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgdGhlICR7b2JqZWN0TmFtZX0gd2l0aCBJRCAke3VpZH0gZG9lcyBub3QgZXhpc3QgaW4gdGhpcyBhY2NvdW50YCk7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKEpTT04uc3RyaW5naWZ5KHsgbWVzc2FnZTogJ05vIGV4aXN0aW5nIG9iamVjdCcgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIEdyYXBoUmVzcG9uc2Uge1xuICAgIGNvZGU6IHN0cmluZztcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgcXVlcmllczogYW55O1xuICAgIHVpZHM6IHsgW2luZGV4OiBzdHJpbmddOiBzdHJpbmcgfTtcbn1cbiJdfQ==