import { catchError, map, of, tap } from 'rxjs';
const route1 = [
    [25.771088, -80.163483],
    [27.439775, -80.32299],
    [28.349469, -80.731105],
    [30.401564, -81.571033],
    [32.116716, -81.144147],
    [32.866511, -79.995399],
    [34.191224, -77.952419],
    [36.850172, -76.319269],
    [36.915037, -76.320643],
    [39.262025, -76.549294],
    [39.900933, -75.143453],
    [40.690263, -74.152375],
    [42.259951, -71.789244],
];
const route2 = [
    [47.492471, -122.26888],
    [45.552207, -122.722648],
    [39.53246, -119.751524],
    [37.803528, -122.312138],
    [37.899332, -121.169307],
    [36.273183, -115.070534],
    [33.77032, -118.273289],
    [34.106012, -117.320254],
    [33.515564, -112.160564],
    [32.126437, -110.848336],
    [31.752085, -106.488887],
    [35.04758, -106.653344],
    [39.796963, -104.995374],
];
const route3 = [
    [29.302729, -98.638744],
    [29.638421, -95.292245],
    [32.615525, -96.693485],
    [29.917836, -90.205272],
    [32.256403, -90.151546],
    [35.044849, -90.153006],
    [38.524627, -90.209535],
    [39.870851, -88.912284],
    [41.705694, -87.577341],
    [41.902382, -89.101932],
    [44.251243, -91.509663],
    [44.970069, -93.174527],
    [46.758181, -92.098748],
];
const emptyroute = [];
const httpOptions = {
    headers: {
        'Content-Type': 'application/graphql+-',
    },
};
const httpMutateOptions = {
    headers: { 'Content-Type': 'application/rdf' },
};
export class GraphService {
    constructor(http, dGraphUrl, accountRequired) {
        this.http = http;
        this.dGraphUrl = dGraphUrl;
        this.accountRequired = accountRequired;
        this.requireAccountId = true;
        this.requireAccountId = accountRequired;
        //const dGraphBasicAuthEnabled = this.appConfigService.dGraphBasicAuthEnabled;
        //if (dGraphBasicAuthEnabled) {
        //    const dGraphBasicAuth = this.appConfigService.dGraphBasicAuth;
        //    (this.httpOptions.headers = { 'Content-Type': 'application/graphql+-' }), { Authorization: dGraphBasicAuth };
        //    (this.httpMutateOptions.headers = { 'Content-Type': 'application/rdf' }), { Authorization: dGraphBasicAuth };
        //}
    }
    getGateway(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        console.log(`GetGateway service called for ${gatewayName}`);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), catchError(this.handleError('getGateway', [])));
    }
    getGateways(account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway))
      @filter(${this.getAccountQuery(account)}) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
        numDevices: count(gateway_device)
        }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log(`fetched ${response.length} gateways`)), catchError(this.handleError('getGateways', [])));
    }
    updateGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${gateway.uid}> <account> "${account ? account : ''}" .
        <${gateway.uid}> <address> "${gateway.address}" .
        <${gateway.uid}> <router> "${gateway.router}" .
        <${gateway.uid}> <routerPort> "${gateway.routerPort}" .
        <${gateway.uid}> <deployNetwork> "${gateway.deployNetwork}" .
        <${gateway.uid}> <description> "${gateway.description}" .
        <${gateway.uid}> <latitude> "${gateway.latitude}" .
        <${gateway.uid}> <longitude> "${gateway.longitude}" .
        <${gateway.uid}> <accessToken> "${gateway.accessToken}" .
        <${gateway.uid}> <username> "${gateway.username}" .
        <${gateway.uid}> <platform> "${gateway.platform}" .
        <${gateway.uid}> <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log(`Update Gateway ${gateway.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => 'gateway updated'), tap(() => console.log(`updated gateway ${gateway.uuid}`)), catchError(this.handleError('updateGateway')));
    }
    addGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Gateway <dgraph.type> "Gateway" .
        _:Gateway <gateway> "" .
        _:Gateway <type> "gateway" .
        _:Gateway <account> "${account ? account : ''}" .
        _:Gateway <uuid> "${gateway.uuid}" .
        _:Gateway <description> "${gateway.description}" .
        _:Gateway <address> "${gateway.address}" .
        _:Gateway <router> "${gateway.router}" .
        _:Gateway <routerPort> "${gateway.routerPort}" .
        _:Gateway <deployNetwork> "${gateway.deployNetwork}" .
        _:Gateway <latitude> "${gateway.latitude}" .
        _:Gateway <longitude> "${gateway.longitude}" .
        _:Gateway <accessToken> "${gateway.accessToken}" .
        _:Gateway <username> "${gateway.username}" .
        _:Gateway <platform> "${gateway.platform}" .
        _:Gateway <createdts> "${gateway.createdts}" .
        _:Gateway <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log(`Add Gateway ${gateway.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = gateway)), tap(() => console.log(`add gateway ${gateway.uid}/${gateway.uuid}`)), catchError(this.handleError('addGateway')));
    }
    deleteGateway(gatewayUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${gatewayUid}> <account> "${account ? account : ''}" .
      }
    }`;
        console.log(`Delete Gateway ${gatewayUid} `);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => `${gatewayUid} deleted`), tap(() => console.log(`deleted gateway ${gatewayUid}`)), catchError(this.handleError('deleteGateway')));
    }
    getGatewayAndProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid
        protocols: gateway_protocol {
          uid uuid created modified protocolType brokerURL
          topic consumerGroupId connectionTimeout sessionTimeout
          initialOffset retryBackOff fetchMinBytes fetchMaxWait
          commitInterval heartbeatInterval maximumQOS
          username password encryptionMode
          caCertificate clientCertificate clientKey
          authMode serverCertificate
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and Protocols for ${gatewayName}`)), catchError(this.handleError('getGatewayWithProtocols', [])));
    }
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayName
     */
    getProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(protocol)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified protocolType brokerURL topic
        consumerGroupId connectionTimeout sessionTimeout initialOffset
        retryBackOff fetchMinBytes fetchMaxWait commitInterval
        heartbeatInterval maximumQOS username password
        encryptionMode caCertificate clientCertificate clientKey
        authMode serverCertificate scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched protocols for ${gatewayName}`)), catchError(this.handleError('getProtocols', [])));
    }
    addProtocol(gatewayUid, protocol, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Protocol <dgraph.type> "Protocol" .
        _:Protocol <type> "protocol" .
        _:Protocol <protocol> "" .
        _:Protocol <account> "${account ? account : ''}" .
        _:Protocol <uuid> "${protocol.uuid}" .
        _:Protocol <created> "${protocol.created}" .
        _:Protocol <modified> "${protocol.modified}" .
        _:Protocol <protocolType> "${protocol.protocolType}" .
        _:Protocol <brokerURL> "${protocol.brokerURL}" .
        _:Protocol <topic> "${protocol.topic}" .
        _:Protocol <consumerGroupId> "${protocol.consumerGroupId}" .
        _:Protocol <connectionTimeout> "${protocol.connectionTimeout}" .
        _:Protocol <sessionTimeout> "${protocol.sessionTimeout}" .
        _:Protocol <initialOffset> "${protocol.initialOffset}" .
        _:Protocol <retryBackOff> "${protocol.retryBackOff}" .
        _:Protocol <fetchMinBytes> "${protocol.fetchMinBytes}" .
        _:Protocol <fetchMaxWait> "${protocol.fetchMaxWait}" .
        _:Protocol <commitInterval> "${protocol.commitInterval}" .
        _:Protocol <heartbeatInterval> "${protocol.heartbeatInterval}" .
        _:Protocol <maximumQOS> "${protocol.maximumQOS}" .
        _:Protocol <username> "${protocol.username}" .
        _:Protocol <password> "${protocol.password}" .
        _:Protocol <encryptionMode> "${protocol.encryptionMode}" .
        _:Protocol <caCertificate> "${protocol.caCertificate}" .
        _:Protocol <clientCertificate> "${protocol.clientCertificate}" .
        _:Protocol <clientKey> "${protocol.clientKey}" .
        _:Protocol <authMode> "${protocol.authMode}" .
        _:Protocol <serverCertificate> "${protocol.serverCertificate}" .
        _:Protocol <scope> "${protocol.scope}" .
      }
    }`;
        console.log(`Add protocol ${protocol.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = protocol)), tap(() => console.log(`add protocols ${protocol.uid}`)), catchError(this.handleError('addProtocols')));
    }
    updateProtocol(protocol, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${protocol.uid}> <account> "${account ? account : ''}" .
        <${protocol.uid}> <uuid> "${protocol.uuid}" .
        <${protocol.uid}> <modified> "${protocol.modified}" .
        <${protocol.uid}> <protocolType> "${protocol.protocolType}" .
        <${protocol.uid}> <brokerURL> "${protocol.brokerURL}" .
        <${protocol.uid}> <topic> "${protocol.topic}" .
        <${protocol.uid}> <consumerGroupId> "${protocol.consumerGroupId}" .
        <${protocol.uid}> <connectionTimeout> "${protocol.connectionTimeout}" .
        <${protocol.uid}> <sessionTimeout> "${protocol.sessionTimeout}" .
        <${protocol.uid}> <initialOffset> "${protocol.initialOffset}" .
        <${protocol.uid}> <retryBackOff> "${protocol.retryBackOff}" .
        <${protocol.uid}> <fetchMinBytes> "${protocol.fetchMinBytes}" .
        <${protocol.uid}> <fetchMaxWait> "${protocol.fetchMaxWait}" .
        <${protocol.uid}> <commitInterval> "${protocol.commitInterval}" .
        <${protocol.uid}> <heartbeatInterval> "${protocol.heartbeatInterval}" .
        <${protocol.uid}> <maximumQOS> "${protocol.maximumQOS}" .
        <${protocol.uid}> <username> "${protocol.username}" .
        <${protocol.uid}> <password> "${protocol.password}" .
        <${protocol.uid}> <encryptionMode> "${protocol.encryptionMode}" .
        <${protocol.uid}> <caCertificate> "${protocol.caCertificate}" .
        <${protocol.uid}> <clientCertificate> "${protocol.clientCertificate}" .
        <${protocol.uid}> <clientKey> "${protocol.clientKey}" .
        <${protocol.uid}> <authMode> "${protocol.authMode}" .
        <${protocol.uid}> <serverCertificate> "${protocol.serverCertificate}" .
        <${protocol.uid}> <scope> "${protocol.scope}" .
      }
    }`;
        console.log(`Update ${protocol.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => protocol), tap(() => console.log(`updated protocols ${protocol.uid}`)), catchError(this.handleError('updateProtocols')));
    }
    deleteProtocol(gatewayUid, protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${protocolUid}> <account> "${account ? account : ''}" .
      }
    }`;
        console.log(`Delete Protocol ${protocolUid} for ${gatewayUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => `${protocolUid} deleted`), tap(() => console.log(`deleted protocol ${protocolUid}`)), catchError(this.handleError('deleteProtocol')));
    }
    getDataStores(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(dataStore)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified dataStoreType
        host port databaseName user password accountName
        warehouse database schema authType username
        clientId clientSecret authorizationCode
        redirectURI loginTimeout url scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched dataStores for gateway ${gatewayName}`)), catchError(this.handleError('getDataStores', [])));
    }
    addDataStore(gatewayUid, dataStore, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:DataStore <dgraph.type> "DataStore" .
        _:DataStore <type> "dataStore" .
        _:DataStore <dataStore> "" .
        _:DataStore <account> "${account ? account : ''}" .
        _:DataStore <uuid> "${dataStore.uuid}" .
        _:DataStore <created> "${dataStore.created}" .
        _:DataStore <modified> "${dataStore.modified}" .
        _:DataStore <dataStoreType> "${dataStore.dataStoreType}" .
        _:DataStore <host> "${dataStore.host}" .
        _:DataStore <port> "${dataStore.port}" .
        _:DataStore <databaseName> "${dataStore.databaseName}" .
        _:DataStore <user> "${dataStore.user}" .
        _:DataStore <password> "${dataStore.password}" .
        _:DataStore <accountName> "${dataStore.accountName}" .
        _:DataStore <warehouse> "${dataStore.warehouse}" .
        _:DataStore <database> "${dataStore.databaseName}" .
        _:DataStore <schema> "${dataStore.schema}" .
        _:DataStore <authType> "${dataStore.authType}" .
        _:DataStore <username> "${dataStore.username}" .
        _:DataStore <clientId> "${dataStore.clientId}" .
        _:DataStore <clientSecret> "${dataStore.clientSecret}" .
        _:DataStore <authorizationCode> "${dataStore.authorizationCode}" .
        _:DataStore <redirectURI> "${dataStore.redirectURI}" .
        _:DataStore <loginTimeout> "${dataStore.loginTimeout}" .
        _:DataStore <url> "${dataStore.url}" .
        _:DataStore <scope> "${dataStore.scope}" .
      }
    }`;
        console.log(`Added datastore ${dataStore.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = dataStore)), tap(() => console.log(`add dataStores ${dataStore.uid}`)), catchError(this.handleError('addDataStores')));
    }
    updateDataStore(dataStore, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${dataStore.uid}> <account> "${account ? account : ''}" .
        <${dataStore.uid}> <uuid> "${dataStore.uuid}" .
        <${dataStore.uid}> <modified> "${dataStore.modified}" .
        <${dataStore.uid}> <dataStoreType> "${dataStore.dataStoreType}" .
        <${dataStore.uid}> <host> "${dataStore.host}" .
        <${dataStore.uid}> <port> "${dataStore.port}" .
        <${dataStore.uid}> <databaseName> "${dataStore.databaseName}" .
        <${dataStore.uid}> <user> "${dataStore.user}" .
        <${dataStore.uid}> <password> "${dataStore.password}" .
        <${dataStore.uid}> <accountName> "${dataStore.accountName}" .
        <${dataStore.uid}> <warehouse> "${dataStore.warehouse}" .
        <${dataStore.uid}> <database> "${dataStore.databaseName}" .
        <${dataStore.uid}> <schema> "${dataStore.schema}" .
        <${dataStore.uid}> <authType> "${dataStore.authType}" .
        <${dataStore.uid}> <username> "${dataStore.username}" .
        <${dataStore.uid}> <clientId> "${dataStore.clientId}" .
        <${dataStore.uid}> <clientSecret> "${dataStore.clientSecret}" .
        <${dataStore.uid}> <authorizationCode> "${dataStore.authorizationCode}" .
        <${dataStore.uid}> <redirectURI> "${dataStore.redirectURI}" .
        <${dataStore.uid}> <loginTimeout> "${dataStore.loginTimeout}" .
        <${dataStore.uid}> <url> "${dataStore.url}" .
        <${dataStore.uid}> <scope> "${dataStore.scope}" .
      }
    }`;
        console.log(`Update dataStore ${dataStore.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => dataStore), tap(() => console.log(`updated dataStores ${dataStore.uid}`)), catchError(this.handleError('updateDataStores')));
    }
    deleteDataStore(gatewayUid, dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${dataStoreUid}> <account> "${account ? account : ''}" .
      }
    }`;
        console.log(`Delete DataStore ${dataStoreUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${dataStoreUid} deleted`)), tap(() => console.log(`deleted dataStore ${dataStoreUid}`)), catchError(this.handleError('deleteDataStore')));
    }
    getGatewayAndModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid
        models: gateway_model {
          uid uuid created modified name
          description inputType url scope
          inputTemplate headers method base64Encoded
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched gateways and models for ${gatewayName}`)), catchError(this.handleError('getGatewayWithModels', [])));
    }
    getModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(model)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified name
        description inputType url scope inputTemplate
        headers method base64Encoded
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched models for ${gatewayName}`)), catchError(this.handleError('getModels', [])));
    }
    addModel(gatewayUid, model, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Model <dgraph.type> "Model" .
        _:Model <type> "model" .
        _:Model <model> "" .
        _:Model <account> "${account ? account : ''}" .
        _:Model <uuid> "${model.uuid}" .
        _:Model <created> "${model.created}" .
        _:Model <modified> "${model.modified}" .
        _:Model <name> "${model.name}" .
        _:Model <description> "${model.description}" .
        _:Model <inputType> "${model.inputType}" .
        _:Model <url> "${model.url}" .
        _:Model <scope> "${model.scope}" .
        _:Model <inputTemplate> "${model.inputTemplate}" .
        _:Model <headers> "${model.headers}" .
        _:Model <method> "${model.method}" .
        _:Model <base64Encoded> "${model.base64Encoded}" .
      }
    }`;
        console.log(`Add model ${model.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = model)), tap(() => console.log(`added model ${model.uid}`)), catchError(this.handleError('addModel')));
    }
    updateModel(model, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${model.uid}> <account> "${account ? account : ''}" .
        <${model.uid}> <uuid> "${model.uuid}" .
        <${model.uid}> <modified> "${model.modified}" .
        <${model.uid}> <name> "${model.name}" .
        <${model.uid}> <description> "${model.description}" .
        <${model.uid}> <inputType> "${model.inputType}" .
        <${model.uid}> <url> "${model.url}" .
        <${model.uid}> <scope> "${model.scope}" .
        <${model.uid}> <inputTemplate> "${model.inputTemplate}" .
        <${model.uid}> <headers> "${model.headers}" .
        <${model.uid}> <method> "${model.method}" .
        <${model.uid}> <base64Encoded> "${model.base64Encoded}" .
      }
    }`;
        console.log(`Update model ${model.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => model), tap(() => console.log('updated models')), catchError(this.handleError('updateModels')));
    }
    checkForError(errors) {
        console.log('Checking for errors in ', errors);
        if (errors) {
            throw new Error(JSON.stringify(errors));
        }
    }
    deleteModel(gatewayUid, modelUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${modelUid}> <account> "${account ? account : ''}" .
      }
    }`;
        console.log(`Delete Model ${modelUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${modelUid} deleted`)), tap(() => console.log(`deleted model ${modelUid}`)), catchError(this.handleError('deleteModel')));
    }
    getGatewayAndPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
        uid uuid brokerURL topic maximumQOS username password encryptionMode caCertificate
        clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
        sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
      }`;
        const pipeline_datastore = `dataStore: pipeline_datastore {
        uid uuid host port databaseName user password accountName warehouse database schema authType
        username clientId clientSecret authorizationCode redirectURI loginTimeout url
      }`;
        const pipeline_filter = 'filter: pipeline_filter { uid deviceNames }';
        const pipeline_streaming = 'streaming: pipeline_streaming { uid deviceName instrumentName function windowType windowSize }';
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid accessToken username platform address router routerPort deployNetwork devicesMetadata
        pipelines: gateway_pipeline {
          uid name uuid pipelineType deployerType protocolType protocolId dataStoreType
          dataStoreId created modified description status flowConfiguration
          logLevel subscriptionTopic
          ${pipeline_protocol}
          ${pipeline_datastore}
          ${pipeline_filter}
          ${pipeline_streaming}
        }
      }
    }`;
        console.log(`Get Gateway and Pipelines for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and pipelines for ${gatewayName}`)), catchError(this.handleError('getGatewayWithPipelines', [])));
    }
    getPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
              uid brokerURL topic maximumQOS username password encryptionMode caCertificate
              clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
              sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
  } `;
        const pipeline_datastore = `datastore: pipeline_datastore {
              uid host port databaseName user password accountName warehouse database schema authType
              username clientId clientSecret authorizationCode redirectURI loginTimeout url
            }`;
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        pipelines as gateway_pipeline {
        }
      }
      resp(func: uid(pipelines)) {
        uid name uuid pipelineType deployerType protocolType protocolId
        dataStoreType dataStoreId created modified description status
        flowConfiguration logLevel subscriptionTopic
        ${pipeline_protocol}
        ${pipeline_datastore}
        ${pipeline_filter}
        ${pipeline_streaming}
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched pipelines for ${gatewayName}`)), catchError(this.handleError('getPipelines', [])));
    }
    addPipeline(gatewayUid, pipeline, transportObj, dataStoreObj, filterObj, streamingObj, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        let query = '';
        query = `{
      set {
        _:Pipeline <dgraph.type> "Pipeline" .
        _:Pipeline <account> "${account ? account : ''}" .
        _:Pipeline <name> "${pipeline.name}" .
        _:Pipeline <uuid> "${pipeline.name}" .
        _:Pipeline <type> "pipeline" .
        _:Pipeline <pipeline> "" .
        _:Pipeline <pipelineType> "${pipeline.pipelineType}" .
        _:Pipeline <deployerType> "${pipeline.deployerType}" .
        _:Pipeline <created> "${pipeline.created}" .
        _:Pipeline <modified> "${pipeline.modified}" .
        _:Pipeline <description> "${pipeline.description}" .
        _:Pipeline <status> "${pipeline.status}" .
        _:Pipeline <flowConfiguration> "${pipeline.flowConfiguration}" .
        _:Pipeline <logLevel> "${pipeline.logLevel}" .
        _:Pipeline <subscriptionTopic> "${pipeline.subscriptionTopic}" .
        <${gatewayUid}> <gateway_pipeline> _:Pipeline .
      }
    }`;
        console.log(`add Pipeline ${pipeline.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = pipeline)), tap(() => console.log(`added pipeline ${pipeline.uid}`)), catchError(this.handleError('addPipelines')));
    }
    updatePipeline(pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${pipeline.uid}> <account> "${account ? account : ''}" .
        <${pipeline.uid}> <description> "${pipeline.description}" .
        <${pipeline.uid}> <status> "${pipeline.status}" .
        <${pipeline.uid}> <modified> "${pipeline.modified}" .
        <${pipeline.uid}> <flowConfiguration> "${pipeline.flowConfiguration}" .
        <${pipeline.uid}> <logLevel> "${pipeline.logLevel}" .
        <${pipeline.uid}> <subscriptionTopic> "${pipeline.subscriptionTopic}" .
      }
    }`;
        console.log(`update Pipeline ${pipeline.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => pipeline), tap(() => console.log(`updated pipeline ${pipeline.uid}`)), catchError(this.handleError('updatePipeline')));
    }
    deletePipeline(gatewayUid, pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${pipeline.uid}> <account> "${account ? account : ''}" .
        <${gatewayUid}> <gateway_pipeline> <${pipeline.uid}> .
      }
    }`;
        console.log(`delete Pipeline ${pipeline.uid} with gateway ${gatewayUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `pipeline deleted`)), tap(() => console.log(`deleted pipeline ${pipeline.uid} with gateway ${gatewayUid}`)), catchError(this.handleError('deletePipeline')));
    }
    /**
     * Get ids of all the pipelines associated with the specified protocol
     * @param protocolUid - the uid of the protocol
     */
    getPipelineIdsFromProtocolUid(protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${protocolUid})) {
        pipelines as ~pipeline_protocol {
        }
      }
      @filter(${this.getAccountQuery(account)})
      resp(func: uid(pipelines)) {
        uid uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipeline ids')), catchError(this.handleError('getPipelineIdsFromProtocolUid', [])));
    }
    /**
     * Get ids of all the pipelines associated with the specified data store
     * @param dataStoreUid - the uid of the data store
     */
    getPipelineIdsFromDataStoreUid(dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${dataStoreUid})) {
        pipelines as ~pipeline_datastore {
        }
      }
      @filter(${this.getAccountQuery(account)})
      resp(func: uid(pipelines)) {
        uid uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipeline ids')), catchError(this.handleError('getPipelineIdsFromDataStoreUid', [])));
    }
    getModelConfigs(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        modelConfigs as gateway_modelconfig {
        }
      }
      resp(func: uid(modelConfigs)) {
        uid name uuid description device resource model created  modified
      }
    }`;
        console.log(`getModelConfigs for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched modelConfigs for ${gatewayName}`)), catchError(this.handleError('getModelConfigs', [])));
    }
    addModelConfig(gatewayUid, modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:ModelConfig <dgraph.type> "ModelConfig" .
        _:ModelConfig <account> "${account ? account : ''}" .
        _:ModelConfig <name> "${modelConfig.name}" .
        _:ModelConfig <uuid> "${modelConfig.name}" .
        _:ModelConfig <type> "modelConfig" .
        _:ModelConfig <modelConfig> "" .
        _:ModelConfig <description> "${modelConfig.description}" .
        _:ModelConfig <device> "${modelConfig.device}" .
        _:ModelConfig <resource> "${modelConfig.resource}" .
        _:ModelConfig <model> "${modelConfig.model}" .
        _:ModelConfig <created> "${modelConfig.created}" .
        _:ModelConfig <modified> "${modelConfig.modified}" .
        <${gatewayUid}> <gateway_modelconfig> _:ModelConfig .
      }
    }`;
        console.log(`Add modelConfig for gateway ${gatewayUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = modelConfig)), tap(() => console.log(`add modelConfig for gateway ${gatewayUid}`)), catchError(this.handleError('addModelConfig')));
    }
    updateModelConfig(modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${modelConfig.uid}> <account> "${account ? account : ''}" .
        <${modelConfig.uid}> <name> "${modelConfig.name}" .
        <${modelConfig.uid}> <uuid> "${modelConfig.uuid}" .
        <${modelConfig.uid}> <description> "${modelConfig.description}" .
        <${modelConfig.uid}> <condDevice> "${modelConfig.device}" .
        <${modelConfig.uid}> <condResource> "${modelConfig.resource}" .
        <${modelConfig.uid}> <model> "${modelConfig.model}" .
        <${modelConfig.uid}> <modified> "${modelConfig.modified}" .
      }
    }`;
        console.log(`Update modelConfig ${modelConfig.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => modelConfig), tap(() => console.log(`updated modelConfig ${modelConfig.uid}`)), catchError(this.handleError('updateModelConfig')));
    }
    deleteModelConfig(gatewayUid, modelConfigUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${modelConfigUid}> <account> "${account ? account : ''}" .
        <${gatewayUid}> <gateway_modelconfig> <${modelConfigUid}> .
      }
    }`;
        console.log(`Delete ModelConfig ${modelConfigUid} for gateway ${gatewayUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${modelConfigUid} deleted`)), tap(() => console.log(`deleted modelConfig ${modelConfigUid} for gateway ${gatewayUid}`)), catchError(this.handleError('deleteModelConfig')));
    }
    getFiltersConfig(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        filtersConfig as gateway_filter {
        }
      }
      resp(func: uid(filtersConfig)) {
        uid
        deviceNames
      }
    }`;
        console.log(`getFiltersConfig for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched filtersConfig for ${gatewayName}`)), catchError(this.handleError('getFiltersConfigs', [])));
    }
    addFiltersConfig(gatewayUid, filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Filter <dgraph.type> "filter" .
        _:Filter <type> "filter" .
        _:Filter <filter> "" .
        _:Filter <deviceNames> "${filtersConfig.deviceNames}" .
        <${gatewayUid}> <gateway_filter> _:Filter .
        <${account}> <account> _:Filter .
      }
    }`;
        console.log(`add FiltersConfig for gateway ${gatewayUid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = filtersConfig)), tap(() => console.log(`added filtersConfig for gateway ${gatewayUid}`)), catchError(this.handleError('addFiltersConfig')));
    }
    updateFiltersConfig(filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${filtersConfig.uid}> <deviceNames> "${filtersConfig.deviceNames}" .
        <${account}> <account> "${account ? account : ''}" .
      }
    }`;
        console.log(`update FiltersConfig ${filtersConfig.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = filtersConfig)), tap(() => console.log(`updated filtersConfig ${filtersConfig.uid}`)), catchError(this.handleError('updateFiltersConfig')));
    }
    getReadings(deviceName, instrumentName, numReadings, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading (first:-${numReadings}) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadings for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log('Response from getReadings: ', response)), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)), catchError(this.handleError('getReadings', [])));
    }
    getReadingsAt(deviceName, instrumentName, ts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(eq(created, ${ts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsAt for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)), catchError(this.handleError('getReadingsAt', [])));
    }
    getReadingsStartingAt(deviceName, instrumentName, fromts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsStartingAt for for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched started at readings for ${deviceName}, ${instrumentName}`)), catchError(this.handleError('getReadingsStartingAt', [])));
    }
    getReadingsBetween(deviceName, instrumentName, fromts, tots, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsBetween for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched readings between for ${deviceName}, ${instrumentName}`)), catchError(this.handleError('getReadingsBetween', [])));
    }
    getLastReadingsForDevice(deviceName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(device)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}")) @normalize {
        device_resource {
          name: name
          resource_reading (first:-1) {
            created: created
            value: value
          }
        }
      }
    }`;
        console.log(`getLastReadingsForDevice for ${deviceName}`);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched last readings for ${deviceName}`)), catchError(this.handleError('getLastReadingsForDevice', [])));
    }
    getNotifications(account) {
        this.ensureAccountAuthorized(account);
        console.log('GetNotifications service called');
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(notification)) @filter(${this.getAccountQuery(account)}) @normalize {
        uid uuid:uuid created:created notifySource:notifySource notifyDevice:notifyDevice
        notifyResource:notifyResource notifyLevel:notifyLevel value:value description:description
        ~gateway_notification {
          gateway: uuid
        }
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log(`fetched notifications`)), catchError(this.handleError('getNotifications', [])));
    }
    getRoute(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let route = null;
        if (deviceName == 'train-0001') {
            route = route1;
        }
        else if (deviceName == 'train-0002') {
            route = route2;
        }
        else if (deviceName == 'train-0003') {
            route = route3;
        }
        else {
            route = emptyroute;
        }
        return route;
    }
    getRouteCenter(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let center = null;
        // 39.0 -98.0 zoom 4
        // East 34.765589   -78.709488
        // West 40.487432 -122.803116
        if (deviceName == 'train-0001') {
            center = [34.0, -98.0];
        }
        else if (deviceName == 'train-0002') {
            center = [40.0, -98.0];
        }
        else if (deviceName == 'train-0003') {
            center = [39.0, -98.0];
        }
        else {
            center = [42.8, 12.8];
        }
        return center;
    }
    ensureAccountAuthorized(account) {
        if (this.requireAccountId) {
            if (!account)
                throw new Error('Account must exist');
        }
    }
    getAccountQuery(account) {
        if (this.requireAccountId) {
            return `eq(account, "${account}")`;
        }
        else {
            return `(eq(account, "${account ? account : ''}") OR not(has(account)))`;
        }
    }
    /**
     * Handle HTTP operation that failed.
     * Let the app continue.
     * @param operation - - name of the operation that failed
     * @param result - optional value to return as the observable result
     */
    handleError(operation = 'operation', result) {
        return (error) => {
            // TODO: better job of transforming error for user consumption
            console.log(`${operation} failed: ${error.code}: ${error.message}`);
            // Let the app keep running by returning an empty result.
            return of(result);
        };
    }
    /**
     * Get Python Resources.
     * @param gatewayUid
     */
    getResources(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `
    {
      resp(func: type(PythonResource)) @filter(eq(scope, "${gatewayName}")) {
        uid
        uuid
        created
        modified
        name
        type
        scope
        fileContent
      }
    }`;
        return this.http.post(url, query, httpOptions)
            .pipe(map(response => response.data.resp), catchError(this.handleError('getResources', [])));
    }
    /**
     * Add Python Resource.
     * @param PythonResource
     */
    addResource(resource, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = ` {
      set {
        _:PythonResource <dgraph.type> "PythonResource".
        _:PythonResource <uuid> "${resource.uuid}" .
        _:PythonResource <name> "${resource.name}" .
        _:PythonResource <created> "${resource.created}" .
        _:PythonResource <modified> "${resource.modified}" .
        _:PythonResource <type> "${resource.type}" .
        _:PythonResource <fileContent> "${resource.fileContent}" .
        _:PythonResource <scope> "${resource.scope}" .
      }}`;
        return this.http.post(url, query, httpMutateOptions)
            .pipe(map(response => response.data.resp), catchError(this.handleError('addResource')));
    }
    /**
     * Update Python Resource.
     * @param PythonResource
     */
    updateResource(resource, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${resource.uid}> <uuid> "${resource.uuid}" .
        <${resource.uid}> <modified> "${resource.modified}" .
        <${resource.uid}> <name> "${resource.name}" .
        <${resource.uid}> <scope> "${resource.scope}" .
        <${resource.uid}> <type> "${resource.type}" .
        <${resource.uid}> <fileContent> "${resource.fileContent}" .
      }
    }`;
        return this.http.post(url, query, httpMutateOptions)
            .pipe(map(response => response.data.resp), catchError(this.handleError('updateResource')));
    }
    /**
     * Delete Python Resource.
     * @param gatewayUid
     * @param PythonResource
     */
    deleteResource(gatewayUid, resourceUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${resourceUid}> * * .
      }
    }`;
        return this.http.post(url, query, httpMutateOptions)
            .pipe(map(response => response.data.resp), catchError(this.handleError('deleteResource')));
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL2xhYnMtYWlyLWdyYXBoLWNsaWVudC9zcmMvYXBpL2dyYXBoLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBWUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQWMsRUFBRSxFQUFFLEdBQUcsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUk1RCxNQUFNLE1BQU0sR0FBZTtJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFFBQVEsQ0FBQztJQUN0QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztDQUMxQixDQUFDO0FBRUYsTUFBTSxNQUFNLEdBQWU7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7Q0FDM0IsQ0FBQztBQUVGLE1BQU0sTUFBTSxHQUFlO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0NBQzFCLENBQUM7QUFFRixNQUFNLFVBQVUsR0FBZSxFQUFFLENBQUM7QUFFbEMsTUFBTSxXQUFXLEdBQUc7SUFDaEIsT0FBTyxFQUFFO1FBQ0wsY0FBYyxFQUFFLHVCQUF1QjtLQUMxQztDQUNKLENBQUM7QUFFRixNQUFNLGlCQUFpQixHQUFHO0lBQ3RCLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxpQkFBaUIsRUFBRTtDQUNqRCxDQUFDO0FBRUYsTUFBTSxPQUFPLFlBQVk7SUFJckIsWUFBb0IsSUFBZ0IsRUFBWSxTQUFpQixFQUFVLGVBQXdCO1FBQS9FLFNBQUksR0FBSixJQUFJLENBQVk7UUFBWSxjQUFTLEdBQVQsU0FBUyxDQUFRO1FBQVUsb0JBQWUsR0FBZixlQUFlLENBQVM7UUFGM0YscUJBQWdCLEdBQUcsSUFBSSxDQUFDO1FBRzVCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUM7UUFDeEMsOEVBQThFO1FBQzlFLCtCQUErQjtRQUMvQixvRUFBb0U7UUFDcEUsbUhBQW1IO1FBQ25ILG1IQUFtSDtRQUNuSCxHQUFHO0lBQ1AsQ0FBQztJQUVELFVBQVUsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQzVDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBQzVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsbUJBQW1CLENBQUM7UUFDakQsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7OztNQUs3RixDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWlCLENBQUMsRUFDbEQsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVksWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQzVELENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQWdCO1FBQ3hCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLG1CQUFtQixDQUFDO1FBQ2pELE1BQU0sS0FBSyxHQUFHOztnQkFFTixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O01BTXZDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxRQUFRLENBQUMsTUFBTSxXQUFXLENBQUMsQ0FBQyxFQUNyRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBWSxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDN0QsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsT0FBZ0IsRUFBRSxPQUFnQjtRQUM1QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxPQUFPLENBQUMsR0FBRyxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7V0FDakQsT0FBTyxDQUFDLEdBQUcsZ0JBQWdCLE9BQU8sQ0FBQyxPQUFPO1dBQzFDLE9BQU8sQ0FBQyxHQUFHLGVBQWUsT0FBTyxDQUFDLE1BQU07V0FDeEMsT0FBTyxDQUFDLEdBQUcsbUJBQW1CLE9BQU8sQ0FBQyxVQUFVO1dBQ2hELE9BQU8sQ0FBQyxHQUFHLHNCQUFzQixPQUFPLENBQUMsYUFBYTtXQUN0RCxPQUFPLENBQUMsR0FBRyxvQkFBb0IsT0FBTyxDQUFDLFdBQVc7V0FDbEQsT0FBTyxDQUFDLEdBQUcsaUJBQWlCLE9BQU8sQ0FBQyxRQUFRO1dBQzVDLE9BQU8sQ0FBQyxHQUFHLGtCQUFrQixPQUFPLENBQUMsU0FBUztXQUM5QyxPQUFPLENBQUMsR0FBRyxvQkFBb0IsT0FBTyxDQUFDLFdBQVc7V0FDbEQsT0FBTyxDQUFDLEdBQUcsaUJBQWlCLE9BQU8sQ0FBQyxRQUFRO1dBQzVDLE9BQU8sQ0FBQyxHQUFHLGlCQUFpQixPQUFPLENBQUMsUUFBUTtXQUM1QyxPQUFPLENBQUMsR0FBRyxrQkFBa0IsT0FBTyxDQUFDLFNBQVM7O01BRW5ELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUU5QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxFQUM1QixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFDekQsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsZUFBZSxDQUFDLENBQUMsQ0FDeEQsQ0FBQztJQUNOLENBQUM7SUFFRCxVQUFVLENBQUMsT0FBZ0IsRUFBRSxPQUFnQjtRQUN6QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7K0JBS1MsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7NEJBQ3pCLE9BQU8sQ0FBQyxJQUFJO21DQUNMLE9BQU8sQ0FBQyxXQUFXOytCQUN2QixPQUFPLENBQUMsT0FBTzs4QkFDaEIsT0FBTyxDQUFDLE1BQU07a0NBQ1YsT0FBTyxDQUFDLFVBQVU7cUNBQ2YsT0FBTyxDQUFDLGFBQWE7Z0NBQzFCLE9BQU8sQ0FBQyxRQUFRO2lDQUNmLE9BQU8sQ0FBQyxTQUFTO21DQUNmLE9BQU8sQ0FBQyxXQUFXO2dDQUN0QixPQUFPLENBQUMsUUFBUTtnQ0FDaEIsT0FBTyxDQUFDLFFBQVE7aUNBQ2YsT0FBTyxDQUFDLFNBQVM7aUNBQ2pCLE9BQU8sQ0FBQyxTQUFTOztNQUU1QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRTNDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQ2pELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsT0FBTyxDQUFDLEdBQUcsSUFBSSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUNwRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBVSxZQUFZLENBQUMsQ0FBQyxDQUN0RCxDQUFDO0lBQ04sQ0FBQztJQUVELGFBQWEsQ0FBQyxVQUFrQixFQUFFLE9BQWdCO1FBQzlDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFVBQVUsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOztNQUVyRCxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsVUFBVSxHQUFHLENBQUMsQ0FBQztRQUU3QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFVBQVUsVUFBVSxDQUFDLEVBQ2xDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixVQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQ3ZELFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFTLGVBQWUsQ0FBQyxDQUFDLENBQ3hELENBQUM7SUFDTixDQUFDO0lBRUQsc0JBQXNCLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUN4RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7Ozs7Ozs7TUFZN0YsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWlCLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFDMUUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVkseUJBQXlCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDekUsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCxZQUFZLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7MENBQ29CLElBQUksQ0FBQyxlQUFlLENBQ3BELE9BQU8sQ0FDVixvQkFBb0IsV0FBVzs7Ozs7Ozs7TUFRaEMsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFrQixDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixXQUFXLEVBQUUsQ0FBQyxDQUFDLEVBQzlELFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFhLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUMvRCxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxVQUFrQixFQUFFLFFBQWtCLEVBQUUsT0FBZ0I7UUFDaEUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7O2dDQUtVLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzZCQUN6QixRQUFRLENBQUMsSUFBSTtnQ0FDVixRQUFRLENBQUMsT0FBTztpQ0FDZixRQUFRLENBQUMsUUFBUTtxQ0FDYixRQUFRLENBQUMsWUFBWTtrQ0FDeEIsUUFBUSxDQUFDLFNBQVM7OEJBQ3RCLFFBQVEsQ0FBQyxLQUFLO3dDQUNKLFFBQVEsQ0FBQyxlQUFlOzBDQUN0QixRQUFRLENBQUMsaUJBQWlCO3VDQUM3QixRQUFRLENBQUMsY0FBYztzQ0FDeEIsUUFBUSxDQUFDLGFBQWE7cUNBQ3ZCLFFBQVEsQ0FBQyxZQUFZO3NDQUNwQixRQUFRLENBQUMsYUFBYTtxQ0FDdkIsUUFBUSxDQUFDLFlBQVk7dUNBQ25CLFFBQVEsQ0FBQyxjQUFjOzBDQUNwQixRQUFRLENBQUMsaUJBQWlCO21DQUNqQyxRQUFRLENBQUMsVUFBVTtpQ0FDckIsUUFBUSxDQUFDLFFBQVE7aUNBQ2pCLFFBQVEsQ0FBQyxRQUFRO3VDQUNYLFFBQVEsQ0FBQyxjQUFjO3NDQUN4QixRQUFRLENBQUMsYUFBYTswQ0FDbEIsUUFBUSxDQUFDLGlCQUFpQjtrQ0FDbEMsUUFBUSxDQUFDLFNBQVM7aUNBQ25CLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7OEJBQ3RDLFFBQVEsQ0FBQyxLQUFLOztNQUV0QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFN0MsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ3ZELFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFXLGNBQWMsQ0FBQyxDQUFDLENBQ3pELENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFFBQWtCLEVBQUUsT0FBZ0I7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsUUFBUSxDQUFDLEdBQUcsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO1dBQ2xELFFBQVEsQ0FBQyxHQUFHLGFBQWEsUUFBUSxDQUFDLElBQUk7V0FDdEMsUUFBUSxDQUFDLEdBQUcsaUJBQWlCLFFBQVEsQ0FBQyxRQUFRO1dBQzlDLFFBQVEsQ0FBQyxHQUFHLHFCQUFxQixRQUFRLENBQUMsWUFBWTtXQUN0RCxRQUFRLENBQUMsR0FBRyxrQkFBa0IsUUFBUSxDQUFDLFNBQVM7V0FDaEQsUUFBUSxDQUFDLEdBQUcsY0FBYyxRQUFRLENBQUMsS0FBSztXQUN4QyxRQUFRLENBQUMsR0FBRyx3QkFBd0IsUUFBUSxDQUFDLGVBQWU7V0FDNUQsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7V0FDaEUsUUFBUSxDQUFDLEdBQUcsdUJBQXVCLFFBQVEsQ0FBQyxjQUFjO1dBQzFELFFBQVEsQ0FBQyxHQUFHLHNCQUFzQixRQUFRLENBQUMsYUFBYTtXQUN4RCxRQUFRLENBQUMsR0FBRyxxQkFBcUIsUUFBUSxDQUFDLFlBQVk7V0FDdEQsUUFBUSxDQUFDLEdBQUcsc0JBQXNCLFFBQVEsQ0FBQyxhQUFhO1dBQ3hELFFBQVEsQ0FBQyxHQUFHLHFCQUFxQixRQUFRLENBQUMsWUFBWTtXQUN0RCxRQUFRLENBQUMsR0FBRyx1QkFBdUIsUUFBUSxDQUFDLGNBQWM7V0FDMUQsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7V0FDaEUsUUFBUSxDQUFDLEdBQUcsbUJBQW1CLFFBQVEsQ0FBQyxVQUFVO1dBQ2xELFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRyxpQkFBaUIsUUFBUSxDQUFDLFFBQVE7V0FDOUMsUUFBUSxDQUFDLEdBQUcsdUJBQXVCLFFBQVEsQ0FBQyxjQUFjO1dBQzFELFFBQVEsQ0FBQyxHQUFHLHNCQUFzQixRQUFRLENBQUMsYUFBYTtXQUN4RCxRQUFRLENBQUMsR0FBRywwQkFBMEIsUUFBUSxDQUFDLGlCQUFpQjtXQUNoRSxRQUFRLENBQUMsR0FBRyxrQkFBa0IsUUFBUSxDQUFDLFNBQVM7V0FDaEQsUUFBUSxDQUFDLEdBQUcsaUJBQWlCLFFBQVEsQ0FBQyxRQUFRO1dBQzlDLFFBQVEsQ0FBQyxHQUFHLDBCQUEwQixRQUFRLENBQUMsaUJBQWlCO1dBQ2hFLFFBQVEsQ0FBQyxHQUFHLGNBQWMsUUFBUSxDQUFDLEtBQUs7O01BRTdDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFdEMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQ25CLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUMzRCxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBVyxpQkFBaUIsQ0FBQyxDQUFDLENBQzVELENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFVBQWtCLEVBQUUsV0FBbUIsRUFBRSxPQUFnQjtRQUNwRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxXQUFXLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs7TUFFdEQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLFdBQVcsUUFBUSxVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRWhFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsV0FBVyxVQUFVLENBQUMsRUFDbkMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFDekQsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsZ0JBQWdCLENBQUMsQ0FBQyxDQUN6RCxDQUFDO0lBQ04sQ0FBQztJQUVELGFBQWEsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzsyQ0FDcUIsSUFBSSxDQUFDLGVBQWUsQ0FDckQsT0FBTyxDQUNWLG9CQUFvQixXQUFXOzs7Ozs7O01BT2hDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUN2RSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYyxlQUFlLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDakUsQ0FBQztJQUNOLENBQUM7SUFFRCxZQUFZLENBQUMsVUFBa0IsRUFBRSxTQUFvQixFQUFFLE9BQWdCO1FBQ25FLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OztpQ0FLVyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs4QkFDekIsU0FBUyxDQUFDLElBQUk7aUNBQ1gsU0FBUyxDQUFDLE9BQU87a0NBQ2hCLFNBQVMsQ0FBQyxRQUFRO3VDQUNiLFNBQVMsQ0FBQyxhQUFhOzhCQUNoQyxTQUFTLENBQUMsSUFBSTs4QkFDZCxTQUFTLENBQUMsSUFBSTtzQ0FDTixTQUFTLENBQUMsWUFBWTs4QkFDOUIsU0FBUyxDQUFDLElBQUk7a0NBQ1YsU0FBUyxDQUFDLFFBQVE7cUNBQ2YsU0FBUyxDQUFDLFdBQVc7bUNBQ3ZCLFNBQVMsQ0FBQyxTQUFTO2tDQUNwQixTQUFTLENBQUMsWUFBWTtnQ0FDeEIsU0FBUyxDQUFDLE1BQU07a0NBQ2QsU0FBUyxDQUFDLFFBQVE7a0NBQ2xCLFNBQVMsQ0FBQyxRQUFRO2tDQUNsQixTQUFTLENBQUMsUUFBUTtzQ0FDZCxTQUFTLENBQUMsWUFBWTsyQ0FDakIsU0FBUyxDQUFDLGlCQUFpQjtxQ0FDakMsU0FBUyxDQUFDLFdBQVc7c0NBQ3BCLFNBQVMsQ0FBQyxZQUFZOzZCQUMvQixTQUFTLENBQUMsR0FBRzsrQkFDWCxTQUFTLENBQUMsS0FBSzs7TUFFeEMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRWpELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQyxDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUN6RCxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBWSxlQUFlLENBQUMsQ0FBQyxDQUMzRCxDQUFDO0lBQ04sQ0FBQztJQUVELGVBQWUsQ0FBQyxTQUFvQixFQUFFLE9BQWdCO1FBQ2xELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFNBQVMsQ0FBQyxHQUFHLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtXQUNuRCxTQUFTLENBQUMsR0FBRyxhQUFhLFNBQVMsQ0FBQyxJQUFJO1dBQ3hDLFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsUUFBUTtXQUNoRCxTQUFTLENBQUMsR0FBRyxzQkFBc0IsU0FBUyxDQUFDLGFBQWE7V0FDMUQsU0FBUyxDQUFDLEdBQUcsYUFBYSxTQUFTLENBQUMsSUFBSTtXQUN4QyxTQUFTLENBQUMsR0FBRyxhQUFhLFNBQVMsQ0FBQyxJQUFJO1dBQ3hDLFNBQVMsQ0FBQyxHQUFHLHFCQUFxQixTQUFTLENBQUMsWUFBWTtXQUN4RCxTQUFTLENBQUMsR0FBRyxhQUFhLFNBQVMsQ0FBQyxJQUFJO1dBQ3hDLFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsUUFBUTtXQUNoRCxTQUFTLENBQUMsR0FBRyxvQkFBb0IsU0FBUyxDQUFDLFdBQVc7V0FDdEQsU0FBUyxDQUFDLEdBQUcsa0JBQWtCLFNBQVMsQ0FBQyxTQUFTO1dBQ2xELFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsWUFBWTtXQUNwRCxTQUFTLENBQUMsR0FBRyxlQUFlLFNBQVMsQ0FBQyxNQUFNO1dBQzVDLFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsUUFBUTtXQUNoRCxTQUFTLENBQUMsR0FBRyxpQkFBaUIsU0FBUyxDQUFDLFFBQVE7V0FDaEQsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxRQUFRO1dBQ2hELFNBQVMsQ0FBQyxHQUFHLHFCQUFxQixTQUFTLENBQUMsWUFBWTtXQUN4RCxTQUFTLENBQUMsR0FBRywwQkFBMEIsU0FBUyxDQUFDLGlCQUFpQjtXQUNsRSxTQUFTLENBQUMsR0FBRyxvQkFBb0IsU0FBUyxDQUFDLFdBQVc7V0FDdEQsU0FBUyxDQUFDLEdBQUcscUJBQXFCLFNBQVMsQ0FBQyxZQUFZO1dBQ3hELFNBQVMsQ0FBQyxHQUFHLFlBQVksU0FBUyxDQUFDLEdBQUc7V0FDdEMsU0FBUyxDQUFDLEdBQUcsY0FBYyxTQUFTLENBQUMsS0FBSzs7TUFFL0MsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRWpELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxFQUNwQixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFDN0QsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVksa0JBQWtCLENBQUMsQ0FBQyxDQUM5RCxDQUFDO0lBQ04sQ0FBQztJQUVELGVBQWUsQ0FBQyxVQUFrQixFQUFFLFlBQW9CLEVBQUUsT0FBZ0I7UUFDdEUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsWUFBWSxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7O01BRXZELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixZQUFZLEVBQUUsQ0FBQyxDQUFDO1FBRWhELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLEdBQUcsWUFBWSxVQUFVLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsWUFBWSxFQUFFLENBQUMsQ0FBQyxFQUMzRCxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUyxpQkFBaUIsQ0FBQyxDQUFDLENBQzFELENBQUM7SUFDTixDQUFDO0lBRUQsbUJBQW1CLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUNyRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7OztNQVE3RixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUU1RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUN4RSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBWSxzQkFBc0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUN0RSxDQUFDO0lBQ04sQ0FBQztJQUVELFNBQVMsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQzNDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzt1Q0FDaUIsSUFBSSxDQUFDLGVBQWUsQ0FDakQsT0FBTyxDQUNWLG9CQUFvQixXQUFXOzs7OztNQUtoQyxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWUsQ0FBQyxFQUNoRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUMzRCxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBVSxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDekQsQ0FBQztJQUNOLENBQUM7SUFFRCxRQUFRLENBQUMsVUFBa0IsRUFBRSxLQUFZLEVBQUUsT0FBZ0I7UUFDdkQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OzZCQUtPLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzBCQUN6QixLQUFLLENBQUMsSUFBSTs2QkFDUCxLQUFLLENBQUMsT0FBTzs4QkFDWixLQUFLLENBQUMsUUFBUTswQkFDbEIsS0FBSyxDQUFDLElBQUk7aUNBQ0gsS0FBSyxDQUFDLFdBQVc7K0JBQ25CLEtBQUssQ0FBQyxTQUFTO3lCQUNyQixLQUFLLENBQUMsR0FBRzsyQkFDUCxLQUFLLENBQUMsS0FBSzttQ0FDSCxLQUFLLENBQUMsYUFBYTs2QkFDekIsS0FBSyxDQUFDLE9BQU87NEJBQ2QsS0FBSyxDQUFDLE1BQU07bUNBQ0wsS0FBSyxDQUFDLGFBQWE7O01BRWhELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFdkMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFDL0MsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUNsRCxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUSxVQUFVLENBQUMsQ0FBQyxDQUNsRCxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxLQUFZLEVBQUUsT0FBZ0I7UUFDdEMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsS0FBSyxDQUFDLEdBQUcsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO1dBQy9DLEtBQUssQ0FBQyxHQUFHLGFBQWEsS0FBSyxDQUFDLElBQUk7V0FDaEMsS0FBSyxDQUFDLEdBQUcsaUJBQWlCLEtBQUssQ0FBQyxRQUFRO1dBQ3hDLEtBQUssQ0FBQyxHQUFHLGFBQWEsS0FBSyxDQUFDLElBQUk7V0FDaEMsS0FBSyxDQUFDLEdBQUcsb0JBQW9CLEtBQUssQ0FBQyxXQUFXO1dBQzlDLEtBQUssQ0FBQyxHQUFHLGtCQUFrQixLQUFLLENBQUMsU0FBUztXQUMxQyxLQUFLLENBQUMsR0FBRyxZQUFZLEtBQUssQ0FBQyxHQUFHO1dBQzlCLEtBQUssQ0FBQyxHQUFHLGNBQWMsS0FBSyxDQUFDLEtBQUs7V0FDbEMsS0FBSyxDQUFDLEdBQUcsc0JBQXNCLEtBQUssQ0FBQyxhQUFhO1dBQ2xELEtBQUssQ0FBQyxHQUFHLGdCQUFnQixLQUFLLENBQUMsT0FBTztXQUN0QyxLQUFLLENBQUMsR0FBRyxlQUFlLEtBQUssQ0FBQyxNQUFNO1dBQ3BDLEtBQUssQ0FBQyxHQUFHLHNCQUFzQixLQUFLLENBQUMsYUFBYTs7TUFFdkQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUNoQixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEVBQ3hDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFRLGNBQWMsQ0FBQyxDQUFDLENBQ3RELENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLE1BQVc7UUFDckIsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUMvQyxJQUFJLE1BQU0sRUFBRTtZQUNSLE1BQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1NBQzNDO0lBQ0wsQ0FBQztJQUVELFdBQVcsQ0FBQyxVQUFrQixFQUFFLFFBQWdCLEVBQUUsT0FBZ0I7UUFDOUQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsUUFBUSxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7O01BRW5ELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBRXhDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLEdBQUcsUUFBUSxVQUFVLENBQUMsQ0FBQyxFQUMvRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsUUFBUSxFQUFFLENBQUMsQ0FBQyxFQUNuRCxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUyxhQUFhLENBQUMsQ0FBQyxDQUN0RCxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0saUJBQWlCLEdBQUc7Ozs7UUFJMUIsQ0FBQztRQUNELE1BQU0sa0JBQWtCLEdBQUc7OztRQUczQixDQUFDO1FBQ0QsTUFBTSxlQUFlLEdBQUcsNkNBQTZDLENBQUM7UUFDdEUsTUFBTSxrQkFBa0IsR0FDcEIsZ0dBQWdHLENBQUM7UUFFckcsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7WUFNdkYsaUJBQWlCO1lBQ2pCLGtCQUFrQjtZQUNsQixlQUFlO1lBQ2Ysa0JBQWtCOzs7TUFHeEIsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWlCLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFDMUUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVkseUJBQXlCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDekUsQ0FBQztJQUNOLENBQUM7SUFFRCxZQUFZLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxpQkFBaUIsR0FBRzs7OztLQUk3QixDQUFDO1FBQ0UsTUFBTSxrQkFBa0IsR0FBRzs7O2NBR3JCLENBQUM7UUFDUCxNQUFNLGVBQWUsR0FBRywyQ0FBMkMsQ0FBQztRQUNwRSxNQUFNLGtCQUFrQixHQUNwQiw4RkFBOEYsQ0FBQztRQUVuRyxNQUFNLEtBQUssR0FBRzt3Q0FDa0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7Ozs7O1VBUXhGLGlCQUFpQjtVQUNqQixrQkFBa0I7VUFDbEIsZUFBZTtVQUNmLGtCQUFrQjs7TUFFdEIsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFrQixDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixXQUFXLEVBQUUsQ0FBQyxDQUFDLEVBQzlELFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFhLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUMvRCxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FDUCxVQUFrQixFQUNsQixRQUFrQixFQUNsQixZQUFrQixFQUNsQixZQUFrQixFQUNsQixTQUFlLEVBQ2YsWUFBa0IsRUFDbEIsT0FBZ0I7UUFFaEIsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFFdEQsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBRWYsS0FBSyxHQUFHOzs7Z0NBR2dCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzZCQUN6QixRQUFRLENBQUMsSUFBSTs2QkFDYixRQUFRLENBQUMsSUFBSTs7O3FDQUdMLFFBQVEsQ0FBQyxZQUFZO3FDQUNyQixRQUFRLENBQUMsWUFBWTtnQ0FDMUIsUUFBUSxDQUFDLE9BQU87aUNBQ2YsUUFBUSxDQUFDLFFBQVE7b0NBQ2QsUUFBUSxDQUFDLFdBQVc7K0JBQ3pCLFFBQVEsQ0FBQyxNQUFNOzBDQUNKLFFBQVEsQ0FBQyxpQkFBaUI7aUNBQ25DLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7V0FDekQsVUFBVTs7TUFFZixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFNUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ3hELFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFXLGNBQWMsQ0FBQyxDQUFDLENBQ3pELENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFFBQWtCLEVBQUUsT0FBZ0I7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsUUFBUSxDQUFDLEdBQUcsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO1dBQ2xELFFBQVEsQ0FBQyxHQUFHLG9CQUFvQixRQUFRLENBQUMsV0FBVztXQUNwRCxRQUFRLENBQUMsR0FBRyxlQUFlLFFBQVEsQ0FBQyxNQUFNO1dBQzFDLFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRywwQkFBMEIsUUFBUSxDQUFDLGlCQUFpQjtXQUNoRSxRQUFRLENBQUMsR0FBRyxpQkFBaUIsUUFBUSxDQUFDLFFBQVE7V0FDOUMsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7O01BRXJFLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUUvQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFDbkIsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQzFELFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFXLGdCQUFnQixDQUFDLENBQUMsQ0FDM0QsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxRQUFrQixFQUFFLE9BQWdCO1FBQ25FLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBRXRELE1BQU0sS0FBSyxHQUFHOztXQUVYLFFBQVEsQ0FBQyxHQUFHLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtXQUNsRCxVQUFVLHlCQUF5QixRQUFRLENBQUMsR0FBRzs7TUFFcEQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRTFFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLGtCQUFrQixDQUFDLENBQUMsRUFDNUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixVQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQ3JGLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFTLGdCQUFnQixDQUFDLENBQUMsQ0FDekQsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCw2QkFBNkIsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQy9ELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRztzQkFDQSxXQUFXOzs7O2dCQUlqQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7OztNQUl2QyxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWtCLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxFQUM5QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYSwrQkFBK0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNoRixDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILDhCQUE4QixDQUFDLFlBQW9CLEVBQUUsT0FBZ0I7UUFDakUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3NCQUNBLFlBQVk7Ozs7Z0JBSWxCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7O01BSXZDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBa0IsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEVBQzlDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFhLGdDQUFnQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ2pGLENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDakQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3dDQUNrQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsV0FBVzs7Ozs7OztNQU81RixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUVsRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBcUIsQ0FBQyxFQUN0RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUNqRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBZ0IsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDckUsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxXQUF3QixFQUFFLE9BQWdCO1FBQ3pFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7bUNBR2EsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0NBQ3pCLFdBQVcsQ0FBQyxJQUFJO2dDQUNoQixXQUFXLENBQUMsSUFBSTs7O3VDQUdULFdBQVcsQ0FBQyxXQUFXO2tDQUM1QixXQUFXLENBQUMsTUFBTTtvQ0FDaEIsV0FBVyxDQUFDLFFBQVE7aUNBQ3ZCLFdBQVcsQ0FBQyxLQUFLO21DQUNmLFdBQVcsQ0FBQyxPQUFPO29DQUNsQixXQUFXLENBQUMsUUFBUTtXQUM3QyxVQUFVOztNQUVmLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRXpELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxDQUFDLEVBQ3JELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixVQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQ25FLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLGdCQUFnQixDQUFDLENBQUMsQ0FDOUQsQ0FBQztJQUNOLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxXQUF3QixFQUFFLE9BQWdCO1FBQ3hELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFdBQVcsQ0FBQyxHQUFHLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtXQUNyRCxXQUFXLENBQUMsR0FBRyxhQUFhLFdBQVcsQ0FBQyxJQUFJO1dBQzVDLFdBQVcsQ0FBQyxHQUFHLGFBQWEsV0FBVyxDQUFDLElBQUk7V0FDNUMsV0FBVyxDQUFDLEdBQUcsb0JBQW9CLFdBQVcsQ0FBQyxXQUFXO1dBQzFELFdBQVcsQ0FBQyxHQUFHLG1CQUFtQixXQUFXLENBQUMsTUFBTTtXQUNwRCxXQUFXLENBQUMsR0FBRyxxQkFBcUIsV0FBVyxDQUFDLFFBQVE7V0FDeEQsV0FBVyxDQUFDLEdBQUcsY0FBYyxXQUFXLENBQUMsS0FBSztXQUM5QyxXQUFXLENBQUMsR0FBRyxpQkFBaUIsV0FBVyxDQUFDLFFBQVE7O01BRXpELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUVyRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFDdEIsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ2hFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLG1CQUFtQixDQUFDLENBQUMsQ0FDakUsQ0FBQztJQUNOLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxVQUFrQixFQUFFLGNBQXNCLEVBQUUsT0FBZ0I7UUFDMUUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsY0FBYyxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7V0FDcEQsVUFBVSw0QkFBNEIsY0FBYzs7TUFFekQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLGNBQWMsZ0JBQWdCLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFOUUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxjQUFjLFVBQVUsQ0FBQyxDQUFDLEVBQ3JFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixjQUFjLGdCQUFnQixVQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQ3pGLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFTLG1CQUFtQixDQUFDLENBQUMsQ0FDNUQsQ0FBQztJQUNOLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQ2xELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzt3Q0FDa0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7Ozs7O01BUTVGLENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRW5ELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUE4QixDQUFDLEVBQy9ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixXQUFXLEVBQUUsQ0FBQyxDQUFDLEVBQ2xFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUF5QixtQkFBbUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNoRixDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUNaLFVBQWtCLEVBQ2xCLGFBQW1DLEVBQ25DLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBRXRELE1BQU0sS0FBSyxHQUFHOzs7OztrQ0FLWSxhQUFhLENBQUMsV0FBVztXQUNoRCxVQUFVO1dBQ1YsT0FBTzs7TUFFWixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUUzRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsQ0FBQyxFQUN2RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUN2RSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBdUIsa0JBQWtCLENBQUMsQ0FBQyxDQUN6RSxDQUFDO0lBQ04sQ0FBQztJQUVELG1CQUFtQixDQUFDLGFBQW1DLEVBQUUsT0FBZ0I7UUFDckUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsYUFBYSxDQUFDLEdBQUcsb0JBQW9CLGFBQWEsQ0FBQyxXQUFXO1dBQzlELE9BQU8sZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOztNQUVsRCxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsYUFBYSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFekQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDLENBQUMsRUFDdkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLGFBQWEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ3BFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUF1QixxQkFBcUIsQ0FBQyxDQUFDLENBQzVFLENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxXQUFtQixFQUFFLE9BQWdCO1FBQ3pGLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVUsSUFBSSxjQUFjOytDQUNyRSxXQUFXOzs7Ozs7O01BT3BELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQztRQUVoRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFDdkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQy9FLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUMvRCxDQUFDO0lBQ04sQ0FBQztJQUVELGFBQWEsQ0FBQyxVQUFrQixFQUFFLGNBQXNCLEVBQUUsRUFBVSxFQUFFLE9BQWdCO1FBQ2xGLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVUsSUFBSSxjQUFjOzJEQUN6RCxFQUFFOzs7Ozs7O01BT3ZELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQztRQUVsRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFDL0UsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsZUFBZSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ2pFLENBQUM7SUFDTixDQUFDO0lBRUQscUJBQXFCLENBQ2pCLFVBQWtCLEVBQ2xCLGNBQXNCLEVBQ3RCLE1BQWMsRUFDZCxPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixVQUFVLElBQUksY0FBYzsyREFDekQsTUFBTTs7Ozs7OztNQU8zRCxDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUM7UUFFOUUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQzFGLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3pFLENBQUM7SUFDTixDQUFDO0lBRUQsa0JBQWtCLENBQ2QsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsTUFBYyxFQUNkLElBQVksRUFDWixPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixVQUFVLElBQUksY0FBYzsyREFDekQsTUFBTSxxQkFBcUIsSUFBSTs7Ozs7OztNQU9wRixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUM7UUFFdkUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQ3ZGLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLG9CQUFvQixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3RFLENBQUM7SUFDTixDQUFDO0lBRUQsd0JBQXdCLENBQUMsVUFBa0IsRUFBRSxPQUFnQjtRQUN6RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7d0NBQ2tCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixVQUFVOzs7Ozs7Ozs7TUFTM0YsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFFMUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFDakUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsMEJBQTBCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDNUUsQ0FBQztJQUNOLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxPQUFnQjtRQUM3QixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBQy9DLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHOzhDQUN3QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7OztNQU9yRSxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQXNCLENBQUMsRUFDdkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxFQUMvQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBaUIsa0JBQWtCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDdkUsQ0FBQztJQUNOLENBQUM7SUFFRCxRQUFRLENBQUMsVUFBa0IsRUFBRSxPQUFnQjtRQUN6QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBRWpCLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRTtZQUM1QixLQUFLLEdBQUcsTUFBTSxDQUFDO1NBQ2xCO2FBQU0sSUFBSSxVQUFVLElBQUksWUFBWSxFQUFFO1lBQ25DLEtBQUssR0FBRyxNQUFNLENBQUM7U0FDbEI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsS0FBSyxHQUFHLE1BQU0sQ0FBQztTQUNsQjthQUFNO1lBQ0gsS0FBSyxHQUFHLFVBQVUsQ0FBQztTQUN0QjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxPQUFnQjtRQUMvQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBRWxCLG9CQUFvQjtRQUNwQiw4QkFBOEI7UUFDOUIsNkJBQTZCO1FBRTdCLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRTtZQUM1QixNQUFNLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMxQjthQUFNLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRTtZQUNuQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMxQjthQUFNLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRTtZQUNuQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMxQjthQUFNO1lBQ0gsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3pCO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVPLHVCQUF1QixDQUFDLE9BQWdCO1FBQzVDLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3ZCLElBQUksQ0FBQyxPQUFPO2dCQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQztTQUN2RDtJQUNMLENBQUM7SUFFTyxlQUFlLENBQUMsT0FBZ0I7UUFDcEMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDdkIsT0FBTyxnQkFBZ0IsT0FBTyxJQUFJLENBQUM7U0FDdEM7YUFBTTtZQUNILE9BQU8saUJBQWlCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLDBCQUEwQixDQUFDO1NBQzVFO0lBQ0wsQ0FBQztJQUNEOzs7OztPQUtHO0lBQ0ssV0FBVyxDQUFJLFNBQVMsR0FBRyxXQUFXLEVBQUUsTUFBVTtRQUN0RCxPQUFPLENBQUMsS0FBVSxFQUFpQixFQUFFO1lBQ2pDLDhEQUE4RDtZQUM5RCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxZQUFZLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFFcEUseURBQXlEO1lBQ3pELE9BQU8sRUFBRSxDQUFDLE1BQVcsQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFSDs7O09BR0c7SUFDRixZQUFZLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUNqRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7OzREQUUwQyxXQUFXOzs7Ozs7Ozs7O01BVWpFLENBQUM7UUFFSCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDO2FBQ2hELElBQUksQ0FDSCxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQXdCLENBQUMsRUFDdkQsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQW1CLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNuRSxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILFdBQVcsQ0FBQyxRQUF3QixFQUFFLE9BQWdCO1FBQ3BELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7bUNBR2lCLFFBQVEsQ0FBQyxJQUFJO21DQUNiLFFBQVEsQ0FBQyxJQUFJO3NDQUNWLFFBQVEsQ0FBQyxPQUFPO3VDQUNmLFFBQVEsQ0FBQyxRQUFRO21DQUNyQixRQUFRLENBQUMsSUFBSTswQ0FDTixRQUFRLENBQUMsV0FBVztvQ0FDMUIsUUFBUSxDQUFDLEtBQUs7U0FDekMsQ0FBQztRQUVOLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQzthQUN0RCxJQUFJLENBQ0gsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFDbkMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsYUFBYSxDQUFDLENBQUMsQ0FDcEQsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCxjQUFjLENBQUMsUUFBd0IsRUFBRSxPQUFnQjtRQUN2RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFUCxRQUFRLENBQUMsR0FBRyxhQUFhLFFBQVEsQ0FBQyxJQUFJO1dBQ3RDLFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRyxhQUFhLFFBQVEsQ0FBQyxJQUFJO1dBQ3RDLFFBQVEsQ0FBQyxHQUFHLGNBQWMsUUFBUSxDQUFDLEtBQUs7V0FDeEMsUUFBUSxDQUFDLEdBQUcsYUFBYSxRQUFRLENBQUMsSUFBSTtXQUN0QyxRQUFRLENBQUMsR0FBRyxvQkFBb0IsUUFBUSxDQUFDLFdBQVc7O01BRXpELENBQUM7UUFFSCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUM7YUFDdEQsSUFBSSxDQUNILEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQ25DLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFTLGdCQUFnQixDQUFDLENBQUMsQ0FDdkQsQ0FBQztJQUNOLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsY0FBYyxDQUFDLFVBQWtCLEVBQUUsV0FBbUIsRUFBRSxPQUFnQjtRQUN0RSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFUCxXQUFXOztNQUVoQixDQUFDO1FBRUgsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDO2FBQ3RELElBQUksQ0FDSCxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUNuQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUyxnQkFBZ0IsQ0FBQyxDQUFDLENBQ3ZELENBQUM7SUFDTixDQUFDO0NBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICAgIERhdGFTdG9yZSxcbiAgICBHYXRld2F5LFxuICAgIEdhdGV3YXlGaWx0ZXJzQ29uZmlnLFxuICAgIE1vZGVsLFxuICAgIE1vZGVsQ29uZmlnLFxuICAgIE5vdGlmaWNhdGlvbixcbiAgICBQaXBlbGluZSxcbiAgICBQcm90b2NvbCxcbiAgICBUU1JlYWRpbmcsXG4gICAgUHl0aG9uUmVzb3VyY2Vcbn0gZnJvbSAnLi4vbW9kZWwvbW9kZWxzJztcbmltcG9ydCB7IGNhdGNoRXJyb3IsIG1hcCwgT2JzZXJ2YWJsZSwgb2YsIHRhcCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcblxuXG5jb25zdCByb3V0ZTE6IG51bWJlcltdW10gPSBbXG4gICAgWzI1Ljc3MTA4OCwgLTgwLjE2MzQ4M10sXG4gICAgWzI3LjQzOTc3NSwgLTgwLjMyMjk5XSxcbiAgICBbMjguMzQ5NDY5LCAtODAuNzMxMTA1XSxcbiAgICBbMzAuNDAxNTY0LCAtODEuNTcxMDMzXSxcbiAgICBbMzIuMTE2NzE2LCAtODEuMTQ0MTQ3XSxcbiAgICBbMzIuODY2NTExLCAtNzkuOTk1Mzk5XSxcbiAgICBbMzQuMTkxMjI0LCAtNzcuOTUyNDE5XSxcbiAgICBbMzYuODUwMTcyLCAtNzYuMzE5MjY5XSxcbiAgICBbMzYuOTE1MDM3LCAtNzYuMzIwNjQzXSxcbiAgICBbMzkuMjYyMDI1LCAtNzYuNTQ5Mjk0XSxcbiAgICBbMzkuOTAwOTMzLCAtNzUuMTQzNDUzXSxcbiAgICBbNDAuNjkwMjYzLCAtNzQuMTUyMzc1XSxcbiAgICBbNDIuMjU5OTUxLCAtNzEuNzg5MjQ0XSxcbl07XG5cbmNvbnN0IHJvdXRlMjogbnVtYmVyW11bXSA9IFtcbiAgICBbNDcuNDkyNDcxLCAtMTIyLjI2ODg4XSxcbiAgICBbNDUuNTUyMjA3LCAtMTIyLjcyMjY0OF0sXG4gICAgWzM5LjUzMjQ2LCAtMTE5Ljc1MTUyNF0sXG4gICAgWzM3LjgwMzUyOCwgLTEyMi4zMTIxMzhdLFxuICAgIFszNy44OTkzMzIsIC0xMjEuMTY5MzA3XSxcbiAgICBbMzYuMjczMTgzLCAtMTE1LjA3MDUzNF0sXG4gICAgWzMzLjc3MDMyLCAtMTE4LjI3MzI4OV0sXG4gICAgWzM0LjEwNjAxMiwgLTExNy4zMjAyNTRdLFxuICAgIFszMy41MTU1NjQsIC0xMTIuMTYwNTY0XSxcbiAgICBbMzIuMTI2NDM3LCAtMTEwLjg0ODMzNl0sXG4gICAgWzMxLjc1MjA4NSwgLTEwNi40ODg4ODddLFxuICAgIFszNS4wNDc1OCwgLTEwNi42NTMzNDRdLFxuICAgIFszOS43OTY5NjMsIC0xMDQuOTk1Mzc0XSxcbl07XG5cbmNvbnN0IHJvdXRlMzogbnVtYmVyW11bXSA9IFtcbiAgICBbMjkuMzAyNzI5LCAtOTguNjM4NzQ0XSxcbiAgICBbMjkuNjM4NDIxLCAtOTUuMjkyMjQ1XSxcbiAgICBbMzIuNjE1NTI1LCAtOTYuNjkzNDg1XSxcbiAgICBbMjkuOTE3ODM2LCAtOTAuMjA1MjcyXSxcbiAgICBbMzIuMjU2NDAzLCAtOTAuMTUxNTQ2XSxcbiAgICBbMzUuMDQ0ODQ5LCAtOTAuMTUzMDA2XSxcbiAgICBbMzguNTI0NjI3LCAtOTAuMjA5NTM1XSxcbiAgICBbMzkuODcwODUxLCAtODguOTEyMjg0XSxcbiAgICBbNDEuNzA1Njk0LCAtODcuNTc3MzQxXSxcbiAgICBbNDEuOTAyMzgyLCAtODkuMTAxOTMyXSxcbiAgICBbNDQuMjUxMjQzLCAtOTEuNTA5NjYzXSxcbiAgICBbNDQuOTcwMDY5LCAtOTMuMTc0NTI3XSxcbiAgICBbNDYuNzU4MTgxLCAtOTIuMDk4NzQ4XSxcbl07XG5cbmNvbnN0IGVtcHR5cm91dGU6IG51bWJlcltdW10gPSBbXTtcblxuY29uc3QgaHR0cE9wdGlvbnMgPSB7XG4gICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2dyYXBocWwrLScsXG4gICAgfSxcbn07XG5cbmNvbnN0IGh0dHBNdXRhdGVPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9yZGYnIH0sXG59O1xuXG5leHBvcnQgY2xhc3MgR3JhcGhTZXJ2aWNlIHtcbiAgICBcbiAgICBwcml2YXRlIHJlcXVpcmVBY2NvdW50SWQgPSB0cnVlO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LCBwcm90ZWN0ZWQgZEdyYXBoVXJsOiBzdHJpbmcsIHByaXZhdGUgYWNjb3VudFJlcXVpcmVkOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMucmVxdWlyZUFjY291bnRJZCA9IGFjY291bnRSZXF1aXJlZDtcbiAgICAgICAgLy9jb25zdCBkR3JhcGhCYXNpY0F1dGhFbmFibGVkID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aEVuYWJsZWQ7XG4gICAgICAgIC8vaWYgKGRHcmFwaEJhc2ljQXV0aEVuYWJsZWQpIHtcbiAgICAgICAgLy8gICAgY29uc3QgZEdyYXBoQmFzaWNBdXRoID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aDtcbiAgICAgICAgLy8gICAgKHRoaXMuaHR0cE9wdGlvbnMuaGVhZGVycyA9IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9ncmFwaHFsKy0nIH0pLCB7IEF1dGhvcml6YXRpb246IGRHcmFwaEJhc2ljQXV0aCB9O1xuICAgICAgICAvLyAgICAodGhpcy5odHRwTXV0YXRlT3B0aW9ucy5oZWFkZXJzID0geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3JkZicgfSksIHsgQXV0aG9yaXphdGlvbjogZEdyYXBoQmFzaWNBdXRoIH07XG4gICAgICAgIC8vfVxuICAgIH1cblxuICAgIGdldEdhdGV3YXkoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc29sZS5sb2coYEdldEdhdGV3YXkgc2VydmljZSBjYWxsZWQgZm9yICR7Z2F0ZXdheU5hbWV9YCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeT9kZWJ1Zz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWQgZGVzY3JpcHRpb24gYWRkcmVzcyByb3V0ZXIgcm91dGVyUG9ydFxuICAgICAgICBkZXBsb3lOZXR3b3JrIGxhdGl0dWRlIGxvbmdpdHVkZSBhY2Nlc3NUb2tlbiB1c2VybmFtZVxuICAgICAgICBwbGF0Zm9ybSBkZXZpY2VzTWV0YWRhdGEgY3JlYXRlZHRzIHVwZGF0ZWR0c1xuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheVtdPignZ2V0R2F0ZXdheScsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheXMoYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5P2RlYnVnPXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhnYXRld2F5KSlcbiAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgdWlkIHV1aWQgZGVzY3JpcHRpb24gYWRkcmVzcyByb3V0ZXIgcm91dGVyUG9ydFxuICAgICAgICBkZXBsb3lOZXR3b3JrIGxhdGl0dWRlIGxvbmdpdHVkZSBhY2Nlc3NUb2tlbiB1c2VybmFtZVxuICAgICAgICBwbGF0Zm9ybSBkZXZpY2VzTWV0YWRhdGEgY3JlYXRlZHRzIHVwZGF0ZWR0c1xuICAgICAgICBudW1EZXZpY2VzOiBjb3VudChnYXRld2F5X2RldmljZSlcbiAgICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCAke3Jlc3BvbnNlLmxlbmd0aH0gZ2F0ZXdheXNgKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheVtdPignZ2V0R2F0ZXdheXMnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZUdhdGV3YXkoZ2F0ZXdheTogR2F0ZXdheSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPGFkZHJlc3M+IFwiJHtnYXRld2F5LmFkZHJlc3N9XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxyb3V0ZXI+IFwiJHtnYXRld2F5LnJvdXRlcn1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPHJvdXRlclBvcnQ+IFwiJHtnYXRld2F5LnJvdXRlclBvcnR9XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxkZXBsb3lOZXR3b3JrPiBcIiR7Z2F0ZXdheS5kZXBsb3lOZXR3b3JrfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8ZGVzY3JpcHRpb24+IFwiJHtnYXRld2F5LmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8bGF0aXR1ZGU+IFwiJHtnYXRld2F5LmxhdGl0dWRlfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8bG9uZ2l0dWRlPiBcIiR7Z2F0ZXdheS5sb25naXR1ZGV9XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxhY2Nlc3NUb2tlbj4gXCIke2dhdGV3YXkuYWNjZXNzVG9rZW59XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDx1c2VybmFtZT4gXCIke2dhdGV3YXkudXNlcm5hbWV9XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxwbGF0Zm9ybT4gXCIke2dhdGV3YXkucGxhdGZvcm19XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDx1cGRhdGVkdHM+IFwiJHtnYXRld2F5LnVwZGF0ZWR0c31cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgR2F0ZXdheSAke2dhdGV3YXkudXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgoKSA9PiAnZ2F0ZXdheSB1cGRhdGVkJyksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZ2F0ZXdheSAke2dhdGV3YXkudXVpZH1gKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPigndXBkYXRlR2F0ZXdheScpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRHYXRld2F5KGdhdGV3YXk6IEdhdGV3YXksIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXk+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86R2F0ZXdheSA8ZGdyYXBoLnR5cGU+IFwiR2F0ZXdheVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxnYXRld2F5PiBcIlwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx0eXBlPiBcImdhdGV3YXlcIiAuXG4gICAgICAgIF86R2F0ZXdheSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHV1aWQ+IFwiJHtnYXRld2F5LnV1aWR9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGRlc2NyaXB0aW9uPiBcIiR7Z2F0ZXdheS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8YWRkcmVzcz4gXCIke2dhdGV3YXkuYWRkcmVzc31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8cm91dGVyPiBcIiR7Z2F0ZXdheS5yb3V0ZXJ9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHJvdXRlclBvcnQ+IFwiJHtnYXRld2F5LnJvdXRlclBvcnR9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGRlcGxveU5ldHdvcms+IFwiJHtnYXRld2F5LmRlcGxveU5ldHdvcmt9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGxhdGl0dWRlPiBcIiR7Z2F0ZXdheS5sYXRpdHVkZX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8bG9uZ2l0dWRlPiBcIiR7Z2F0ZXdheS5sb25naXR1ZGV9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGFjY2Vzc1Rva2VuPiBcIiR7Z2F0ZXdheS5hY2Nlc3NUb2tlbn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8dXNlcm5hbWU+IFwiJHtnYXRld2F5LnVzZXJuYW1lfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxwbGF0Zm9ybT4gXCIke2dhdGV3YXkucGxhdGZvcm19XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGNyZWF0ZWR0cz4gXCIke2dhdGV3YXkuY3JlYXRlZHRzfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx1cGRhdGVkdHM+IFwiJHtnYXRld2F5LnVwZGF0ZWR0c31cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgR2F0ZXdheSAke2dhdGV3YXkudXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBnYXRld2F5KSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBnYXRld2F5ICR7Z2F0ZXdheS51aWR9LyR7Z2F0ZXdheS51dWlkfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5PignYWRkR2F0ZXdheScpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVHYXRld2F5KGdhdGV3YXlVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBHYXRld2F5ICR7Z2F0ZXdheVVpZH0gYCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKCkgPT4gYCR7Z2F0ZXdheVVpZH0gZGVsZXRlZGApLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxzdHJpbmc+KCdkZWxldGVHYXRld2F5JykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlBbmRQcm90b2NvbHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICAgIHByb3RvY29sczogZ2F0ZXdheV9wcm90b2NvbCB7XG4gICAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBwcm90b2NvbFR5cGUgYnJva2VyVVJMXG4gICAgICAgICAgdG9waWMgY29uc3VtZXJHcm91cElkIGNvbm5lY3Rpb25UaW1lb3V0IHNlc3Npb25UaW1lb3V0XG4gICAgICAgICAgaW5pdGlhbE9mZnNldCByZXRyeUJhY2tPZmYgZmV0Y2hNaW5CeXRlcyBmZXRjaE1heFdhaXRcbiAgICAgICAgICBjb21taXRJbnRlcnZhbCBoZWFydGJlYXRJbnRlcnZhbCBtYXhpbXVtUU9TXG4gICAgICAgICAgdXNlcm5hbWUgcGFzc3dvcmQgZW5jcnlwdGlvbk1vZGVcbiAgICAgICAgICBjYUNlcnRpZmljYXRlIGNsaWVudENlcnRpZmljYXRlIGNsaWVudEtleVxuICAgICAgICAgIGF1dGhNb2RlIHNlcnZlckNlcnRpZmljYXRlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEdldCBHYXRld2F5IGFuZCBQcm90b2NvbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBHYXRld2F5IGFuZCBQcm90b2NvbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPEdhdGV3YXlbXT4oJ2dldEdhdGV3YXlXaXRoUHJvdG9jb2xzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgYWxsIGdsb2JhbCBwcm90b2NvbHMgYW5kIHRoZSBwcm90b2NvbHMgc2NvcGVkIGZvciB0aGUgZ2F0ZXdheVxuICAgICAqIEBwYXJhbSBnYXRld2F5TmFtZVxuICAgICAqL1xuICAgIGdldFByb3RvY29scyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQcm90b2NvbFtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKHByb3RvY29sKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KFxuICAgICAgICAgIGFjY291bnQsXG4gICAgICApfSBBTkQgKGVxKHNjb3BlLCBcIiR7Z2F0ZXdheU5hbWV9XCIpIE9SIGVxKHNjb3BlLCBcIkdMT0JBTFwiKSkpIHtcbiAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBwcm90b2NvbFR5cGUgYnJva2VyVVJMIHRvcGljXG4gICAgICAgIGNvbnN1bWVyR3JvdXBJZCBjb25uZWN0aW9uVGltZW91dCBzZXNzaW9uVGltZW91dCBpbml0aWFsT2Zmc2V0XG4gICAgICAgIHJldHJ5QmFja09mZiBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdCBjb21taXRJbnRlcnZhbFxuICAgICAgICBoZWFydGJlYXRJbnRlcnZhbCBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkXG4gICAgICAgIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGUgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5XG4gICAgICAgIGF1dGhNb2RlIHNlcnZlckNlcnRpZmljYXRlIHNjb3BlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUHJvdG9jb2xbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcHJvdG9jb2xzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQcm90b2NvbFtdPignZ2V0UHJvdG9jb2xzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRQcm90b2NvbChnYXRld2F5VWlkOiBudW1iZXIsIHByb3RvY29sOiBQcm90b2NvbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2w+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UHJvdG9jb2wgPGRncmFwaC50eXBlPiBcIlByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDx0eXBlPiBcInByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwcm90b2NvbD4gXCJcIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8dXVpZD4gXCIke3Byb3RvY29sLnV1aWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjcmVhdGVkPiBcIiR7cHJvdG9jb2wuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPG1vZGlmaWVkPiBcIiR7cHJvdG9jb2wubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwcm90b2NvbFR5cGU+IFwiJHtwcm90b2NvbC5wcm90b2NvbFR5cGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxicm9rZXJVUkw+IFwiJHtwcm90b2NvbC5icm9rZXJVUkx9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDx0b3BpYz4gXCIke3Byb3RvY29sLnRvcGljfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y29uc3VtZXJHcm91cElkPiBcIiR7cHJvdG9jb2wuY29uc3VtZXJHcm91cElkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y29ubmVjdGlvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5jb25uZWN0aW9uVGltZW91dH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHNlc3Npb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuc2Vzc2lvblRpbWVvdXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxpbml0aWFsT2Zmc2V0PiBcIiR7cHJvdG9jb2wuaW5pdGlhbE9mZnNldH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHJldHJ5QmFja09mZj4gXCIke3Byb3RvY29sLnJldHJ5QmFja09mZn1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGZldGNoTWluQnl0ZXM+IFwiJHtwcm90b2NvbC5mZXRjaE1pbkJ5dGVzfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8ZmV0Y2hNYXhXYWl0PiBcIiR7cHJvdG9jb2wuZmV0Y2hNYXhXYWl0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y29tbWl0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5jb21taXRJbnRlcnZhbH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGhlYXJ0YmVhdEludGVydmFsPiBcIiR7cHJvdG9jb2wuaGVhcnRiZWF0SW50ZXJ2YWx9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxtYXhpbXVtUU9TPiBcIiR7cHJvdG9jb2wubWF4aW11bVFPU31cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHVzZXJuYW1lPiBcIiR7cHJvdG9jb2wudXNlcm5hbWV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwYXNzd29yZD4gXCIke3Byb3RvY29sLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8ZW5jcnlwdGlvbk1vZGU+IFwiJHtwcm90b2NvbC5lbmNyeXB0aW9uTW9kZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNhQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jYUNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y2xpZW50Q2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jbGllbnRDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNsaWVudEtleT4gXCIke3Byb3RvY29sLmNsaWVudEtleX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGF1dGhNb2RlPiBcIiR7cHJvdG9jb2wuYXV0aE1vZGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxzZXJ2ZXJDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLnNlcnZlckNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8c2NvcGU+IFwiJHtwcm90b2NvbC5zY29wZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgcHJvdG9jb2wgJHtwcm90b2NvbC51dWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IHByb3RvY29sKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBwcm90b2NvbHMgJHtwcm90b2NvbC51aWR9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFByb3RvY29sPignYWRkUHJvdG9jb2xzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZVByb3RvY29sKHByb3RvY29sOiBQcm90b2NvbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2w+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDx1dWlkPiBcIiR7cHJvdG9jb2wudXVpZH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxtb2RpZmllZD4gXCIke3Byb3RvY29sLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHByb3RvY29sVHlwZT4gXCIke3Byb3RvY29sLnByb3RvY29sVHlwZX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxicm9rZXJVUkw+IFwiJHtwcm90b2NvbC5icm9rZXJVUkx9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8dG9waWM+IFwiJHtwcm90b2NvbC50b3BpY31cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxjb25zdW1lckdyb3VwSWQ+IFwiJHtwcm90b2NvbC5jb25zdW1lckdyb3VwSWR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8Y29ubmVjdGlvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5jb25uZWN0aW9uVGltZW91dH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxzZXNzaW9uVGltZW91dD4gXCIke3Byb3RvY29sLnNlc3Npb25UaW1lb3V0fVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGluaXRpYWxPZmZzZXQ+IFwiJHtwcm90b2NvbC5pbml0aWFsT2Zmc2V0fVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHJldHJ5QmFja09mZj4gXCIke3Byb3RvY29sLnJldHJ5QmFja09mZn1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxmZXRjaE1pbkJ5dGVzPiBcIiR7cHJvdG9jb2wuZmV0Y2hNaW5CeXRlc31cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxmZXRjaE1heFdhaXQ+IFwiJHtwcm90b2NvbC5mZXRjaE1heFdhaXR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8Y29tbWl0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5jb21taXRJbnRlcnZhbH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxoZWFydGJlYXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmhlYXJ0YmVhdEludGVydmFsfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPG1heGltdW1RT1M+IFwiJHtwcm90b2NvbC5tYXhpbXVtUU9TfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHVzZXJuYW1lPiBcIiR7cHJvdG9jb2wudXNlcm5hbWV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8cGFzc3dvcmQ+IFwiJHtwcm90b2NvbC5wYXNzd29yZH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxlbmNyeXB0aW9uTW9kZT4gXCIke3Byb3RvY29sLmVuY3J5cHRpb25Nb2RlfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGNhQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jYUNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGNsaWVudENlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2xpZW50Q2VydGlmaWNhdGV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8Y2xpZW50S2V5PiBcIiR7cHJvdG9jb2wuY2xpZW50S2V5fVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGF1dGhNb2RlPiBcIiR7cHJvdG9jb2wuYXV0aE1vZGV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8c2VydmVyQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5zZXJ2ZXJDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxzY29wZT4gXCIke3Byb3RvY29sLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSAke3Byb3RvY29sLnVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgoKSA9PiBwcm90b2NvbCksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgcHJvdG9jb2xzICR7cHJvdG9jb2wudWlkfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQcm90b2NvbD4oJ3VwZGF0ZVByb3RvY29scycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVQcm90b2NvbChnYXRld2F5VWlkOiBudW1iZXIsIHByb3RvY29sVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgZGVsZXRlIHtcbiAgICAgICAgPCR7cHJvdG9jb2xVaWR9PiA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIFByb3RvY29sICR7cHJvdG9jb2xVaWR9IGZvciAke2dhdGV3YXlVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKCkgPT4gYCR7cHJvdG9jb2xVaWR9IGRlbGV0ZWRgKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZGVsZXRlZCBwcm90b2NvbCAke3Byb3RvY29sVWlkfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxzdHJpbmc+KCdkZWxldGVQcm90b2NvbCcpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXREYXRhU3RvcmVzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERhdGFTdG9yZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGRhdGFTdG9yZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShcbiAgICAgICAgICBhY2NvdW50LFxuICAgICAgKX0gQU5EIChlcShzY29wZSwgXCIke2dhdGV3YXlOYW1lfVwiKSBPUiBlcShzY29wZSwgXCJHTE9CQUxcIikpKSB7XG4gICAgICAgIHVpZCB1dWlkIGNyZWF0ZWQgbW9kaWZpZWQgZGF0YVN0b3JlVHlwZVxuICAgICAgICBob3N0IHBvcnQgZGF0YWJhc2VOYW1lIHVzZXIgcGFzc3dvcmQgYWNjb3VudE5hbWVcbiAgICAgICAgd2FyZWhvdXNlIGRhdGFiYXNlIHNjaGVtYSBhdXRoVHlwZSB1c2VybmFtZVxuICAgICAgICBjbGllbnRJZCBjbGllbnRTZWNyZXQgYXV0aG9yaXphdGlvbkNvZGVcbiAgICAgICAgcmVkaXJlY3RVUkkgbG9naW5UaW1lb3V0IHVybCBzY29wZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIERhdGFTdG9yZVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBkYXRhU3RvcmVzIGZvciBnYXRld2F5ICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPERhdGFTdG9yZVtdPignZ2V0RGF0YVN0b3JlcycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkRGF0YVN0b3JlKGdhdGV3YXlVaWQ6IG51bWJlciwgZGF0YVN0b3JlOiBEYXRhU3RvcmUsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERhdGFTdG9yZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpEYXRhU3RvcmUgPGRncmFwaC50eXBlPiBcIkRhdGFTdG9yZVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHR5cGU+IFwiZGF0YVN0b3JlXCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YVN0b3JlPiBcIlwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHV1aWQ+IFwiJHtkYXRhU3RvcmUudXVpZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjcmVhdGVkPiBcIiR7ZGF0YVN0b3JlLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8bW9kaWZpZWQ+IFwiJHtkYXRhU3RvcmUubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YVN0b3JlVHlwZT4gXCIke2RhdGFTdG9yZS5kYXRhU3RvcmVUeXBlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGhvc3Q+IFwiJHtkYXRhU3RvcmUuaG9zdH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxwb3J0PiBcIiR7ZGF0YVN0b3JlLnBvcnR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YWJhc2VOYW1lPiBcIiR7ZGF0YVN0b3JlLmRhdGFiYXNlTmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1c2VyPiBcIiR7ZGF0YVN0b3JlLnVzZXJ9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8cGFzc3dvcmQ+IFwiJHtkYXRhU3RvcmUucGFzc3dvcmR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8YWNjb3VudE5hbWU+IFwiJHtkYXRhU3RvcmUuYWNjb3VudE5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8d2FyZWhvdXNlPiBcIiR7ZGF0YVN0b3JlLndhcmVob3VzZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxkYXRhYmFzZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8c2NoZW1hPiBcIiR7ZGF0YVN0b3JlLnNjaGVtYX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhdXRoVHlwZT4gXCIke2RhdGFTdG9yZS5hdXRoVHlwZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1c2VybmFtZT4gXCIke2RhdGFTdG9yZS51c2VybmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjbGllbnRJZD4gXCIke2RhdGFTdG9yZS5jbGllbnRJZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjbGllbnRTZWNyZXQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50U2VjcmV0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGF1dGhvcml6YXRpb25Db2RlPiBcIiR7ZGF0YVN0b3JlLmF1dGhvcml6YXRpb25Db2RlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHJlZGlyZWN0VVJJPiBcIiR7ZGF0YVN0b3JlLnJlZGlyZWN0VVJJfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGxvZ2luVGltZW91dD4gXCIke2RhdGFTdG9yZS5sb2dpblRpbWVvdXR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXJsPiBcIiR7ZGF0YVN0b3JlLnVybH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxzY29wZT4gXCIke2RhdGFTdG9yZS5zY29wZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGRlZCBkYXRhc3RvcmUgJHtkYXRhU3RvcmUudXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBkYXRhU3RvcmUpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgYWRkIGRhdGFTdG9yZXMgJHtkYXRhU3RvcmUudWlkfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxEYXRhU3RvcmU+KCdhZGREYXRhU3RvcmVzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZURhdGFTdG9yZShkYXRhU3RvcmU6IERhdGFTdG9yZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8RGF0YVN0b3JlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDx1dWlkPiBcIiR7ZGF0YVN0b3JlLnV1aWR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPG1vZGlmaWVkPiBcIiR7ZGF0YVN0b3JlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxkYXRhU3RvcmVUeXBlPiBcIiR7ZGF0YVN0b3JlLmRhdGFTdG9yZVR5cGV9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGhvc3Q+IFwiJHtkYXRhU3RvcmUuaG9zdH1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8cG9ydD4gXCIke2RhdGFTdG9yZS5wb3J0fVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxkYXRhYmFzZU5hbWU+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDx1c2VyPiBcIiR7ZGF0YVN0b3JlLnVzZXJ9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHBhc3N3b3JkPiBcIiR7ZGF0YVN0b3JlLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxhY2NvdW50TmFtZT4gXCIke2RhdGFTdG9yZS5hY2NvdW50TmFtZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8d2FyZWhvdXNlPiBcIiR7ZGF0YVN0b3JlLndhcmVob3VzZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8ZGF0YWJhc2U+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxzY2hlbWE+IFwiJHtkYXRhU3RvcmUuc2NoZW1hfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxhdXRoVHlwZT4gXCIke2RhdGFTdG9yZS5hdXRoVHlwZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8dXNlcm5hbWU+IFwiJHtkYXRhU3RvcmUudXNlcm5hbWV9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGNsaWVudElkPiBcIiR7ZGF0YVN0b3JlLmNsaWVudElkfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxjbGllbnRTZWNyZXQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50U2VjcmV0fVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxhdXRob3JpemF0aW9uQ29kZT4gXCIke2RhdGFTdG9yZS5hdXRob3JpemF0aW9uQ29kZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8cmVkaXJlY3RVUkk+IFwiJHtkYXRhU3RvcmUucmVkaXJlY3RVUkl9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGxvZ2luVGltZW91dD4gXCIke2RhdGFTdG9yZS5sb2dpblRpbWVvdXR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHVybD4gXCIke2RhdGFTdG9yZS51cmx9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHNjb3BlPiBcIiR7ZGF0YVN0b3JlLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSBkYXRhU3RvcmUgJHtkYXRhU3RvcmUudWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKCgpID0+IGRhdGFTdG9yZSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZGF0YVN0b3JlcyAke2RhdGFTdG9yZS51aWR9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPERhdGFTdG9yZT4oJ3VwZGF0ZURhdGFTdG9yZXMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlRGF0YVN0b3JlKGdhdGV3YXlVaWQ6IG51bWJlciwgZGF0YVN0b3JlVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgZGVsZXRlIHtcbiAgICAgICAgPCR7ZGF0YVN0b3JlVWlkfT4gPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBEYXRhU3RvcmUgJHtkYXRhU3RvcmVVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYCR7ZGF0YVN0b3JlVWlkfSBkZWxldGVkYCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIGRhdGFTdG9yZSAke2RhdGFTdG9yZVVpZH1gKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlRGF0YVN0b3JlJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlBbmRNb2RlbHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICAgIG1vZGVsczogZ2F0ZXdheV9tb2RlbCB7XG4gICAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBuYW1lXG4gICAgICAgICAgZGVzY3JpcHRpb24gaW5wdXRUeXBlIHVybCBzY29wZVxuICAgICAgICAgIGlucHV0VGVtcGxhdGUgaGVhZGVycyBtZXRob2QgYmFzZTY0RW5jb2RlZFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBHZXQgR2F0ZXdheSBhbmQgUHJvdG9jb2xzIGZvciAke2dhdGV3YXlOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgZ2F0ZXdheXMgYW5kIG1vZGVscyBmb3IgJHtnYXRld2F5TmFtZX1gKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheVtdPignZ2V0R2F0ZXdheVdpdGhNb2RlbHMnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldE1vZGVscyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbFtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKG1vZGVsKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KFxuICAgICAgICAgIGFjY291bnQsXG4gICAgICApfSBBTkQgKGVxKHNjb3BlLCBcIiR7Z2F0ZXdheU5hbWV9XCIpIE9SIGVxKHNjb3BlLCBcIkdMT0JBTFwiKSkpIHtcbiAgICAgICAgdWlkIHV1aWQgY3JlYXRlZCBtb2RpZmllZCBuYW1lXG4gICAgICAgIGRlc2NyaXB0aW9uIGlucHV0VHlwZSB1cmwgc2NvcGUgaW5wdXRUZW1wbGF0ZVxuICAgICAgICBoZWFkZXJzIG1ldGhvZCBiYXNlNjRFbmNvZGVkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgTW9kZWxbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgbW9kZWxzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbFtdPignZ2V0TW9kZWxzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRNb2RlbChnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsOiBNb2RlbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWw+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86TW9kZWwgPGRncmFwaC50eXBlPiBcIk1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDx0eXBlPiBcIm1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDxtb2RlbD4gXCJcIiAuXG4gICAgICAgIF86TW9kZWwgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8dXVpZD4gXCIke21vZGVsLnV1aWR9XCIgLlxuICAgICAgICBfOk1vZGVsIDxjcmVhdGVkPiBcIiR7bW9kZWwuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPG1vZGlmaWVkPiBcIiR7bW9kZWwubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOk1vZGVsIDxuYW1lPiBcIiR7bW9kZWwubmFtZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWwuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOk1vZGVsIDxpbnB1dFR5cGU+IFwiJHttb2RlbC5pbnB1dFR5cGV9XCIgLlxuICAgICAgICBfOk1vZGVsIDx1cmw+IFwiJHttb2RlbC51cmx9XCIgLlxuICAgICAgICBfOk1vZGVsIDxzY29wZT4gXCIke21vZGVsLnNjb3BlfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8aW5wdXRUZW1wbGF0ZT4gXCIke21vZGVsLmlucHV0VGVtcGxhdGV9XCIgLlxuICAgICAgICBfOk1vZGVsIDxoZWFkZXJzPiBcIiR7bW9kZWwuaGVhZGVyc31cIiAuXG4gICAgICAgIF86TW9kZWwgPG1ldGhvZD4gXCIke21vZGVsLm1ldGhvZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPGJhc2U2NEVuY29kZWQ+IFwiJHttb2RlbC5iYXNlNjRFbmNvZGVkfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEFkZCBtb2RlbCAke21vZGVsLnV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gbW9kZWwpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgYWRkZWQgbW9kZWwgJHttb2RlbC51aWR9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE1vZGVsPignYWRkTW9kZWwnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlTW9kZWwobW9kZWw6IE1vZGVsLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbD4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPHV1aWQ+IFwiJHttb2RlbC51dWlkfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPG1vZGlmaWVkPiBcIiR7bW9kZWwubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8bmFtZT4gXCIke21vZGVsLm5hbWV9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8ZGVzY3JpcHRpb24+IFwiJHttb2RlbC5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIDwke21vZGVsLnVpZH0+IDxpbnB1dFR5cGU+IFwiJHttb2RlbC5pbnB1dFR5cGV9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8dXJsPiBcIiR7bW9kZWwudXJsfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPHNjb3BlPiBcIiR7bW9kZWwuc2NvcGV9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8aW5wdXRUZW1wbGF0ZT4gXCIke21vZGVsLmlucHV0VGVtcGxhdGV9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8aGVhZGVycz4gXCIke21vZGVsLmhlYWRlcnN9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8bWV0aG9kPiBcIiR7bW9kZWwubWV0aG9kfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPGJhc2U2NEVuY29kZWQ+IFwiJHttb2RlbC5iYXNlNjRFbmNvZGVkfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSBtb2RlbCAke21vZGVsLnVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgoKSA9PiBtb2RlbCksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ3VwZGF0ZWQgbW9kZWxzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE1vZGVsPigndXBkYXRlTW9kZWxzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGNoZWNrRm9yRXJyb3IoZXJyb3JzOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ0NoZWNraW5nIGZvciBlcnJvcnMgaW4gJywgZXJyb3JzKTtcbiAgICAgICAgaWYgKGVycm9ycykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKEpTT04uc3RyaW5naWZ5KGVycm9ycykpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZGVsZXRlTW9kZWwoZ2F0ZXdheVVpZDogbnVtYmVyLCBtb2RlbFVpZDogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIGRlbGV0ZSB7XG4gICAgICAgIDwke21vZGVsVWlkfT4gPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYERlbGV0ZSBNb2RlbCAke21vZGVsVWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGAke21vZGVsVWlkfSBkZWxldGVkYCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIG1vZGVsICR7bW9kZWxVaWR9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPHN0cmluZz4oJ2RlbGV0ZU1vZGVsJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlBbmRQaXBlbGluZXMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcGlwZWxpbmVfcHJvdG9jb2wgPSBgcHJvdG9jb2w6IHBpcGVsaW5lX3Byb3RvY29sIHtcbiAgICAgICAgdWlkIHV1aWQgYnJva2VyVVJMIHRvcGljIG1heGltdW1RT1MgdXNlcm5hbWUgcGFzc3dvcmQgZW5jcnlwdGlvbk1vZGUgY2FDZXJ0aWZpY2F0ZVxuICAgICAgICBjbGllbnRDZXJ0aWZpY2F0ZSBjbGllbnRLZXkgYXV0aE1vZGUgc2VydmVyQ2VydGlmaWNhdGUgY29uc3VtZXJHcm91cElkIGNvbm5lY3Rpb25UaW1lb3V0XG4gICAgICAgIHNlc3Npb25UaW1lb3V0IHJldHJ5QmFja09mZiBjb21taXRJbnRlcnZhbCBpbml0aWFsT2Zmc2V0IGZldGNoTWluQnl0ZXMgZmV0Y2hNYXhXYWl0IGhlYXJ0YmVhdEludGVydmFsXG4gICAgICB9YDtcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZGF0YXN0b3JlID0gYGRhdGFTdG9yZTogcGlwZWxpbmVfZGF0YXN0b3JlIHtcbiAgICAgICAgdWlkIHV1aWQgaG9zdCBwb3J0IGRhdGFiYXNlTmFtZSB1c2VyIHBhc3N3b3JkIGFjY291bnROYW1lIHdhcmVob3VzZSBkYXRhYmFzZSBzY2hlbWEgYXV0aFR5cGVcbiAgICAgICAgdXNlcm5hbWUgY2xpZW50SWQgY2xpZW50U2VjcmV0IGF1dGhvcml6YXRpb25Db2RlIHJlZGlyZWN0VVJJIGxvZ2luVGltZW91dCB1cmxcbiAgICAgIH1gO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9maWx0ZXIgPSAnZmlsdGVyOiBwaXBlbGluZV9maWx0ZXIgeyB1aWQgZGV2aWNlTmFtZXMgfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3N0cmVhbWluZyA9XG4gICAgICAgICAgICAnc3RyZWFtaW5nOiBwaXBlbGluZV9zdHJlYW1pbmcgeyB1aWQgZGV2aWNlTmFtZSBpbnN0cnVtZW50TmFtZSBmdW5jdGlvbiB3aW5kb3dUeXBlIHdpbmRvd1NpemUgfSc7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWQgYWNjZXNzVG9rZW4gdXNlcm5hbWUgcGxhdGZvcm0gYWRkcmVzcyByb3V0ZXIgcm91dGVyUG9ydCBkZXBsb3lOZXR3b3JrIGRldmljZXNNZXRhZGF0YVxuICAgICAgICBwaXBlbGluZXM6IGdhdGV3YXlfcGlwZWxpbmUge1xuICAgICAgICAgIHVpZCBuYW1lIHV1aWQgcGlwZWxpbmVUeXBlIGRlcGxveWVyVHlwZSBwcm90b2NvbFR5cGUgcHJvdG9jb2xJZCBkYXRhU3RvcmVUeXBlXG4gICAgICAgICAgZGF0YVN0b3JlSWQgY3JlYXRlZCBtb2RpZmllZCBkZXNjcmlwdGlvbiBzdGF0dXMgZmxvd0NvbmZpZ3VyYXRpb25cbiAgICAgICAgICBsb2dMZXZlbCBzdWJzY3JpcHRpb25Ub3BpY1xuICAgICAgICAgICR7cGlwZWxpbmVfcHJvdG9jb2x9XG4gICAgICAgICAgJHtwaXBlbGluZV9kYXRhc3RvcmV9XG4gICAgICAgICAgJHtwaXBlbGluZV9maWx0ZXJ9XG4gICAgICAgICAgJHtwaXBlbGluZV9zdHJlYW1pbmd9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEdldCBHYXRld2F5IGFuZCBQaXBlbGluZXMgZm9yICR7Z2F0ZXdheU5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBHYXRld2F5IGFuZCBwaXBlbGluZXMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPEdhdGV3YXlbXT4oJ2dldEdhdGV3YXlXaXRoUGlwZWxpbmVzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRQaXBlbGluZXMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3Byb3RvY29sID0gYHByb3RvY29sOiBwaXBlbGluZV9wcm90b2NvbCB7XG4gICAgICAgICAgICAgIHVpZCBicm9rZXJVUkwgdG9waWMgbWF4aW11bVFPUyB1c2VybmFtZSBwYXNzd29yZCBlbmNyeXB0aW9uTW9kZSBjYUNlcnRpZmljYXRlXG4gICAgICAgICAgICAgIGNsaWVudENlcnRpZmljYXRlIGNsaWVudEtleSBhdXRoTW9kZSBzZXJ2ZXJDZXJ0aWZpY2F0ZSBjb25zdW1lckdyb3VwSWQgY29ubmVjdGlvblRpbWVvdXRcbiAgICAgICAgICAgICAgc2Vzc2lvblRpbWVvdXQgcmV0cnlCYWNrT2ZmIGNvbW1pdEludGVydmFsIGluaXRpYWxPZmZzZXQgZmV0Y2hNaW5CeXRlcyBmZXRjaE1heFdhaXQgaGVhcnRiZWF0SW50ZXJ2YWxcbiAgfSBgO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9kYXRhc3RvcmUgPSBgZGF0YXN0b3JlOiBwaXBlbGluZV9kYXRhc3RvcmUge1xuICAgICAgICAgICAgICB1aWQgaG9zdCBwb3J0IGRhdGFiYXNlTmFtZSB1c2VyIHBhc3N3b3JkIGFjY291bnROYW1lIHdhcmVob3VzZSBkYXRhYmFzZSBzY2hlbWEgYXV0aFR5cGVcbiAgICAgICAgICAgICAgdXNlcm5hbWUgY2xpZW50SWQgY2xpZW50U2VjcmV0IGF1dGhvcml6YXRpb25Db2RlIHJlZGlyZWN0VVJJIGxvZ2luVGltZW91dCB1cmxcbiAgICAgICAgICAgIH1gO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9maWx0ZXIgPSAnZmlsdGVyOiBwaXBlbGluZV9maWx0ZXIge3VpZCBkZXZpY2VOYW1lc30nO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9zdHJlYW1pbmcgPVxuICAgICAgICAgICAgJ3N0cmVhbWluZzogcGlwZWxpbmVfc3RyZWFtaW5nIHt1aWQgZGV2aWNlTmFtZSBpbnN0cnVtZW50TmFtZSBmdW5jdGlvbiB3aW5kb3dUeXBlIHdpbmRvd1NpemV9JztcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHBpcGVsaW5lcyBhcyBnYXRld2F5X3BpcGVsaW5lIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocGlwZWxpbmVzKSkge1xuICAgICAgICB1aWQgbmFtZSB1dWlkIHBpcGVsaW5lVHlwZSBkZXBsb3llclR5cGUgcHJvdG9jb2xUeXBlIHByb3RvY29sSWRcbiAgICAgICAgZGF0YVN0b3JlVHlwZSBkYXRhU3RvcmVJZCBjcmVhdGVkIG1vZGlmaWVkIGRlc2NyaXB0aW9uIHN0YXR1c1xuICAgICAgICBmbG93Q29uZmlndXJhdGlvbiBsb2dMZXZlbCBzdWJzY3JpcHRpb25Ub3BpY1xuICAgICAgICAke3BpcGVsaW5lX3Byb3RvY29sfVxuICAgICAgICAke3BpcGVsaW5lX2RhdGFzdG9yZX1cbiAgICAgICAgJHtwaXBlbGluZV9maWx0ZXJ9XG4gICAgICAgICR7cGlwZWxpbmVfc3RyZWFtaW5nfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFBpcGVsaW5lW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHBpcGVsaW5lcyBmb3IgJHtnYXRld2F5TmFtZX1gKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UGlwZWxpbmVbXT4oJ2dldFBpcGVsaW5lcycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkUGlwZWxpbmUoXG4gICAgICAgIGdhdGV3YXlVaWQ6IG51bWJlcixcbiAgICAgICAgcGlwZWxpbmU6IFBpcGVsaW5lLFxuICAgICAgICB0cmFuc3BvcnRPYmo/OiBhbnksXG4gICAgICAgIGRhdGFTdG9yZU9iaj86IGFueSxcbiAgICAgICAgZmlsdGVyT2JqPzogYW55LFxuICAgICAgICBzdHJlYW1pbmdPYmo/OiBhbnksXG4gICAgICAgIGFjY291bnQ/OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxQaXBlbGluZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcblxuICAgICAgICBsZXQgcXVlcnkgPSAnJztcblxuICAgICAgICBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICBfOlBpcGVsaW5lIDxkZ3JhcGgudHlwZT4gXCJQaXBlbGluZVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxuYW1lPiBcIiR7cGlwZWxpbmUubmFtZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHV1aWQ+IFwiJHtwaXBlbGluZS5uYW1lfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8dHlwZT4gXCJwaXBlbGluZVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8cGlwZWxpbmU+IFwiXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxwaXBlbGluZVR5cGU+IFwiJHtwaXBlbGluZS5waXBlbGluZVR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXBsb3llclR5cGU+IFwiJHtwaXBlbGluZS5kZXBsb3llclR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxjcmVhdGVkPiBcIiR7cGlwZWxpbmUuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXNjcmlwdGlvbj4gXCIke3BpcGVsaW5lLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8c3RhdHVzPiBcIiR7cGlwZWxpbmUuc3RhdHVzfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGxvZ0xldmVsPiBcIiR7cGlwZWxpbmUubG9nTGV2ZWx9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxzdWJzY3JpcHRpb25Ub3BpYz4gXCIke3BpcGVsaW5lLnN1YnNjcmlwdGlvblRvcGljfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X3BpcGVsaW5lPiBfOlBpcGVsaW5lIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYGFkZCBQaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwaXBlbGluZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGRlZCBwaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UGlwZWxpbmU+KCdhZGRQaXBlbGluZXMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlUGlwZWxpbmUocGlwZWxpbmU6IFBpcGVsaW5lLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPGRlc2NyaXB0aW9uPiBcIiR7cGlwZWxpbmUuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiA8c3RhdHVzPiBcIiR7cGlwZWxpbmUuc3RhdHVzfVwiIC5cbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgIDwke3BpcGVsaW5lLnVpZH0+IDxsb2dMZXZlbD4gXCIke3BpcGVsaW5lLmxvZ0xldmVsfVwiIC5cbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPHN1YnNjcmlwdGlvblRvcGljPiBcIiR7cGlwZWxpbmUuc3Vic2NyaXB0aW9uVG9waWN9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgdXBkYXRlIFBpcGVsaW5lICR7cGlwZWxpbmUudWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKCgpID0+IHBpcGVsaW5lKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBwaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UGlwZWxpbmU+KCd1cGRhdGVQaXBlbGluZScpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVQaXBlbGluZShnYXRld2F5VWlkOiBudW1iZXIsIHBpcGVsaW5lOiBQaXBlbGluZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIGRlbGV0ZSB7XG4gICAgICAgIDwke3BpcGVsaW5lLnVpZH0+IDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9waXBlbGluZT4gPCR7cGlwZWxpbmUudWlkfT4gLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgZGVsZXRlIFBpcGVsaW5lICR7cGlwZWxpbmUudWlkfSB3aXRoIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGBwaXBlbGluZSBkZWxldGVkYCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIHBpcGVsaW5lICR7cGlwZWxpbmUudWlkfSB3aXRoIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxzdHJpbmc+KCdkZWxldGVQaXBlbGluZScpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgaWRzIG9mIGFsbCB0aGUgcGlwZWxpbmVzIGFzc29jaWF0ZWQgd2l0aCB0aGUgc3BlY2lmaWVkIHByb3RvY29sXG4gICAgICogQHBhcmFtIHByb3RvY29sVWlkIC0gdGhlIHVpZCBvZiB0aGUgcHJvdG9jb2xcbiAgICAgKi9cbiAgICBnZXRQaXBlbGluZUlkc0Zyb21Qcm90b2NvbFVpZChwcm90b2NvbFVpZDogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IHVpZCgke3Byb3RvY29sVWlkfSkpIHtcbiAgICAgICAgcGlwZWxpbmVzIGFzIH5waXBlbGluZV9wcm90b2NvbCB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pXG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUGlwZWxpbmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcGlwZWxpbmUgaWRzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFBpcGVsaW5lW10+KCdnZXRQaXBlbGluZUlkc0Zyb21Qcm90b2NvbFVpZCcsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGlkcyBvZiBhbGwgdGhlIHBpcGVsaW5lcyBhc3NvY2lhdGVkIHdpdGggdGhlIHNwZWNpZmllZCBkYXRhIHN0b3JlXG4gICAgICogQHBhcmFtIGRhdGFTdG9yZVVpZCAtIHRoZSB1aWQgb2YgdGhlIGRhdGEgc3RvcmVcbiAgICAgKi9cbiAgICBnZXRQaXBlbGluZUlkc0Zyb21EYXRhU3RvcmVVaWQoZGF0YVN0b3JlVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFBpcGVsaW5lW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogdWlkKCR7ZGF0YVN0b3JlVWlkfSkpIHtcbiAgICAgICAgcGlwZWxpbmVzIGFzIH5waXBlbGluZV9kYXRhc3RvcmUge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KVxuICAgICAgcmVzcChmdW5jOiB1aWQocGlwZWxpbmVzKSkge1xuICAgICAgICB1aWQgdXVpZFxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFBpcGVsaW5lW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHBpcGVsaW5lIGlkcycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQaXBlbGluZVtdPignZ2V0UGlwZWxpbmVJZHNGcm9tRGF0YVN0b3JlVWlkJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRNb2RlbENvbmZpZ3MoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWxDb25maWdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIG1vZGVsQ29uZmlncyBhcyBnYXRld2F5X21vZGVsY29uZmlnIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQobW9kZWxDb25maWdzKSkge1xuICAgICAgICB1aWQgbmFtZSB1dWlkIGRlc2NyaXB0aW9uIGRldmljZSByZXNvdXJjZSBtb2RlbCBjcmVhdGVkICBtb2RpZmllZFxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRNb2RlbENvbmZpZ3MgZm9yICR7Z2F0ZXdheU5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgTW9kZWxDb25maWdbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgbW9kZWxDb25maWdzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbENvbmZpZ1tdPignZ2V0TW9kZWxDb25maWdzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRNb2RlbENvbmZpZyhnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsQ29uZmlnOiBNb2RlbENvbmZpZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWxDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86TW9kZWxDb25maWcgPGRncmFwaC50eXBlPiBcIk1vZGVsQ29uZmlnXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPG5hbWU+IFwiJHttb2RlbENvbmZpZy5uYW1lfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8dXVpZD4gXCIke21vZGVsQ29uZmlnLm5hbWV9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDx0eXBlPiBcIm1vZGVsQ29uZmlnXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxtb2RlbENvbmZpZz4gXCJcIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWxDb25maWcuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxkZXZpY2U+IFwiJHttb2RlbENvbmZpZy5kZXZpY2V9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxyZXNvdXJjZT4gXCIke21vZGVsQ29uZmlnLnJlc291cmNlfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8bW9kZWw+IFwiJHttb2RlbENvbmZpZy5tb2RlbH1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPGNyZWF0ZWQ+IFwiJHttb2RlbENvbmZpZy5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8bW9kaWZpZWQ+IFwiJHttb2RlbENvbmZpZy5tb2RpZmllZH1cIiAuXG4gICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9tb2RlbGNvbmZpZz4gXzpNb2RlbENvbmZpZyAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgbW9kZWxDb25maWcgZm9yIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IG1vZGVsQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBtb2RlbENvbmZpZyBmb3IgZ2F0ZXdheSAke2dhdGV3YXlVaWR9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE1vZGVsQ29uZmlnPignYWRkTW9kZWxDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlTW9kZWxDb25maWcobW9kZWxDb25maWc6IE1vZGVsQ29uZmlnLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbENvbmZpZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7bW9kZWxDb25maWcudWlkfT4gPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgPCR7bW9kZWxDb25maWcudWlkfT4gPG5hbWU+IFwiJHttb2RlbENvbmZpZy5uYW1lfVwiIC5cbiAgICAgICAgPCR7bW9kZWxDb25maWcudWlkfT4gPHV1aWQ+IFwiJHttb2RlbENvbmZpZy51dWlkfVwiIC5cbiAgICAgICAgPCR7bW9kZWxDb25maWcudWlkfT4gPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWxDb25maWcuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICA8JHttb2RlbENvbmZpZy51aWR9PiA8Y29uZERldmljZT4gXCIke21vZGVsQ29uZmlnLmRldmljZX1cIiAuXG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDxjb25kUmVzb3VyY2U+IFwiJHttb2RlbENvbmZpZy5yZXNvdXJjZX1cIiAuXG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDxtb2RlbD4gXCIke21vZGVsQ29uZmlnLm1vZGVsfVwiIC5cbiAgICAgICAgPCR7bW9kZWxDb25maWcudWlkfT4gPG1vZGlmaWVkPiBcIiR7bW9kZWxDb25maWcubW9kaWZpZWR9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlIG1vZGVsQ29uZmlnICR7bW9kZWxDb25maWcudWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKCgpID0+IG1vZGVsQ29uZmlnKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBtb2RlbENvbmZpZyAke21vZGVsQ29uZmlnLnVpZH1gKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8TW9kZWxDb25maWc+KCd1cGRhdGVNb2RlbENvbmZpZycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVNb2RlbENvbmZpZyhnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsQ29uZmlnVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgZGVsZXRlIHtcbiAgICAgICAgPCR7bW9kZWxDb25maWdVaWR9PiA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfbW9kZWxjb25maWc+IDwke21vZGVsQ29uZmlnVWlkfT4gLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIE1vZGVsQ29uZmlnICR7bW9kZWxDb25maWdVaWR9IGZvciBnYXRld2F5ICR7Z2F0ZXdheVVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBgJHttb2RlbENvbmZpZ1VpZH0gZGVsZXRlZGApKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZGVsZXRlZCBtb2RlbENvbmZpZyAke21vZGVsQ29uZmlnVWlkfSBmb3IgZ2F0ZXdheSAke2dhdGV3YXlVaWR9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPHN0cmluZz4oJ2RlbGV0ZU1vZGVsQ29uZmlnJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEZpbHRlcnNDb25maWcoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheUZpbHRlcnNDb25maWdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIGZpbHRlcnNDb25maWcgYXMgZ2F0ZXdheV9maWx0ZXIge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChmaWx0ZXJzQ29uZmlnKSkge1xuICAgICAgICB1aWRcbiAgICAgICAgZGV2aWNlTmFtZXNcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgZ2V0RmlsdGVyc0NvbmZpZyBmb3IgJHtnYXRld2F5TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5RmlsdGVyc0NvbmZpZ1tdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBmaWx0ZXJzQ29uZmlnIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5RmlsdGVyc0NvbmZpZ1tdPignZ2V0RmlsdGVyc0NvbmZpZ3MnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZEZpbHRlcnNDb25maWcoXG4gICAgICAgIGdhdGV3YXlVaWQ6IG51bWJlcixcbiAgICAgICAgZmlsdGVyc0NvbmZpZzogR2F0ZXdheUZpbHRlcnNDb25maWcsXG4gICAgICAgIGFjY291bnQ/OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxHYXRld2F5RmlsdGVyc0NvbmZpZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICBfOkZpbHRlciA8ZGdyYXBoLnR5cGU+IFwiZmlsdGVyXCIgLlxuICAgICAgICBfOkZpbHRlciA8dHlwZT4gXCJmaWx0ZXJcIiAuXG4gICAgICAgIF86RmlsdGVyIDxmaWx0ZXI+IFwiXCIgLlxuICAgICAgICBfOkZpbHRlciA8ZGV2aWNlTmFtZXM+IFwiJHtmaWx0ZXJzQ29uZmlnLmRldmljZU5hbWVzfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X2ZpbHRlcj4gXzpGaWx0ZXIgLlxuICAgICAgICA8JHthY2NvdW50fT4gPGFjY291bnQ+IF86RmlsdGVyIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYGFkZCBGaWx0ZXJzQ29uZmlnIGZvciBnYXRld2F5ICR7Z2F0ZXdheVVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBmaWx0ZXJzQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZGVkIGZpbHRlcnNDb25maWcgZm9yIGdhdGV3YXkgJHtnYXRld2F5VWlkfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5RmlsdGVyc0NvbmZpZz4oJ2FkZEZpbHRlcnNDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlRmlsdGVyc0NvbmZpZyhmaWx0ZXJzQ29uZmlnOiBHYXRld2F5RmlsdGVyc0NvbmZpZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheUZpbHRlcnNDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIDwke2ZpbHRlcnNDb25maWcudWlkfT4gPGRldmljZU5hbWVzPiBcIiR7ZmlsdGVyc0NvbmZpZy5kZXZpY2VOYW1lc31cIiAuXG4gICAgICAgIDwke2FjY291bnR9PiA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgdXBkYXRlIEZpbHRlcnNDb25maWcgJHtmaWx0ZXJzQ29uZmlnLnVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBmaWx0ZXJzQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZmlsdGVyc0NvbmZpZyAke2ZpbHRlcnNDb25maWcudWlkfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5RmlsdGVyc0NvbmZpZz4oJ3VwZGF0ZUZpbHRlcnNDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3MoZGV2aWNlTmFtZTogc3RyaW5nLCBpbnN0cnVtZW50TmFtZTogc3RyaW5nLCBudW1SZWFkaW5nczogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LSR7bnVtUmVhZGluZ3N9KSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldFJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFRTUmVhZGluZ1tdKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IGNvbnNvbGUubG9nKCdSZXNwb25zZSBmcm9tIGdldFJlYWRpbmdzOiAnLCByZXNwb25zZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxUU1JlYWRpbmdbXT4oJ2dldFJlYWRpbmdzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc0F0KGRldmljZU5hbWU6IHN0cmluZywgaW5zdHJ1bWVudE5hbWU6IHN0cmluZywgdHM6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8VFNSZWFkaW5nW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKHJlc291cmNlKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7XG4gICAgICAgIHJlYWRpbmdzIGFzIHJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihlcShjcmVhdGVkLCAke3RzfSkpIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocmVhZGluZ3MpLCBvcmRlcmFzYzpjcmVhdGVkKSB7XG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgdmFsdWVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgZ2V0UmVhZGluZ3NBdCBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBUU1JlYWRpbmdbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcmVhZGluZ3MgZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFRTUmVhZGluZ1tdPignZ2V0UmVhZGluZ3NBdCcsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3NTdGFydGluZ0F0KFxuICAgICAgICBkZXZpY2VOYW1lOiBzdHJpbmcsXG4gICAgICAgIGluc3RydW1lbnROYW1lOiBzdHJpbmcsXG4gICAgICAgIGZyb210czogbnVtYmVyLFxuICAgICAgICBhY2NvdW50Pzogc3RyaW5nLFxuICAgICk6IE9ic2VydmFibGU8VFNSZWFkaW5nW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKHJlc291cmNlKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7XG4gICAgICAgIHJlYWRpbmdzIGFzIHJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihndChjcmVhdGVkLCAke2Zyb210c30pKSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldFJlYWRpbmdzU3RhcnRpbmdBdCBmb3IgZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgVFNSZWFkaW5nW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIHN0YXJ0ZWQgYXQgcmVhZGluZ3MgZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFRTUmVhZGluZ1tdPignZ2V0UmVhZGluZ3NTdGFydGluZ0F0JywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc0JldHdlZW4oXG4gICAgICAgIGRldmljZU5hbWU6IHN0cmluZyxcbiAgICAgICAgaW5zdHJ1bWVudE5hbWU6IHN0cmluZyxcbiAgICAgICAgZnJvbXRzOiBudW1iZXIsXG4gICAgICAgIHRvdHM6IG51bWJlcixcbiAgICAgICAgYWNjb3VudD86IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPFRTUmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhyZXNvdXJjZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSBBTkQgbHQoY3JlYXRlZCwgJHt0b3RzfSkpIChmaXJzdDotNTAwKSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldFJlYWRpbmdzQmV0d2VlbiBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBUU1JlYWRpbmdbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcmVhZGluZ3MgYmV0d2VlbiBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8VFNSZWFkaW5nW10+KCdnZXRSZWFkaW5nc0JldHdlZW4nLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldExhc3RSZWFkaW5nc0ZvckRldmljZShkZXZpY2VOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRTUmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZGV2aWNlKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2RldmljZU5hbWV9XCIpKSBAbm9ybWFsaXplIHtcbiAgICAgICAgZGV2aWNlX3Jlc291cmNlIHtcbiAgICAgICAgICBuYW1lOiBuYW1lXG4gICAgICAgICAgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LTEpIHtcbiAgICAgICAgICAgIGNyZWF0ZWQ6IGNyZWF0ZWRcbiAgICAgICAgICAgIHZhbHVlOiB2YWx1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRMYXN0UmVhZGluZ3NGb3JEZXZpY2UgZm9yICR7ZGV2aWNlTmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBUU1JlYWRpbmdbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgbGFzdCByZWFkaW5ncyBmb3IgJHtkZXZpY2VOYW1lfWApKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxUU1JlYWRpbmdbXT4oJ2dldExhc3RSZWFkaW5nc0ZvckRldmljZScsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0Tm90aWZpY2F0aW9ucyhhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxOb3RpZmljYXRpb25bXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zb2xlLmxvZygnR2V0Tm90aWZpY2F0aW9ucyBzZXJ2aWNlIGNhbGxlZCcpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhub3RpZmljYXRpb24pKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSBAbm9ybWFsaXplIHtcbiAgICAgICAgdWlkIHV1aWQ6dXVpZCBjcmVhdGVkOmNyZWF0ZWQgbm90aWZ5U291cmNlOm5vdGlmeVNvdXJjZSBub3RpZnlEZXZpY2U6bm90aWZ5RGV2aWNlXG4gICAgICAgIG5vdGlmeVJlc291cmNlOm5vdGlmeVJlc291cmNlIG5vdGlmeUxldmVsOm5vdGlmeUxldmVsIHZhbHVlOnZhbHVlIGRlc2NyaXB0aW9uOmRlc2NyaXB0aW9uXG4gICAgICAgIH5nYXRld2F5X25vdGlmaWNhdGlvbiB7XG4gICAgICAgICAgZ2F0ZXdheTogdXVpZFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgTm90aWZpY2F0aW9uW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBmZXRjaGVkIG5vdGlmaWNhdGlvbnNgKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8Tm90aWZpY2F0aW9uW10+KCdnZXROb3RpZmljYXRpb25zJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSb3V0ZShkZXZpY2VOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBudW1iZXJbXVtdIHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgbGV0IHJvdXRlID0gbnVsbDtcblxuICAgICAgICBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMScpIHtcbiAgICAgICAgICAgIHJvdXRlID0gcm91dGUxO1xuICAgICAgICB9IGVsc2UgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDInKSB7XG4gICAgICAgICAgICByb3V0ZSA9IHJvdXRlMjtcbiAgICAgICAgfSBlbHNlIGlmIChkZXZpY2VOYW1lID09ICd0cmFpbi0wMDAzJykge1xuICAgICAgICAgICAgcm91dGUgPSByb3V0ZTM7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByb3V0ZSA9IGVtcHR5cm91dGU7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcm91dGU7XG4gICAgfVxuXG4gICAgZ2V0Um91dGVDZW50ZXIoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogbnVtYmVyW10ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBsZXQgY2VudGVyID0gbnVsbDtcblxuICAgICAgICAvLyAzOS4wIC05OC4wIHpvb20gNFxuICAgICAgICAvLyBFYXN0IDM0Ljc2NTU4OSAgIC03OC43MDk0ODhcbiAgICAgICAgLy8gV2VzdCA0MC40ODc0MzIgLTEyMi44MDMxMTZcblxuICAgICAgICBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMScpIHtcbiAgICAgICAgICAgIGNlbnRlciA9IFszNC4wLCAtOTguMF07XG4gICAgICAgIH0gZWxzZSBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMicpIHtcbiAgICAgICAgICAgIGNlbnRlciA9IFs0MC4wLCAtOTguMF07XG4gICAgICAgIH0gZWxzZSBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMycpIHtcbiAgICAgICAgICAgIGNlbnRlciA9IFszOS4wLCAtOTguMF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbNDIuOCwgMTIuOF07XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gY2VudGVyO1xuICAgIH1cblxuICAgIHByaXZhdGUgZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudD86IHN0cmluZykge1xuICAgICAgICBpZiAodGhpcy5yZXF1aXJlQWNjb3VudElkKSB7XG4gICAgICAgICAgICBpZiAoIWFjY291bnQpIHRocm93IG5ldyBFcnJvcignQWNjb3VudCBtdXN0IGV4aXN0Jyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIGdldEFjY291bnRRdWVyeShhY2NvdW50Pzogc3RyaW5nKSB7XG4gICAgICAgIGlmICh0aGlzLnJlcXVpcmVBY2NvdW50SWQpIHtcbiAgICAgICAgICAgIHJldHVybiBgZXEoYWNjb3VudCwgXCIke2FjY291bnR9XCIpYDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBgKGVxKGFjY291bnQsIFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiKSBPUiBub3QoaGFzKGFjY291bnQpKSlgO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEhhbmRsZSBIVFRQIG9wZXJhdGlvbiB0aGF0IGZhaWxlZC5cbiAgICAgKiBMZXQgdGhlIGFwcCBjb250aW51ZS5cbiAgICAgKiBAcGFyYW0gb3BlcmF0aW9uIC0gLSBuYW1lIG9mIHRoZSBvcGVyYXRpb24gdGhhdCBmYWlsZWRcbiAgICAgKiBAcGFyYW0gcmVzdWx0IC0gb3B0aW9uYWwgdmFsdWUgdG8gcmV0dXJuIGFzIHRoZSBvYnNlcnZhYmxlIHJlc3VsdFxuICAgICAqL1xuICAgIHByaXZhdGUgaGFuZGxlRXJyb3I8VD4ob3BlcmF0aW9uID0gJ29wZXJhdGlvbicsIHJlc3VsdD86IFQpIHtcbiAgICAgICAgcmV0dXJuIChlcnJvcjogYW55KTogT2JzZXJ2YWJsZTxUPiA9PiB7XG4gICAgICAgICAgICAvLyBUT0RPOiBiZXR0ZXIgam9iIG9mIHRyYW5zZm9ybWluZyBlcnJvciBmb3IgdXNlciBjb25zdW1wdGlvblxuICAgICAgICAgICAgY29uc29sZS5sb2coYCR7b3BlcmF0aW9ufSBmYWlsZWQ6ICR7ZXJyb3IuY29kZX06ICR7ZXJyb3IubWVzc2FnZX1gKTtcblxuICAgICAgICAgICAgLy8gTGV0IHRoZSBhcHAga2VlcCBydW5uaW5nIGJ5IHJldHVybmluZyBhbiBlbXB0eSByZXN1bHQuXG4gICAgICAgICAgICByZXR1cm4gb2YocmVzdWx0IGFzIFQpO1xuICAgICAgICB9O1xuICAgIH1cblxuICAvKipcbiAgICogR2V0IFB5dGhvbiBSZXNvdXJjZXMuXG4gICAqIEBwYXJhbSBnYXRld2F5VWlkXG4gICAqL1xuICAgZ2V0UmVzb3VyY2VzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFB5dGhvblJlc291cmNlW10+IHtcbiAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgY29uc3QgcXVlcnkgPSBgXG4gICAge1xuICAgICAgcmVzcChmdW5jOiB0eXBlKFB5dGhvblJlc291cmNlKSkgQGZpbHRlcihlcShzY29wZSwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICB1aWRcbiAgICAgICAgdXVpZFxuICAgICAgICBjcmVhdGVkXG4gICAgICAgIG1vZGlmaWVkXG4gICAgICAgIG5hbWVcbiAgICAgICAgdHlwZVxuICAgICAgICBzY29wZVxuICAgICAgICBmaWxlQ29udGVudFxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpXG4gICAgICAucGlwZShcbiAgICAgICAgbWFwKHJlc3BvbnNlID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBQeXRob25SZXNvdXJjZVtdKSxcbiAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFB5dGhvblJlc291cmNlW10+KCdnZXRSZXNvdXJjZXMnLCBbXSkpXG4gICAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZCBQeXRob24gUmVzb3VyY2UuXG4gICAqIEBwYXJhbSBQeXRob25SZXNvdXJjZVxuICAgKi9cbiAgYWRkUmVzb3VyY2UocmVzb3VyY2U6IFB5dGhvblJlc291cmNlLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgIGNvbnN0IHF1ZXJ5ID0gYCB7XG4gICAgICBzZXQge1xuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxkZ3JhcGgudHlwZT4gXCJQeXRob25SZXNvdXJjZVwiLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDx1dWlkPiBcIiR7cmVzb3VyY2UudXVpZH1cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPG5hbWU+IFwiJHtyZXNvdXJjZS5uYW1lfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8Y3JlYXRlZD4gXCIke3Jlc291cmNlLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxtb2RpZmllZD4gXCIke3Jlc291cmNlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8dHlwZT4gXCIke3Jlc291cmNlLnR5cGV9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxmaWxlQ29udGVudD4gXCIke3Jlc291cmNlLmZpbGVDb250ZW50fVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8c2NvcGU+IFwiJHtyZXNvdXJjZS5zY29wZX1cIiAuXG4gICAgICB9fWA7XG5cbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucylcbiAgICAgIC5waXBlKFxuICAgICAgICBtYXAocmVzcG9uc2UgPT4gcmVzcG9uc2UuZGF0YS5yZXNwKSxcbiAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPHN0cmluZz4oJ2FkZFJlc291cmNlJykpXG4gICAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSBQeXRob24gUmVzb3VyY2UuXG4gICAqIEBwYXJhbSBQeXRob25SZXNvdXJjZVxuICAgKi9cbiAgdXBkYXRlUmVzb3VyY2UocmVzb3VyY2U6IFB5dGhvblJlc291cmNlLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIDwke3Jlc291cmNlLnVpZH0+IDx1dWlkPiBcIiR7cmVzb3VyY2UudXVpZH1cIiAuXG4gICAgICAgIDwke3Jlc291cmNlLnVpZH0+IDxtb2RpZmllZD4gXCIke3Jlc291cmNlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgPCR7cmVzb3VyY2UudWlkfT4gPG5hbWU+IFwiJHtyZXNvdXJjZS5uYW1lfVwiIC5cbiAgICAgICAgPCR7cmVzb3VyY2UudWlkfT4gPHNjb3BlPiBcIiR7cmVzb3VyY2Uuc2NvcGV9XCIgLlxuICAgICAgICA8JHtyZXNvdXJjZS51aWR9PiA8dHlwZT4gXCIke3Jlc291cmNlLnR5cGV9XCIgLlxuICAgICAgICA8JHtyZXNvdXJjZS51aWR9PiA8ZmlsZUNvbnRlbnQ+IFwiJHtyZXNvdXJjZS5maWxlQ29udGVudH1cIiAuXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucylcbiAgICAgIC5waXBlKFxuICAgICAgICBtYXAocmVzcG9uc2UgPT4gcmVzcG9uc2UuZGF0YS5yZXNwKSxcbiAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPHN0cmluZz4oJ3VwZGF0ZVJlc291cmNlJykpXG4gICAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZSBQeXRob24gUmVzb3VyY2UuXG4gICAqIEBwYXJhbSBnYXRld2F5VWlkXG4gICAqIEBwYXJhbSBQeXRob25SZXNvdXJjZVxuICAgKi9cbiAgZGVsZXRlUmVzb3VyY2UoZ2F0ZXdheVVpZDogc3RyaW5nLCByZXNvdXJjZVVpZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIGRlbGV0ZSB7XG4gICAgICAgIDwke3Jlc291cmNlVWlkfT4gKiAqIC5cbiAgICAgIH1cbiAgICB9YDtcblxuICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKVxuICAgICAgLnBpcGUoXG4gICAgICAgIG1hcChyZXNwb25zZSA9PiByZXNwb25zZS5kYXRhLnJlc3ApLFxuICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlUmVzb3VyY2UnKSlcbiAgICAgICk7XG4gIH1cbn1cbiJdfQ==