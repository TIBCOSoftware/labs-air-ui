import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PythonResource } from '../model/pythonResource';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class PythonService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Delete a resource from a Gateway
     * Delete a resource from an existing Gateway
     * @param resourceUid resourceUid to delete
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deletePythonResource(resourceUid: number, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deletePythonResource(resourceUid: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deletePythonResource(resourceUid: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the all python resources for a Gateway
     * Get all of the known python resources for a Gateway
     * @param gatewayName The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPythonResources(gatewayName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<PythonResource>>;
    getPythonResources(gatewayName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<PythonResource>>>;
    getPythonResources(gatewayName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<PythonResource>>>;
    /**
     * Update a python resource
     * Update a python resource
     * @param body The python resource to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updatePythonResource(body: PythonResource, observe?: 'body', reportProgress?: boolean): Observable<PythonResource>;
    updatePythonResource(body: PythonResource, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PythonResource>>;
    updatePythonResource(body: PythonResource, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PythonResource>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PythonService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PythonService>;
}
