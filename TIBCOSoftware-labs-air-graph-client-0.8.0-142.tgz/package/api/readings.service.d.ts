import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Reading } from '../model/reading';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ReadingsService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a reading
     * Add a Reading to an existing Gateway if it exists
     * @param body The readings to add
     * @param gatewayUuid The UUID of the Gateway
     * @param deviceName The Name of the Device
     * @param resourceName The Name of the Resource
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addReading(body: Array<Reading>, gatewayUuid: string, deviceName: string, resourceName: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Reading>>;
    addReading(body: Array<Reading>, gatewayUuid: string, deviceName: string, resourceName: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Reading>>>;
    addReading(body: Array<Reading>, gatewayUuid: string, deviceName: string, resourceName: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Reading>>>;
    /**
     * Get the TSReadings
     * Get the TSReadings for the Device and Instrument
     * @param gatewayUuid The UUID of the gateway
     * @param deviceName The name of the Device
     * @param instrumentName The name of the Instrument
     * @param numReadings The number of readings
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getReadings(gatewayUuid: string, deviceName: string, instrumentName: string, numReadings: number, observe?: 'body', reportProgress?: boolean): Observable<Array<Reading>>;
    getReadings(gatewayUuid: string, deviceName: string, instrumentName: string, numReadings: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Reading>>>;
    getReadings(gatewayUuid: string, deviceName: string, instrumentName: string, numReadings: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Reading>>>;
    /**
     * Get the TSReadings between timestamps
     * Get the TSReadings starting at timestamp and ending at another timestamp for the Device and Instrument
     * @param gatewayUuid The UUID of the gateway
     * @param deviceName The name of the Device
     * @param instrumentName The name of the Instrument
     * @param from The timestamp to get readings from
     * @param to The timestamp to get readings to
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getReadingsBetween(gatewayUuid: string, deviceName: string, instrumentName: string, from: number, to: number, observe?: 'body', reportProgress?: boolean): Observable<Array<Reading>>;
    getReadingsBetween(gatewayUuid: string, deviceName: string, instrumentName: string, from: number, to: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Reading>>>;
    getReadingsBetween(gatewayUuid: string, deviceName: string, instrumentName: string, from: number, to: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Reading>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadingsService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReadingsService>;
}
