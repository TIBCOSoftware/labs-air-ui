import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Gateway } from '../model/gateway';
import { RestEndpoint } from '../model/restEndpoint';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class RestEndpointsService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Add a Rest Endpoint
     * Add the Rest Endpoint to a Gateway
     * @param body
     * @param gatewayUuid The UUID of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    addRestEndpoint(body: RestEndpoint, gatewayUuid: string, observe?: 'body', reportProgress?: boolean): Observable<RestEndpoint>;
    addRestEndpoint(body: RestEndpoint, gatewayUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<RestEndpoint>>;
    addRestEndpoint(body: RestEndpoint, gatewayUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<RestEndpoint>>;
    /**
     * Delete a Rest Endpoint from a Gateway
     * Delete a Rest Endpoint from an existing Gateway
     * @param gatewayUuid gatewayUuid to reference
     * @param restEndpointUuid restEndpointUuid to delete
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteRestEndpoint(gatewayUuid: string, restEndpointUuid: string, observe?: 'body', reportProgress?: boolean): Observable<string>;
    deleteRestEndpoint(gatewayUuid: string, restEndpointUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    deleteRestEndpoint(gatewayUuid: string, restEndpointUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     * Get the Gateway and its Rest Endpoints
     * Get the Gateway and the associated Rest Endpoints
     * @param gatewayUuid The UUID of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGatewayAndRestEndpoints(gatewayUuid: string, observe?: 'body', reportProgress?: boolean): Observable<Array<Gateway>>;
    getGatewayAndRestEndpoints(gatewayUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Gateway>>>;
    getGatewayAndRestEndpoints(gatewayUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Gateway>>>;
    /**
     * Get the Rest Endpoints for a Gateway
     * Get the Gateway and the associated Rest Endpoints
     * @param gatewayUuid The name of the Gateway
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getRestEndpoints(gatewayUuid: string, observe?: 'body', reportProgress?: boolean): Observable<Array<RestEndpoint>>;
    getRestEndpoints(gatewayUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<RestEndpoint>>>;
    getRestEndpoints(gatewayUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<RestEndpoint>>>;
    /**
     * Update a Rest Endpoint
     * Update a Rest Endpoint
     * @param body The Rest Endpoint to update
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateRestEndpoint(body: RestEndpoint, observe?: 'body', reportProgress?: boolean): Observable<RestEndpoint>;
    updateRestEndpoint(body: RestEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<RestEndpoint>>;
    updateRestEndpoint(body: RestEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<RestEndpoint>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RestEndpointsService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RestEndpointsService>;
}
