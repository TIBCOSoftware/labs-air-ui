import { DataStore, Gateway, RestEndpoint, Notification, Pipeline, Protocol, PythonResource, Reading } from '../model/models';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
export declare abstract class GraphService {
    protected http: HttpClient;
    protected requireAccountId: boolean;
    protected dGraphUrl: string;
    constructor(http: HttpClient, dGraphUrl: string, accountRequired: boolean);
    getGateway(gatewayUuid: string, account?: string): Observable<Gateway[]>;
    getGateways(account?: string): Observable<Gateway[]>;
    updateGateway(gateway: Gateway, account?: string): Observable<string>;
    addGateway(gateway: Gateway, account?: string): Observable<Gateway>;
    deleteGateway(gatewayUuid: string, account?: string): Observable<string>;
    getGatewayAndProtocols(gatewayUuid: string, account?: string): Observable<Gateway[]>;
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayUuid
     * @param account
     */
    getProtocols(gatewayUuid: string, account?: string): Observable<Protocol[]>;
    addProtocol(gatewayUid: string, protocol: Protocol, account?: string): Observable<Protocol>;
    updateProtocol(protocol: Protocol, account?: string): Observable<Protocol>;
    deleteProtocol(gatewayUid: string, protocolUid: string, account?: string): Observable<string>;
    getDataStores(gatewayUuid: string, account?: string): Observable<DataStore[]>;
    addDataStore(gatewayUid: string, dataStore: DataStore, account?: string): Observable<DataStore>;
    updateDataStore(dataStore: DataStore, account?: string): Observable<DataStore>;
    deleteDataStore(gatewayUuid: string, dataStoreUuid: string, account?: string): Observable<string>;
    getGatewayAndRestEndpoints(gatewayName: string, account?: string): Observable<Gateway[]>;
    getRestEndpoints(gatewayName: string, account?: string): Observable<RestEndpoint[]>;
    addRestEndpoint(gatewayUid: string, model: RestEndpoint, account?: string): Observable<RestEndpoint>;
    updateRestEndpoint(model: RestEndpoint, account?: string): Observable<RestEndpoint>;
    deleteRestEndpoint(gatewayUid: string, modelUid: string, account?: string): Observable<string>;
    getGatewayAndPipelines(gatewayName: string, account?: string): Observable<Gateway[]>;
    getPipelines(gatewayName: string, account?: string): Observable<Pipeline[]>;
    addPipeline(gatewayUid: string, pipeline: Pipeline, transportObj?: any, dataStoreObj?: any, filterObj?: any, streamingObj?: any, account?: string): Observable<Pipeline>;
    updatePipeline(pipeline: Pipeline, account?: string): Observable<Pipeline>;
    deletePipeline(gatewayUid: string, pipelineId: string, account?: string): Observable<string>;
    /**
     * Get Python Resources.
     * @param gatewayUid
     */
    getPythonResources(gatewayName: string, account?: string): Observable<PythonResource[]>;
    /**
     * Update Python Resource.
     * @param PythonResource
     */
    updatePythonResource(pythonResource: PythonResource, account?: string): Observable<PythonResource>;
    /**
     * Add Python Resource.
     * @param PythonResource
     */
    addPythonResource(gatewayUuid: string, pythonResource: PythonResource, account?: string): Observable<PythonResource>;
    /**
     * Delete Python Resource.
     * @param resourceUid
     */
    deletePythonResource(pythonResourceUid: string, account?: string): Observable<string>;
    getReadings(gatewayUuid: string, deviceName: string, instrumentName: string, numReadings: number, account?: string): Observable<Reading[]>;
    getReadingsAt(deviceName: string, instrumentName: string, ts: number, account?: string): Observable<Reading[]>;
    getReadingsStartingAt(deviceName: string, instrumentName: string, fromts: number, account?: string): Observable<Reading[]>;
    getReadingsBetween(gatewayUuid: string, deviceName: string, instrumentName: string, fromts: number, tots: number, account?: string): Observable<Reading[]>;
    getLastReadingsForDevice(deviceName: string, account?: string): Observable<Reading[]>;
    addReading(gatewayUuid: string, deviceName: string, instrumentName: string, reading: Reading[], accountId: string): Promise<Reading[]>;
    getNotifications(account?: string): Observable<Notification[]>;
    addNotification(gatewayUuid: string, notification: Notification, accountId: string): Observable<Notification>;
    deleteNotification(gatewayUuid: string, notificationUuid: string, accountId: string): Observable<string>;
    ensureAccountAuthorized(account?: string): void;
    getAccountQuery(account?: string): string;
    /**
     * Discovers the presence of errors in the response from dGraph and reports them.
     *
     * @param response the response object from dGraph
     * @param operation the operation that was being performed for logging purposes
     */
    checkForErrors(response: any, operation?: string): void;
    /**
     * If the operation was successful, obtain a UID from the response.
     *
     * @param dGraphResponse A response from dGraph
     * @param objectKey the name of the Object, for example Gateway or Model
     * @returns a UID found from the response
     */
    getIDFromResponse(dGraphResponse: GraphResponse, objectKey: string): string | undefined;
    getPreQuery(objectName: string, uid: string | number | undefined, account?: string): string;
    confirmObjectExists(response: any, operation: string, objectName: string, uid: number | string | undefined): void;
}
export interface GraphResponse {
    code: string;
    message: string;
    queries: any;
    uids: {
        [index: string]: string;
    };
}
