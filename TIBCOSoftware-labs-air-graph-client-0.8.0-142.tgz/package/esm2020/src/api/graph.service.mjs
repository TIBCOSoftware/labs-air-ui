import { map, switchMap, tap } from 'rxjs';
const httpOptions = {
    headers: {
        'Content-Type': 'application/graphql+-',
    },
};
const httpMutateOptions = {
    headers: { 'Content-Type': 'application/rdf' },
};
export class GraphService {
    constructor(http, dGraphUrl, accountRequired) {
        this.http = http;
        this.requireAccountId = true;
        this.dGraphUrl = dGraphUrl;
        this.requireAccountId = accountRequired;
        //const dGraphBasicAuthEnabled = this.appConfigService.dGraphBasicAuthEnabled;
        //if (dGraphBasicAuthEnabled) {
        //    const dGraphBasicAuth = this.appConfigService.dGraphBasicAuth;
        //    (this.httpOptions.headers = { 'Content-Type': 'application/graphql+-' }), { Authorization: dGraphBasicAuth };
        //    (this.httpMutateOptions.headers = { 'Content-Type': 'application/rdf' }), { Authorization: dGraphBasicAuth };
        //}
    }
    getGateway(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        console.log(`GetGateway service called for ${gatewayUuid}`);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayUuid}")) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGateway');
        }), map((response) => response.data.resp));
    }
    getGateways(account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query?debug=true`;
        const query = `{
      resp(func: has(gateway))
      @filter(${this.getAccountQuery(account)}) {
        uid uuid description address router routerPort
        deployNetwork latitude longitude accessToken username
        platform devicesMetadata createdts updatedts
        numDevices: count(gateway_device)
        }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGateways');
        }), map((response) => response.data.resp), tap((response) => console.log(`fetched ${response.length} gateways`)));
    }
    updateGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('gateway', gateway.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
              var(func: uid(${gateway.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <account> "${account ? account : ''}" .
                uid(v) <address> "${gateway.address}" .
                uid(v) <router> "${gateway.router}" .
                uid(v) <routerPort> "${gateway.routerPort}" .
                uid(v) <deployNetwork> "${gateway.deployNetwork}" .
                uid(v) <description> "${gateway.description}" .
                uid(v) <latitude> "${gateway.latitude}" .
                uid(v) <longitude> "${gateway.longitude}" .
                uid(v) <accessToken> "${gateway.accessToken}" .
                uid(v) <username> "${gateway.username}" .
                uid(v) <platform> "${gateway.platform}" .
                uid(v) <updatedts> "${gateway.updatedts}" .
              }
            }
          }`;
        console.log(`Update Gateway ${gateway.uuid} ${gateway.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateGateway', 'gateway', gateway.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateGateway')), tap(() => console.log(`updated gateway ${gateway.uuid}`)), map(() => 'gateway updated'));
    }
    addGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        if (gateway.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Gateway <dgraph.type> "Gateway" .
        _:Gateway <gateway> "" .
        _:Gateway <type> "gateway" .
        _:Gateway <account> "${account ? account : ''}" .
        _:Gateway <uuid> "${gateway.uuid}" .
        _:Gateway <description> "${gateway.description}" .
        _:Gateway <address> "${gateway.address}" .
        _:Gateway <router> "${gateway.router}" .
        _:Gateway <routerPort> "${gateway.routerPort}" .
        _:Gateway <deployNetwork> "${gateway.deployNetwork}" .
        _:Gateway <latitude> "${gateway.latitude}" .
        _:Gateway <longitude> "${gateway.longitude}" .
        _:Gateway <accessToken> "${gateway.accessToken}" .
        _:Gateway <username> "${gateway.username}" .
        _:Gateway <platform> "${gateway.platform}" .
        _:Gateway <createdts> "${gateway.createdts}" .
        _:Gateway <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log(`Add Gateway ${gateway.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addGateway');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Gateway');
            if (id) {
                gateway.uid = id;
            }
        }), map((response) => (response.data.resp = gateway)), tap(() => console.log(`add gateway ${gateway.uid}/${gateway.uuid}`)));
    }
    deleteGateway(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('gateway', gatewayUuid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${gatewayUuid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Gateway ${gatewayUuid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteGateway', 'gateway', gatewayUuid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteGateway')), tap(() => console.log(`deleted gateway ${gatewayUuid}`)), map(() => `${gatewayUuid} deleted`));
    }
    getGatewayAndProtocols(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayUuid}")) {
        uid uuid
        protocols: gateway_protocol {
          uid uuid created modified protocolType brokerURL
          topic consumerGroupId connectionTimeout sessionTimeout
          initialOffset retryBackOff fetchMinBytes fetchMaxWait
          commitInterval heartbeatInterval maximumQOS
          username password encryptionMode
          caCertificate clientCertificate clientKey
          authMode serverCertificate
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayUuid}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayWithProtocols');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and Protocols for ${gatewayUuid}`)));
    }
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayUuid
     * @param account
     */
    getProtocols(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(protocol)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayUuid}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified protocolType brokerURL topic
        consumerGroupId connectionTimeout sessionTimeout initialOffset
        retryBackOff fetchMinBytes fetchMaxWait commitInterval
        heartbeatInterval maximumQOS username password
        encryptionMode caCertificate clientCertificate clientKey
        authMode serverCertificate scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getProtocols');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched protocols for ${gatewayUuid}`)));
    }
    addProtocol(gatewayUid, protocol, account) {
        this.ensureAccountAuthorized(account);
        if (protocol.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Protocol <dgraph.type> "Protocol" .
        _:Protocol <type> "protocol" .
        _:Protocol <protocol> "" .
        _:Protocol <account> "${account ? account : ''}" .
        _:Protocol <uuid> "${protocol.uuid}" .
        _:Protocol <created> "${protocol.created}" .
        _:Protocol <modified> "${protocol.modified}" .
        _:Protocol <protocolType> "${protocol.protocolType}" .
        _:Protocol <brokerURL> "${protocol.brokerURL}" .
        _:Protocol <topic> "${protocol.topic}" .
        _:Protocol <consumerGroupId> "${protocol.consumerGroupId}" .
        _:Protocol <connectionTimeout> "${protocol.connectionTimeout}" .
        _:Protocol <sessionTimeout> "${protocol.sessionTimeout}" .
        _:Protocol <initialOffset> "${protocol.initialOffset}" .
        _:Protocol <retryBackOff> "${protocol.retryBackOff}" .
        _:Protocol <fetchMinBytes> "${protocol.fetchMinBytes}" .
        _:Protocol <fetchMaxWait> "${protocol.fetchMaxWait}" .
        _:Protocol <commitInterval> "${protocol.commitInterval}" .
        _:Protocol <heartbeatInterval> "${protocol.heartbeatInterval}" .
        _:Protocol <maximumQOS> "${protocol.maximumQOS}" .
        _:Protocol <username> "${protocol.username}" .
        _:Protocol <password> "${protocol.password}" .
        _:Protocol <encryptionMode> "${protocol.encryptionMode}" .
        _:Protocol <caCertificate> "${protocol.caCertificate}" .
        _:Protocol <clientCertificate> "${protocol.clientCertificate}" .
        _:Protocol <clientKey> "${protocol.clientKey}" .
        _:Protocol <authMode> "${protocol.authMode}" .
        _:Protocol <serverCertificate> "${protocol.serverCertificate}" .
        _:Protocol <scope> "${protocol.scope}" .
      }
    }`;
        console.log(`Add protocol ${protocol.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addProtocol');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Protocol');
            if (id) {
                protocol.uid = id;
            }
        }), map((response) => (response.data.resp = protocol)), tap(() => console.log(`add protocols ${protocol.uid}`)));
    }
    updateProtocol(protocol, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('protocol', protocol.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${protocol.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if (eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <uuid> "${protocol.uuid}" .
            uid(v) <modified> "${protocol.modified}" .
            uid(v) <protocolType> "${protocol.protocolType}" .
            uid(v) <brokerURL> "${protocol.brokerURL}" .
            uid(v) <topic> "${protocol.topic}" .
            uid(v) <consumerGroupId> "${protocol.consumerGroupId}" .
            uid(v) <connectionTimeout> "${protocol.connectionTimeout}" .
            uid(v) <sessionTimeout> "${protocol.sessionTimeout}" .
            uid(v) <initialOffset> "${protocol.initialOffset}" .
            uid(v) <retryBackOff> "${protocol.retryBackOff}" .
            uid(v) <fetchMinBytes> "${protocol.fetchMinBytes}" .
            uid(v) <fetchMaxWait> "${protocol.fetchMaxWait}" .
            uid(v) <commitInterval> "${protocol.commitInterval}" .
            uid(v) <heartbeatInterval> "${protocol.heartbeatInterval}" .
            uid(v) <maximumQOS> "${protocol.maximumQOS}" .
            uid(v) <username> "${protocol.username}" .
            uid(v) <password> "${protocol.password}" .
            uid(v) <encryptionMode> "${protocol.encryptionMode}" .
            uid(v) <caCertificate> "${protocol.caCertificate}" .
            uid(v) <clientCertificate> "${protocol.clientCertificate}" .
            uid(v) <clientKey> "${protocol.clientKey}" .
            uid(v) <authMode> "${protocol.authMode}" .
            uid(v) <serverCertificate> "${protocol.serverCertificate}" .
            uid(v) <scope> "${protocol.scope}" .
          }
        }
    }`;
        console.log(`Update ${protocol.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateProtocol', 'protocol', protocol.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateProtocol')), tap(() => console.log(`updated protocol ${protocol.uid}`)), map(() => protocol));
    }
    deleteProtocol(gatewayUid, protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('protocol', protocolUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${protocolUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Protocol ${protocolUid} for ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteProtocol', 'protocol', protocolUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteProtocol')), map(() => `${protocolUid} deleted`));
    }
    getDataStores(gatewayUuid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(dataStore)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayUuid}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified dataStoreType
        host port databaseName user password accountName
        warehouse database schema authType username
        clientId clientSecret authorizationCode
        redirectURI loginTimeout url scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getDataStores');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched dataStores for gateway ${gatewayUuid}`)));
    }
    addDataStore(gatewayUid, dataStore, account) {
        this.ensureAccountAuthorized(account);
        if (dataStore.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:DataStore <dgraph.type> "DataStore" .
        _:DataStore <type> "dataStore" .
        _:DataStore <dataStore> "" .
        _:DataStore <account> "${account ? account : ''}" .
        _:DataStore <uuid> "${dataStore.uuid}" .
        _:DataStore <created> "${dataStore.created}" .
        _:DataStore <modified> "${dataStore.modified}" .
        _:DataStore <dataStoreType> "${dataStore.dataStoreType}" .
        _:DataStore <host> "${dataStore.host}" .
        _:DataStore <port> "${dataStore.port}" .
        _:DataStore <databaseName> "${dataStore.databaseName}" .
        _:DataStore <user> "${dataStore.user}" .
        _:DataStore <password> "${dataStore.password}" .
        _:DataStore <accountName> "${dataStore.accountName}" .
        _:DataStore <warehouse> "${dataStore.warehouse}" .
        _:DataStore <database> "${dataStore.databaseName}" .
        _:DataStore <schema> "${dataStore.schema}" .
        _:DataStore <authType> "${dataStore.authType}" .
        _:DataStore <username> "${dataStore.username}" .
        _:DataStore <clientId> "${dataStore.clientId}" .
        _:DataStore <clientSecret> "${dataStore.clientSecret}" .
        _:DataStore <authorizationCode> "${dataStore.authorizationCode}" .
        _:DataStore <redirectURI> "${dataStore.redirectURI}" .
        _:DataStore <loginTimeout> "${dataStore.loginTimeout}" .
        _:DataStore <url> "${dataStore.url}" .
        _:DataStore <scope> "${dataStore.scope}" .
      }
    }`;
        console.log(`Added datastore ${dataStore.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addDataStore');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'DataStore');
            if (id) {
                dataStore.uid = id;
            }
        }), map((response) => (response.data.resp = dataStore)), tap(() => console.log(`add dataStores ${dataStore.uid}`)));
    }
    updateDataStore(dataStore, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('dataStore', dataStore.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${dataStore.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
                uuid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                uid(v) <account> "${account ? account : ''}" .
                uid(v) <uuid> "${dataStore.uuid}" .
                uid(v) <modified> "${dataStore.modified}" .
                uid(v) <dataStoreType> "${dataStore.dataStoreType}" .
                uid(v) <host> "${dataStore.host}" .
                uid(v) <port> "${dataStore.port}" .
                uid(v) <databaseName> "${dataStore.databaseName}" .
                uid(v) <user> "${dataStore.user}" .
                uid(v) <password> "${dataStore.password}" .
                uid(v) <accountName> "${dataStore.accountName}" .
                uid(v) <warehouse> "${dataStore.warehouse}" .
                uid(v) <database> "${dataStore.databaseName}" .
                uid(v) <schema> "${dataStore.schema}" .
                uid(v) <authType> "${dataStore.authType}" .
                uid(v) <username> "${dataStore.username}" .
                uid(v) <clientId> "${dataStore.clientId}" .
                uid(v) <clientSecret> "${dataStore.clientSecret}" .
                uid(v) <authorizationCode> "${dataStore.authorizationCode}" .
                uid(v) <redirectURI> "${dataStore.redirectURI}" .
                uid(v) <loginTimeout> "${dataStore.loginTimeout}" .
                uid(v) <url> "${dataStore.url}" .
                uid(v) <scope> "${dataStore.scope}" .
              }
            }
          }`;
        console.log(`Update dataStore ${dataStore.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateDataStore', 'dataStore', dataStore.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateDataStore')), tap(() => console.log(`updated dataStore ${dataStore.uid}`)), map(() => dataStore));
    }
    deleteDataStore(gatewayUuid, dataStoreUuid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('dataStore', dataStoreUuid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${dataStoreUuid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete DataStore ${dataStoreUuid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteDataStore', 'dataStore', dataStoreUuid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteDataStore')), tap(() => console.log(`deleted dataStore ${dataStoreUuid}`)), map(() => `${dataStoreUuid} deleted`));
    }
    getGatewayAndRestEndpoints(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid
        models: gateway_model {
          uid uuid created modified name
          description inputType url scope
          inputTemplate headers method base64Encoded
        }
      }
    }`;
        console.log(`Get Gateway and Protocols for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayAndModels');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched gateways and models for ${gatewayName}`)));
    }
    getRestEndpoints(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(model)) @filter(${this.getAccountQuery(account)} AND (eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified name
        description inputType url scope inputTemplate
        headers method base64Encoded
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getModels');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched models for ${gatewayName}`)));
    }
    addRestEndpoint(gatewayUid, model, account) {
        this.ensureAccountAuthorized(account);
        if (model.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Model <dgraph.type> "Model" .
        _:Model <type> "model" .
        _:Model <model> "" .
        _:Model <account> "${account ? account : ''}" .
        _:Model <uuid> "${model.uuid}" .
        _:Model <created> "${model.created}" .
        _:Model <modified> "${model.modified}" .
        _:Model <name> "${model.name}" .
        _:Model <description> "${model.description}" .
        _:Model <inputType> "${model.inputType}" .
        _:Model <url> "${model.url}" .
        _:Model <scope> "${model.scope}" .
        _:Model <inputTemplate> "${model.inputTemplate}" .
        _:Model <headers> "${model.headers}" .
        _:Model <method> "${model.method}" .
        _:Model <base64Encoded> "${model.base64Encoded}" .
      }
    }`;
        console.log(`Add model ${model.uuid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addModel');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Model');
            if (id) {
                model.uid = id;
            }
        }), map((response) => (response.data.resp = model)), tap(() => console.log(`added model ${model.uid}`)));
    }
    updateRestEndpoint(model, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('model', model.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${model.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <uuid> "${model.uuid}" .
            uid(v) <modified> "${model.modified}" .
            uid(v) <name> "${model.name}" .
            uid(v) <description> "${model.description}" .
            uid(v) <inputType> "${model.inputType}" .
            uid(v) <url> "${model.url}" .
            uid(v) <scope> "${model.scope}" .
            uid(v) <inputTemplate> "${model.inputTemplate}" .
            uid(v) <headers> "${model.headers}" .
            uid(v) <method> "${model.method}" .
            uid(v) <base64Encoded> "${model.base64Encoded}" .
          }
        }
        }`;
        console.log(`Update model ${model.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updateModel', 'model', model.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updateModel')), tap(() => console.log(`updated model ${model.uid}`)), map(() => model));
    }
    deleteRestEndpoint(gatewayUid, modelUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('model', modelUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${modelUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`Delete Model ${modelUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deleteModel', 'model', modelUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deleteModel')), tap(() => console.log(`deleted model ${modelUid}`)), map(() => `${modelUid} deleted`));
    }
    getGatewayAndPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
        uid uuid brokerURL topic maximumQOS username password encryptionMode caCertificate
        clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
        sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
      }`;
        const pipeline_datastore = `dataStore: pipeline_datastore {
        uid uuid host port databaseName user password accountName warehouse database schema authType
        username clientId clientSecret authorizationCode redirectURI loginTimeout url
      }`;
        const pipeline_filter = 'filter: pipeline_filter { uid deviceNames }';
        const pipeline_streaming = 'streaming: pipeline_streaming { uid deviceName instrumentName function windowType windowSize }';
        const query = `{
      resp(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        uid uuid accessToken username platform address router routerPort deployNetwork devicesMetadata
        pipelines: gateway_pipeline {
          uid name uuid pipelineType deployerType protocolType protocolId dataStoreType
          dataStoreId created modified description status flowConfiguration
          logLevel subscriptionTopic requirement configurationFile
          ${pipeline_protocol}
          ${pipeline_datastore}
          ${pipeline_filter}
          ${pipeline_streaming}
        }
      }
    }`;
        console.log(`Get Gateway and Pipelines for ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getGatewayWithPipelines');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched Gateway and pipelines for ${gatewayName}`)));
    }
    getPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = `protocol: pipeline_protocol {
              uid brokerURL topic maximumQOS username password encryptionMode caCertificate
              clientCertificate clientKey authMode serverCertificate consumerGroupId connectionTimeout
              sessionTimeout retryBackOff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval
  } `;
        const pipeline_datastore = `datastore: pipeline_datastore {
              uid host port databaseName user password accountName warehouse database schema authType
              username clientId clientSecret authorizationCode redirectURI loginTimeout url
            }`;
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      var(func: has(gateway)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${gatewayName}")) {
        pipelines as gateway_pipeline {
        }
      }
      resp(func: uid(pipelines)) {
        uid name uuid pipelineType deployerType protocolType protocolId
        dataStoreType dataStoreId created modified description status
        flowConfiguration logLevel subscriptionTopic requirement configurationFile
        ${pipeline_protocol}
        ${pipeline_datastore}
        ${pipeline_filter}
        ${pipeline_streaming}
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPipelines');
        }), map((response) => response.data.resp), tap(() => console.log(`fetched pipelines for ${gatewayName}`)));
    }
    addPipeline(gatewayUid, pipeline, transportObj, dataStoreObj, filterObj, streamingObj, account) {
        this.ensureAccountAuthorized(account);
        if (pipeline.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Pipeline <dgraph.type> "Pipeline" .
        _:Pipeline <account> "${account ? account : ''}" .
        _:Pipeline <name> "${pipeline.name}" .
        _:Pipeline <uuid> "${pipeline.name}" .
        _:Pipeline <type> "pipeline" .
        _:Pipeline <pipeline> "" .
        _:Pipeline <pipelineType> "${pipeline.pipelineType}" .
        _:Pipeline <deployerType> "${pipeline.deployerType}" .
        _:Pipeline <created> "${pipeline.created}" .
        _:Pipeline <modified> "${pipeline.modified}" .
        _:Pipeline <description> "${pipeline.description}" .
        _:Pipeline <status> "${pipeline.status}" .
        _:Pipeline <flowConfiguration> "${pipeline.flowConfiguration}" .
        _:Pipeline <logLevel> "${pipeline.logLevel}" .
        _:Pipeline <subscriptionTopic> "${pipeline.subscriptionTopic}" .
        _:Pipeline <requirement> "${pipeline.requirement}" .
        _:Pipeline <configurationFile> "${pipeline.configurationFile}" .
        <${gatewayUid}> <gateway_pipeline> _:Pipeline .
      }
    }`;
        console.log(`add Pipeline ${pipeline.uid}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addPipeline');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'Pipeline');
            if (id) {
                pipeline.uid = id;
            }
        }), map((response) => (response.data.resp = pipeline)), tap(() => console.log(`added pipeline ${pipeline.uid}`)));
    }
    updatePipeline(pipeline, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pipeline', pipeline.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
          var(func: uid(${pipeline.uid}))
          @filter(${this.getAccountQuery(account)}) {
            v as uid
          }
        }
        mutation @if(eq(len(v), 1)) {
          set {
            uid(v) <account> "${account ? account : ''}" .
            uid(v) <description> "${pipeline.description}" .
            uid(v) <status> "${pipeline.status}" .
            uid(v) <modified> "${pipeline.modified}" .
            uid(v) <flowConfiguration> "${pipeline.flowConfiguration}" .
            uid(v) <logLevel> "${pipeline.logLevel}" .
            uid(v) <subscriptionTopic> "${pipeline.subscriptionTopic}" .
            uid(v) <requirement> "${pipeline.requirement}" .
            uid(v) <configurationFile> "${pipeline.configurationFile}" .
          }
        }
      }`;
        console.log(`update Pipeline ${pipeline.uid}`);
        // With the upsert approach, it is not possible to see if the mutation occurred.
        // Use a preQuery for the object first to determine if it exists.
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updatePipeline', 'pipeline', pipeline.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatePipeline')), tap(() => console.log(`updated pipeline ${pipeline.uid}`)), map(() => pipeline));
    }
    deletePipeline(gatewayUid, pipelineId, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pipeline', pipelineId, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
          upsert {
            query {
              var(func: uid(${pipelineId}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
                <${gatewayUid}> <gateway_pipeline> <${pipelineId}> .
              }
            }
          }`;
        console.log(`delete Pipeline ${pipelineId} with gateway ${gatewayUid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deletePipeline', 'pipeline', pipelineId)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deletePipeline')), tap(() => console.log(`deleted pipeline ${pipelineId} with gateway ${gatewayUid}`)), map(() => `pipeline deleted`));
    }
    /**
     * Get Python Resources.
     * @param gatewayUid
     */
    getPythonResources(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `
    {
      resp(func: type(PythonResource)) @filter(${this.getAccountQuery(account)} AND(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL"))) {
        uid uuid created modified name type scope fileContent inputs outputs filePath
      }
    }`;
        console.log(`get python resource from ${gatewayName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getPythonResource');
        }), map((response) => response.data.resp));
    }
    /**
     * Update Python Resource.
     * @param PythonResource
     */
    updatePythonResource(pythonResource, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pythonResource', pythonResource.uid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `
        upsert {
            query {
              var(func: uid(${pythonResource.uid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              set {
                <${pythonResource.uid}> <account> "${account ? account : ''}" .
                <${pythonResource.uid}> <modified> "${pythonResource.modified}" .
                <${pythonResource.uid}> <name> "${pythonResource.name}" .
                <${pythonResource.uid}> <scope> "${pythonResource.scope}" .
                <${pythonResource.uid}> <type> "${pythonResource.type}" .
                <${pythonResource.uid}> <fileContent> "${pythonResource.fileContent}" .
                <${pythonResource.uid}> <inputs> "${pythonResource.inputs}" .
                <${pythonResource.uid}> <outputs> "${pythonResource.outputs}" .
                <${pythonResource.uid}> <filePath> "${pythonResource.filePath}" .
              }
            }
        }`;
        console.log(`Update PythonResource ${pythonResource.uid}`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'updatePythonResource', 'pythonResource', pythonResource.uid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'updatePythonResource')), tap(() => console.log(`updated filterConfig ${pythonResource.uid}`)), map(() => pythonResource));
    }
    /**
     * Add Python Resource.
     * @param PythonResource
     */
    addPythonResource(gatewayUuid, pythonResource, account) {
        this.ensureAccountAuthorized(account);
        if (pythonResource.uid) {
            throw new Error('Cannot add with an ID');
        }
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = ` {
      set {
        _:PythonResource <dgraph.type> "PythonResource" .
        _:PythonResource <pythonResource> "" .
        _:PythonResource <type> "pythonResource" .
        _:PythonResource <account> "${account ? account : ''}" .
        _:PythonResource <name> "${pythonResource.name}" .
        _:PythonResource <created> "${pythonResource.created}" .
        _:PythonResource <modified> "${pythonResource.modified}" .
        _:PythonResource <type> "${pythonResource.type}" .
        _:PythonResource <fileContent> "${pythonResource.fileContent}" .
        _:PythonResource <scope> "${pythonResource.scope}" .
        _:PythonResource <inputs> "${pythonResource.inputs}" .
        _:PythonResource <outputs> "${pythonResource.outputs}" .
        _:PythonResource <filePath> "${pythonResource.filePath}" .
      }}`;
        console.log(`Add PythonResource ${pythonResource.name}`);
        return this.http.post(url, query, httpMutateOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'addPythonResource');
        }), tap((response) => {
            const id = this.getIDFromResponse(response.data, 'PythonResource');
            if (id) {
                pythonResource.uid = id;
            }
        }), map((response) => (response.data.resp = pythonResource)), tap(() => console.log(`add pythonResource ${pythonResource.uid}`)));
    }
    /**
     * Delete Python Resource.
     * @param resourceUid
     */
    deletePythonResource(pythonResourceUid, account) {
        this.ensureAccountAuthorized(account);
        const preQueryUrl = `${this.dGraphUrl}/query`;
        const preQuery = this.getPreQuery('pythonResource', pythonResourceUid, account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `upsert {
            query {
              var(func: uid(${pythonResourceUid}))
              @filter(${this.getAccountQuery(account)}) {
                v as uid
              }
            }
            mutation @if(eq(len(v), 1)) {
              delete {
                uid(v) * * .
              }
            }
          }`;
        console.log(`${pythonResourceUid} is being deleted`);
        return this.http.post(preQueryUrl, preQuery, httpOptions).pipe(tap((response) => this.confirmObjectExists(response, 'deletePythonResource', 'pythonResource', pythonResourceUid)), switchMap(() => this.http.post(url, query, httpMutateOptions)), tap((response) => this.checkForErrors(response, 'deletePythonResource')), tap(() => console.log(`updated filterConfig ${pythonResourceUid}`)), map(() => `${pythonResourceUid} deleted`));
    }
    getReadings(gatewayUuid, deviceName, instrumentName, numReadings, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading (first:-${numReadings}) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadings for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadings');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap((response) => console.log('Response from getReadings: ', response)), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsAt(deviceName, instrumentName, ts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(eq(created, ${ts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsAt for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsAt');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsStartingAt(deviceName, instrumentName, fromts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsStartingAt for for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsStartingAt');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched started at readings for ${deviceName}, ${instrumentName}`)));
    }
    getReadingsBetween(gatewayUuid, deviceName, instrumentName, fromts, tots, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log(`getReadingsBetween for ${deviceName}, ${instrumentName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getReadingsBetween');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched readings between for ${deviceName}, ${instrumentName}`)));
    }
    getLastReadingsForDevice(deviceName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(device)) @filter(${this.getAccountQuery(account)} AND eq(uuid, "${deviceName}")) @normalize {
        device_resource {
          name: name
          resource_reading (first:-1) {
            created: created
            value: value
          }
        }
      }
    }`;
        console.log(`getLastReadingsForDevice for ${deviceName}`);
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getLastReadingsForDevice');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched last readings for ${deviceName}`)));
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    addReading(gatewayUuid, deviceName, instrumentName, reading, accountId) {
        throw new Error('Only supports GraphQL graph service');
    }
    getNotifications(account) {
        this.ensureAccountAuthorized(account);
        console.log('GetNotifications service called');
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(notification)) @filter(${this.getAccountQuery(account)}) @normalize {
        uid uuid:uuid created:created notifySource:notifySource notifyDevice:notifyDevice
        notifyResource:notifyResource notifyLevel:notifyLevel value:value description:description
        ~gateway_notification {
          gateway: uuid
        }
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(tap((response) => {
            this.checkForErrors(response, 'getNotifications');
        }), map((response) => {
            if (response.data?.resp) {
                return response.data?.resp;
            }
            else {
                return [];
            }
        }), tap(() => console.log(`fetched notifications`)));
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    addNotification(gatewayUuid, notification, accountId) {
        throw new Error('Only supports GraphQL graph service');
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    deleteNotification(gatewayUuid, notificationUuid, accountId) {
        throw new Error('Only supports GraphQL graph service');
    }
    ensureAccountAuthorized(account) {
        if (this.requireAccountId) {
            if (!account)
                throw new Error('Account must exist');
        }
    }
    getAccountQuery(account) {
        if (this.requireAccountId) {
            return `eq(account, "${account}")`;
        }
        else {
            return `(eq(account, "${account ? account : ''}") OR not(has(account)))`;
        }
    }
    /**
     * Discovers the presence of errors in the response from dGraph and reports them.
     *
     * @param response the response object from dGraph
     * @param operation the operation that was being performed for logging purposes
     */
    checkForErrors(response, operation = 'operation') {
        let hasErrors = false;
        let errors;
        if (response?.data?.errors) {
            hasErrors = true;
            console.log(`${operation} failed: ${response.data.errors[0].message}`);
            errors = { message: response.data.errors[0].message };
        }
        else if (response?.errors) {
            hasErrors = true;
            console.log(`${operation} failed: ${response.errors[0].message}`);
            errors = { message: response.errors[0].message };
        }
        if (hasErrors) {
            throw new Error(JSON.stringify(errors));
        }
    }
    /**
     * If the operation was successful, obtain a UID from the response.
     *
     * @param dGraphResponse A response from dGraph
     * @param objectKey the name of the Object, for example Gateway or Model
     * @returns a UID found from the response
     */
    getIDFromResponse(dGraphResponse, objectKey) {
        if (dGraphResponse.code === 'Success') {
            const uid = dGraphResponse.uids[objectKey];
            return uid;
        }
        return undefined;
    }
    getPreQuery(objectName, uid, account) {
        if (!uid) {
            throw new Error(JSON.stringify({ message: 'No ID defined' }));
        }
        return `{
        resp(func: has(${objectName})) @filter(${this.getAccountQuery(account)} AND (uid(${uid}))) {
          uid uuid
        }
      }`;
    }
    confirmObjectExists(response, operation, objectName, uid) {
        if (!uid) {
            throw new Error(JSON.stringify({ message: 'No ID defined' }));
        }
        this.checkForErrors(response, operation);
        if (Array.isArray(response.data.resp)) {
            const responseArray = response.data.resp;
            if (responseArray.length === 0) {
                console.log(`the ${objectName} with ID ${uid} does not exist in this account`);
                throw new Error(JSON.stringify({ message: 'No existing object' }));
            }
        }
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2xhYnMtYWlyLWdyYXBoLWNsaWVudC9zcmMvYXBpL2dyYXBoLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxFQUFFLEdBQUcsRUFBYyxTQUFTLEVBQUUsR0FBRyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBSXZELE1BQU0sV0FBVyxHQUFHO0lBQ2hCLE9BQU8sRUFBRTtRQUNMLGNBQWMsRUFBRSx1QkFBdUI7S0FDMUM7Q0FDSixDQUFDO0FBRUYsTUFBTSxpQkFBaUIsR0FBRztJQUN0QixPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsaUJBQWlCLEVBQUU7Q0FDakQsQ0FBQztBQUVGLE1BQU0sT0FBZ0IsWUFBWTtJQUs5QixZQUFzQixJQUFnQixFQUFFLFNBQWlCLEVBQUUsZUFBd0I7UUFBN0QsU0FBSSxHQUFKLElBQUksQ0FBWTtRQUg1QixxQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFJOUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFDM0IsSUFBSSxDQUFDLGdCQUFnQixHQUFHLGVBQWUsQ0FBQztRQUN4Qyw4RUFBOEU7UUFDOUUsK0JBQStCO1FBQy9CLG9FQUFvRTtRQUNwRSxtSEFBbUg7UUFDbkgsbUhBQW1IO1FBQ25ILEdBQUc7SUFDUCxDQUFDO0lBRUQsVUFBVSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDNUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFDNUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxtQkFBbUIsQ0FBQztRQUNqRCxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7O01BSzdGLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLENBQ3JELENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQWdCO1FBQ3hCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLG1CQUFtQixDQUFDO1FBQ2pELE1BQU0sS0FBSyxHQUFHOztnQkFFTixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O01BTXZDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLFFBQVEsQ0FBQyxNQUFNLFdBQVcsQ0FBQyxDQUFDLENBQ3hFLENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLE9BQWdCLEVBQUUsT0FBZ0I7UUFDNUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFbkUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLE9BQU8sQ0FBQyxHQUFHO3dCQUNqQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O29DQU1qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtvQ0FDdEIsT0FBTyxDQUFDLE9BQU87bUNBQ2hCLE9BQU8sQ0FBQyxNQUFNO3VDQUNWLE9BQU8sQ0FBQyxVQUFVOzBDQUNmLE9BQU8sQ0FBQyxhQUFhO3dDQUN2QixPQUFPLENBQUMsV0FBVztxQ0FDdEIsT0FBTyxDQUFDLFFBQVE7c0NBQ2YsT0FBTyxDQUFDLFNBQVM7d0NBQ2YsT0FBTyxDQUFDLFdBQVc7cUNBQ3RCLE9BQU8sQ0FBQyxRQUFRO3FDQUNoQixPQUFPLENBQUMsUUFBUTtzQ0FDZixPQUFPLENBQUMsU0FBUzs7O1lBRzNDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixPQUFPLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRTdELGdGQUFnRjtRQUNoRixpRUFBaUU7UUFFakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQzlGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQyxFQUNqRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFDekQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixDQUFDLENBQy9CLENBQUM7SUFDTixDQUFDO0lBRUQsVUFBVSxDQUFDLE9BQWdCLEVBQUUsT0FBZ0I7UUFDekMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNiLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OytCQUtTLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUN6QixPQUFPLENBQUMsSUFBSTttQ0FDTCxPQUFPLENBQUMsV0FBVzsrQkFDdkIsT0FBTyxDQUFDLE9BQU87OEJBQ2hCLE9BQU8sQ0FBQyxNQUFNO2tDQUNWLE9BQU8sQ0FBQyxVQUFVO3FDQUNmLE9BQU8sQ0FBQyxhQUFhO2dDQUMxQixPQUFPLENBQUMsUUFBUTtpQ0FDZixPQUFPLENBQUMsU0FBUzttQ0FDZixPQUFPLENBQUMsV0FBVztnQ0FDdEIsT0FBTyxDQUFDLFFBQVE7Z0NBQ2hCLE9BQU8sQ0FBQyxRQUFRO2lDQUNmLE9BQU8sQ0FBQyxTQUFTO2lDQUNqQixPQUFPLENBQUMsU0FBUzs7TUFFNUMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUUzQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztZQUM1RCxJQUFJLEVBQUUsRUFBRTtnQkFDSixPQUFPLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUNwQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUNqRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLE9BQU8sQ0FBQyxHQUFHLElBQUksT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FDdkUsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUMvQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRW5FLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs4QkFHUSxXQUFXO3dCQUNqQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFFTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRTdDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDLEVBQzlGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQyxFQUNqRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUN4RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxXQUFXLFVBQVUsQ0FBQyxDQUN0QyxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsV0FBVzs7Ozs7Ozs7Ozs7O01BWTdGLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRTVELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUseUJBQXlCLENBQUMsQ0FBQztRQUM3RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUM3RSxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxZQUFZLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7MENBQ29CLElBQUksQ0FBQyxlQUFlLENBQ3BELE9BQU8sQ0FDVixvQkFBb0IsV0FBVzs7Ozs7Ozs7TUFRaEMsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWtCLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FDakUsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxRQUFrQixFQUFFLE9BQWdCO1FBQ2hFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxJQUFJLFFBQVEsQ0FBQyxHQUFHLEVBQUU7WUFDZCxNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDNUM7UUFFRCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OztnQ0FLVSxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTs2QkFDekIsUUFBUSxDQUFDLElBQUk7Z0NBQ1YsUUFBUSxDQUFDLE9BQU87aUNBQ2YsUUFBUSxDQUFDLFFBQVE7cUNBQ2IsUUFBUSxDQUFDLFlBQVk7a0NBQ3hCLFFBQVEsQ0FBQyxTQUFTOzhCQUN0QixRQUFRLENBQUMsS0FBSzt3Q0FDSixRQUFRLENBQUMsZUFBZTswQ0FDdEIsUUFBUSxDQUFDLGlCQUFpQjt1Q0FDN0IsUUFBUSxDQUFDLGNBQWM7c0NBQ3hCLFFBQVEsQ0FBQyxhQUFhO3FDQUN2QixRQUFRLENBQUMsWUFBWTtzQ0FDcEIsUUFBUSxDQUFDLGFBQWE7cUNBQ3ZCLFFBQVEsQ0FBQyxZQUFZO3VDQUNuQixRQUFRLENBQUMsY0FBYzswQ0FDcEIsUUFBUSxDQUFDLGlCQUFpQjttQ0FDakMsUUFBUSxDQUFDLFVBQVU7aUNBQ3JCLFFBQVEsQ0FBQyxRQUFRO2lDQUNqQixRQUFRLENBQUMsUUFBUTt1Q0FDWCxRQUFRLENBQUMsY0FBYztzQ0FDeEIsUUFBUSxDQUFDLGFBQWE7MENBQ2xCLFFBQVEsQ0FBQyxpQkFBaUI7a0NBQ2xDLFFBQVEsQ0FBQyxTQUFTO2lDQUNuQixRQUFRLENBQUMsUUFBUTswQ0FDUixRQUFRLENBQUMsaUJBQWlCOzhCQUN0QyxRQUFRLENBQUMsS0FBSzs7TUFFdEMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRTdDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQzdELElBQUksRUFBRSxFQUFFO2dCQUNKLFFBQVEsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO2FBQ3JCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUMxRCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxRQUFrQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXJFLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7OzswQkFHSSxRQUFRLENBQUMsR0FBRztvQkFDbEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7OztnQ0FNakIsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7NkJBQ3pCLFFBQVEsQ0FBQyxJQUFJO2lDQUNULFFBQVEsQ0FBQyxRQUFRO3FDQUNiLFFBQVEsQ0FBQyxZQUFZO2tDQUN4QixRQUFRLENBQUMsU0FBUzs4QkFDdEIsUUFBUSxDQUFDLEtBQUs7d0NBQ0osUUFBUSxDQUFDLGVBQWU7MENBQ3RCLFFBQVEsQ0FBQyxpQkFBaUI7dUNBQzdCLFFBQVEsQ0FBQyxjQUFjO3NDQUN4QixRQUFRLENBQUMsYUFBYTtxQ0FDdkIsUUFBUSxDQUFDLFlBQVk7c0NBQ3BCLFFBQVEsQ0FBQyxhQUFhO3FDQUN2QixRQUFRLENBQUMsWUFBWTt1Q0FDbkIsUUFBUSxDQUFDLGNBQWM7MENBQ3BCLFFBQVEsQ0FBQyxpQkFBaUI7bUNBQ2pDLFFBQVEsQ0FBQyxVQUFVO2lDQUNyQixRQUFRLENBQUMsUUFBUTtpQ0FDakIsUUFBUSxDQUFDLFFBQVE7dUNBQ1gsUUFBUSxDQUFDLGNBQWM7c0NBQ3hCLFFBQVEsQ0FBQyxhQUFhOzBDQUNsQixRQUFRLENBQUMsaUJBQWlCO2tDQUNsQyxRQUFRLENBQUMsU0FBUztpQ0FDbkIsUUFBUSxDQUFDLFFBQVE7MENBQ1IsUUFBUSxDQUFDLGlCQUFpQjs4QkFDdEMsUUFBUSxDQUFDLEtBQUs7OztNQUd0QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRXRDLGdGQUFnRjtRQUNoRixpRUFBaUU7UUFDakUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDakcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGdCQUFnQixDQUFDLENBQUMsRUFDbEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQzFELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FDdEIsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxXQUFtQixFQUFFLE9BQWdCO1FBQ3BFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxNQUFNLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFcEUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLFdBQVc7d0JBQ2pCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7WUFTekMsQ0FBQztRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLFdBQVcsUUFBUSxVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRWhFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsV0FBVyxDQUFDLENBQUMsRUFDaEcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGdCQUFnQixDQUFDLENBQUMsRUFDbEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsV0FBVyxVQUFVLENBQUMsQ0FDdEMsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUMvQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7MkNBQ3FCLElBQUksQ0FBQyxlQUFlLENBQ3JELE9BQU8sQ0FDVixvQkFBb0IsV0FBVzs7Ozs7OztNQU9oQyxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQztRQUNuRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUMxRSxDQUFDO0lBQ04sQ0FBQztJQUVELFlBQVksQ0FBQyxVQUFrQixFQUFFLFNBQW9CLEVBQUUsT0FBZ0I7UUFDbkUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLElBQUksU0FBUyxDQUFDLEdBQUcsRUFBRTtZQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7O2lDQUtXLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzhCQUN6QixTQUFTLENBQUMsSUFBSTtpQ0FDWCxTQUFTLENBQUMsT0FBTztrQ0FDaEIsU0FBUyxDQUFDLFFBQVE7dUNBQ2IsU0FBUyxDQUFDLGFBQWE7OEJBQ2hDLFNBQVMsQ0FBQyxJQUFJOzhCQUNkLFNBQVMsQ0FBQyxJQUFJO3NDQUNOLFNBQVMsQ0FBQyxZQUFZOzhCQUM5QixTQUFTLENBQUMsSUFBSTtrQ0FDVixTQUFTLENBQUMsUUFBUTtxQ0FDZixTQUFTLENBQUMsV0FBVzttQ0FDdkIsU0FBUyxDQUFDLFNBQVM7a0NBQ3BCLFNBQVMsQ0FBQyxZQUFZO2dDQUN4QixTQUFTLENBQUMsTUFBTTtrQ0FDZCxTQUFTLENBQUMsUUFBUTtrQ0FDbEIsU0FBUyxDQUFDLFFBQVE7a0NBQ2xCLFNBQVMsQ0FBQyxRQUFRO3NDQUNkLFNBQVMsQ0FBQyxZQUFZOzJDQUNqQixTQUFTLENBQUMsaUJBQWlCO3FDQUNqQyxTQUFTLENBQUMsV0FBVztzQ0FDcEIsU0FBUyxDQUFDLFlBQVk7NkJBQy9CLFNBQVMsQ0FBQyxHQUFHOytCQUNYLFNBQVMsQ0FBQyxLQUFLOztNQUV4QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFakQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDOUQsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osU0FBUyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7YUFDdEI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQzVELENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFNBQW9CLEVBQUUsT0FBZ0I7UUFDbEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFdkUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUV0RCxNQUFNLEtBQUssR0FBRzs7OzhCQUdRLFNBQVMsQ0FBQyxHQUFHO3dCQUNuQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7OztvQ0FPakIsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7aUNBQ3pCLFNBQVMsQ0FBQyxJQUFJO3FDQUNWLFNBQVMsQ0FBQyxRQUFROzBDQUNiLFNBQVMsQ0FBQyxhQUFhO2lDQUNoQyxTQUFTLENBQUMsSUFBSTtpQ0FDZCxTQUFTLENBQUMsSUFBSTt5Q0FDTixTQUFTLENBQUMsWUFBWTtpQ0FDOUIsU0FBUyxDQUFDLElBQUk7cUNBQ1YsU0FBUyxDQUFDLFFBQVE7d0NBQ2YsU0FBUyxDQUFDLFdBQVc7c0NBQ3ZCLFNBQVMsQ0FBQyxTQUFTO3FDQUNwQixTQUFTLENBQUMsWUFBWTttQ0FDeEIsU0FBUyxDQUFDLE1BQU07cUNBQ2QsU0FBUyxDQUFDLFFBQVE7cUNBQ2xCLFNBQVMsQ0FBQyxRQUFRO3FDQUNsQixTQUFTLENBQUMsUUFBUTt5Q0FDZCxTQUFTLENBQUMsWUFBWTs4Q0FDakIsU0FBUyxDQUFDLGlCQUFpQjt3Q0FDakMsU0FBUyxDQUFDLFdBQVc7eUNBQ3BCLFNBQVMsQ0FBQyxZQUFZO2dDQUMvQixTQUFTLENBQUMsR0FBRztrQ0FDWCxTQUFTLENBQUMsS0FBSzs7O1lBR3JDLENBQUM7UUFFTCxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUVqRCxnRkFBZ0Y7UUFDaEYsaUVBQWlFO1FBQ2pFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQ3BHLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUM1RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQ3ZCLENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFdBQW1CLEVBQUUsYUFBcUIsRUFBRSxPQUFnQjtRQUN4RSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXZFLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs4QkFHUSxhQUFhO3dCQUNuQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixhQUFhLEVBQUUsQ0FBQyxDQUFDO1FBRWpELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFDcEcsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLGFBQWEsRUFBRSxDQUFDLENBQUMsRUFDNUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsYUFBYSxVQUFVLENBQUMsQ0FDeEMsQ0FBQztJQUNOLENBQUM7SUFFRCwwQkFBMEIsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQzVELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFdBQVc7Ozs7Ozs7O01BUTdGLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRTVELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUscUJBQXFCLENBQUMsQ0FBQztRQUN6RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUMzRSxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDbEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3VDQUNpQixJQUFJLENBQUMsZUFBZSxDQUNqRCxPQUFPLENBQ1Ysb0JBQW9CLFdBQVc7Ozs7O01BS2hDLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFzQixDQUFDLEVBQ3ZELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQzlELENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFVBQWtCLEVBQUUsS0FBbUIsRUFBRSxPQUFnQjtRQUNyRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsSUFBSSxLQUFLLENBQUMsR0FBRyxFQUFFO1lBQ1gsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7NkJBS08sT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7MEJBQ3pCLEtBQUssQ0FBQyxJQUFJOzZCQUNQLEtBQUssQ0FBQyxPQUFPOzhCQUNaLEtBQUssQ0FBQyxRQUFROzBCQUNsQixLQUFLLENBQUMsSUFBSTtpQ0FDSCxLQUFLLENBQUMsV0FBVzsrQkFDbkIsS0FBSyxDQUFDLFNBQVM7eUJBQ3JCLEtBQUssQ0FBQyxHQUFHOzJCQUNQLEtBQUssQ0FBQyxLQUFLO21DQUNILEtBQUssQ0FBQyxhQUFhOzZCQUN6QixLQUFLLENBQUMsT0FBTzs0QkFDZCxLQUFLLENBQUMsTUFBTTttQ0FDTCxLQUFLLENBQUMsYUFBYTs7TUFFaEQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUV2QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMxRCxJQUFJLEVBQUUsRUFBRTtnQkFDSixLQUFLLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQzthQUNsQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUMvQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQ3JELENBQUM7SUFDTixDQUFDO0lBRUQsa0JBQWtCLENBQUMsS0FBbUIsRUFBRSxPQUFnQjtRQUNwRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUUvRCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7MEJBR0ksS0FBSyxDQUFDLEdBQUc7b0JBQ2YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7OztnQ0FNakIsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7NkJBQ3pCLEtBQUssQ0FBQyxJQUFJO2lDQUNOLEtBQUssQ0FBQyxRQUFROzZCQUNsQixLQUFLLENBQUMsSUFBSTtvQ0FDSCxLQUFLLENBQUMsV0FBVztrQ0FDbkIsS0FBSyxDQUFDLFNBQVM7NEJBQ3JCLEtBQUssQ0FBQyxHQUFHOzhCQUNQLEtBQUssQ0FBQyxLQUFLO3NDQUNILEtBQUssQ0FBQyxhQUFhO2dDQUN6QixLQUFLLENBQUMsT0FBTzsrQkFDZCxLQUFLLENBQUMsTUFBTTtzQ0FDTCxLQUFLLENBQUMsYUFBYTs7O1VBRy9DLENBQUM7UUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUV6QyxnRkFBZ0Y7UUFDaEYsaUVBQWlFO1FBQ2pFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUN4RixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFDL0QsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQ3BELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FDbkIsQ0FBQztJQUNOLENBQUM7SUFFRCxrQkFBa0IsQ0FBQyxVQUFrQixFQUFFLFFBQWdCLEVBQUUsT0FBZ0I7UUFDckUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUU5RCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsUUFBUTt3QkFDZCxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBRXhDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sV0FBVyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQy9ELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ3ZGLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQyxFQUMvRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsUUFBUSxFQUFFLENBQUMsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxRQUFRLFVBQVUsQ0FBQyxDQUNuQyxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0saUJBQWlCLEdBQUc7Ozs7UUFJMUIsQ0FBQztRQUNELE1BQU0sa0JBQWtCLEdBQUc7OztRQUczQixDQUFDO1FBQ0QsTUFBTSxlQUFlLEdBQUcsNkNBQTZDLENBQUM7UUFDdEUsTUFBTSxrQkFBa0IsR0FDcEIsZ0dBQWdHLENBQUM7UUFFckcsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7WUFNdkYsaUJBQWlCO1lBQ2pCLGtCQUFrQjtZQUNsQixlQUFlO1lBQ2Ysa0JBQWtCOzs7TUFHeEIsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSx5QkFBeUIsQ0FBQyxDQUFDO1FBQzdELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQzdFLENBQUM7SUFDTixDQUFDO0lBRUQsWUFBWSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDOUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0saUJBQWlCLEdBQUc7Ozs7S0FJN0IsQ0FBQztRQUNFLE1BQU0sa0JBQWtCLEdBQUc7OztjQUdyQixDQUFDO1FBQ1AsTUFBTSxlQUFlLEdBQUcsMkNBQTJDLENBQUM7UUFDcEUsTUFBTSxrQkFBa0IsR0FDcEIsOEZBQThGLENBQUM7UUFFbkcsTUFBTSxLQUFLLEdBQUc7d0NBQ2tCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixXQUFXOzs7Ozs7OztVQVF4RixpQkFBaUI7VUFDakIsa0JBQWtCO1VBQ2xCLGVBQWU7VUFDZixrQkFBa0I7O01BRXRCLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFrQixDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQ2pFLENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUNQLFVBQWtCLEVBQ2xCLFFBQWtCLEVBQ2xCLFlBQWtCLEVBQ2xCLFlBQWtCLEVBQ2xCLFNBQWUsRUFDZixZQUFrQixFQUNsQixPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsSUFBSSxRQUFRLENBQUMsR0FBRyxFQUFFO1lBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7O2dDQUdVLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFOzZCQUN6QixRQUFRLENBQUMsSUFBSTs2QkFDYixRQUFRLENBQUMsSUFBSTs7O3FDQUdMLFFBQVEsQ0FBQyxZQUFZO3FDQUNyQixRQUFRLENBQUMsWUFBWTtnQ0FDMUIsUUFBUSxDQUFDLE9BQU87aUNBQ2YsUUFBUSxDQUFDLFFBQVE7b0NBQ2QsUUFBUSxDQUFDLFdBQVc7K0JBQ3pCLFFBQVEsQ0FBQyxNQUFNOzBDQUNKLFFBQVEsQ0FBQyxpQkFBaUI7aUNBQ25DLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7b0NBQ2hDLFFBQVEsQ0FBQyxXQUFXOzBDQUNkLFFBQVEsQ0FBQyxpQkFBaUI7V0FDekQsVUFBVTs7TUFFZixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFNUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDN0QsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osUUFBUSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7YUFDckI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQzNELENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFFBQWtCLEVBQUUsT0FBZ0I7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFckUsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OzBCQUdJLFFBQVEsQ0FBQyxHQUFHO29CQUNsQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7O2dDQU1qQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtvQ0FDbEIsUUFBUSxDQUFDLFdBQVc7K0JBQ3pCLFFBQVEsQ0FBQyxNQUFNO2lDQUNiLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7aUNBQ25DLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7b0NBQ2hDLFFBQVEsQ0FBQyxXQUFXOzBDQUNkLFFBQVEsQ0FBQyxpQkFBaUI7OztRQUc1RCxDQUFDO1FBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFL0MsZ0ZBQWdGO1FBQ2hGLGlFQUFpRTtRQUNqRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUNqRyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxFQUNsRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFDMUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUN0QixDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLFVBQWtCLEVBQUUsT0FBZ0I7UUFDbkUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUVuRSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OEJBR1EsVUFBVTt3QkFDaEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7bUJBT2xDLFVBQVUseUJBQXlCLFVBQVU7OztZQUdwRCxDQUFDO1FBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsVUFBVSxpQkFBaUIsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUV4RSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMvRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDLEVBQy9GLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLEVBQ2xFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixVQUFVLGlCQUFpQixVQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQ25GLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUNoQyxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILGtCQUFrQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDcEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHOztpREFFMkIsSUFBSSxDQUFDLGVBQWUsQ0FDM0QsT0FBTyxDQUNWLG1CQUFtQixXQUFXOzs7TUFHL0IsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFDdkQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1FBQ3ZELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUF3QixDQUFDLENBQzVELENBQUM7SUFDTixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsb0JBQW9CLENBQUMsY0FBOEIsRUFBRSxPQUFnQjtRQUNqRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxXQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRWpGLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs4QkFHUSxjQUFjLENBQUMsR0FBRzt3QkFDeEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7Ozs7OzttQkFNbEMsY0FBYyxDQUFDLEdBQUcsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO21CQUN4RCxjQUFjLENBQUMsR0FBRyxpQkFBaUIsY0FBYyxDQUFDLFFBQVE7bUJBQzFELGNBQWMsQ0FBQyxHQUFHLGFBQWEsY0FBYyxDQUFDLElBQUk7bUJBQ2xELGNBQWMsQ0FBQyxHQUFHLGNBQWMsY0FBYyxDQUFDLEtBQUs7bUJBQ3BELGNBQWMsQ0FBQyxHQUFHLGFBQWEsY0FBYyxDQUFDLElBQUk7bUJBQ2xELGNBQWMsQ0FBQyxHQUFHLG9CQUFvQixjQUFjLENBQUMsV0FBVzttQkFDaEUsY0FBYyxDQUFDLEdBQUcsZUFBZSxjQUFjLENBQUMsTUFBTTttQkFDdEQsY0FBYyxDQUFDLEdBQUcsZ0JBQWdCLGNBQWMsQ0FBQyxPQUFPO21CQUN4RCxjQUFjLENBQUMsR0FBRyxpQkFBaUIsY0FBYyxDQUFDLFFBQVE7OztVQUduRSxDQUFDO1FBRUgsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFM0QsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLHNCQUFzQixFQUFFLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUNuSCxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsc0JBQXNCLENBQUMsQ0FBQyxFQUN4RSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFDcEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUM1QixDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILGlCQUFpQixDQUFDLFdBQW1CLEVBQUUsY0FBOEIsRUFBRSxPQUFnQjtRQUNuRixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsSUFBSSxjQUFjLENBQUMsR0FBRyxFQUFFO1lBQ3BCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUM1QztRQUNELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7O3NDQUtnQixPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTttQ0FDekIsY0FBYyxDQUFDLElBQUk7c0NBQ2hCLGNBQWMsQ0FBQyxPQUFPO3VDQUNyQixjQUFjLENBQUMsUUFBUTttQ0FDM0IsY0FBYyxDQUFDLElBQUk7MENBQ1osY0FBYyxDQUFDLFdBQVc7b0NBQ2hDLGNBQWMsQ0FBQyxLQUFLO3FDQUNuQixjQUFjLENBQUMsTUFBTTtzQ0FDcEIsY0FBYyxDQUFDLE9BQU87dUNBQ3JCLGNBQWMsQ0FBQyxRQUFRO1NBQ3JELENBQUM7UUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixjQUFjLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUV6RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztRQUN2RCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFDbkUsSUFBSSxFQUFFLEVBQUU7Z0JBQ0osY0FBYyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7YUFDM0I7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsY0FBYyxDQUFDLENBQUMsRUFDeEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLGNBQWMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQ3JFLENBQUM7SUFDTixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsb0JBQW9CLENBQUMsaUJBQXlCLEVBQUUsT0FBZ0I7UUFDNUQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFaEYsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7OEJBRVEsaUJBQWlCO3dCQUN2QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O1lBU3pDLENBQUM7UUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsaUJBQWlCLG1CQUFtQixDQUFDLENBQUM7UUFDckQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDL0QsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLHNCQUFzQixFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixDQUFDLENBQUMsRUFDbEgsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLHNCQUFzQixDQUFDLENBQUMsRUFDeEUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxpQkFBaUIsVUFBVSxDQUFDLENBQzVDLENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUNQLFdBQW1CLEVBQ25CLFVBQWtCLEVBQ2xCLGNBQXNCLEVBQ3RCLFdBQW1CLEVBQ25CLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt5Q0FDbUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVUsSUFBSSxjQUFjOytDQUNyRSxXQUFXOzs7Ozs7O01BT3BELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQztRQUVoRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQWlCLENBQUM7YUFDM0M7aUJBQU07Z0JBQ0gsT0FBTyxFQUFlLENBQUM7YUFDMUI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFDdkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQ2xGLENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxFQUFVLEVBQUUsT0FBZ0I7UUFDbEYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsVUFBVSxJQUFJLGNBQWM7MkRBQ3pELEVBQUU7Ozs7Ozs7TUFPdkQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDO1FBRWxFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFDbkQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBaUIsQ0FBQzthQUMzQztpQkFBTTtnQkFDSCxPQUFPLEVBQWUsQ0FBQzthQUMxQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixVQUFVLEtBQUssY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUNsRixDQUFDO0lBQ04sQ0FBQztJQUVELHFCQUFxQixDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxNQUFjLEVBQUUsT0FBZ0I7UUFDOUYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3lDQUNtQixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsVUFBVSxJQUFJLGNBQWM7MkRBQ3pELE1BQU07Ozs7Ozs7TUFPM0QsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDO1FBRTlFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztRQUMzRCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7Z0JBQ3JCLE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxJQUFpQixDQUFDO2FBQzNDO2lCQUFNO2dCQUNILE9BQU8sRUFBZSxDQUFDO2FBQzFCO1FBQ0wsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQzdGLENBQUM7SUFDTixDQUFDO0lBRUQsa0JBQWtCLENBQ2QsV0FBbUIsRUFDbkIsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsTUFBYyxFQUNkLElBQVksRUFDWixPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7eUNBQ21CLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLGtCQUFrQixVQUFVLElBQUksY0FBYzsyREFDekQsTUFBTSxxQkFBcUIsSUFBSTs7Ozs7OztNQU9wRixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUM7UUFFdkUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO1FBQ3hELENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQ2IsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtnQkFDckIsT0FBTyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQWlCLENBQUM7YUFDM0M7aUJBQU07Z0JBQ0gsT0FBTyxFQUFlLENBQUM7YUFDMUI7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsVUFBVSxLQUFLLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FDMUYsQ0FBQztJQUNOLENBQUM7SUFFRCx3QkFBd0IsQ0FBQyxVQUFrQixFQUFFLE9BQWdCO1FBQ3pELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRzt3Q0FDa0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLFVBQVU7Ozs7Ozs7OztNQVMzRixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUUxRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLDBCQUEwQixDQUFDLENBQUM7UUFDOUQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBaUIsQ0FBQzthQUMzQztpQkFBTTtnQkFDSCxPQUFPLEVBQWUsQ0FBQzthQUMxQjtRQUNMLENBQUMsQ0FBQyxFQUNGLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQ3BFLENBQUM7SUFDTixDQUFDO0lBRUQsNkRBQTZEO0lBQzdELFVBQVUsQ0FDTixXQUFtQixFQUNuQixVQUFrQixFQUNsQixjQUFzQixFQUN0QixPQUFrQixFQUNsQixTQUFpQjtRQUVqQixNQUFNLElBQUksS0FBSyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVELGdCQUFnQixDQUFDLE9BQWdCO1FBQzdCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFDL0MsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7OENBQ3dCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDOzs7Ozs7O01BT3JFLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNiLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDLEVBQ0YsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDYixJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO2dCQUNyQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBc0IsQ0FBQzthQUNoRDtpQkFBTTtnQkFDSCxPQUFPLEVBQW9CLENBQUM7YUFDL0I7UUFDTCxDQUFDLENBQUMsRUFDRixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQ2xELENBQUM7SUFDTixDQUFDO0lBRUQsNkRBQTZEO0lBQzdELGVBQWUsQ0FBQyxXQUFtQixFQUFFLFlBQTBCLEVBQUUsU0FBaUI7UUFDOUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCw2REFBNkQ7SUFDN0Qsa0JBQWtCLENBQUMsV0FBbUIsRUFBRSxnQkFBd0IsRUFBRSxTQUFpQjtRQUMvRSxNQUFNLElBQUksS0FBSyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVELHVCQUF1QixDQUFDLE9BQWdCO1FBQ3BDLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3ZCLElBQUksQ0FBQyxPQUFPO2dCQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQztTQUN2RDtJQUNMLENBQUM7SUFFRCxlQUFlLENBQUMsT0FBZ0I7UUFDNUIsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDdkIsT0FBTyxnQkFBZ0IsT0FBTyxJQUFJLENBQUM7U0FDdEM7YUFBTTtZQUNILE9BQU8saUJBQWlCLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLDBCQUEwQixDQUFDO1NBQzVFO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsY0FBYyxDQUFDLFFBQWEsRUFBRSxTQUFTLEdBQUcsV0FBVztRQUNqRCxJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxNQUFNLENBQUM7UUFFWCxJQUFJLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFO1lBQ3hCLFNBQVMsR0FBRyxJQUFJLENBQUM7WUFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFNBQVMsWUFBWSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ3ZFLE1BQU0sR0FBRyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUN6RDthQUFNLElBQUksUUFBUSxFQUFFLE1BQU0sRUFBRTtZQUN6QixTQUFTLEdBQUcsSUFBSSxDQUFDO1lBQ2pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLFlBQVksUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ2xFLE1BQU0sR0FBRyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQ3BEO1FBRUQsSUFBSSxTQUFTLEVBQUU7WUFDWCxNQUFNLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztTQUMzQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxpQkFBaUIsQ0FBQyxjQUE2QixFQUFFLFNBQWlCO1FBQzlELElBQUksY0FBYyxDQUFDLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDbkMsTUFBTSxHQUFHLEdBQUcsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUMzQyxPQUFPLEdBQUcsQ0FBQztTQUNkO1FBQ0QsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVELFdBQVcsQ0FBQyxVQUFrQixFQUFFLEdBQWdDLEVBQUUsT0FBZ0I7UUFDOUUsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNOLE1BQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDakU7UUFDRCxPQUFPO3lCQUNVLFVBQVUsY0FBYyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEdBQUc7OztRQUd0RixDQUFDO0lBQ0wsQ0FBQztJQUVELG1CQUFtQixDQUFDLFFBQWEsRUFBRSxTQUFpQixFQUFFLFVBQWtCLEVBQUUsR0FBZ0M7UUFDdEcsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNOLE1BQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDakU7UUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN6QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNuQyxNQUFNLGFBQWEsR0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUM3QyxJQUFJLGFBQWEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUM1QixPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sVUFBVSxZQUFZLEdBQUcsaUNBQWlDLENBQUMsQ0FBQztnQkFDL0UsTUFBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ3RFO1NBQ0o7SUFDTCxDQUFDO0NBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEYXRhU3RvcmUsIEdhdGV3YXksIFJlc3RFbmRwb2ludCwgTm90aWZpY2F0aW9uLCBQaXBlbGluZSwgUHJvdG9jb2wsIFB5dGhvblJlc291cmNlLCBSZWFkaW5nIH0gZnJvbSAnLi4vbW9kZWwvbW9kZWxzJztcbmltcG9ydCB7IG1hcCwgT2JzZXJ2YWJsZSwgc3dpdGNoTWFwLCB0YXAgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5cblxuY29uc3QgaHR0cE9wdGlvbnMgPSB7XG4gICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2dyYXBocWwrLScsXG4gICAgfSxcbn07XG5cbmNvbnN0IGh0dHBNdXRhdGVPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9yZGYnIH0sXG59O1xuXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgR3JhcGhTZXJ2aWNlIHtcbiAgICBcbiAgICBwcm90ZWN0ZWQgcmVxdWlyZUFjY291bnRJZCA9IHRydWU7XG4gICAgcHJvdGVjdGVkIGRHcmFwaFVybDogc3RyaW5nO1xuXG4gICAgY29uc3RydWN0b3IocHJvdGVjdGVkIGh0dHA6IEh0dHBDbGllbnQsIGRHcmFwaFVybDogc3RyaW5nLCBhY2NvdW50UmVxdWlyZWQ6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5kR3JhcGhVcmwgPSBkR3JhcGhVcmw7XG4gICAgICAgIHRoaXMucmVxdWlyZUFjY291bnRJZCA9IGFjY291bnRSZXF1aXJlZDtcbiAgICAgICAgLy9jb25zdCBkR3JhcGhCYXNpY0F1dGhFbmFibGVkID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aEVuYWJsZWQ7XG4gICAgICAgIC8vaWYgKGRHcmFwaEJhc2ljQXV0aEVuYWJsZWQpIHtcbiAgICAgICAgLy8gICAgY29uc3QgZEdyYXBoQmFzaWNBdXRoID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aDtcbiAgICAgICAgLy8gICAgKHRoaXMuaHR0cE9wdGlvbnMuaGVhZGVycyA9IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9ncmFwaHFsKy0nIH0pLCB7IEF1dGhvcml6YXRpb246IGRHcmFwaEJhc2ljQXV0aCB9O1xuICAgICAgICAvLyAgICAodGhpcy5odHRwTXV0YXRlT3B0aW9ucy5oZWFkZXJzID0geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3JkZicgfSksIHsgQXV0aG9yaXphdGlvbjogZEdyYXBoQmFzaWNBdXRoIH07XG4gICAgICAgIC8vfVxuICAgIH1cblxuICAgIGdldEdhdGV3YXkoZ2F0ZXdheVV1aWQ6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc29sZS5sb2coYEdldEdhdGV3YXkgc2VydmljZSBjYWxsZWQgZm9yICR7Z2F0ZXdheVV1aWR9YCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeT9kZWJ1Zz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5VXVpZH1cIikpIHtcbiAgICAgICAgdWlkIHV1aWQgZGVzY3JpcHRpb24gYWRkcmVzcyByb3V0ZXIgcm91dGVyUG9ydFxuICAgICAgICBkZXBsb3lOZXR3b3JrIGxhdGl0dWRlIGxvbmdpdHVkZSBhY2Nlc3NUb2tlbiB1c2VybmFtZVxuICAgICAgICBwbGF0Zm9ybSBkZXZpY2VzTWV0YWRhdGEgY3JlYXRlZHRzIHVwZGF0ZWR0c1xuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRHYXRld2F5Jyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlzKGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeT9kZWJ1Zz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpXG4gICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgIHVpZCB1dWlkIGRlc2NyaXB0aW9uIGFkZHJlc3Mgcm91dGVyIHJvdXRlclBvcnRcbiAgICAgICAgZGVwbG95TmV0d29yayBsYXRpdHVkZSBsb25naXR1ZGUgYWNjZXNzVG9rZW4gdXNlcm5hbWVcbiAgICAgICAgcGxhdGZvcm0gZGV2aWNlc01ldGFkYXRhIGNyZWF0ZWR0cyB1cGRhdGVkdHNcbiAgICAgICAgbnVtRGV2aWNlczogY291bnQoZ2F0ZXdheV9kZXZpY2UpXG4gICAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0R2F0ZXdheXMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCAke3Jlc3BvbnNlLmxlbmd0aH0gZ2F0ZXdheXNgKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlR2F0ZXdheShnYXRld2F5OiBHYXRld2F5LCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnZ2F0ZXdheScsIGdhdGV3YXkudWlkLCBhY2NvdW50KTtcblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtnYXRld2F5LnVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgICAgICB1aWQodikgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGFkZHJlc3M+IFwiJHtnYXRld2F5LmFkZHJlc3N9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cm91dGVyPiBcIiR7Z2F0ZXdheS5yb3V0ZXJ9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cm91dGVyUG9ydD4gXCIke2dhdGV3YXkucm91dGVyUG9ydH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxkZXBsb3lOZXR3b3JrPiBcIiR7Z2F0ZXdheS5kZXBsb3lOZXR3b3JrfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGRlc2NyaXB0aW9uPiBcIiR7Z2F0ZXdheS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxsYXRpdHVkZT4gXCIke2dhdGV3YXkubGF0aXR1ZGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8bG9uZ2l0dWRlPiBcIiR7Z2F0ZXdheS5sb25naXR1ZGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8YWNjZXNzVG9rZW4+IFwiJHtnYXRld2F5LmFjY2Vzc1Rva2VufVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVzZXJuYW1lPiBcIiR7Z2F0ZXdheS51c2VybmFtZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxwbGF0Zm9ybT4gXCIke2dhdGV3YXkucGxhdGZvcm19XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8dXBkYXRlZHRzPiBcIiR7Z2F0ZXdheS51cGRhdGVkdHN9XCIgLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgR2F0ZXdheSAke2dhdGV3YXkudXVpZH0gJHtnYXRld2F5LnVpZH1gKTtcblxuICAgICAgICAvLyBXaXRoIHRoZSB1cHNlcnQgYXBwcm9hY2gsIGl0IGlzIG5vdCBwb3NzaWJsZSB0byBzZWUgaWYgdGhlIG11dGF0aW9uIG9jY3VycmVkLlxuICAgICAgICAvLyBVc2UgYSBwcmVRdWVyeSBmb3IgdGhlIG9iamVjdCBmaXJzdCB0byBkZXRlcm1pbmUgaWYgaXQgZXhpc3RzLlxuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVHYXRld2F5JywgJ2dhdGV3YXknLCBnYXRld2F5LnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdGVHYXRld2F5JykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIGdhdGV3YXkgJHtnYXRld2F5LnV1aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+ICdnYXRld2F5IHVwZGF0ZWQnKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRHYXRld2F5KGdhdGV3YXk6IEdhdGV3YXksIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXk+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAoZ2F0ZXdheS51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpHYXRld2F5IDxkZ3JhcGgudHlwZT4gXCJHYXRld2F5XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGdhdGV3YXk+IFwiXCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHR5cGU+IFwiZ2F0ZXdheVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8dXVpZD4gXCIke2dhdGV3YXkudXVpZH1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8ZGVzY3JpcHRpb24+IFwiJHtnYXRld2F5LmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxhZGRyZXNzPiBcIiR7Z2F0ZXdheS5hZGRyZXNzfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxyb3V0ZXI+IFwiJHtnYXRld2F5LnJvdXRlcn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8cm91dGVyUG9ydD4gXCIke2dhdGV3YXkucm91dGVyUG9ydH1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8ZGVwbG95TmV0d29yaz4gXCIke2dhdGV3YXkuZGVwbG95TmV0d29ya31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8bGF0aXR1ZGU+IFwiJHtnYXRld2F5LmxhdGl0dWRlfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxsb25naXR1ZGU+IFwiJHtnYXRld2F5LmxvbmdpdHVkZX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8YWNjZXNzVG9rZW4+IFwiJHtnYXRld2F5LmFjY2Vzc1Rva2VufVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx1c2VybmFtZT4gXCIke2dhdGV3YXkudXNlcm5hbWV9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHBsYXRmb3JtPiBcIiR7Z2F0ZXdheS5wbGF0Zm9ybX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8Y3JlYXRlZHRzPiBcIiR7Z2F0ZXdheS5jcmVhdGVkdHN9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHVwZGF0ZWR0cz4gXCIke2dhdGV3YXkudXBkYXRlZHRzfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEFkZCBHYXRld2F5ICR7Z2F0ZXdheS51dWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRHYXRld2F5Jyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ0dhdGV3YXknKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZ2F0ZXdheS51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBnYXRld2F5KSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBnYXRld2F5ICR7Z2F0ZXdheS51aWR9LyR7Z2F0ZXdheS51dWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVHYXRld2F5KGdhdGV3YXlVdWlkOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdnYXRld2F5JywgZ2F0ZXdheVV1aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7Z2F0ZXdheVV1aWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIEdhdGV3YXkgJHtnYXRld2F5VXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAnZGVsZXRlR2F0ZXdheScsICdnYXRld2F5JywgZ2F0ZXdheVV1aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlR2F0ZXdheScpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZGVsZXRlZCBnYXRld2F5ICR7Z2F0ZXdheVV1aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke2dhdGV3YXlVdWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheUFuZFByb3RvY29scyhnYXRld2F5VXVpZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5VXVpZH1cIikpIHtcbiAgICAgICAgdWlkIHV1aWRcbiAgICAgICAgcHJvdG9jb2xzOiBnYXRld2F5X3Byb3RvY29sIHtcbiAgICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIHByb3RvY29sVHlwZSBicm9rZXJVUkxcbiAgICAgICAgICB0b3BpYyBjb25zdW1lckdyb3VwSWQgY29ubmVjdGlvblRpbWVvdXQgc2Vzc2lvblRpbWVvdXRcbiAgICAgICAgICBpbml0aWFsT2Zmc2V0IHJldHJ5QmFja09mZiBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdFxuICAgICAgICAgIGNvbW1pdEludGVydmFsIGhlYXJ0YmVhdEludGVydmFsIG1heGltdW1RT1NcbiAgICAgICAgICB1c2VybmFtZSBwYXNzd29yZCBlbmNyeXB0aW9uTW9kZVxuICAgICAgICAgIGNhQ2VydGlmaWNhdGUgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5XG4gICAgICAgICAgYXV0aE1vZGUgc2VydmVyQ2VydGlmaWNhdGVcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgR2V0IEdhdGV3YXkgYW5kIFByb3RvY29scyBmb3IgJHtnYXRld2F5VXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0R2F0ZXdheVdpdGhQcm90b2NvbHMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgR2F0ZXdheSBhbmQgUHJvdG9jb2xzIGZvciAke2dhdGV3YXlVdWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgYWxsIGdsb2JhbCBwcm90b2NvbHMgYW5kIHRoZSBwcm90b2NvbHMgc2NvcGVkIGZvciB0aGUgZ2F0ZXdheVxuICAgICAqIEBwYXJhbSBnYXRld2F5VXVpZFxuICAgICAqIEBwYXJhbSBhY2NvdW50XG4gICAgICovXG4gICAgZ2V0UHJvdG9jb2xzKGdhdGV3YXlVdWlkOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFByb3RvY29sW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMocHJvdG9jb2wpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoXG4gICAgICAgICAgYWNjb3VudCxcbiAgICAgICl9IEFORCAoZXEoc2NvcGUsIFwiJHtnYXRld2F5VXVpZH1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSkge1xuICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIHByb3RvY29sVHlwZSBicm9rZXJVUkwgdG9waWNcbiAgICAgICAgY29uc3VtZXJHcm91cElkIGNvbm5lY3Rpb25UaW1lb3V0IHNlc3Npb25UaW1lb3V0IGluaXRpYWxPZmZzZXRcbiAgICAgICAgcmV0cnlCYWNrT2ZmIGZldGNoTWluQnl0ZXMgZmV0Y2hNYXhXYWl0IGNvbW1pdEludGVydmFsXG4gICAgICAgIGhlYXJ0YmVhdEludGVydmFsIG1heGltdW1RT1MgdXNlcm5hbWUgcGFzc3dvcmRcbiAgICAgICAgZW5jcnlwdGlvbk1vZGUgY2FDZXJ0aWZpY2F0ZSBjbGllbnRDZXJ0aWZpY2F0ZSBjbGllbnRLZXlcbiAgICAgICAgYXV0aE1vZGUgc2VydmVyQ2VydGlmaWNhdGUgc2NvcGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UHJvdG9jb2xzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBQcm90b2NvbFtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBwcm90b2NvbHMgZm9yICR7Z2F0ZXdheVV1aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZFByb3RvY29sKGdhdGV3YXlVaWQ6IHN0cmluZywgcHJvdG9jb2w6IFByb3RvY29sLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQcm90b2NvbD4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGlmIChwcm90b2NvbC51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpQcm90b2NvbCA8ZGdyYXBoLnR5cGU+IFwiUHJvdG9jb2xcIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHR5cGU+IFwicHJvdG9jb2xcIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHByb3RvY29sPiBcIlwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDx1dWlkPiBcIiR7cHJvdG9jb2wudXVpZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNyZWF0ZWQ+IFwiJHtwcm90b2NvbC5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8bW9kaWZpZWQ+IFwiJHtwcm90b2NvbC5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHByb3RvY29sVHlwZT4gXCIke3Byb3RvY29sLnByb3RvY29sVHlwZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGJyb2tlclVSTD4gXCIke3Byb3RvY29sLmJyb2tlclVSTH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHRvcGljPiBcIiR7cHJvdG9jb2wudG9waWN9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjb25zdW1lckdyb3VwSWQ+IFwiJHtwcm90b2NvbC5jb25zdW1lckdyb3VwSWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjb25uZWN0aW9uVGltZW91dD4gXCIke3Byb3RvY29sLmNvbm5lY3Rpb25UaW1lb3V0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8c2Vzc2lvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5zZXNzaW9uVGltZW91dH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGluaXRpYWxPZmZzZXQ+IFwiJHtwcm90b2NvbC5pbml0aWFsT2Zmc2V0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8cmV0cnlCYWNrT2ZmPiBcIiR7cHJvdG9jb2wucmV0cnlCYWNrT2ZmfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8ZmV0Y2hNaW5CeXRlcz4gXCIke3Byb3RvY29sLmZldGNoTWluQnl0ZXN9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxmZXRjaE1heFdhaXQ+IFwiJHtwcm90b2NvbC5mZXRjaE1heFdhaXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjb21taXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmNvbW1pdEludGVydmFsfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8aGVhcnRiZWF0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5oZWFydGJlYXRJbnRlcnZhbH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPG1heGltdW1RT1M+IFwiJHtwcm90b2NvbC5tYXhpbXVtUU9TfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8dXNlcm5hbWU+IFwiJHtwcm90b2NvbC51c2VybmFtZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHBhc3N3b3JkPiBcIiR7cHJvdG9jb2wucGFzc3dvcmR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxlbmNyeXB0aW9uTW9kZT4gXCIke3Byb3RvY29sLmVuY3J5cHRpb25Nb2RlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y2FDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLmNhQ2VydGlmaWNhdGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjbGllbnRDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLmNsaWVudENlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y2xpZW50S2V5PiBcIiR7cHJvdG9jb2wuY2xpZW50S2V5fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8YXV0aE1vZGU+IFwiJHtwcm90b2NvbC5hdXRoTW9kZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHNlcnZlckNlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuc2VydmVyQ2VydGlmaWNhdGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxzY29wZT4gXCIke3Byb3RvY29sLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEFkZCBwcm90b2NvbCAke3Byb3RvY29sLnV1aWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2FkZFByb3RvY29sJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ1Byb3RvY29sJyk7XG4gICAgICAgICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHByb3RvY29sLnVpZCA9IGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IHByb3RvY29sKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBwcm90b2NvbHMgJHtwcm90b2NvbC51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZVByb3RvY29sKHByb3RvY29sOiBQcm90b2NvbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2w+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncHJvdG9jb2wnLCBwcm90b2NvbC51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cHJvdG9jb2wudWlkfSkpXG4gICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbXV0YXRpb24gQGlmIChlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgIHVpZCh2KSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx1dWlkPiBcIiR7cHJvdG9jb2wudXVpZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPG1vZGlmaWVkPiBcIiR7cHJvdG9jb2wubW9kaWZpZWR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxwcm90b2NvbFR5cGU+IFwiJHtwcm90b2NvbC5wcm90b2NvbFR5cGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxicm9rZXJVUkw+IFwiJHtwcm90b2NvbC5icm9rZXJVUkx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDx0b3BpYz4gXCIke3Byb3RvY29sLnRvcGljfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y29uc3VtZXJHcm91cElkPiBcIiR7cHJvdG9jb2wuY29uc3VtZXJHcm91cElkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y29ubmVjdGlvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5jb25uZWN0aW9uVGltZW91dH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHNlc3Npb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuc2Vzc2lvblRpbWVvdXR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxpbml0aWFsT2Zmc2V0PiBcIiR7cHJvdG9jb2wuaW5pdGlhbE9mZnNldH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHJldHJ5QmFja09mZj4gXCIke3Byb3RvY29sLnJldHJ5QmFja09mZn1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGZldGNoTWluQnl0ZXM+IFwiJHtwcm90b2NvbC5mZXRjaE1pbkJ5dGVzfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8ZmV0Y2hNYXhXYWl0PiBcIiR7cHJvdG9jb2wuZmV0Y2hNYXhXYWl0fVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y29tbWl0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5jb21taXRJbnRlcnZhbH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGhlYXJ0YmVhdEludGVydmFsPiBcIiR7cHJvdG9jb2wuaGVhcnRiZWF0SW50ZXJ2YWx9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxtYXhpbXVtUU9TPiBcIiR7cHJvdG9jb2wubWF4aW11bVFPU31cIiAuXG4gICAgICAgICAgICB1aWQodikgPHVzZXJuYW1lPiBcIiR7cHJvdG9jb2wudXNlcm5hbWV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxwYXNzd29yZD4gXCIke3Byb3RvY29sLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8ZW5jcnlwdGlvbk1vZGU+IFwiJHtwcm90b2NvbC5lbmNyeXB0aW9uTW9kZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNhQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jYUNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y2xpZW50Q2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jbGllbnRDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGNsaWVudEtleT4gXCIke3Byb3RvY29sLmNsaWVudEtleX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGF1dGhNb2RlPiBcIiR7cHJvdG9jb2wuYXV0aE1vZGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxzZXJ2ZXJDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLnNlcnZlckNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8c2NvcGU+IFwiJHtwcm90b2NvbC5zY29wZX1cIiAuXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGUgJHtwcm90b2NvbC51aWR9YCk7XG5cbiAgICAgICAgLy8gV2l0aCB0aGUgdXBzZXJ0IGFwcHJvYWNoLCBpdCBpcyBub3QgcG9zc2libGUgdG8gc2VlIGlmIHRoZSBtdXRhdGlvbiBvY2N1cnJlZC5cbiAgICAgICAgLy8gVXNlIGEgcHJlUXVlcnkgZm9yIHRoZSBvYmplY3QgZmlyc3QgdG8gZGV0ZXJtaW5lIGlmIGl0IGV4aXN0cy5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ3VwZGF0ZVByb3RvY29sJywgJ3Byb3RvY29sJywgcHJvdG9jb2wudWlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ3VwZGF0ZVByb3RvY29sJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGB1cGRhdGVkIHByb3RvY29sICR7cHJvdG9jb2wudWlkfWApKSxcbiAgICAgICAgICAgIG1hcCgoKSA9PiBwcm90b2NvbCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlUHJvdG9jb2woZ2F0ZXdheVVpZDogc3RyaW5nLCBwcm90b2NvbFVpZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncHJvdG9jb2wnLCBwcm90b2NvbFVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtwcm90b2NvbFVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgZGVsZXRlIHtcbiAgICAgICAgICAgICAgICB1aWQodikgKiAqIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIFByb3RvY29sICR7cHJvdG9jb2xVaWR9IGZvciAke2dhdGV3YXlVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZVByb3RvY29sJywgJ3Byb3RvY29sJywgcHJvdG9jb2xVaWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlUHJvdG9jb2wnKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gYCR7cHJvdG9jb2xVaWR9IGRlbGV0ZWRgKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXREYXRhU3RvcmVzKGdhdGV3YXlVdWlkOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERhdGFTdG9yZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGRhdGFTdG9yZSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShcbiAgICAgICAgICBhY2NvdW50LFxuICAgICAgKX0gQU5EIChlcShzY29wZSwgXCIke2dhdGV3YXlVdWlkfVwiKSBPUiBlcShzY29wZSwgXCJHTE9CQUxcIikpKSB7XG4gICAgICAgIHVpZCB1dWlkIGNyZWF0ZWQgbW9kaWZpZWQgZGF0YVN0b3JlVHlwZVxuICAgICAgICBob3N0IHBvcnQgZGF0YWJhc2VOYW1lIHVzZXIgcGFzc3dvcmQgYWNjb3VudE5hbWVcbiAgICAgICAgd2FyZWhvdXNlIGRhdGFiYXNlIHNjaGVtYSBhdXRoVHlwZSB1c2VybmFtZVxuICAgICAgICBjbGllbnRJZCBjbGllbnRTZWNyZXQgYXV0aG9yaXphdGlvbkNvZGVcbiAgICAgICAgcmVkaXJlY3RVUkkgbG9naW5UaW1lb3V0IHVybCBzY29wZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXREYXRhU3RvcmVzJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBEYXRhU3RvcmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgZGF0YVN0b3JlcyBmb3IgZ2F0ZXdheSAke2dhdGV3YXlVdWlkfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGREYXRhU3RvcmUoZ2F0ZXdheVVpZDogc3RyaW5nLCBkYXRhU3RvcmU6IERhdGFTdG9yZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8RGF0YVN0b3JlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKGRhdGFTdG9yZS51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpEYXRhU3RvcmUgPGRncmFwaC50eXBlPiBcIkRhdGFTdG9yZVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHR5cGU+IFwiZGF0YVN0b3JlXCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YVN0b3JlPiBcIlwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHV1aWQ+IFwiJHtkYXRhU3RvcmUudXVpZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjcmVhdGVkPiBcIiR7ZGF0YVN0b3JlLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8bW9kaWZpZWQ+IFwiJHtkYXRhU3RvcmUubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YVN0b3JlVHlwZT4gXCIke2RhdGFTdG9yZS5kYXRhU3RvcmVUeXBlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGhvc3Q+IFwiJHtkYXRhU3RvcmUuaG9zdH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxwb3J0PiBcIiR7ZGF0YVN0b3JlLnBvcnR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YWJhc2VOYW1lPiBcIiR7ZGF0YVN0b3JlLmRhdGFiYXNlTmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1c2VyPiBcIiR7ZGF0YVN0b3JlLnVzZXJ9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8cGFzc3dvcmQ+IFwiJHtkYXRhU3RvcmUucGFzc3dvcmR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8YWNjb3VudE5hbWU+IFwiJHtkYXRhU3RvcmUuYWNjb3VudE5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8d2FyZWhvdXNlPiBcIiR7ZGF0YVN0b3JlLndhcmVob3VzZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxkYXRhYmFzZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8c2NoZW1hPiBcIiR7ZGF0YVN0b3JlLnNjaGVtYX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhdXRoVHlwZT4gXCIke2RhdGFTdG9yZS5hdXRoVHlwZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1c2VybmFtZT4gXCIke2RhdGFTdG9yZS51c2VybmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjbGllbnRJZD4gXCIke2RhdGFTdG9yZS5jbGllbnRJZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjbGllbnRTZWNyZXQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50U2VjcmV0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGF1dGhvcml6YXRpb25Db2RlPiBcIiR7ZGF0YVN0b3JlLmF1dGhvcml6YXRpb25Db2RlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHJlZGlyZWN0VVJJPiBcIiR7ZGF0YVN0b3JlLnJlZGlyZWN0VVJJfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGxvZ2luVGltZW91dD4gXCIke2RhdGFTdG9yZS5sb2dpblRpbWVvdXR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXJsPiBcIiR7ZGF0YVN0b3JlLnVybH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxzY29wZT4gXCIke2RhdGFTdG9yZS5zY29wZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGRlZCBkYXRhc3RvcmUgJHtkYXRhU3RvcmUudXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkRGF0YVN0b3JlJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZCA9IHRoaXMuZ2V0SURGcm9tUmVzcG9uc2UocmVzcG9uc2UuZGF0YSwgJ0RhdGFTdG9yZScpO1xuICAgICAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgICAgICBkYXRhU3RvcmUudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gZGF0YVN0b3JlKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGFkZCBkYXRhU3RvcmVzICR7ZGF0YVN0b3JlLnVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlRGF0YVN0b3JlKGRhdGFTdG9yZTogRGF0YVN0b3JlLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxEYXRhU3RvcmU+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnZGF0YVN0b3JlJywgZGF0YVN0b3JlLnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke2RhdGFTdG9yZS51aWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgICAgdXVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBzZXQge1xuICAgICAgICAgICAgICAgIHVpZCh2KSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8dXVpZD4gXCIke2RhdGFTdG9yZS51dWlkfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPG1vZGlmaWVkPiBcIiR7ZGF0YVN0b3JlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGRhdGFTdG9yZVR5cGU+IFwiJHtkYXRhU3RvcmUuZGF0YVN0b3JlVHlwZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxob3N0PiBcIiR7ZGF0YVN0b3JlLmhvc3R9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8cG9ydD4gXCIke2RhdGFTdG9yZS5wb3J0fVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGRhdGFiYXNlTmFtZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8dXNlcj4gXCIke2RhdGFTdG9yZS51c2VyfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHBhc3N3b3JkPiBcIiR7ZGF0YVN0b3JlLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPGFjY291bnROYW1lPiBcIiR7ZGF0YVN0b3JlLmFjY291bnROYW1lfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHdhcmVob3VzZT4gXCIke2RhdGFTdG9yZS53YXJlaG91c2V9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8ZGF0YWJhc2U+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHNjaGVtYT4gXCIke2RhdGFTdG9yZS5zY2hlbWF9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8YXV0aFR5cGU+IFwiJHtkYXRhU3RvcmUuYXV0aFR5cGV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8dXNlcm5hbWU+IFwiJHtkYXRhU3RvcmUudXNlcm5hbWV9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8Y2xpZW50SWQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50SWR9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8Y2xpZW50U2VjcmV0PiBcIiR7ZGF0YVN0b3JlLmNsaWVudFNlY3JldH1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxhdXRob3JpemF0aW9uQ29kZT4gXCIke2RhdGFTdG9yZS5hdXRob3JpemF0aW9uQ29kZX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxyZWRpcmVjdFVSST4gXCIke2RhdGFTdG9yZS5yZWRpcmVjdFVSSX1cIiAuXG4gICAgICAgICAgICAgICAgdWlkKHYpIDxsb2dpblRpbWVvdXQ+IFwiJHtkYXRhU3RvcmUubG9naW5UaW1lb3V0fVwiIC5cbiAgICAgICAgICAgICAgICB1aWQodikgPHVybD4gXCIke2RhdGFTdG9yZS51cmx9XCIgLlxuICAgICAgICAgICAgICAgIHVpZCh2KSA8c2NvcGU+IFwiJHtkYXRhU3RvcmUuc2NvcGV9XCIgLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSBkYXRhU3RvcmUgJHtkYXRhU3RvcmUudWlkfWApO1xuXG4gICAgICAgIC8vIFdpdGggdGhlIHVwc2VydCBhcHByb2FjaCwgaXQgaXMgbm90IHBvc3NpYmxlIHRvIHNlZSBpZiB0aGUgbXV0YXRpb24gb2NjdXJyZWQuXG4gICAgICAgIC8vIFVzZSBhIHByZVF1ZXJ5IGZvciB0aGUgb2JqZWN0IGZpcnN0IHRvIGRldGVybWluZSBpZiBpdCBleGlzdHMuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVEYXRhU3RvcmUnLCAnZGF0YVN0b3JlJywgZGF0YVN0b3JlLnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdGVEYXRhU3RvcmUnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZGF0YVN0b3JlICR7ZGF0YVN0b3JlLnVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gZGF0YVN0b3JlKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVEYXRhU3RvcmUoZ2F0ZXdheVV1aWQ6IHN0cmluZywgZGF0YVN0b3JlVXVpZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnZGF0YVN0b3JlJywgZGF0YVN0b3JlVXVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtkYXRhU3RvcmVVdWlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBkZWxldGUge1xuICAgICAgICAgICAgICAgIHVpZCh2KSAqICogLlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBEZWxldGUgRGF0YVN0b3JlICR7ZGF0YVN0b3JlVXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAnZGVsZXRlRGF0YVN0b3JlJywgJ2RhdGFTdG9yZScsIGRhdGFTdG9yZVV1aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlRGF0YVN0b3JlJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIGRhdGFTdG9yZSAke2RhdGFTdG9yZVV1aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke2RhdGFTdG9yZVV1aWR9IGRlbGV0ZWRgKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRHYXRld2F5QW5kUmVzdEVuZHBvaW50cyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWRcbiAgICAgICAgbW9kZWxzOiBnYXRld2F5X21vZGVsIHtcbiAgICAgICAgICB1aWQgdXVpZCBjcmVhdGVkIG1vZGlmaWVkIG5hbWVcbiAgICAgICAgICBkZXNjcmlwdGlvbiBpbnB1dFR5cGUgdXJsIHNjb3BlXG4gICAgICAgICAgaW5wdXRUZW1wbGF0ZSBoZWFkZXJzIG1ldGhvZCBiYXNlNjRFbmNvZGVkXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYEdldCBHYXRld2F5IGFuZCBQcm90b2NvbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldEdhdGV3YXlBbmRNb2RlbHMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgZ2F0ZXdheXMgYW5kIG1vZGVscyBmb3IgJHtnYXRld2F5TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVzdEVuZHBvaW50cyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxSZXN0RW5kcG9pbnRbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhtb2RlbCkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShcbiAgICAgICAgICBhY2NvdW50LFxuICAgICAgKX0gQU5EIChlcShzY29wZSwgXCIke2dhdGV3YXlOYW1lfVwiKSBPUiBlcShzY29wZSwgXCJHTE9CQUxcIikpKSB7XG4gICAgICAgIHVpZCB1dWlkIGNyZWF0ZWQgbW9kaWZpZWQgbmFtZVxuICAgICAgICBkZXNjcmlwdGlvbiBpbnB1dFR5cGUgdXJsIHNjb3BlIGlucHV0VGVtcGxhdGVcbiAgICAgICAgaGVhZGVycyBtZXRob2QgYmFzZTY0RW5jb2RlZFxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRNb2RlbHMnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFJlc3RFbmRwb2ludFtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBtb2RlbHMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZFJlc3RFbmRwb2ludChnYXRld2F5VWlkOiBzdHJpbmcsIG1vZGVsOiBSZXN0RW5kcG9pbnQsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFJlc3RFbmRwb2ludD4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGlmIChtb2RlbC51aWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGFkZCB3aXRoIGFuIElEJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpNb2RlbCA8ZGdyYXBoLnR5cGU+IFwiTW9kZWxcIiAuXG4gICAgICAgIF86TW9kZWwgPHR5cGU+IFwibW9kZWxcIiAuXG4gICAgICAgIF86TW9kZWwgPG1vZGVsPiBcIlwiIC5cbiAgICAgICAgXzpNb2RlbCA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOk1vZGVsIDx1dWlkPiBcIiR7bW9kZWwudXVpZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPGNyZWF0ZWQ+IFwiJHttb2RlbC5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8bW9kaWZpZWQ+IFwiJHttb2RlbC5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPG5hbWU+IFwiJHttb2RlbC5uYW1lfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8ZGVzY3JpcHRpb24+IFwiJHttb2RlbC5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIF86TW9kZWwgPGlucHV0VHlwZT4gXCIke21vZGVsLmlucHV0VHlwZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPHVybD4gXCIke21vZGVsLnVybH1cIiAuXG4gICAgICAgIF86TW9kZWwgPHNjb3BlPiBcIiR7bW9kZWwuc2NvcGV9XCIgLlxuICAgICAgICBfOk1vZGVsIDxpbnB1dFRlbXBsYXRlPiBcIiR7bW9kZWwuaW5wdXRUZW1wbGF0ZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPGhlYWRlcnM+IFwiJHttb2RlbC5oZWFkZXJzfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8bWV0aG9kPiBcIiR7bW9kZWwubWV0aG9kfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8YmFzZTY0RW5jb2RlZD4gXCIke21vZGVsLmJhc2U2NEVuY29kZWR9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgQWRkIG1vZGVsICR7bW9kZWwudXVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnYWRkTW9kZWwnKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkID0gdGhpcy5nZXRJREZyb21SZXNwb25zZShyZXNwb25zZS5kYXRhLCAnTW9kZWwnKTtcbiAgICAgICAgICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgbW9kZWwudWlkID0gaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gbW9kZWwpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgYWRkZWQgbW9kZWwgJHttb2RlbC51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZVJlc3RFbmRwb2ludChtb2RlbDogUmVzdEVuZHBvaW50LCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxSZXN0RW5kcG9pbnQ+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnbW9kZWwnLCBtb2RlbC51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7bW9kZWwudWlkfSkpXG4gICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICBzZXQge1xuICAgICAgICAgICAgdWlkKHYpIDxhY2NvdW50PiBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIiAuXG4gICAgICAgICAgICB1aWQodikgPHV1aWQ+IFwiJHttb2RlbC51dWlkfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bW9kaWZpZWQ+IFwiJHttb2RlbC5tb2RpZmllZH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPG5hbWU+IFwiJHttb2RlbC5uYW1lfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8ZGVzY3JpcHRpb24+IFwiJHttb2RlbC5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGlucHV0VHlwZT4gXCIke21vZGVsLmlucHV0VHlwZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHVybD4gXCIke21vZGVsLnVybH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHNjb3BlPiBcIiR7bW9kZWwuc2NvcGV9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxpbnB1dFRlbXBsYXRlPiBcIiR7bW9kZWwuaW5wdXRUZW1wbGF0ZX1cIiAuXG4gICAgICAgICAgICB1aWQodikgPGhlYWRlcnM+IFwiJHttb2RlbC5oZWFkZXJzfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bWV0aG9kPiBcIiR7bW9kZWwubWV0aG9kfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8YmFzZTY0RW5jb2RlZD4gXCIke21vZGVsLmJhc2U2NEVuY29kZWR9XCIgLlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZSBtb2RlbCAke21vZGVsLnVpZH1gKTtcblxuICAgICAgICAvLyBXaXRoIHRoZSB1cHNlcnQgYXBwcm9hY2gsIGl0IGlzIG5vdCBwb3NzaWJsZSB0byBzZWUgaWYgdGhlIG11dGF0aW9uIG9jY3VycmVkLlxuICAgICAgICAvLyBVc2UgYSBwcmVRdWVyeSBmb3IgdGhlIG9iamVjdCBmaXJzdCB0byBkZXRlcm1pbmUgaWYgaXQgZXhpc3RzLlxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlTW9kZWwnLCAnbW9kZWwnLCBtb2RlbC51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlTW9kZWwnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgbW9kZWwgJHttb2RlbC51aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IG1vZGVsKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVSZXN0RW5kcG9pbnQoZ2F0ZXdheVVpZDogc3RyaW5nLCBtb2RlbFVpZDogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgnbW9kZWwnLCBtb2RlbFVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHttb2RlbFVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgZGVsZXRlIHtcbiAgICAgICAgICAgICAgICB1aWQodikgKiAqIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlIE1vZGVsICR7bW9kZWxVaWR9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZU1vZGVsJywgJ21vZGVsJywgbW9kZWxVaWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlTW9kZWwnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGRlbGV0ZWQgbW9kZWwgJHttb2RlbFVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gYCR7bW9kZWxVaWR9IGRlbGV0ZWRgKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRHYXRld2F5QW5kUGlwZWxpbmVzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3Byb3RvY29sID0gYHByb3RvY29sOiBwaXBlbGluZV9wcm90b2NvbCB7XG4gICAgICAgIHVpZCB1dWlkIGJyb2tlclVSTCB0b3BpYyBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGVcbiAgICAgICAgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5IGF1dGhNb2RlIHNlcnZlckNlcnRpZmljYXRlIGNvbnN1bWVyR3JvdXBJZCBjb25uZWN0aW9uVGltZW91dFxuICAgICAgICBzZXNzaW9uVGltZW91dCByZXRyeUJhY2tPZmYgY29tbWl0SW50ZXJ2YWwgaW5pdGlhbE9mZnNldCBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdCBoZWFydGJlYXRJbnRlcnZhbFxuICAgICAgfWA7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2RhdGFzdG9yZSA9IGBkYXRhU3RvcmU6IHBpcGVsaW5lX2RhdGFzdG9yZSB7XG4gICAgICAgIHVpZCB1dWlkIGhvc3QgcG9ydCBkYXRhYmFzZU5hbWUgdXNlciBwYXNzd29yZCBhY2NvdW50TmFtZSB3YXJlaG91c2UgZGF0YWJhc2Ugc2NoZW1hIGF1dGhUeXBlXG4gICAgICAgIHVzZXJuYW1lIGNsaWVudElkIGNsaWVudFNlY3JldCBhdXRob3JpemF0aW9uQ29kZSByZWRpcmVjdFVSSSBsb2dpblRpbWVvdXQgdXJsXG4gICAgICB9YDtcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZmlsdGVyID0gJ2ZpbHRlcjogcGlwZWxpbmVfZmlsdGVyIHsgdWlkIGRldmljZU5hbWVzIH0nO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9zdHJlYW1pbmcgPVxuICAgICAgICAgICAgJ3N0cmVhbWluZzogcGlwZWxpbmVfc3RyZWFtaW5nIHsgdWlkIGRldmljZU5hbWUgaW5zdHJ1bWVudE5hbWUgZnVuY3Rpb24gd2luZG93VHlwZSB3aW5kb3dTaXplIH0nO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkIGFjY2Vzc1Rva2VuIHVzZXJuYW1lIHBsYXRmb3JtIGFkZHJlc3Mgcm91dGVyIHJvdXRlclBvcnQgZGVwbG95TmV0d29yayBkZXZpY2VzTWV0YWRhdGFcbiAgICAgICAgcGlwZWxpbmVzOiBnYXRld2F5X3BpcGVsaW5lIHtcbiAgICAgICAgICB1aWQgbmFtZSB1dWlkIHBpcGVsaW5lVHlwZSBkZXBsb3llclR5cGUgcHJvdG9jb2xUeXBlIHByb3RvY29sSWQgZGF0YVN0b3JlVHlwZVxuICAgICAgICAgIGRhdGFTdG9yZUlkIGNyZWF0ZWQgbW9kaWZpZWQgZGVzY3JpcHRpb24gc3RhdHVzIGZsb3dDb25maWd1cmF0aW9uXG4gICAgICAgICAgbG9nTGV2ZWwgc3Vic2NyaXB0aW9uVG9waWMgcmVxdWlyZW1lbnQgY29uZmlndXJhdGlvbkZpbGVcbiAgICAgICAgICAke3BpcGVsaW5lX3Byb3RvY29sfVxuICAgICAgICAgICR7cGlwZWxpbmVfZGF0YXN0b3JlfVxuICAgICAgICAgICR7cGlwZWxpbmVfZmlsdGVyfVxuICAgICAgICAgICR7cGlwZWxpbmVfc3RyZWFtaW5nfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBHZXQgR2F0ZXdheSBhbmQgUGlwZWxpbmVzIGZvciAke2dhdGV3YXlOYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRHYXRld2F5V2l0aFBpcGVsaW5lcycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBHYXRld2F5IGFuZCBwaXBlbGluZXMgZm9yICR7Z2F0ZXdheU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFBpcGVsaW5lcyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcGlwZWxpbmVfcHJvdG9jb2wgPSBgcHJvdG9jb2w6IHBpcGVsaW5lX3Byb3RvY29sIHtcbiAgICAgICAgICAgICAgdWlkIGJyb2tlclVSTCB0b3BpYyBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGVcbiAgICAgICAgICAgICAgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5IGF1dGhNb2RlIHNlcnZlckNlcnRpZmljYXRlIGNvbnN1bWVyR3JvdXBJZCBjb25uZWN0aW9uVGltZW91dFxuICAgICAgICAgICAgICBzZXNzaW9uVGltZW91dCByZXRyeUJhY2tPZmYgY29tbWl0SW50ZXJ2YWwgaW5pdGlhbE9mZnNldCBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdCBoZWFydGJlYXRJbnRlcnZhbFxuICB9IGA7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2RhdGFzdG9yZSA9IGBkYXRhc3RvcmU6IHBpcGVsaW5lX2RhdGFzdG9yZSB7XG4gICAgICAgICAgICAgIHVpZCBob3N0IHBvcnQgZGF0YWJhc2VOYW1lIHVzZXIgcGFzc3dvcmQgYWNjb3VudE5hbWUgd2FyZWhvdXNlIGRhdGFiYXNlIHNjaGVtYSBhdXRoVHlwZVxuICAgICAgICAgICAgICB1c2VybmFtZSBjbGllbnRJZCBjbGllbnRTZWNyZXQgYXV0aG9yaXphdGlvbkNvZGUgcmVkaXJlY3RVUkkgbG9naW5UaW1lb3V0IHVybFxuICAgICAgICAgICAgfWA7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2ZpbHRlciA9ICdmaWx0ZXI6IHBpcGVsaW5lX2ZpbHRlciB7dWlkIGRldmljZU5hbWVzfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3N0cmVhbWluZyA9XG4gICAgICAgICAgICAnc3RyZWFtaW5nOiBwaXBlbGluZV9zdHJlYW1pbmcge3VpZCBkZXZpY2VOYW1lIGluc3RydW1lbnROYW1lIGZ1bmN0aW9uIHdpbmRvd1R5cGUgd2luZG93U2l6ZX0nO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EIGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgcGlwZWxpbmVzIGFzIGdhdGV3YXlfcGlwZWxpbmUge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZCBuYW1lIHV1aWQgcGlwZWxpbmVUeXBlIGRlcGxveWVyVHlwZSBwcm90b2NvbFR5cGUgcHJvdG9jb2xJZFxuICAgICAgICBkYXRhU3RvcmVUeXBlIGRhdGFTdG9yZUlkIGNyZWF0ZWQgbW9kaWZpZWQgZGVzY3JpcHRpb24gc3RhdHVzXG4gICAgICAgIGZsb3dDb25maWd1cmF0aW9uIGxvZ0xldmVsIHN1YnNjcmlwdGlvblRvcGljIHJlcXVpcmVtZW50IGNvbmZpZ3VyYXRpb25GaWxlXG4gICAgICAgICR7cGlwZWxpbmVfcHJvdG9jb2x9XG4gICAgICAgICR7cGlwZWxpbmVfZGF0YXN0b3JlfVxuICAgICAgICAke3BpcGVsaW5lX2ZpbHRlcn1cbiAgICAgICAgJHtwaXBlbGluZV9zdHJlYW1pbmd9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFBpcGVsaW5lcycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUGlwZWxpbmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcGlwZWxpbmVzIGZvciAke2dhdGV3YXlOYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRQaXBlbGluZShcbiAgICAgICAgZ2F0ZXdheVVpZDogc3RyaW5nLFxuICAgICAgICBwaXBlbGluZTogUGlwZWxpbmUsXG4gICAgICAgIHRyYW5zcG9ydE9iaj86IGFueSxcbiAgICAgICAgZGF0YVN0b3JlT2JqPzogYW55LFxuICAgICAgICBmaWx0ZXJPYmo/OiBhbnksXG4gICAgICAgIHN0cmVhbWluZ09iaj86IGFueSxcbiAgICAgICAgYWNjb3VudD86IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPFBpcGVsaW5lPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgaWYgKHBpcGVsaW5lLnVpZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgYWRkIHdpdGggYW4gSUQnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICBfOlBpcGVsaW5lIDxkZ3JhcGgudHlwZT4gXCJQaXBlbGluZVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxuYW1lPiBcIiR7cGlwZWxpbmUubmFtZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHV1aWQ+IFwiJHtwaXBlbGluZS5uYW1lfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8dHlwZT4gXCJwaXBlbGluZVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8cGlwZWxpbmU+IFwiXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxwaXBlbGluZVR5cGU+IFwiJHtwaXBlbGluZS5waXBlbGluZVR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXBsb3llclR5cGU+IFwiJHtwaXBlbGluZS5kZXBsb3llclR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxjcmVhdGVkPiBcIiR7cGlwZWxpbmUuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXNjcmlwdGlvbj4gXCIke3BpcGVsaW5lLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8c3RhdHVzPiBcIiR7cGlwZWxpbmUuc3RhdHVzfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGxvZ0xldmVsPiBcIiR7cGlwZWxpbmUubG9nTGV2ZWx9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxzdWJzY3JpcHRpb25Ub3BpYz4gXCIke3BpcGVsaW5lLnN1YnNjcmlwdGlvblRvcGljfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8cmVxdWlyZW1lbnQ+IFwiJHtwaXBlbGluZS5yZXF1aXJlbWVudH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGNvbmZpZ3VyYXRpb25GaWxlPiBcIiR7cGlwZWxpbmUuY29uZmlndXJhdGlvbkZpbGV9XCIgLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfcGlwZWxpbmU+IF86UGlwZWxpbmUgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgYWRkIFBpcGVsaW5lICR7cGlwZWxpbmUudWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRQaXBlbGluZScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdQaXBlbGluZScpO1xuICAgICAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgICAgICBwaXBlbGluZS51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwaXBlbGluZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGRlZCBwaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlUGlwZWxpbmUocGlwZWxpbmU6IFBpcGVsaW5lLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5VXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcHJlUXVlcnkgPSB0aGlzLmdldFByZVF1ZXJ5KCdwaXBlbGluZScsIHBpcGVsaW5lLnVpZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtwaXBlbGluZS51aWR9KSlcbiAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgIHNldCB7XG4gICAgICAgICAgICB1aWQodikgPGFjY291bnQ+IFwiJHthY2NvdW50ID8gYWNjb3VudCA6ICcnfVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8ZGVzY3JpcHRpb24+IFwiJHtwaXBlbGluZS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHN0YXR1cz4gXCIke3BpcGVsaW5lLnN0YXR1c31cIiAuXG4gICAgICAgICAgICB1aWQodikgPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxmbG93Q29uZmlndXJhdGlvbj4gXCIke3BpcGVsaW5lLmZsb3dDb25maWd1cmF0aW9ufVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8bG9nTGV2ZWw+IFwiJHtwaXBlbGluZS5sb2dMZXZlbH1cIiAuXG4gICAgICAgICAgICB1aWQodikgPHN1YnNjcmlwdGlvblRvcGljPiBcIiR7cGlwZWxpbmUuc3Vic2NyaXB0aW9uVG9waWN9XCIgLlxuICAgICAgICAgICAgdWlkKHYpIDxyZXF1aXJlbWVudD4gXCIke3BpcGVsaW5lLnJlcXVpcmVtZW50fVwiIC5cbiAgICAgICAgICAgIHVpZCh2KSA8Y29uZmlndXJhdGlvbkZpbGU+IFwiJHtwaXBlbGluZS5jb25maWd1cmF0aW9uRmlsZX1cIiAuXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYHVwZGF0ZSBQaXBlbGluZSAke3BpcGVsaW5lLnVpZH1gKTtcblxuICAgICAgICAvLyBXaXRoIHRoZSB1cHNlcnQgYXBwcm9hY2gsIGl0IGlzIG5vdCBwb3NzaWJsZSB0byBzZWUgaWYgdGhlIG11dGF0aW9uIG9jY3VycmVkLlxuICAgICAgICAvLyBVc2UgYSBwcmVRdWVyeSBmb3IgdGhlIG9iamVjdCBmaXJzdCB0byBkZXRlcm1pbmUgaWYgaXQgZXhpc3RzLlxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAndXBkYXRlUGlwZWxpbmUnLCAncGlwZWxpbmUnLCBwaXBlbGluZS51aWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAndXBkYXRlUGlwZWxpbmUnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgcGlwZWxpbmUgJHtwaXBlbGluZS51aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IHBpcGVsaW5lKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVQaXBlbGluZShnYXRld2F5VWlkOiBzdHJpbmcsIHBpcGVsaW5lSWQ6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ3BpcGVsaW5lJywgcGlwZWxpbmVJZCwgYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgICAgICAgIHVwc2VydCB7XG4gICAgICAgICAgICBxdWVyeSB7XG4gICAgICAgICAgICAgIHZhcihmdW5jOiB1aWQoJHtwaXBlbGluZUlkfSkpXG4gICAgICAgICAgICAgIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0pIHtcbiAgICAgICAgICAgICAgICB2IGFzIHVpZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtdXRhdGlvbiBAaWYoZXEobGVuKHYpLCAxKSkge1xuICAgICAgICAgICAgICBkZWxldGUge1xuICAgICAgICAgICAgICAgIHVpZCh2KSAqICogLlxuICAgICAgICAgICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9waXBlbGluZT4gPCR7cGlwZWxpbmVJZH0+IC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZyhgZGVsZXRlIFBpcGVsaW5lICR7cGlwZWxpbmVJZH0gd2l0aCBnYXRld2F5ICR7Z2F0ZXdheVVpZH1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55PihwcmVRdWVyeVVybCwgcHJlUXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlLCAnZGVsZXRlUGlwZWxpbmUnLCAncGlwZWxpbmUnLCBwaXBlbGluZUlkKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykpLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2RlbGV0ZVBpcGVsaW5lJykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBkZWxldGVkIHBpcGVsaW5lICR7cGlwZWxpbmVJZH0gd2l0aCBnYXRld2F5ICR7Z2F0ZXdheVVpZH1gKSksXG4gICAgICAgICAgICBtYXAoKCkgPT4gYHBpcGVsaW5lIGRlbGV0ZWRgKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgUHl0aG9uIFJlc291cmNlcy5cbiAgICAgKiBAcGFyYW0gZ2F0ZXdheVVpZFxuICAgICAqL1xuICAgIGdldFB5dGhvblJlc291cmNlcyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQeXRob25SZXNvdXJjZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICB7XG4gICAgICByZXNwKGZ1bmM6IHR5cGUoUHl0aG9uUmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoXG4gICAgICAgICAgYWNjb3VudCxcbiAgICAgICl9IEFORChlcShzY29wZSwgXCIke2dhdGV3YXlOYW1lfVwiKSBPUiBlcShzY29wZSwgXCJHTE9CQUxcIikpKSB7XG4gICAgICAgIHVpZCB1dWlkIGNyZWF0ZWQgbW9kaWZpZWQgbmFtZSB0eXBlIHNjb3BlIGZpbGVDb250ZW50IGlucHV0cyBvdXRwdXRzIGZpbGVQYXRoXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXQgcHl0aG9uIHJlc291cmNlIGZyb20gJHtnYXRld2F5TmFtZX1gKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFB5dGhvblJlc291cmNlJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBQeXRob25SZXNvdXJjZVtdKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGUgUHl0aG9uIFJlc291cmNlLlxuICAgICAqIEBwYXJhbSBQeXRob25SZXNvdXJjZVxuICAgICAqL1xuICAgIHVwZGF0ZVB5dGhvblJlc291cmNlKHB5dGhvblJlc291cmNlOiBQeXRob25SZXNvdXJjZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHl0aG9uUmVzb3VyY2U+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zdCBwcmVRdWVyeVVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHByZVF1ZXJ5ID0gdGhpcy5nZXRQcmVRdWVyeSgncHl0aG9uUmVzb3VyY2UnLCBweXRob25SZXNvdXJjZS51aWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgICAgdXBzZXJ0IHtcbiAgICAgICAgICAgIHF1ZXJ5IHtcbiAgICAgICAgICAgICAgdmFyKGZ1bmM6IHVpZCgke3B5dGhvblJlc291cmNlLnVpZH0pKVxuICAgICAgICAgICAgICBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9KSB7XG4gICAgICAgICAgICAgICAgdiBhcyB1aWRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbXV0YXRpb24gQGlmKGVxKGxlbih2KSwgMSkpIHtcbiAgICAgICAgICAgICAgc2V0IHtcbiAgICAgICAgICAgICAgICA8JHtweXRob25SZXNvdXJjZS51aWR9PiA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxtb2RpZmllZD4gXCIke3B5dGhvblJlc291cmNlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgICAgICAgICA8JHtweXRob25SZXNvdXJjZS51aWR9PiA8bmFtZT4gXCIke3B5dGhvblJlc291cmNlLm5hbWV9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxzY29wZT4gXCIke3B5dGhvblJlc291cmNlLnNjb3BlfVwiIC5cbiAgICAgICAgICAgICAgICA8JHtweXRob25SZXNvdXJjZS51aWR9PiA8dHlwZT4gXCIke3B5dGhvblJlc291cmNlLnR5cGV9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxmaWxlQ29udGVudD4gXCIke3B5dGhvblJlc291cmNlLmZpbGVDb250ZW50fVwiIC5cbiAgICAgICAgICAgICAgICA8JHtweXRob25SZXNvdXJjZS51aWR9PiA8aW5wdXRzPiBcIiR7cHl0aG9uUmVzb3VyY2UuaW5wdXRzfVwiIC5cbiAgICAgICAgICAgICAgICA8JHtweXRob25SZXNvdXJjZS51aWR9PiA8b3V0cHV0cz4gXCIke3B5dGhvblJlc291cmNlLm91dHB1dHN9XCIgLlxuICAgICAgICAgICAgICAgIDwke3B5dGhvblJlc291cmNlLnVpZH0+IDxmaWxlUGF0aD4gXCIke3B5dGhvblJlc291cmNlLmZpbGVQYXRofVwiIC5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlIFB5dGhvblJlc291cmNlICR7cHl0aG9uUmVzb3VyY2UudWlkfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHByZVF1ZXJ5VXJsLCBwcmVRdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNvbmZpcm1PYmplY3RFeGlzdHMocmVzcG9uc2UsICd1cGRhdGVQeXRob25SZXNvdXJjZScsICdweXRob25SZXNvdXJjZScsIHB5dGhvblJlc291cmNlLnVpZCkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICd1cGRhdGVQeXRob25SZXNvdXJjZScpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgdXBkYXRlZCBmaWx0ZXJDb25maWcgJHtweXRob25SZXNvdXJjZS51aWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IHB5dGhvblJlc291cmNlKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBZGQgUHl0aG9uIFJlc291cmNlLlxuICAgICAqIEBwYXJhbSBQeXRob25SZXNvdXJjZVxuICAgICAqL1xuICAgIGFkZFB5dGhvblJlc291cmNlKGdhdGV3YXlVdWlkOiBzdHJpbmcsIHB5dGhvblJlc291cmNlOiBQeXRob25SZXNvdXJjZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHl0aG9uUmVzb3VyY2U+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBpZiAocHl0aG9uUmVzb3VyY2UudWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBhZGQgd2l0aCBhbiBJRCcpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGAge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8ZGdyYXBoLnR5cGU+IFwiUHl0aG9uUmVzb3VyY2VcIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPHB5dGhvblJlc291cmNlPiBcIlwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8dHlwZT4gXCJweXRob25SZXNvdXJjZVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8YWNjb3VudD4gXCIke2FjY291bnQgPyBhY2NvdW50IDogJyd9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxuYW1lPiBcIiR7cHl0aG9uUmVzb3VyY2UubmFtZX1cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPGNyZWF0ZWQ+IFwiJHtweXRob25SZXNvdXJjZS5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8bW9kaWZpZWQ+IFwiJHtweXRob25SZXNvdXJjZS5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPHR5cGU+IFwiJHtweXRob25SZXNvdXJjZS50eXBlfVwiIC5cbiAgICAgICAgXzpQeXRob25SZXNvdXJjZSA8ZmlsZUNvbnRlbnQ+IFwiJHtweXRob25SZXNvdXJjZS5maWxlQ29udGVudH1cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPHNjb3BlPiBcIiR7cHl0aG9uUmVzb3VyY2Uuc2NvcGV9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxpbnB1dHM+IFwiJHtweXRob25SZXNvdXJjZS5pbnB1dHN9XCIgLlxuICAgICAgICBfOlB5dGhvblJlc291cmNlIDxvdXRwdXRzPiBcIiR7cHl0aG9uUmVzb3VyY2Uub3V0cHV0c31cIiAuXG4gICAgICAgIF86UHl0aG9uUmVzb3VyY2UgPGZpbGVQYXRoPiBcIiR7cHl0aG9uUmVzb3VyY2UuZmlsZVBhdGh9XCIgLlxuICAgICAgfX1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBBZGQgUHl0aG9uUmVzb3VyY2UgJHtweXRob25SZXNvdXJjZS5uYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdhZGRQeXRob25SZXNvdXJjZScpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWQgPSB0aGlzLmdldElERnJvbVJlc3BvbnNlKHJlc3BvbnNlLmRhdGEsICdQeXRob25SZXNvdXJjZScpO1xuICAgICAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgICAgICBweXRob25SZXNvdXJjZS51aWQgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBweXRob25SZXNvdXJjZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKGBhZGQgcHl0aG9uUmVzb3VyY2UgJHtweXRob25SZXNvdXJjZS51aWR9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERlbGV0ZSBQeXRob24gUmVzb3VyY2UuXG4gICAgICogQHBhcmFtIHJlc291cmNlVWlkXG4gICAgICovXG4gICAgZGVsZXRlUHl0aG9uUmVzb3VyY2UocHl0aG9uUmVzb3VyY2VVaWQ6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc3QgcHJlUXVlcnlVcmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBwcmVRdWVyeSA9IHRoaXMuZ2V0UHJlUXVlcnkoJ3B5dGhvblJlc291cmNlJywgcHl0aG9uUmVzb3VyY2VVaWQsIGFjY291bnQpO1xuXG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB1cHNlcnQge1xuICAgICAgICAgICAgcXVlcnkge1xuICAgICAgICAgICAgICB2YXIoZnVuYzogdWlkKCR7cHl0aG9uUmVzb3VyY2VVaWR9KSlcbiAgICAgICAgICAgICAgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkge1xuICAgICAgICAgICAgICAgIHYgYXMgdWlkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG11dGF0aW9uIEBpZihlcShsZW4odiksIDEpKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgdWlkKHYpICogKiAuXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coYCR7cHl0aG9uUmVzb3VyY2VVaWR9IGlzIGJlaW5nIGRlbGV0ZWRgKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4ocHJlUXVlcnlVcmwsIHByZVF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHRoaXMuY29uZmlybU9iamVjdEV4aXN0cyhyZXNwb25zZSwgJ2RlbGV0ZVB5dGhvblJlc291cmNlJywgJ3B5dGhvblJlc291cmNlJywgcHl0aG9uUmVzb3VyY2VVaWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZGVsZXRlUHl0aG9uUmVzb3VyY2UnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYHVwZGF0ZWQgZmlsdGVyQ29uZmlnICR7cHl0aG9uUmVzb3VyY2VVaWR9YCkpLFxuICAgICAgICAgICAgbWFwKCgpID0+IGAke3B5dGhvblJlc291cmNlVWlkfSBkZWxldGVkYCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3MoXG4gICAgICAgIGdhdGV3YXlVdWlkOiBzdHJpbmcsXG4gICAgICAgIGRldmljZU5hbWU6IHN0cmluZyxcbiAgICAgICAgaW5zdHJ1bWVudE5hbWU6IHN0cmluZyxcbiAgICAgICAgbnVtUmVhZGluZ3M6IG51bWJlcixcbiAgICAgICAgYWNjb3VudD86IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPFJlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LSR7bnVtUmVhZGluZ3N9KSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coYGdldFJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRSZWFkaW5ncycpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnJlc3ApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LnJlc3AgYXMgUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbXSBhcyBSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiBjb25zb2xlLmxvZygnUmVzcG9uc2UgZnJvbSBnZXRSZWFkaW5nczogJywgcmVzcG9uc2UpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCByZWFkaW5ncyBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3NBdChkZXZpY2VOYW1lOiBzdHJpbmcsIGluc3RydW1lbnROYW1lOiBzdHJpbmcsIHRzOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFJlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGVxKGNyZWF0ZWQsICR7dHN9KSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRSZWFkaW5nc0F0IGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXRSZWFkaW5nc0F0Jyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFJlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCByZWFkaW5ncyBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3NTdGFydGluZ0F0KGRldmljZU5hbWU6IHN0cmluZywgaW5zdHJ1bWVudE5hbWU6IHN0cmluZywgZnJvbXRzOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFJlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocmVhZGluZ3MpLCBvcmRlcmFzYzpjcmVhdGVkKSB7XG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgdmFsdWVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZyhgZ2V0UmVhZGluZ3NTdGFydGluZ0F0IGZvciBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0UmVhZGluZ3NTdGFydGluZ0F0Jyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFJlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBzdGFydGVkIGF0IHJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9LCAke2luc3RydW1lbnROYW1lfWApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc0JldHdlZW4oXG4gICAgICAgIGdhdGV3YXlVdWlkOiBzdHJpbmcsXG4gICAgICAgIGRldmljZU5hbWU6IHN0cmluZyxcbiAgICAgICAgaW5zdHJ1bWVudE5hbWU6IHN0cmluZyxcbiAgICAgICAgZnJvbXRzOiBudW1iZXIsXG4gICAgICAgIHRvdHM6IG51bWJlcixcbiAgICAgICAgYWNjb3VudD86IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPFJlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKCR7dGhpcy5nZXRBY2NvdW50UXVlcnkoYWNjb3VudCl9IEFORCBlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkgQU5EIGx0KGNyZWF0ZWQsICR7dG90c30pKSAoZmlyc3Q6LTUwMCkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRSZWFkaW5nc0JldHdlZW4gZm9yICR7ZGV2aWNlTmFtZX0sICR7aW5zdHJ1bWVudE5hbWV9YCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckVycm9ycyhyZXNwb25zZSwgJ2dldFJlYWRpbmdzQmV0d2VlbicpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnJlc3ApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LnJlc3AgYXMgUmVhZGluZ1tdO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbXSBhcyBSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgcmVhZGluZ3MgYmV0d2VlbiBmb3IgJHtkZXZpY2VOYW1lfSwgJHtpbnN0cnVtZW50TmFtZX1gKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0TGFzdFJlYWRpbmdzRm9yRGV2aWNlKGRldmljZU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZGV2aWNlKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSBBTkQgZXEodXVpZCwgXCIke2RldmljZU5hbWV9XCIpKSBAbm9ybWFsaXplIHtcbiAgICAgICAgZGV2aWNlX3Jlc291cmNlIHtcbiAgICAgICAgICBuYW1lOiBuYW1lXG4gICAgICAgICAgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LTEpIHtcbiAgICAgICAgICAgIGNyZWF0ZWQ6IGNyZWF0ZWRcbiAgICAgICAgICAgIHZhbHVlOiB2YWx1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGBnZXRMYXN0UmVhZGluZ3NGb3JEZXZpY2UgZm9yICR7ZGV2aWNlTmFtZX1gKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yRXJyb3JzKHJlc3BvbnNlLCAnZ2V0TGFzdFJlYWRpbmdzRm9yRGV2aWNlJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBSZWFkaW5nW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdIGFzIFJlYWRpbmdbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZyhgZmV0Y2hlZCBsYXN0IHJlYWRpbmdzIGZvciAke2RldmljZU5hbWV9YCkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgICBhZGRSZWFkaW5nKFxuICAgICAgICBnYXRld2F5VXVpZDogc3RyaW5nLFxuICAgICAgICBkZXZpY2VOYW1lOiBzdHJpbmcsXG4gICAgICAgIGluc3RydW1lbnROYW1lOiBzdHJpbmcsXG4gICAgICAgIHJlYWRpbmc6IFJlYWRpbmdbXSxcbiAgICAgICAgYWNjb3VudElkOiBzdHJpbmcsXG4gICAgKTogUHJvbWlzZTxSZWFkaW5nW10+IHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdPbmx5IHN1cHBvcnRzIEdyYXBoUUwgZ3JhcGggc2VydmljZScpO1xuICAgIH1cblxuICAgIGdldE5vdGlmaWNhdGlvbnMoYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8Tm90aWZpY2F0aW9uW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc29sZS5sb2coJ0dldE5vdGlmaWNhdGlvbnMgc2VydmljZSBjYWxsZWQnKTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMobm90aWZpY2F0aW9uKSkgQGZpbHRlcigke3RoaXMuZ2V0QWNjb3VudFF1ZXJ5KGFjY291bnQpfSkgQG5vcm1hbGl6ZSB7XG4gICAgICAgIHVpZCB1dWlkOnV1aWQgY3JlYXRlZDpjcmVhdGVkIG5vdGlmeVNvdXJjZTpub3RpZnlTb3VyY2Ugbm90aWZ5RGV2aWNlOm5vdGlmeURldmljZVxuICAgICAgICBub3RpZnlSZXNvdXJjZTpub3RpZnlSZXNvdXJjZSBub3RpZnlMZXZlbDpub3RpZnlMZXZlbCB2YWx1ZTp2YWx1ZSBkZXNjcmlwdGlvbjpkZXNjcmlwdGlvblxuICAgICAgICB+Z2F0ZXdheV9ub3RpZmljYXRpb24ge1xuICAgICAgICAgIGdhdGV3YXk6IHV1aWRcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsICdnZXROb3RpZmljYXRpb25zJyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ucmVzcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8ucmVzcCBhcyBOb3RpZmljYXRpb25bXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gW10gYXMgTm90aWZpY2F0aW9uW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coYGZldGNoZWQgbm90aWZpY2F0aW9uc2ApKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVudXNlZC12YXJzXG4gICAgYWRkTm90aWZpY2F0aW9uKGdhdGV3YXlVdWlkOiBzdHJpbmcsIG5vdGlmaWNhdGlvbjogTm90aWZpY2F0aW9uLCBhY2NvdW50SWQ6IHN0cmluZyk6IE9ic2VydmFibGU8Tm90aWZpY2F0aW9uPiB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignT25seSBzdXBwb3J0cyBHcmFwaFFMIGdyYXBoIHNlcnZpY2UnKTtcbiAgICB9XG5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVudXNlZC12YXJzXG4gICAgZGVsZXRlTm90aWZpY2F0aW9uKGdhdGV3YXlVdWlkOiBzdHJpbmcsIG5vdGlmaWNhdGlvblV1aWQ6IHN0cmluZywgYWNjb3VudElkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ09ubHkgc3VwcG9ydHMgR3JhcGhRTCBncmFwaCBzZXJ2aWNlJyk7XG4gICAgfVxuXG4gICAgZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudD86IHN0cmluZykge1xuICAgICAgICBpZiAodGhpcy5yZXF1aXJlQWNjb3VudElkKSB7XG4gICAgICAgICAgICBpZiAoIWFjY291bnQpIHRocm93IG5ldyBFcnJvcignQWNjb3VudCBtdXN0IGV4aXN0Jyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBnZXRBY2NvdW50UXVlcnkoYWNjb3VudD86IHN0cmluZykge1xuICAgICAgICBpZiAodGhpcy5yZXF1aXJlQWNjb3VudElkKSB7XG4gICAgICAgICAgICByZXR1cm4gYGVxKGFjY291bnQsIFwiJHthY2NvdW50fVwiKWA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gYChlcShhY2NvdW50LCBcIiR7YWNjb3VudCA/IGFjY291bnQgOiAnJ31cIikgT1Igbm90KGhhcyhhY2NvdW50KSkpYDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERpc2NvdmVycyB0aGUgcHJlc2VuY2Ugb2YgZXJyb3JzIGluIHRoZSByZXNwb25zZSBmcm9tIGRHcmFwaCBhbmQgcmVwb3J0cyB0aGVtLlxuICAgICAqXG4gICAgICogQHBhcmFtIHJlc3BvbnNlIHRoZSByZXNwb25zZSBvYmplY3QgZnJvbSBkR3JhcGhcbiAgICAgKiBAcGFyYW0gb3BlcmF0aW9uIHRoZSBvcGVyYXRpb24gdGhhdCB3YXMgYmVpbmcgcGVyZm9ybWVkIGZvciBsb2dnaW5nIHB1cnBvc2VzXG4gICAgICovXG4gICAgY2hlY2tGb3JFcnJvcnMocmVzcG9uc2U6IGFueSwgb3BlcmF0aW9uID0gJ29wZXJhdGlvbicpIHtcbiAgICAgICAgbGV0IGhhc0Vycm9ycyA9IGZhbHNlO1xuICAgICAgICBsZXQgZXJyb3JzO1xuXG4gICAgICAgIGlmIChyZXNwb25zZT8uZGF0YT8uZXJyb3JzKSB7XG4gICAgICAgICAgICBoYXNFcnJvcnMgPSB0cnVlO1xuICAgICAgICAgICAgY29uc29sZS5sb2coYCR7b3BlcmF0aW9ufSBmYWlsZWQ6ICR7cmVzcG9uc2UuZGF0YS5lcnJvcnNbMF0ubWVzc2FnZX1gKTtcbiAgICAgICAgICAgIGVycm9ycyA9IHsgbWVzc2FnZTogcmVzcG9uc2UuZGF0YS5lcnJvcnNbMF0ubWVzc2FnZSB9O1xuICAgICAgICB9IGVsc2UgaWYgKHJlc3BvbnNlPy5lcnJvcnMpIHtcbiAgICAgICAgICAgIGhhc0Vycm9ycyA9IHRydWU7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgJHtvcGVyYXRpb259IGZhaWxlZDogJHtyZXNwb25zZS5lcnJvcnNbMF0ubWVzc2FnZX1gKTtcbiAgICAgICAgICAgIGVycm9ycyA9IHsgbWVzc2FnZTogcmVzcG9uc2UuZXJyb3JzWzBdLm1lc3NhZ2UgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChoYXNFcnJvcnMpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihKU09OLnN0cmluZ2lmeShlcnJvcnMpKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIElmIHRoZSBvcGVyYXRpb24gd2FzIHN1Y2Nlc3NmdWwsIG9idGFpbiBhIFVJRCBmcm9tIHRoZSByZXNwb25zZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBkR3JhcGhSZXNwb25zZSBBIHJlc3BvbnNlIGZyb20gZEdyYXBoXG4gICAgICogQHBhcmFtIG9iamVjdEtleSB0aGUgbmFtZSBvZiB0aGUgT2JqZWN0LCBmb3IgZXhhbXBsZSBHYXRld2F5IG9yIE1vZGVsXG4gICAgICogQHJldHVybnMgYSBVSUQgZm91bmQgZnJvbSB0aGUgcmVzcG9uc2VcbiAgICAgKi9cbiAgICBnZXRJREZyb21SZXNwb25zZShkR3JhcGhSZXNwb25zZTogR3JhcGhSZXNwb25zZSwgb2JqZWN0S2V5OiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICBpZiAoZEdyYXBoUmVzcG9uc2UuY29kZSA9PT0gJ1N1Y2Nlc3MnKSB7XG4gICAgICAgICAgICBjb25zdCB1aWQgPSBkR3JhcGhSZXNwb25zZS51aWRzW29iamVjdEtleV07XG4gICAgICAgICAgICByZXR1cm4gdWlkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgZ2V0UHJlUXVlcnkob2JqZWN0TmFtZTogc3RyaW5nLCB1aWQ6IHN0cmluZyB8IG51bWJlciB8IHVuZGVmaW5lZCwgYWNjb3VudD86IHN0cmluZykge1xuICAgICAgICBpZiAoIXVpZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKEpTT04uc3RyaW5naWZ5KHsgbWVzc2FnZTogJ05vIElEIGRlZmluZWQnIH0pKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYHtcbiAgICAgICAgcmVzcChmdW5jOiBoYXMoJHtvYmplY3ROYW1lfSkpIEBmaWx0ZXIoJHt0aGlzLmdldEFjY291bnRRdWVyeShhY2NvdW50KX0gQU5EICh1aWQoJHt1aWR9KSkpIHtcbiAgICAgICAgICB1aWQgdXVpZFxuICAgICAgICB9XG4gICAgICB9YDtcbiAgICB9XG5cbiAgICBjb25maXJtT2JqZWN0RXhpc3RzKHJlc3BvbnNlOiBhbnksIG9wZXJhdGlvbjogc3RyaW5nLCBvYmplY3ROYW1lOiBzdHJpbmcsIHVpZDogbnVtYmVyIHwgc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmICghdWlkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoSlNPTi5zdHJpbmdpZnkoeyBtZXNzYWdlOiAnTm8gSUQgZGVmaW5lZCcgfSkpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuY2hlY2tGb3JFcnJvcnMocmVzcG9uc2UsIG9wZXJhdGlvbik7XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KHJlc3BvbnNlLmRhdGEucmVzcCkpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlQXJyYXk6IFtdID0gcmVzcG9uc2UuZGF0YS5yZXNwO1xuICAgICAgICAgICAgaWYgKHJlc3BvbnNlQXJyYXkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYHRoZSAke29iamVjdE5hbWV9IHdpdGggSUQgJHt1aWR9IGRvZXMgbm90IGV4aXN0IGluIHRoaXMgYWNjb3VudGApO1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihKU09OLnN0cmluZ2lmeSh7IG1lc3NhZ2U6ICdObyBleGlzdGluZyBvYmplY3QnIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuZXhwb3J0IGludGVyZmFjZSBHcmFwaFJlc3BvbnNlIHtcbiAgICBjb2RlOiBzdHJpbmc7XG4gICAgbWVzc2FnZTogc3RyaW5nO1xuICAgIHF1ZXJpZXM6IGFueTtcbiAgICB1aWRzOiB7IFtpbmRleDogc3RyaW5nXTogc3RyaW5nIH07XG59XG4iXX0=