import { DataStore, Gateway, GatewayFiltersConfig, Model, ModelConfig, Notification, Pipeline, Protocol, TSReading } from '../model/models';
import { Observable } from 'rxjs';
import { Axios } from 'axios-observable';
export declare class GraphService {
    private http;
    protected dGraphUrl: string;
    constructor(http: Axios, dGraphUrl: string);
    getGateway(gatewayName: string, account: string): Observable<Gateway[]>;
    getGateways(account: string): Observable<Gateway[]>;
    updateGateway(gateway: Gateway, account: string): Observable<string>;
    addGateway(gateway: Gateway, account: string): Observable<Gateway>;
    deleteGateway(gatewayUid: number, account: string): Observable<string>;
    getGatewayAndProtocols(gatewayName: string, account: string): Observable<Gateway[]>;
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayName
     * @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500)
     */
    getProtocols(gatewayName: string, account: string): Observable<Protocol[]>;
    addProtocol(gatewayUid: number, protocol: Protocol, account: string): Observable<Protocol>;
    updateProtocol(protocol: Protocol, account: string): Observable<Protocol>;
    deleteProtocol(gatewayUid: number, protocolUid: number, account: string): Observable<string>;
    getDataStores(gatewayName: string, account: string): Observable<DataStore[]>;
    addDataStore(gatewayUid: number, dataStore: DataStore, account: string): Observable<DataStore>;
    updateDataStore(dataStore: DataStore, account: string): Observable<DataStore>;
    deleteDataStore(gatewayUid: number, dataStoreUid: number, account: string): Observable<string>;
    getGatewayAndModels(gatewayName: string, account: string): Observable<Gateway[]>;
    getModels(gatewayName: string, account: string): Observable<Model[]>;
    addModel(gatewayUid: number, model: Model, account: string): Observable<Model>;
    updateModel(model: Model, account: string): Observable<Model>;
    deleteModel(gatewayUid: number, modelUid: number, account: string): Observable<string>;
    getGatewayAndPipelines(gatewayName: string, account: string): Observable<Gateway[]>;
    getPipelines(gatewayName: string, account: string): Observable<Pipeline[]>;
    addPipeline(gatewayUid: number, pipeline: Pipeline, account: string): Observable<Pipeline>;
    updatePipeline(pipeline: Pipeline, account: string): Observable<Pipeline>;
    deletePipeline(gatewayUid: number, pipeline: Pipeline, account: string): Observable<string>;
    /**
     * Get ids of all the pipelines associated with the specified protocol
     * @param protocolUid - the uid of the protocol
     */
    getPipelineIdsFromProtocolUid(protocolUid: number, account: string): Observable<Pipeline[]>;
    /**
     * Get ids of all the pipelines associated with the specified data store
     * @param dataStoreUid - the uid of the data store
     */
    getPipelineIdsFromDataStoreUid(dataStoreUid: number, account: string): Observable<Pipeline[]>;
    getModelConfigs(gatewayName: string, account: string): Observable<ModelConfig[]>;
    addModelConfig(gatewayUid: number, modelConfig: ModelConfig, account: string): Observable<ModelConfig>;
    updateModelConfig(modelConfig: ModelConfig, account: string): Observable<ModelConfig>;
    deleteModelConfig(gatewayUid: number, modelConfigUid: number, account: string): Observable<string>;
    getFiltersConfig(gatewayName: string, account: string): Observable<GatewayFiltersConfig[]>;
    addFiltersConfig(gatewayUid: number, filtersConfig: GatewayFiltersConfig, account: string): Observable<GatewayFiltersConfig>;
    updateFiltersConfig(filtersConfig: GatewayFiltersConfig, account: string): Observable<GatewayFiltersConfig>;
    getReadings(deviceName: string, instrumentName: string, numReadings: number, account: string): Observable<TSReading[]>;
    getReadingsAt(deviceName: string, instrumentName: string, ts: number, account: string): Observable<TSReading[]>;
    getReadingsStartingAt(deviceName: string, instrumentName: string, fromts: number, account: string): Observable<TSReading[]>;
    getReadingsBetween(deviceName: string, instrumentName: string, fromts: number, tots: number, account: string): Observable<TSReading[]>;
    getLastReadingsForDevice(deviceName: string, account: string): Observable<TSReading[]>;
    getNotifications(account: string): Observable<Notification[]>;
    getRoute(deviceName: string, account: string): number[][];
    getRouteCenter(deviceName: string, account: string): number[];
    private ensureAccountAuthorized;
    /**
     * Handle HTTP operation that failed.
     * Let the app continue.
     * @param operation - - name of the operation that failed
     * @param result - optional value to return as the observable result
     */
    private handleError;
}
