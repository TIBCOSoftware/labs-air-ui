import { catchError, map, of, tap } from 'rxjs';
const route1 = [
    [25.771088, -80.163483],
    [27.439775, -80.32299],
    [28.349469, -80.731105],
    [30.401564, -81.571033],
    [32.116716, -81.144147],
    [32.866511, -79.995399],
    [34.191224, -77.952419],
    [36.850172, -76.319269],
    [36.915037, -76.320643],
    [39.262025, -76.549294],
    [39.900933, -75.143453],
    [40.690263, -74.152375],
    [42.259951, -71.789244],
];
const route2 = [
    [47.492471, -122.26888],
    [45.552207, -122.722648],
    [39.53246, -119.751524],
    [37.803528, -122.312138],
    [37.899332, -121.169307],
    [36.273183, -115.070534],
    [33.77032, -118.273289],
    [34.106012, -117.320254],
    [33.515564, -112.160564],
    [32.126437, -110.848336],
    [31.752085, -106.488887],
    [35.04758, -106.653344],
    [39.796963, -104.995374],
];
const route3 = [
    [29.302729, -98.638744],
    [29.638421, -95.292245],
    [32.615525, -96.693485],
    [29.917836, -90.205272],
    [32.256403, -90.151546],
    [35.044849, -90.153006],
    [38.524627, -90.209535],
    [39.870851, -88.912284],
    [41.705694, -87.577341],
    [41.902382, -89.101932],
    [44.251243, -91.509663],
    [44.970069, -93.174527],
    [46.758181, -92.098748],
];
const emptyroute = [];
const httpOptions = {
    headers: { 'Content-Type': 'application/graphql+-' },
};
const httpMutateOptions = {
    headers: { 'Content-Type': 'application/rdf' },
};
export class GraphService {
    constructor(http, dGraphUrl, accountRequired) {
        this.http = http;
        this.dGraphUrl = dGraphUrl;
        this.accountRequired = accountRequired;
        this.requireAccountId = true;
        console.log(`dGraphUrl: ${this.dGraphUrl} requires account identifier ${accountRequired}`);
        this.requireAccountId = accountRequired;
        //const dGraphBasicAuthEnabled = this.appConfigService.dGraphBasicAuthEnabled;
        //if (dGraphBasicAuthEnabled) {
        //    const dGraphBasicAuth = this.appConfigService.dGraphBasicAuth;
        //    (this.httpOptions.headers = { 'Content-Type': 'application/graphql+-' }), { Authorization: dGraphBasicAuth };
        //    (this.httpMutateOptions.headers = { 'Content-Type': 'application/rdf' }), { Authorization: dGraphBasicAuth };
        //}
    }
    getGateway(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        console.log('GetGateway service called for: ', gatewayName);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid description address router routerPort deployNetwork latitude longitude accessToken username platform devicesMetadata createdts updatedts
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log('Response from getGateway: ', response)), catchError(this.handleError('getGateway', [])));
    }
    getGateways(account) {
        this.ensureAccountAuthorized(account);
        console.log(`GetGateways service called for ${account}`);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) {
        uid uuid description address router routerPort deployNetwork latitude longitude accessToken username platform devicesMetadata createdts updatedts
        numDevices: count(gateway_device)

      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched gateways')), catchError(this.handleError('getGateways', [])));
    }
    updateGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${gateway.uid}> <address> "${gateway.address}" .
        <${gateway.uid}> <router> "${gateway.router}" .
        <${gateway.uid}> <routerPort> "${gateway.routerPort}" .
        <${gateway.uid}> <deployNetwork> "${gateway.deployNetwork}" .
        <${gateway.uid}> <description> "${gateway.description}" .
        <${gateway.uid}> <latitude> "${gateway.latitude}" .
        <${gateway.uid}> <longitude> "${gateway.longitude}" .
        <${gateway.uid}> <accessToken> "${gateway.accessToken}" .
        <${gateway.uid}> <username> "${gateway.username}" .
        <${gateway.uid}> <platform> "${gateway.platform}" .
        <${gateway.uid}> <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log('Update Gateway Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => 'gateway updated'), tap(() => console.log('updated gateway')), catchError(this.handleError('updateGateway')));
    }
    addGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Gateway <dgraph.type> "Gateway" .
        _:Gateway <gateway> "" .
        _:Gateway <type> "gateway" .
        _:Gateway <uuid> "${gateway.uuid}" .
        _:Gateway <description> "${gateway.description}" .
        _:Gateway <address> "${gateway.address}" .
        _:Gateway <router> "${gateway.router}" .
        _:Gateway <routerPort> "${gateway.routerPort}" .
        _:Gateway <deployNetwork> "${gateway.deployNetwork}" .
        _:Gateway <latitude> "${gateway.latitude}" .
        _:Gateway <longitude> "${gateway.longitude}" .
        _:Gateway <accessToken> "${gateway.accessToken}" .
        _:Gateway <username> "${gateway.username}" .
        _:Gateway <platform> "${gateway.platform}" .
        _:Gateway <createdts> "${gateway.createdts}" .
        _:Gateway <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log('Add Gateway Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = gateway)), tap(() => console.log('add gateway')), catchError(this.handleError('addGateway')));
    }
    deleteGateway(gatewayUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${gatewayUid}> * * .
      }
    }`;
        console.log('Delete Gateway Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => `${gatewayUid} deleted`), tap(() => console.log('deleted gateway')), catchError(this.handleError('deleteGateway')));
    }
    getGatewayAndProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid
        protocols: gateway_protocol {
          uid
          uuid
          created
          modified
          protocolType
          brokerURL
          topic
          consumerGroupId
          connectionTimeout
          sessionTimeout
          initialOffset
          retryBackoff
          fetchMinBytes
          fetchMaxWait
          commitInterval
          heartbeatInterval
          maximumQOS
          username
          password
          encryptionMode
          caCertificate
          clientCertificate
          clientKey
          authMode
          serverCerticate
        }
      }
    }`;
        console.log('Get Gateway and Protocols query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched Gateway')), catchError(this.handleError('getGatewayWithProtocols', [])));
    }
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayName
     * @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500)
     */
    getProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(protocol)) @filter(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL")) {
        uid
        uuid
        created
        modified
        protocolType
        brokerURL
        topic
        consumerGroupId
        connectionTimeout
        sessionTimeout
        initialOffset
        retryBackoff
        fetchMinBytes
        fetchMaxWait
        commitInterval
        heartbeatInterval
        maximumQOS
        username
        password
        encryptionMode
        caCertificate
        clientCertificate
        clientKey
        authMode
        serverCerticate
        scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched protocols')), catchError(this.handleError('getProtocols', [])));
    }
    addProtocol(gatewayUid, protocol, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Protocol <dgraph.type> "Protocol" .
        _:Protocol <type> "protocol" .
        _:Protocol <protocol> "" .
        _:Protocol <uuid> "${protocol.uuid}" .
        _:Protocol <created> "${protocol.created}" .
        _:Protocol <modified> "${protocol.modified}" .
        _:Protocol <protocolType> "${protocol.protocolType}" .
        _:Protocol <brokerURL> "${protocol.brokerURL}" .
        _:Protocol <topic> "${protocol.topic}" .
        _:Protocol <consumerGroupId> "${protocol.consumerGroupId}" .
        _:Protocol <connectionTimeout> "${protocol.connectionTimeout}" .
        _:Protocol <sessionTimeout> "${protocol.sessionTimeout}" .
        _:Protocol <initialOffset> "${protocol.initialOffset}" .
        _:Protocol <retryBackoff> "${protocol.retryBackOff}" .
        _:Protocol <fetchMinBytes> "${protocol.fetchMinBytes}" .
        _:Protocol <fetchMaxWait> "${protocol.fetchMaxWait}" .
        _:Protocol <commitInterval> "${protocol.commitInterval}" .
        _:Protocol <heartbeatInterval> "${protocol.heartbeatInterval}" .
        _:Protocol <maximumQOS> "${protocol.maximumQOS}" .
        _:Protocol <username> "${protocol.username}" .
        _:Protocol <password> "${protocol.password}" .
        _:Protocol <encryptionMode> "${protocol.encryptionMode}" .
        _:Protocol <caCertificate> "${protocol.caCertificate}" .
        _:Protocol <clientCertificate> "${protocol.clientCertificate}" .
        _:Protocol <clientKey> "${protocol.clientKey}" .
        _:Protocol <authMode> "${protocol.authMode}" .
        _:Protocol <serverCerticate> "${protocol.serverCertificate}" .
        _:Protocol <scope> "${protocol.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = protocol)), tap(() => console.log('add protocols')), catchError(this.handleError('addProtocols')));
    }
    updateProtocol(protocol, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${protocol.uid}> <uuid> "${protocol.uuid}" .
        <${protocol.uid}> <modified> "${protocol.modified}" .
        <${protocol.uid}> <protocolType> "${protocol.protocolType}" .
        <${protocol.uid}> <brokerURL> "${protocol.brokerURL}" .
        <${protocol.uid}> <topic> "${protocol.topic}" .
        <${protocol.uid}> <consumerGroupId> "${protocol.consumerGroupId}" .
        <${protocol.uid}> <connectionTimeout> "${protocol.connectionTimeout}" .
        <${protocol.uid}> <sessionTimeout> "${protocol.sessionTimeout}" .
        <${protocol.uid}> <initialOffset> "${protocol.initialOffset}" .
        <${protocol.uid}> <retryBackoff> "${protocol.retryBackOff}" .
        <${protocol.uid}> <fetchMinBytes> "${protocol.fetchMinBytes}" .
        <${protocol.uid}> <fetchMaxWait> "${protocol.fetchMaxWait}" .
        <${protocol.uid}> <commitInterval> "${protocol.commitInterval}" .
        <${protocol.uid}> <heartbeatInterval> "${protocol.heartbeatInterval}" .
        <${protocol.uid}> <maximumQOS> "${protocol.maximumQOS}" .
        <${protocol.uid}> <username> "${protocol.username}" .
        <${protocol.uid}> <password> "${protocol.password}" .
        <${protocol.uid}> <encryptionMode> "${protocol.encryptionMode}" .
        <${protocol.uid}> <caCertificate> "${protocol.caCertificate}" .
        <${protocol.uid}> <clientCertificate> "${protocol.clientCertificate}" .
        <${protocol.uid}> <clientKey> "${protocol.clientKey}" .
        <${protocol.uid}> <authMode> "${protocol.authMode}" .
        <${protocol.uid}> <serverCerticate> "${protocol.serverCertificate}" .
        <${protocol.uid}> <scope> "${protocol.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = protocol)), tap(() => console.log('updated protocols')), catchError(this.handleError('updateProtocols')));
    }
    deleteProtocol(gatewayUid, protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${protocolUid}> * * .
      }
    }`;
        console.log('Delete Protocol Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${protocolUid} deleted`)), tap(() => console.log('deleted protocol')), catchError(this.handleError('deleteProtocol')));
    }
    getDataStores(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(dataStore)) @filter(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL")) {
        uid
        uuid
        created
        modified
        dataStoreType
        host
        port
        databaseName
        user
        password
        accountName
        warehouse
        database
        schema
        authType
        username
        clientId
        clientSecret
        authorizationCode
        redirectURI
        loginTimeout
        url
        scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched dataStores')), catchError(this.handleError('getDataStores', [])));
    }
    addDataStore(gatewayUid, dataStore, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:DataStore <dgraph.type> "DataStore" .
        _:DataStore <type> "dataStore" .
        _:DataStore <dataStore> "" .
        _:DataStore <uuid> "${dataStore.uuid}" .
        _:DataStore <created> "${dataStore.created}" .
        _:DataStore <modified> "${dataStore.modified}" .
        _:DataStore <dataStoreType> "${dataStore.dataStoreType}" .
        _:DataStore <host> "${dataStore.host}" .
        _:DataStore <port> "${dataStore.port}" .
        _:DataStore <databaseName> "${dataStore.databaseName}" .
        _:DataStore <user> "${dataStore.user}" .
        _:DataStore <password> "${dataStore.password}" .
        _:DataStore <accountName> "${dataStore.accountName}" .
        _:DataStore <warehouse> "${dataStore.warehouse}" .
        _:DataStore <database> "${dataStore.databaseName}" .
        _:DataStore <schema> "${dataStore.schema}" .
        _:DataStore <authType> "${dataStore.authType}" .
        _:DataStore <username> "${dataStore.username}" .
        _:DataStore <clientId> "${dataStore.clientId}" .
        _:DataStore <clientSecret> "${dataStore.clientSecret}" .
        _:DataStore <authorizationCode> "${dataStore.authorizationCode}" .
        _:DataStore <redirectURI> "${dataStore.redirectURI}" .
        _:DataStore <loginTimeout> "${dataStore.loginTimeout}" .
        _:DataStore <url> "${dataStore.url}" .
        _:DataStore <scope> "${dataStore.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = dataStore)), tap(() => console.log('add dataStores')), catchError(this.handleError('addDataStores')));
    }
    updateDataStore(dataStore, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${dataStore.uid}> <uuid> "${dataStore.uuid}" .
        <${dataStore.uid}> <modified> "${dataStore.modified}" .
        <${dataStore.uid}> <dataStoreType> "${dataStore.dataStoreType}" .
        <${dataStore.uid}> <host> "${dataStore.host}" .
        <${dataStore.uid}> <port> "${dataStore.port}" .
        <${dataStore.uid}> <databaseName> "${dataStore.databaseName}" .
        <${dataStore.uid}> <user> "${dataStore.user}" .
        <${dataStore.uid}> <password> "${dataStore.password}" .
        <${dataStore.uid}> <accountName> "${dataStore.accountName}" .
        <${dataStore.uid}> <warehouse> "${dataStore.warehouse}" .
        <${dataStore.uid}> <database> "${dataStore.databaseName}" .
        <${dataStore.uid}> <schema> "${dataStore.schema}" .
        <${dataStore.uid}> <authType> "${dataStore.authType}" .
        <${dataStore.uid}> <username> "${dataStore.username}" .
        <${dataStore.uid}> <clientId> "${dataStore.clientId}" .
        <${dataStore.uid}> <clientSecret> "${dataStore.clientSecret}" .
        <${dataStore.uid}> <authorizationCode> "${dataStore.authorizationCode}" .
        <${dataStore.uid}> <redirectURI> "${dataStore.redirectURI}" .
        <${dataStore.uid}> <loginTimeout> "${dataStore.loginTimeout}" .
        <${dataStore.uid}> <url> "${dataStore.url}" .
        <${dataStore.uid}> <scope> "${dataStore.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = dataStore)), tap(() => console.log('updated dataStores')), catchError(this.handleError('updateDataStores')));
    }
    deleteDataStore(gatewayUid, dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${dataStoreUid}> * * .
      }
    }`;
        console.log('Delete DataStore Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${dataStoreUid} deleted`)), tap(() => console.log('deleted dataStore')), catchError(this.handleError('deleteDataStore')));
    }
    getGatewayAndModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid
        models: gateway_model {
          uid
          uuid
          created
          modified
          name
          description
          inputType
          url
          scope
          inputTemplate
        }
      }
    }`;
        console.log('Get Gateway and Protocols query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched Gateway')), catchError(this.handleError('getGatewayWithModels', [])));
    }
    getModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(model)) @filter(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL")) {
        uid
        uuid
        created
        modified
        name
        description
        inputType
        url
        scope
        inputTemplate
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched models')), catchError(this.handleError('getModels', [])));
    }
    addModel(gatewayUid, model, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Model <dgraph.type> "Model" .
        _:Model <type> "model" .
        _:Model <model> "" .
        _:Model <uuid> "${model.uuid}" .
        _:Model <created> "${model.created}" .
        _:Model <modified> "${model.modified}" .
        _:Model <name> "${model.name}" .
        _:Model <description> "${model.description}" .
        _:Model <inputType> "${model.inputType}" .
        _:Model <url> "${model.url}" .
        _:Model <scope> "${model.scope}" .
        _:Model <inputTemplate> "${model.inputTemplate}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = model)), tap(() => console.log('add models')), catchError(this.handleError('addModels')));
    }
    updateModel(model, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${model.uid}> <uuid> "${model.uuid}" .
        <${model.uid}> <modified> "${model.modified}" .
        <${model.uid}> <name> "${model.name}" .
        <${model.uid}> <description> "${model.description}" .
        <${model.uid}> <inputType> "${model.inputType}" .
        <${model.uid}> <url> "${model.url}" .
        <${model.uid}> <scope> "${model.scope}" .
        <${model.uid}> <inputTemplate> "${model.inputTemplate}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = model)), tap(() => console.log('updated models')), catchError(this.handleError('updateModels')));
    }
    deleteModel(gatewayUid, modelUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${modelUid}> * * .
      }
    }`;
        console.log('Delete Model Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${modelUid} deleted`)), tap(() => console.log('deleted protocol')), catchError(this.handleError('deleteModel')));
    }
    getGatewayAndPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = 'protocol: pipeline_protocol {uid uuid brokerURL topic maximumQOS username password encryptionMode caCertificate clientCertificate clientKey authMode serverCerticate consumerGroupId connectionTimeout sessionTimeout retryBackoff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval}';
        const pipeline_datastore = 'dataStore: pipeline_datastore {uid uuid host port databaseName user password accountName warehouse database schema authType username clientId clientSecret authorizationCode redirectURI loginTimeout url}';
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid accessToken username platform address router routerPort deployNetwork devicesMetadata
        pipelines: gateway_pipeline {
          uid
          name
          uuid
          pipelineType
          deployerType
          protocolType
          protocolId
          dataStoreType
          dataStoreId
          created
          modified
          description
          status
          flowConfiguration
          logLevel
          subscriptionTopic
          ${pipeline_protocol}
          ${pipeline_datastore}
          ${pipeline_filter}
          ${pipeline_streaming}
        }
      }
    }`;
        console.log('Get Gateway and Pipelines query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched Gateway')), catchError(this.handleError('getGatewayWithPipelines', [])));
    }
    getPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = 'protocol: pipeline_protocol {uid brokerURL topic maximumQOS username password encryptionMode caCertificate clientCertificate clientKey authMode serverCerticate consumerGroupId connectionTimeout sessionTimeout retryBackoff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval}';
        const pipeline_datastore = 'datastore: pipeline_datastore {uid host port databaseName user password accountName warehouse database schema authType username clientId clientSecret authorizationCode redirectURI loginTimeout url}';
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      var(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        pipelines as gateway_pipeline {
        }
      }
      resp(func: uid(pipelines)) {
        uid
        name
        uuid
        pipelineType
        deployerType
        protocolType
        protocolId
        dataStoreType
        dataStoreId
        created
        modified
        description
        status
        flowConfiguration
        logLevel
        subscriptionTopic
        ${pipeline_protocol}
        ${pipeline_datastore}
        ${pipeline_filter}
        ${pipeline_streaming}
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipelines')), catchError(this.handleError('getPipelines', [])));
    }
    addPipeline(gatewayUid, pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        let query = '';
        query = `{
      set {
        _:Pipeline <dgraph.type> "Pipeline" .
        _:Pipeline <name> "${pipeline.name}" .
        _:Pipeline <uuid> "${pipeline.name}" .
        _:Pipeline <type> "pipeline" .
        _:Pipeline <pipeline> "" .
        _:Pipeline <pipelineType> "${pipeline.pipelineType}" .
        _:Pipeline <deployerType> "${pipeline.deployerType}" .
        _:Pipeline <created> "${pipeline.created}" .
        _:Pipeline <modified> "${pipeline.modified}" .
        _:Pipeline <description> "${pipeline.description}" .
        _:Pipeline <status> "${pipeline.status}" .
        _:Pipeline <flowConfiguration> "${pipeline.flowConfiguration}" .
        _:Pipeline <logLevel> "${pipeline.logLevel}" .
        _:Pipeline <subscriptionTopic> "${pipeline.subscriptionTopic}" .
        <${gatewayUid}> <gateway_pipeline> _:Pipeline .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = pipeline)), tap(() => console.log('add pipeline')), catchError(this.handleError('addPipelines')));
    }
    updatePipeline(pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${pipeline.uid}> <description> "${pipeline.description}" .
        <${pipeline.uid}> <status> "${pipeline.status}" .
        <${pipeline.uid}> <modified> "${pipeline.modified}" .
        <${pipeline.uid}> <flowConfiguration> "${pipeline.flowConfiguration}" .
        <${pipeline.uid}> <logLevel> "${pipeline.logLevel}" .
        <${pipeline.uid}> <subscriptionTopic> "${pipeline.subscriptionTopic}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = pipeline)), tap(() => console.log('updated pipelines')), catchError(this.handleError('updatePipeline')));
    }
    deletePipeline(gatewayUid, pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${pipeline.uid}> * * .
        <${gatewayUid}> <gateway_pipeline> <${pipeline.uid}> .
      }
    }`;
        console.log('Delete Pipeline Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `pipeline deleted`)), tap(() => console.log('deleted pipeline')), catchError(this.handleError('deletePipeline')));
    }
    /**
     * Get ids of all the pipelines associated with the specified protocol
     * @param protocolUid - the uid of the protocol
     */
    getPipelineIdsFromProtocolUid(protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${protocolUid})) {
        pipelines as ~pipeline_protocol {
        }
      }
      resp(func: uid(pipelines)) {
        uid
        uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipeline ids')), catchError(this.handleError('getPipelineIdsFromProtocolUid', [])));
    }
    /**
     * Get ids of all the pipelines associated with the specified data store
     * @param dataStoreUid - the uid of the data store
     */
    getPipelineIdsFromDataStoreUid(dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${dataStoreUid})) {
        pipelines as ~pipeline_datastore {
        }
      }
      resp(func: uid(pipelines)) {
        uid
        uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipeline ids')), catchError(this.handleError('getPipelineIdsFromDataStoreUid', [])));
    }
    getModelConfigs(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        modelConfigs as gateway_modelconfig {
        }
      }
      resp(func: uid(modelConfigs)) {
        uid
        name
        uuid
        description
        device
        resource
        model
        created
        modified
      }
    }`;
        console.log('getModelConfigs service query: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched modelConfigs')), catchError(this.handleError('getModelConfigs', [])));
    }
    addModelConfig(gatewayUid, modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:ModelConfig <dgraph.type> "ModelConfig" .
        _:ModelConfig <name> "${modelConfig.name}" .
        _:ModelConfig <uuid> "${modelConfig.name}" .
        _:ModelConfig <type> "modelConfig" .
        _:ModelConfig <modelConfig> "" .
        _:ModelConfig <description> "${modelConfig.description}" .
        _:ModelConfig <device> "${modelConfig.device}" .
        _:ModelConfig <resource> "${modelConfig.resource}" .
        _:ModelConfig <model> "${modelConfig.model}" .
        _:ModelConfig <created> "${modelConfig.created}" .
        _:ModelConfig <modified> "${modelConfig.modified}" .
        <${gatewayUid}> <gateway_modelconfig> _:ModelConfig .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = modelConfig)), tap(() => console.log('add modelConfig')), catchError(this.handleError('addModelConfig')));
    }
    updateModelConfig(modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${modelConfig.uid}> <name> "${modelConfig.name}" .
        <${modelConfig.uid}> <uuid> "${modelConfig.uuid}" .
        <${modelConfig.uid}> <description> "${modelConfig.description}" .
        <${modelConfig.uid}> <condDevice> "${modelConfig.device}" .
        <${modelConfig.uid}> <condResource> "${modelConfig.resource}" .
        <${modelConfig.uid}> <model> "${modelConfig.model}" .
        <${modelConfig.uid}> <modified> "${modelConfig.modified}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = modelConfig)), tap(() => console.log('updated modelConfig')), catchError(this.handleError('updateModelConfig')));
    }
    deleteModelConfig(gatewayUid, modelConfigUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${modelConfigUid}> * * .
        <${gatewayUid}> <gateway_modelconfig> <${modelConfigUid}> .
      }
    }`;
        console.log('Delete ModelConfig Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${modelConfigUid} deleted`)), tap(() => console.log('deleted modelConfig')), catchError(this.handleError('deleteModelConfig')));
    }
    getFiltersConfig(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        filtersConfig as gateway_filter {
        }
      }
      resp(func: uid(filtersConfig)) {
        uid
        deviceNames
      }
    }`;
        console.log('getFiltersConfig service query: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched filtersConfig')), catchError(this.handleError('getFiltersConfigs', [])));
    }
    addFiltersConfig(gatewayUid, filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Filter <dgraph.type> "filter" .
        _:Filter <type> "filter" .
        _:Filter <filter> "" .
        _:Filter <deviceNames> "${filtersConfig.deviceNames}" .
        <${gatewayUid}> <gateway_filter> _:Filter .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = filtersConfig)), tap(() => console.log('add filtersConfig')), catchError(this.handleError('addFiltersConfig')));
    }
    updateFiltersConfig(filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${filtersConfig.uid}> <deviceNames> "${filtersConfig.deviceNames}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = filtersConfig)), tap(() => console.log('updated filtersConfig')), catchError(this.handleError('updateFiltersConfig')));
    }
    getReadings(deviceName, instrumentName, numReadings, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        // return this.http.post<any>(url, `{resp(func: has(reading)) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) {~device_resource @filter (eq(uuid, "${deviceName}")) {}}}}`, httpOptions)
        // return this.http.post<any>(url, `{resp(func: has(reading)) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading (first:-${numReadings}) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('getReadings query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log('Response from getReadings: ', response)), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadings', [])));
    }
    getReadingsAt(deviceName, instrumentName, ts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(eq(created, ${ts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('getReadingsAt query statement: ', query);
        // return this.http.post<any>(url, `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadingsAt', [])));
    }
    getReadingsStartingAt(deviceName, instrumentName, fromts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        // const myquery = `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`;
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('the query is: ', query);
        // return this.http.post<any>(url, `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadingsStartingAt', [])));
    }
    getReadingsBetween(deviceName, instrumentName, fromts, tots, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        // const myquery = `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`;
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('the query is: ', query);
        // return this.http.post<any>(url, `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadingsBetween', [])));
    }
    getLastReadingsForDevice(deviceName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(device)) @filter(eq(uuid, "${deviceName}")) @normalize {
        device_resource {
          name: name
          resource_reading (first:-1) {
            created: created
            value: value
          }
        }
      }
    }`;
        console.log('Reading query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getLastReadingsForDevice', [])));
    }
    getNotifications(account) {
        this.ensureAccountAuthorized(account);
        console.log('GetNotifications service called');
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(notification)) @normalize {
        uid uuid:uuid created:created notifySource:notifySource notifyDevice:notifyDevice notifyResource:notifyResource notifyLevel:notifyLevel value:value description:description ~gateway_notification {
          gateway: uuid
        }
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log('Response from GetNoti: ', response)), tap(() => console.log('fetched notifications')), catchError(this.handleError('getNotifications', [])));
    }
    getRoute(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let route = null;
        if (deviceName == 'train-0001') {
            route = route1;
        }
        else if (deviceName == 'train-0002') {
            route = route2;
        }
        else if (deviceName == 'train-0003') {
            route = route3;
        }
        else {
            route = emptyroute;
        }
        return route;
    }
    getRouteCenter(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let center = null;
        // 39.0 -98.0 zoom 4
        // East 34.765589   -78.709488
        // West 40.487432 -122.803116
        if (deviceName == 'train-0001') {
            center = [34.0, -98.0];
        }
        else if (deviceName == 'train-0002') {
            center = [40.0, -98.0];
        }
        else if (deviceName == 'train-0003') {
            center = [39.0, -98.0];
        }
        else {
            center = [42.8, 12.8];
        }
        return center;
    }
    ensureAccountAuthorized(account) {
        if (this.requireAccountId) {
            if (!account)
                throw new Error('Account must exist');
        }
    }
    /**
     * Handle HTTP operation that failed.
     * Let the app continue.
     * @param operation - - name of the operation that failed
     * @param result - optional value to return as the observable result
     */
    handleError(operation = 'operation', result) {
        return (error) => {
            // TODO: better job of transforming error for user consumption
            console.log(`${operation} failed: ${error.code}: ${error.message}`);
            // Let the app keep running by returning an empty result.
            return of(result);
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL2xhYnMtYWlyLWdyYXBoLWNsaWVudC9zcmMvYXBpL2dyYXBoLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBV0EsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQWMsRUFBRSxFQUFFLEdBQUcsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUc1RCxNQUFNLE1BQU0sR0FBZTtJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFFBQVEsQ0FBQztJQUN0QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztDQUMxQixDQUFDO0FBRUYsTUFBTSxNQUFNLEdBQWU7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7Q0FDM0IsQ0FBQztBQUVGLE1BQU0sTUFBTSxHQUFlO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0NBQzFCLENBQUM7QUFFRixNQUFNLFVBQVUsR0FBZSxFQUFFLENBQUM7QUFFbEMsTUFBTSxXQUFXLEdBQUc7SUFDaEIsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLHVCQUF1QixFQUFFO0NBQ3ZELENBQUM7QUFFRixNQUFNLGlCQUFpQixHQUFHO0lBQ3RCLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxpQkFBaUIsRUFBRTtDQUNqRCxDQUFDO0FBRUYsTUFBTSxPQUFPLFlBQVk7SUFJckIsWUFBb0IsSUFBVyxFQUFZLFNBQWlCLEVBQVUsZUFBd0I7UUFBMUUsU0FBSSxHQUFKLElBQUksQ0FBTztRQUFZLGNBQVMsR0FBVCxTQUFTLENBQVE7UUFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBUztRQUZ4RixxQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFHMUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLElBQUksQ0FBQyxTQUFTLGdDQUFnQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBQzdGLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUM7UUFDdEMsOEVBQThFO1FBQzlFLCtCQUErQjtRQUMvQixvRUFBb0U7UUFDcEUsbUhBQW1IO1FBQ25ILG1IQUFtSDtRQUNuSCxHQUFHO0lBQ1AsQ0FBQztJQUVELFVBQVUsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQzVDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV0QyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQzVELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO21EQUM2QixXQUFXOzs7TUFHeEQsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUN0RSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBWSxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDNUQsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsT0FBZ0I7UUFDeEIsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDekQsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7Ozs7OztNQU1oQixDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWlCLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBWSxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDN0QsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsT0FBZ0IsRUFBRSxPQUFnQjtRQUM1QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxPQUFPLENBQUMsR0FBRyxnQkFBZ0IsT0FBTyxDQUFDLE9BQU87V0FDMUMsT0FBTyxDQUFDLEdBQUcsZUFBZSxPQUFPLENBQUMsTUFBTTtXQUN4QyxPQUFPLENBQUMsR0FBRyxtQkFBbUIsT0FBTyxDQUFDLFVBQVU7V0FDaEQsT0FBTyxDQUFDLEdBQUcsc0JBQXNCLE9BQU8sQ0FBQyxhQUFhO1dBQ3RELE9BQU8sQ0FBQyxHQUFHLG9CQUFvQixPQUFPLENBQUMsV0FBVztXQUNsRCxPQUFPLENBQUMsR0FBRyxpQkFBaUIsT0FBTyxDQUFDLFFBQVE7V0FDNUMsT0FBTyxDQUFDLEdBQUcsa0JBQWtCLE9BQU8sQ0FBQyxTQUFTO1dBQzlDLE9BQU8sQ0FBQyxHQUFHLG9CQUFvQixPQUFPLENBQUMsV0FBVztXQUNsRCxPQUFPLENBQUMsR0FBRyxpQkFBaUIsT0FBTyxDQUFDLFFBQVE7V0FDNUMsT0FBTyxDQUFDLEdBQUcsaUJBQWlCLE9BQU8sQ0FBQyxRQUFRO1dBQzVDLE9BQU8sQ0FBQyxHQUFHLGtCQUFrQixPQUFPLENBQUMsU0FBUzs7TUFFbkQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFeEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsaUJBQWlCLENBQUMsRUFDNUIsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUN6QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUyxlQUFlLENBQUMsQ0FBQyxDQUN4RCxDQUFDO0lBQ04sQ0FBQztJQUVELFVBQVUsQ0FBQyxPQUFnQixFQUFFLE9BQWdCO1FBQ3pDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7Ozs0QkFLTSxPQUFPLENBQUMsSUFBSTttQ0FDTCxPQUFPLENBQUMsV0FBVzsrQkFDdkIsT0FBTyxDQUFDLE9BQU87OEJBQ2hCLE9BQU8sQ0FBQyxNQUFNO2tDQUNWLE9BQU8sQ0FBQyxVQUFVO3FDQUNmLE9BQU8sQ0FBQyxhQUFhO2dDQUMxQixPQUFPLENBQUMsUUFBUTtpQ0FDZixPQUFPLENBQUMsU0FBUzttQ0FDZixPQUFPLENBQUMsV0FBVztnQ0FDdEIsT0FBTyxDQUFDLFFBQVE7Z0NBQ2hCLE9BQU8sQ0FBQyxRQUFRO2lDQUNmLE9BQU8sQ0FBQyxTQUFTO2lDQUNqQixPQUFPLENBQUMsU0FBUzs7TUFFNUMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFckQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFDakQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUMsRUFDckMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVUsWUFBWSxDQUFDLENBQUMsQ0FDdEQsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsVUFBa0IsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxVQUFVOztNQUVmLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXhELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsVUFBVSxVQUFVLENBQUMsRUFDbEMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUN6QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUyxlQUFlLENBQUMsQ0FBQyxDQUN4RCxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO21EQUM2QixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7TUE4QnhELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZDQUE2QyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRWxFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFDekMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVkseUJBQXlCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDekUsQ0FBQztJQUNOLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsWUFBWSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDOUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3FEQUMrQixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O01BNEIxRCxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWtCLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxFQUMzQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYSxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDL0QsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxRQUFrQixFQUFFLE9BQWdCO1FBQ2hFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7Ozs2QkFLTyxRQUFRLENBQUMsSUFBSTtnQ0FDVixRQUFRLENBQUMsT0FBTztpQ0FDZixRQUFRLENBQUMsUUFBUTtxQ0FDYixRQUFRLENBQUMsWUFBWTtrQ0FDeEIsUUFBUSxDQUFDLFNBQVM7OEJBQ3RCLFFBQVEsQ0FBQyxLQUFLO3dDQUNKLFFBQVEsQ0FBQyxlQUFlOzBDQUN0QixRQUFRLENBQUMsaUJBQWlCO3VDQUM3QixRQUFRLENBQUMsY0FBYztzQ0FDeEIsUUFBUSxDQUFDLGFBQWE7cUNBQ3ZCLFFBQVEsQ0FBQyxZQUFZO3NDQUNwQixRQUFRLENBQUMsYUFBYTtxQ0FDdkIsUUFBUSxDQUFDLFlBQVk7dUNBQ25CLFFBQVEsQ0FBQyxjQUFjOzBDQUNwQixRQUFRLENBQUMsaUJBQWlCO21DQUNqQyxRQUFRLENBQUMsVUFBVTtpQ0FDckIsUUFBUSxDQUFDLFFBQVE7aUNBQ2pCLFFBQVEsQ0FBQyxRQUFRO3VDQUNYLFFBQVEsQ0FBQyxjQUFjO3NDQUN4QixRQUFRLENBQUMsYUFBYTswQ0FDbEIsUUFBUSxDQUFDLGlCQUFpQjtrQ0FDbEMsUUFBUSxDQUFDLFNBQVM7aUNBQ25CLFFBQVEsQ0FBQyxRQUFRO3dDQUNWLFFBQVEsQ0FBQyxpQkFBaUI7OEJBQ3BDLFFBQVEsQ0FBQyxLQUFLOztNQUV0QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV6QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUN2QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBVyxjQUFjLENBQUMsQ0FBQyxDQUN6RCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxRQUFrQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFFBQVEsQ0FBQyxHQUFHLGFBQWEsUUFBUSxDQUFDLElBQUk7V0FDdEMsUUFBUSxDQUFDLEdBQUcsaUJBQWlCLFFBQVEsQ0FBQyxRQUFRO1dBQzlDLFFBQVEsQ0FBQyxHQUFHLHFCQUFxQixRQUFRLENBQUMsWUFBWTtXQUN0RCxRQUFRLENBQUMsR0FBRyxrQkFBa0IsUUFBUSxDQUFDLFNBQVM7V0FDaEQsUUFBUSxDQUFDLEdBQUcsY0FBYyxRQUFRLENBQUMsS0FBSztXQUN4QyxRQUFRLENBQUMsR0FBRyx3QkFBd0IsUUFBUSxDQUFDLGVBQWU7V0FDNUQsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7V0FDaEUsUUFBUSxDQUFDLEdBQUcsdUJBQXVCLFFBQVEsQ0FBQyxjQUFjO1dBQzFELFFBQVEsQ0FBQyxHQUFHLHNCQUFzQixRQUFRLENBQUMsYUFBYTtXQUN4RCxRQUFRLENBQUMsR0FBRyxxQkFBcUIsUUFBUSxDQUFDLFlBQVk7V0FDdEQsUUFBUSxDQUFDLEdBQUcsc0JBQXNCLFFBQVEsQ0FBQyxhQUFhO1dBQ3hELFFBQVEsQ0FBQyxHQUFHLHFCQUFxQixRQUFRLENBQUMsWUFBWTtXQUN0RCxRQUFRLENBQUMsR0FBRyx1QkFBdUIsUUFBUSxDQUFDLGNBQWM7V0FDMUQsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7V0FDaEUsUUFBUSxDQUFDLEdBQUcsbUJBQW1CLFFBQVEsQ0FBQyxVQUFVO1dBQ2xELFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRyxpQkFBaUIsUUFBUSxDQUFDLFFBQVE7V0FDOUMsUUFBUSxDQUFDLEdBQUcsdUJBQXVCLFFBQVEsQ0FBQyxjQUFjO1dBQzFELFFBQVEsQ0FBQyxHQUFHLHNCQUFzQixRQUFRLENBQUMsYUFBYTtXQUN4RCxRQUFRLENBQUMsR0FBRywwQkFBMEIsUUFBUSxDQUFDLGlCQUFpQjtXQUNoRSxRQUFRLENBQUMsR0FBRyxrQkFBa0IsUUFBUSxDQUFDLFNBQVM7V0FDaEQsUUFBUSxDQUFDLEdBQUcsaUJBQWlCLFFBQVEsQ0FBQyxRQUFRO1dBQzlDLFFBQVEsQ0FBQyxHQUFHLHdCQUF3QixRQUFRLENBQUMsaUJBQWlCO1dBQzlELFFBQVEsQ0FBQyxHQUFHLGNBQWMsUUFBUSxDQUFDLEtBQUs7O01BRTdDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVcsaUJBQWlCLENBQUMsQ0FBQyxDQUM1RCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLFdBQW1CLEVBQUUsT0FBZ0I7UUFDcEUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsV0FBVzs7TUFFaEIsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxXQUFXLFVBQVUsQ0FBQyxDQUFDLEVBQ2xFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsZ0JBQWdCLENBQUMsQ0FBQyxDQUN6RCxDQUFDO0lBQ04sQ0FBQztJQUVELGFBQWEsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRztzREFDZ0MsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztNQXlCM0QsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFtQixDQUFDLEVBQ3BELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUMsRUFDNUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsZUFBZSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ2pFLENBQUM7SUFDTixDQUFDO0lBRUQsWUFBWSxDQUFDLFVBQWtCLEVBQUUsU0FBb0IsRUFBRSxPQUFnQjtRQUNuRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7OEJBS1EsU0FBUyxDQUFDLElBQUk7aUNBQ1gsU0FBUyxDQUFDLE9BQU87a0NBQ2hCLFNBQVMsQ0FBQyxRQUFRO3VDQUNiLFNBQVMsQ0FBQyxhQUFhOzhCQUNoQyxTQUFTLENBQUMsSUFBSTs4QkFDZCxTQUFTLENBQUMsSUFBSTtzQ0FDTixTQUFTLENBQUMsWUFBWTs4QkFDOUIsU0FBUyxDQUFDLElBQUk7a0NBQ1YsU0FBUyxDQUFDLFFBQVE7cUNBQ2YsU0FBUyxDQUFDLFdBQVc7bUNBQ3ZCLFNBQVMsQ0FBQyxTQUFTO2tDQUNwQixTQUFTLENBQUMsWUFBWTtnQ0FDeEIsU0FBUyxDQUFDLE1BQU07a0NBQ2QsU0FBUyxDQUFDLFFBQVE7a0NBQ2xCLFNBQVMsQ0FBQyxRQUFRO2tDQUNsQixTQUFTLENBQUMsUUFBUTtzQ0FDZCxTQUFTLENBQUMsWUFBWTsyQ0FDakIsU0FBUyxDQUFDLGlCQUFpQjtxQ0FDakMsU0FBUyxDQUFDLFdBQVc7c0NBQ3BCLFNBQVMsQ0FBQyxZQUFZOzZCQUMvQixTQUFTLENBQUMsR0FBRzsrQkFDWCxTQUFTLENBQUMsS0FBSzs7TUFFeEMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxFQUN4QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBWSxlQUFlLENBQUMsQ0FBQyxDQUMzRCxDQUFDO0lBQ04sQ0FBQztJQUVELGVBQWUsQ0FBQyxTQUFvQixFQUFFLE9BQWdCO1FBQ2xELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFNBQVMsQ0FBQyxHQUFHLGFBQWEsU0FBUyxDQUFDLElBQUk7V0FDeEMsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxRQUFRO1dBQ2hELFNBQVMsQ0FBQyxHQUFHLHNCQUFzQixTQUFTLENBQUMsYUFBYTtXQUMxRCxTQUFTLENBQUMsR0FBRyxhQUFhLFNBQVMsQ0FBQyxJQUFJO1dBQ3hDLFNBQVMsQ0FBQyxHQUFHLGFBQWEsU0FBUyxDQUFDLElBQUk7V0FDeEMsU0FBUyxDQUFDLEdBQUcscUJBQXFCLFNBQVMsQ0FBQyxZQUFZO1dBQ3hELFNBQVMsQ0FBQyxHQUFHLGFBQWEsU0FBUyxDQUFDLElBQUk7V0FDeEMsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxRQUFRO1dBQ2hELFNBQVMsQ0FBQyxHQUFHLG9CQUFvQixTQUFTLENBQUMsV0FBVztXQUN0RCxTQUFTLENBQUMsR0FBRyxrQkFBa0IsU0FBUyxDQUFDLFNBQVM7V0FDbEQsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxZQUFZO1dBQ3BELFNBQVMsQ0FBQyxHQUFHLGVBQWUsU0FBUyxDQUFDLE1BQU07V0FDNUMsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxRQUFRO1dBQ2hELFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsUUFBUTtXQUNoRCxTQUFTLENBQUMsR0FBRyxpQkFBaUIsU0FBUyxDQUFDLFFBQVE7V0FDaEQsU0FBUyxDQUFDLEdBQUcscUJBQXFCLFNBQVMsQ0FBQyxZQUFZO1dBQ3hELFNBQVMsQ0FBQyxHQUFHLDBCQUEwQixTQUFTLENBQUMsaUJBQWlCO1dBQ2xFLFNBQVMsQ0FBQyxHQUFHLG9CQUFvQixTQUFTLENBQUMsV0FBVztXQUN0RCxTQUFTLENBQUMsR0FBRyxxQkFBcUIsU0FBUyxDQUFDLFlBQVk7V0FDeEQsU0FBUyxDQUFDLEdBQUcsWUFBWSxTQUFTLENBQUMsR0FBRztXQUN0QyxTQUFTLENBQUMsR0FBRyxjQUFjLFNBQVMsQ0FBQyxLQUFLOztNQUUvQyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV6QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLEVBQzVDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFZLGtCQUFrQixDQUFDLENBQUMsQ0FDOUQsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsVUFBa0IsRUFBRSxZQUFvQixFQUFFLE9BQWdCO1FBQ3RFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFlBQVk7O01BRWpCLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRTFELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLEdBQUcsWUFBWSxVQUFVLENBQUMsQ0FBQyxFQUNuRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEVBQzNDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFTLGlCQUFpQixDQUFDLENBQUMsQ0FDMUQsQ0FBQztJQUNOLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQ3JELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzttREFDNkIsV0FBVzs7Ozs7Ozs7Ozs7Ozs7O01BZXhELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZDQUE2QyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRWxFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFDekMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVksc0JBQXNCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDdEUsQ0FBQztJQUNOLENBQUM7SUFFRCxTQUFTLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUMzQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7a0RBQzRCLFdBQVc7Ozs7Ozs7Ozs7OztNQVl2RCxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWUsQ0FBQyxFQUNoRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEVBQ3hDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFVLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUN6RCxDQUFDO0lBQ04sQ0FBQztJQUVELFFBQVEsQ0FBQyxVQUFrQixFQUFFLEtBQVksRUFBRSxPQUFnQjtRQUN2RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7MEJBS0ksS0FBSyxDQUFDLElBQUk7NkJBQ1AsS0FBSyxDQUFDLE9BQU87OEJBQ1osS0FBSyxDQUFDLFFBQVE7MEJBQ2xCLEtBQUssQ0FBQyxJQUFJO2lDQUNILEtBQUssQ0FBQyxXQUFXOytCQUNuQixLQUFLLENBQUMsU0FBUzt5QkFDckIsS0FBSyxDQUFDLEdBQUc7MkJBQ1AsS0FBSyxDQUFDLEtBQUs7bUNBQ0gsS0FBSyxDQUFDLGFBQWE7O01BRWhELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQy9DLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDLEVBQ3BDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFRLFdBQVcsQ0FBQyxDQUFDLENBQ25ELENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLEtBQVksRUFBRSxPQUFnQjtRQUN0QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxLQUFLLENBQUMsR0FBRyxhQUFhLEtBQUssQ0FBQyxJQUFJO1dBQ2hDLEtBQUssQ0FBQyxHQUFHLGlCQUFpQixLQUFLLENBQUMsUUFBUTtXQUN4QyxLQUFLLENBQUMsR0FBRyxhQUFhLEtBQUssQ0FBQyxJQUFJO1dBQ2hDLEtBQUssQ0FBQyxHQUFHLG9CQUFvQixLQUFLLENBQUMsV0FBVztXQUM5QyxLQUFLLENBQUMsR0FBRyxrQkFBa0IsS0FBSyxDQUFDLFNBQVM7V0FDMUMsS0FBSyxDQUFDLEdBQUcsWUFBWSxLQUFLLENBQUMsR0FBRztXQUM5QixLQUFLLENBQUMsR0FBRyxjQUFjLEtBQUssQ0FBQyxLQUFLO1dBQ2xDLEtBQUssQ0FBQyxHQUFHLHNCQUFzQixLQUFLLENBQUMsYUFBYTs7TUFFdkQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFDL0MsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxFQUN4QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUSxjQUFjLENBQUMsQ0FBQyxDQUN0RCxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxVQUFrQixFQUFFLFFBQWdCLEVBQUUsT0FBZ0I7UUFDOUQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsUUFBUTs7TUFFYixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV0RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLFFBQVEsVUFBVSxDQUFDLENBQUMsRUFDL0QsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUyxhQUFhLENBQUMsQ0FBQyxDQUN0RCxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0saUJBQWlCLEdBQ25CLCtTQUErUyxDQUFDO1FBQ3BULE1BQU0sa0JBQWtCLEdBQ3BCLDRNQUE0TSxDQUFDO1FBQ2pOLE1BQU0sZUFBZSxHQUFHLDJDQUEyQyxDQUFDO1FBQ3BFLE1BQU0sa0JBQWtCLEdBQ3BCLDhGQUE4RixDQUFDO1FBRW5HLE1BQU0sS0FBSyxHQUFHO21EQUM2QixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBbUJsRCxpQkFBaUI7WUFDakIsa0JBQWtCO1lBQ2xCLGVBQWU7WUFDZixrQkFBa0I7OztNQUd4QixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2Q0FBNkMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQ3pDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFZLHlCQUF5QixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3pFLENBQUM7SUFDTixDQUFDO0lBRUQsWUFBWSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDOUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0saUJBQWlCLEdBQ25CLDBTQUEwUyxDQUFDO1FBQy9TLE1BQU0sa0JBQWtCLEdBQ3BCLHVNQUF1TSxDQUFDO1FBQzVNLE1BQU0sZUFBZSxHQUFHLDJDQUEyQyxDQUFDO1FBQ3BFLE1BQU0sa0JBQWtCLEdBQ3BCLDhGQUE4RixDQUFDO1FBRW5HLE1BQU0sS0FBSyxHQUFHO2tEQUM0QixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7VUFxQm5ELGlCQUFpQjtVQUNqQixrQkFBa0I7VUFDbEIsZUFBZTtVQUNmLGtCQUFrQjs7TUFFdEIsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFrQixDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWEsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQy9ELENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLFVBQWtCLEVBQUUsUUFBa0IsRUFBRSxPQUFnQjtRQUNoRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUV0RCxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7UUFFZixLQUFLLEdBQUc7Ozs2QkFHYSxRQUFRLENBQUMsSUFBSTs2QkFDYixRQUFRLENBQUMsSUFBSTs7O3FDQUdMLFFBQVEsQ0FBQyxZQUFZO3FDQUNyQixRQUFRLENBQUMsWUFBWTtnQ0FDMUIsUUFBUSxDQUFDLE9BQU87aUNBQ2YsUUFBUSxDQUFDLFFBQVE7b0NBQ2QsUUFBUSxDQUFDLFdBQVc7K0JBQ3pCLFFBQVEsQ0FBQyxNQUFNOzBDQUNKLFFBQVEsQ0FBQyxpQkFBaUI7aUNBQ25DLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7V0FDekQsVUFBVTs7TUFFZixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV6QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUN0QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBVyxjQUFjLENBQUMsQ0FBQyxDQUN6RCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxRQUFrQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFFBQVEsQ0FBQyxHQUFHLG9CQUFvQixRQUFRLENBQUMsV0FBVztXQUNwRCxRQUFRLENBQUMsR0FBRyxlQUFlLFFBQVEsQ0FBQyxNQUFNO1dBQzFDLFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRywwQkFBMEIsUUFBUSxDQUFDLGlCQUFpQjtXQUNoRSxRQUFRLENBQUMsR0FBRyxpQkFBaUIsUUFBUSxDQUFDLFFBQVE7V0FDOUMsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7O01BRXJFLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVcsZ0JBQWdCLENBQUMsQ0FBQyxDQUMzRCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLFFBQWtCLEVBQUUsT0FBZ0I7UUFDbkUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFFdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsUUFBUSxDQUFDLEdBQUc7V0FDWixVQUFVLHlCQUF5QixRQUFRLENBQUMsR0FBRzs7TUFFcEQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsa0JBQWtCLENBQUMsQ0FBQyxFQUM1RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQzFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFTLGdCQUFnQixDQUFDLENBQUMsQ0FDekQsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCw2QkFBNkIsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQy9ELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRztzQkFDQSxXQUFXOzs7Ozs7OztNQVEzQixDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWtCLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxFQUM5QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYSwrQkFBK0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNoRixDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILDhCQUE4QixDQUFDLFlBQW9CLEVBQUUsT0FBZ0I7UUFDakUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3NCQUNBLFlBQVk7Ozs7Ozs7O01BUTVCLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBa0IsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEVBQzlDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFhLGdDQUFnQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ2pGLENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDakQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO2tEQUM0QixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7TUFldkQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFdEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQXFCLENBQUMsRUFDdEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxFQUM5QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBZ0IsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDckUsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxXQUF3QixFQUFFLE9BQWdCO1FBQ3pFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7Z0NBR1UsV0FBVyxDQUFDLElBQUk7Z0NBQ2hCLFdBQVcsQ0FBQyxJQUFJOzs7dUNBR1QsV0FBVyxDQUFDLFdBQVc7a0NBQzVCLFdBQVcsQ0FBQyxNQUFNO29DQUNoQixXQUFXLENBQUMsUUFBUTtpQ0FDdkIsV0FBVyxDQUFDLEtBQUs7bUNBQ2YsV0FBVyxDQUFDLE9BQU87b0NBQ2xCLFdBQVcsQ0FBQyxRQUFRO1dBQzdDLFVBQVU7O01BRWYsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsV0FBVyxDQUFDLENBQUMsRUFDckQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUN6QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYyxnQkFBZ0IsQ0FBQyxDQUFDLENBQzlELENBQUM7SUFDTixDQUFDO0lBRUQsaUJBQWlCLENBQUMsV0FBd0IsRUFBRSxPQUFnQjtRQUN4RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxXQUFXLENBQUMsR0FBRyxhQUFhLFdBQVcsQ0FBQyxJQUFJO1dBQzVDLFdBQVcsQ0FBQyxHQUFHLGFBQWEsV0FBVyxDQUFDLElBQUk7V0FDNUMsV0FBVyxDQUFDLEdBQUcsb0JBQW9CLFdBQVcsQ0FBQyxXQUFXO1dBQzFELFdBQVcsQ0FBQyxHQUFHLG1CQUFtQixXQUFXLENBQUMsTUFBTTtXQUNwRCxXQUFXLENBQUMsR0FBRyxxQkFBcUIsV0FBVyxDQUFDLFFBQVE7V0FDeEQsV0FBVyxDQUFDLEdBQUcsY0FBYyxXQUFXLENBQUMsS0FBSztXQUM5QyxXQUFXLENBQUMsR0FBRyxpQkFBaUIsV0FBVyxDQUFDLFFBQVE7O01BRXpELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxDQUFDLEVBQ3JELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUMsRUFDN0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsbUJBQW1CLENBQUMsQ0FBQyxDQUNqRSxDQUFDO0lBQ04sQ0FBQztJQUVELGlCQUFpQixDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxPQUFnQjtRQUMxRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxjQUFjO1dBQ2QsVUFBVSw0QkFBNEIsY0FBYzs7TUFFekQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxjQUFjLFVBQVUsQ0FBQyxDQUFDLEVBQ3JFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUMsRUFDN0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsbUJBQW1CLENBQUMsQ0FBQyxDQUM1RCxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDbEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO2tEQUM0QixXQUFXOzs7Ozs7OztNQVF2RCxDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV2RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBOEIsQ0FBQyxFQUMvRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLEVBQy9DLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUF5QixtQkFBbUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNoRixDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUNaLFVBQWtCLEVBQ2xCLGFBQW1DLEVBQ25DLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBRXRELE1BQU0sS0FBSyxHQUFHOzs7OztrQ0FLWSxhQUFhLENBQUMsV0FBVztXQUNoRCxVQUFVOztNQUVmLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxDQUFDLEVBQ3ZELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQXVCLGtCQUFrQixDQUFDLENBQUMsQ0FDekUsQ0FBQztJQUNOLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxhQUFtQyxFQUFFLE9BQWdCO1FBQ3JFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLGFBQWEsQ0FBQyxHQUFHLG9CQUFvQixhQUFhLENBQUMsV0FBVzs7TUFFbkUsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDLENBQUMsRUFDdkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxFQUMvQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBdUIscUJBQXFCLENBQUMsQ0FBQyxDQUM1RSxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxVQUFrQixFQUFFLGNBQXNCLEVBQUUsV0FBbUIsRUFBRSxPQUFnQjtRQUN6RixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsdU9BQXVPO1FBQ3ZPLGlMQUFpTDtRQUVqTCxNQUFNLEtBQUssR0FBRzttREFDNkIsVUFBVSxJQUFJLGNBQWM7K0NBQ2hDLFdBQVc7Ozs7Ozs7TUFPcEQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFcEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ3ZFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQy9ELENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxFQUFVLEVBQUUsT0FBZ0I7UUFDbEYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO21EQUM2QixVQUFVLElBQUksY0FBYzsyREFDcEIsRUFBRTs7Ozs7OztNQU92RCxDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV0RCxpTkFBaU47UUFDak4sT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYyxlQUFlLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDakUsQ0FBQztJQUNOLENBQUM7SUFFRCxxQkFBcUIsQ0FDakIsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsTUFBYyxFQUNkLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxvTEFBb0w7UUFDcEwsTUFBTSxLQUFLLEdBQUc7bURBQzZCLFVBQVUsSUFBSSxjQUFjOzJEQUNwQixNQUFNOzs7Ozs7O01BTzNELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXJDLGlOQUFpTjtRQUNqTixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQzFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3pFLENBQUM7SUFDTixDQUFDO0lBRUQsa0JBQWtCLENBQ2QsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsTUFBYyxFQUNkLElBQVksRUFDWixPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsb0xBQW9MO1FBQ3BMLE1BQU0sS0FBSyxHQUFHO21EQUM2QixVQUFVLElBQUksY0FBYzsyREFDcEIsTUFBTSxxQkFBcUIsSUFBSTs7Ozs7OztNQU9wRixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVyQyxpTkFBaU47UUFDak4sT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYyxvQkFBb0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUN0RSxDQUFDO0lBQ04sQ0FBQztJQUVELHdCQUF3QixDQUFDLFVBQWtCLEVBQUUsT0FBZ0I7UUFDekQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO2tEQUM0QixVQUFVOzs7Ozs7Ozs7TUFTdEQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFaEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYywwQkFBMEIsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUM1RSxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUFDLE9BQWdCO1FBQzdCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFDL0MsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7Ozs7OztNQU1oQixDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQXNCLENBQUMsRUFDdkQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUMsRUFDL0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWlCLGtCQUFrQixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3ZFLENBQUM7SUFDTixDQUFDO0lBRUQsUUFBUSxDQUFDLFVBQWtCLEVBQUUsT0FBZ0I7UUFDekMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQztRQUVqQixJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDNUIsS0FBSyxHQUFHLE1BQU0sQ0FBQztTQUNsQjthQUFNLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRTtZQUNuQyxLQUFLLEdBQUcsTUFBTSxDQUFDO1NBQ2xCO2FBQU0sSUFBSSxVQUFVLElBQUksWUFBWSxFQUFFO1lBQ25DLEtBQUssR0FBRyxNQUFNLENBQUM7U0FDbEI7YUFBTTtZQUNILEtBQUssR0FBRyxVQUFVLENBQUM7U0FDdEI7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQsY0FBYyxDQUFDLFVBQWtCLEVBQUUsT0FBZ0I7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztRQUVsQixvQkFBb0I7UUFDcEIsOEJBQThCO1FBQzlCLDZCQUE2QjtRQUU3QixJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDNUIsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTTtZQUNILE1BQU0sR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztTQUN6QjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxPQUFnQjtRQUM5QyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN6QixJQUFJLENBQUMsT0FBTztnQkFBRSxNQUFNLElBQUksS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7U0FDckQ7SUFDSCxDQUFDO0lBQ0Q7Ozs7O09BS0c7SUFDSyxXQUFXLENBQUksU0FBUyxHQUFHLFdBQVcsRUFBRSxNQUFVO1FBQ3RELE9BQU8sQ0FBQyxLQUFVLEVBQWlCLEVBQUU7WUFDakMsOERBQThEO1lBQzlELE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLFlBQVksS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUVwRSx5REFBeUQ7WUFDekQsT0FBTyxFQUFFLENBQUMsTUFBVyxDQUFDLENBQUM7UUFDM0IsQ0FBQyxDQUFDO0lBQ04sQ0FBQztDQUNKIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgICBEYXRhU3RvcmUsXG4gICAgR2F0ZXdheSxcbiAgICBHYXRld2F5RmlsdGVyc0NvbmZpZyxcbiAgICBNb2RlbCxcbiAgICBNb2RlbENvbmZpZyxcbiAgICBOb3RpZmljYXRpb24sXG4gICAgUGlwZWxpbmUsXG4gICAgUHJvdG9jb2wsXG4gICAgVFNSZWFkaW5nLFxufSBmcm9tICcuLi9tb2RlbC9tb2RlbHMnO1xuaW1wb3J0IHsgY2F0Y2hFcnJvciwgbWFwLCBPYnNlcnZhYmxlLCBvZiwgdGFwIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBBeGlvcyB9IGZyb20gJ2F4aW9zLW9ic2VydmFibGUnO1xuXG5jb25zdCByb3V0ZTE6IG51bWJlcltdW10gPSBbXG4gICAgWzI1Ljc3MTA4OCwgLTgwLjE2MzQ4M10sXG4gICAgWzI3LjQzOTc3NSwgLTgwLjMyMjk5XSxcbiAgICBbMjguMzQ5NDY5LCAtODAuNzMxMTA1XSxcbiAgICBbMzAuNDAxNTY0LCAtODEuNTcxMDMzXSxcbiAgICBbMzIuMTE2NzE2LCAtODEuMTQ0MTQ3XSxcbiAgICBbMzIuODY2NTExLCAtNzkuOTk1Mzk5XSxcbiAgICBbMzQuMTkxMjI0LCAtNzcuOTUyNDE5XSxcbiAgICBbMzYuODUwMTcyLCAtNzYuMzE5MjY5XSxcbiAgICBbMzYuOTE1MDM3LCAtNzYuMzIwNjQzXSxcbiAgICBbMzkuMjYyMDI1LCAtNzYuNTQ5Mjk0XSxcbiAgICBbMzkuOTAwOTMzLCAtNzUuMTQzNDUzXSxcbiAgICBbNDAuNjkwMjYzLCAtNzQuMTUyMzc1XSxcbiAgICBbNDIuMjU5OTUxLCAtNzEuNzg5MjQ0XSxcbl07XG5cbmNvbnN0IHJvdXRlMjogbnVtYmVyW11bXSA9IFtcbiAgICBbNDcuNDkyNDcxLCAtMTIyLjI2ODg4XSxcbiAgICBbNDUuNTUyMjA3LCAtMTIyLjcyMjY0OF0sXG4gICAgWzM5LjUzMjQ2LCAtMTE5Ljc1MTUyNF0sXG4gICAgWzM3LjgwMzUyOCwgLTEyMi4zMTIxMzhdLFxuICAgIFszNy44OTkzMzIsIC0xMjEuMTY5MzA3XSxcbiAgICBbMzYuMjczMTgzLCAtMTE1LjA3MDUzNF0sXG4gICAgWzMzLjc3MDMyLCAtMTE4LjI3MzI4OV0sXG4gICAgWzM0LjEwNjAxMiwgLTExNy4zMjAyNTRdLFxuICAgIFszMy41MTU1NjQsIC0xMTIuMTYwNTY0XSxcbiAgICBbMzIuMTI2NDM3LCAtMTEwLjg0ODMzNl0sXG4gICAgWzMxLjc1MjA4NSwgLTEwNi40ODg4ODddLFxuICAgIFszNS4wNDc1OCwgLTEwNi42NTMzNDRdLFxuICAgIFszOS43OTY5NjMsIC0xMDQuOTk1Mzc0XSxcbl07XG5cbmNvbnN0IHJvdXRlMzogbnVtYmVyW11bXSA9IFtcbiAgICBbMjkuMzAyNzI5LCAtOTguNjM4NzQ0XSxcbiAgICBbMjkuNjM4NDIxLCAtOTUuMjkyMjQ1XSxcbiAgICBbMzIuNjE1NTI1LCAtOTYuNjkzNDg1XSxcbiAgICBbMjkuOTE3ODM2LCAtOTAuMjA1MjcyXSxcbiAgICBbMzIuMjU2NDAzLCAtOTAuMTUxNTQ2XSxcbiAgICBbMzUuMDQ0ODQ5LCAtOTAuMTUzMDA2XSxcbiAgICBbMzguNTI0NjI3LCAtOTAuMjA5NTM1XSxcbiAgICBbMzkuODcwODUxLCAtODguOTEyMjg0XSxcbiAgICBbNDEuNzA1Njk0LCAtODcuNTc3MzQxXSxcbiAgICBbNDEuOTAyMzgyLCAtODkuMTAxOTMyXSxcbiAgICBbNDQuMjUxMjQzLCAtOTEuNTA5NjYzXSxcbiAgICBbNDQuOTcwMDY5LCAtOTMuMTc0NTI3XSxcbiAgICBbNDYuNzU4MTgxLCAtOTIuMDk4NzQ4XSxcbl07XG5cbmNvbnN0IGVtcHR5cm91dGU6IG51bWJlcltdW10gPSBbXTtcblxuY29uc3QgaHR0cE9wdGlvbnMgPSB7XG4gICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2dyYXBocWwrLScgfSxcbn07XG5cbmNvbnN0IGh0dHBNdXRhdGVPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9yZGYnIH0sXG59O1xuXG5leHBvcnQgY2xhc3MgR3JhcGhTZXJ2aWNlIHtcblxuICBwcml2YXRlIHJlcXVpcmVBY2NvdW50SWQgPSB0cnVlO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBBeGlvcywgcHJvdGVjdGVkIGRHcmFwaFVybDogc3RyaW5nLCBwcml2YXRlIGFjY291bnRSZXF1aXJlZDogYm9vbGVhbikge1xuICAgICAgICBjb25zb2xlLmxvZyhgZEdyYXBoVXJsOiAke3RoaXMuZEdyYXBoVXJsfSByZXF1aXJlcyBhY2NvdW50IGlkZW50aWZpZXIgJHthY2NvdW50UmVxdWlyZWR9YCk7XG4gICAgICB0aGlzLnJlcXVpcmVBY2NvdW50SWQgPSBhY2NvdW50UmVxdWlyZWQ7XG4gICAgICAgIC8vY29uc3QgZEdyYXBoQmFzaWNBdXRoRW5hYmxlZCA9IHRoaXMuYXBwQ29uZmlnU2VydmljZS5kR3JhcGhCYXNpY0F1dGhFbmFibGVkO1xuICAgICAgICAvL2lmIChkR3JhcGhCYXNpY0F1dGhFbmFibGVkKSB7XG4gICAgICAgIC8vICAgIGNvbnN0IGRHcmFwaEJhc2ljQXV0aCA9IHRoaXMuYXBwQ29uZmlnU2VydmljZS5kR3JhcGhCYXNpY0F1dGg7XG4gICAgICAgIC8vICAgICh0aGlzLmh0dHBPcHRpb25zLmhlYWRlcnMgPSB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vZ3JhcGhxbCstJyB9KSwgeyBBdXRob3JpemF0aW9uOiBkR3JhcGhCYXNpY0F1dGggfTtcbiAgICAgICAgLy8gICAgKHRoaXMuaHR0cE11dGF0ZU9wdGlvbnMuaGVhZGVycyA9IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9yZGYnIH0pLCB7IEF1dGhvcml6YXRpb246IGRHcmFwaEJhc2ljQXV0aCB9O1xuICAgICAgICAvL31cbiAgICB9XG5cbiAgICBnZXRHYXRld2F5KGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdHZXRHYXRld2F5IHNlcnZpY2UgY2FsbGVkIGZvcjogJywgZ2F0ZXdheU5hbWUpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhnYXRld2F5KSkgQGZpbHRlcihlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkIGRlc2NyaXB0aW9uIGFkZHJlc3Mgcm91dGVyIHJvdXRlclBvcnQgZGVwbG95TmV0d29yayBsYXRpdHVkZSBsb25naXR1ZGUgYWNjZXNzVG9rZW4gdXNlcm5hbWUgcGxhdGZvcm0gZGV2aWNlc01ldGFkYXRhIGNyZWF0ZWR0cyB1cGRhdGVkdHNcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gY29uc29sZS5sb2coJ1Jlc3BvbnNlIGZyb20gZ2V0R2F0ZXdheTogJywgcmVzcG9uc2UpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5W10+KCdnZXRHYXRld2F5JywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRHYXRld2F5cyhhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc29sZS5sb2coYEdldEdhdGV3YXlzIHNlcnZpY2UgY2FsbGVkIGZvciAke2FjY291bnR9YCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSB7XG4gICAgICAgIHVpZCB1dWlkIGRlc2NyaXB0aW9uIGFkZHJlc3Mgcm91dGVyIHJvdXRlclBvcnQgZGVwbG95TmV0d29yayBsYXRpdHVkZSBsb25naXR1ZGUgYWNjZXNzVG9rZW4gdXNlcm5hbWUgcGxhdGZvcm0gZGV2aWNlc01ldGFkYXRhIGNyZWF0ZWR0cyB1cGRhdGVkdHNcbiAgICAgICAgbnVtRGV2aWNlczogY291bnQoZ2F0ZXdheV9kZXZpY2UpXG5cbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIGdhdGV3YXlzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPEdhdGV3YXlbXT4oJ2dldEdhdGV3YXlzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVHYXRld2F5KGdhdGV3YXk6IEdhdGV3YXksIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8YWRkcmVzcz4gXCIke2dhdGV3YXkuYWRkcmVzc31cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPHJvdXRlcj4gXCIke2dhdGV3YXkucm91dGVyfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8cm91dGVyUG9ydD4gXCIke2dhdGV3YXkucm91dGVyUG9ydH1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPGRlcGxveU5ldHdvcms+IFwiJHtnYXRld2F5LmRlcGxveU5ldHdvcmt9XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxkZXNjcmlwdGlvbj4gXCIke2dhdGV3YXkuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxsYXRpdHVkZT4gXCIke2dhdGV3YXkubGF0aXR1ZGV9XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxsb25naXR1ZGU+IFwiJHtnYXRld2F5LmxvbmdpdHVkZX1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPGFjY2Vzc1Rva2VuPiBcIiR7Z2F0ZXdheS5hY2Nlc3NUb2tlbn1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPHVzZXJuYW1lPiBcIiR7Z2F0ZXdheS51c2VybmFtZX1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPHBsYXRmb3JtPiBcIiR7Z2F0ZXdheS5wbGF0Zm9ybX1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPHVwZGF0ZWR0cz4gXCIke2dhdGV3YXkudXBkYXRlZHRzfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ1VwZGF0ZSBHYXRld2F5IE11dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgoKSA9PiAnZ2F0ZXdheSB1cGRhdGVkJyksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ3VwZGF0ZWQgZ2F0ZXdheScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxzdHJpbmc+KCd1cGRhdGVHYXRld2F5JykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZEdhdGV3YXkoZ2F0ZXdheTogR2F0ZXdheSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpHYXRld2F5IDxkZ3JhcGgudHlwZT4gXCJHYXRld2F5XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGdhdGV3YXk+IFwiXCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHR5cGU+IFwiZ2F0ZXdheVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx1dWlkPiBcIiR7Z2F0ZXdheS51dWlkfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxkZXNjcmlwdGlvbj4gXCIke2dhdGV3YXkuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGFkZHJlc3M+IFwiJHtnYXRld2F5LmFkZHJlc3N9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHJvdXRlcj4gXCIke2dhdGV3YXkucm91dGVyfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxyb3V0ZXJQb3J0PiBcIiR7Z2F0ZXdheS5yb3V0ZXJQb3J0fVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxkZXBsb3lOZXR3b3JrPiBcIiR7Z2F0ZXdheS5kZXBsb3lOZXR3b3JrfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxsYXRpdHVkZT4gXCIke2dhdGV3YXkubGF0aXR1ZGV9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGxvbmdpdHVkZT4gXCIke2dhdGV3YXkubG9uZ2l0dWRlfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxhY2Nlc3NUb2tlbj4gXCIke2dhdGV3YXkuYWNjZXNzVG9rZW59XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHVzZXJuYW1lPiBcIiR7Z2F0ZXdheS51c2VybmFtZX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8cGxhdGZvcm0+IFwiJHtnYXRld2F5LnBsYXRmb3JtfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxjcmVhdGVkdHM+IFwiJHtnYXRld2F5LmNyZWF0ZWR0c31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8dXBkYXRlZHRzPiBcIiR7Z2F0ZXdheS51cGRhdGVkdHN9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnQWRkIEdhdGV3YXkgTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGdhdGV3YXkpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnYWRkIGdhdGV3YXknKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheT4oJ2FkZEdhdGV3YXknKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlR2F0ZXdheShnYXRld2F5VWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgZGVsZXRlIHtcbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+ICogKiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdEZWxldGUgR2F0ZXdheSBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKCkgPT4gYCR7Z2F0ZXdheVVpZH0gZGVsZXRlZGApLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdkZWxldGVkIGdhdGV3YXknKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlR2F0ZXdheScpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRHYXRld2F5QW5kUHJvdG9jb2xzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhnYXRld2F5KSkgQGZpbHRlcihlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICAgIHByb3RvY29sczogZ2F0ZXdheV9wcm90b2NvbCB7XG4gICAgICAgICAgdWlkXG4gICAgICAgICAgdXVpZFxuICAgICAgICAgIGNyZWF0ZWRcbiAgICAgICAgICBtb2RpZmllZFxuICAgICAgICAgIHByb3RvY29sVHlwZVxuICAgICAgICAgIGJyb2tlclVSTFxuICAgICAgICAgIHRvcGljXG4gICAgICAgICAgY29uc3VtZXJHcm91cElkXG4gICAgICAgICAgY29ubmVjdGlvblRpbWVvdXRcbiAgICAgICAgICBzZXNzaW9uVGltZW91dFxuICAgICAgICAgIGluaXRpYWxPZmZzZXRcbiAgICAgICAgICByZXRyeUJhY2tvZmZcbiAgICAgICAgICBmZXRjaE1pbkJ5dGVzXG4gICAgICAgICAgZmV0Y2hNYXhXYWl0XG4gICAgICAgICAgY29tbWl0SW50ZXJ2YWxcbiAgICAgICAgICBoZWFydGJlYXRJbnRlcnZhbFxuICAgICAgICAgIG1heGltdW1RT1NcbiAgICAgICAgICB1c2VybmFtZVxuICAgICAgICAgIHBhc3N3b3JkXG4gICAgICAgICAgZW5jcnlwdGlvbk1vZGVcbiAgICAgICAgICBjYUNlcnRpZmljYXRlXG4gICAgICAgICAgY2xpZW50Q2VydGlmaWNhdGVcbiAgICAgICAgICBjbGllbnRLZXlcbiAgICAgICAgICBhdXRoTW9kZVxuICAgICAgICAgIHNlcnZlckNlcnRpY2F0ZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdHZXQgR2F0ZXdheSBhbmQgUHJvdG9jb2xzIHF1ZXJ5IHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgR2F0ZXdheScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5W10+KCdnZXRHYXRld2F5V2l0aFByb3RvY29scycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGFsbCBnbG9iYWwgcHJvdG9jb2xzIGFuZCB0aGUgcHJvdG9jb2xzIHNjb3BlZCBmb3IgdGhlIGdhdGV3YXlcbiAgICAgKiBAcGFyYW0gZ2F0ZXdheU5hbWVcbiAgICAgKiBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkgQU5EIGx0KGNyZWF0ZWQsICR7dG90c30pKSAoZmlyc3Q6LTUwMClcbiAgICAgKi9cbiAgICBnZXRQcm90b2NvbHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2xbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhwcm90b2NvbCkpIEBmaWx0ZXIoZXEoc2NvcGUsIFwiJHtnYXRld2F5TmFtZX1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICB1dWlkXG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgbW9kaWZpZWRcbiAgICAgICAgcHJvdG9jb2xUeXBlXG4gICAgICAgIGJyb2tlclVSTFxuICAgICAgICB0b3BpY1xuICAgICAgICBjb25zdW1lckdyb3VwSWRcbiAgICAgICAgY29ubmVjdGlvblRpbWVvdXRcbiAgICAgICAgc2Vzc2lvblRpbWVvdXRcbiAgICAgICAgaW5pdGlhbE9mZnNldFxuICAgICAgICByZXRyeUJhY2tvZmZcbiAgICAgICAgZmV0Y2hNaW5CeXRlc1xuICAgICAgICBmZXRjaE1heFdhaXRcbiAgICAgICAgY29tbWl0SW50ZXJ2YWxcbiAgICAgICAgaGVhcnRiZWF0SW50ZXJ2YWxcbiAgICAgICAgbWF4aW11bVFPU1xuICAgICAgICB1c2VybmFtZVxuICAgICAgICBwYXNzd29yZFxuICAgICAgICBlbmNyeXB0aW9uTW9kZVxuICAgICAgICBjYUNlcnRpZmljYXRlXG4gICAgICAgIGNsaWVudENlcnRpZmljYXRlXG4gICAgICAgIGNsaWVudEtleVxuICAgICAgICBhdXRoTW9kZVxuICAgICAgICBzZXJ2ZXJDZXJ0aWNhdGVcbiAgICAgICAgc2NvcGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBQcm90b2NvbFtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBwcm90b2NvbHMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UHJvdG9jb2xbXT4oJ2dldFByb3RvY29scycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkUHJvdG9jb2woZ2F0ZXdheVVpZDogbnVtYmVyLCBwcm90b2NvbDogUHJvdG9jb2wsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFByb3RvY29sPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICBfOlByb3RvY29sIDxkZ3JhcGgudHlwZT4gXCJQcm90b2NvbFwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8dHlwZT4gXCJwcm90b2NvbFwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8cHJvdG9jb2w+IFwiXCIgLlxuICAgICAgICBfOlByb3RvY29sIDx1dWlkPiBcIiR7cHJvdG9jb2wudXVpZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNyZWF0ZWQ+IFwiJHtwcm90b2NvbC5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8bW9kaWZpZWQ+IFwiJHtwcm90b2NvbC5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHByb3RvY29sVHlwZT4gXCIke3Byb3RvY29sLnByb3RvY29sVHlwZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGJyb2tlclVSTD4gXCIke3Byb3RvY29sLmJyb2tlclVSTH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHRvcGljPiBcIiR7cHJvdG9jb2wudG9waWN9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjb25zdW1lckdyb3VwSWQ+IFwiJHtwcm90b2NvbC5jb25zdW1lckdyb3VwSWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjb25uZWN0aW9uVGltZW91dD4gXCIke3Byb3RvY29sLmNvbm5lY3Rpb25UaW1lb3V0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8c2Vzc2lvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5zZXNzaW9uVGltZW91dH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGluaXRpYWxPZmZzZXQ+IFwiJHtwcm90b2NvbC5pbml0aWFsT2Zmc2V0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8cmV0cnlCYWNrb2ZmPiBcIiR7cHJvdG9jb2wucmV0cnlCYWNrT2ZmfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8ZmV0Y2hNaW5CeXRlcz4gXCIke3Byb3RvY29sLmZldGNoTWluQnl0ZXN9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxmZXRjaE1heFdhaXQ+IFwiJHtwcm90b2NvbC5mZXRjaE1heFdhaXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjb21taXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmNvbW1pdEludGVydmFsfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8aGVhcnRiZWF0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5oZWFydGJlYXRJbnRlcnZhbH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPG1heGltdW1RT1M+IFwiJHtwcm90b2NvbC5tYXhpbXVtUU9TfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8dXNlcm5hbWU+IFwiJHtwcm90b2NvbC51c2VybmFtZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHBhc3N3b3JkPiBcIiR7cHJvdG9jb2wucGFzc3dvcmR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxlbmNyeXB0aW9uTW9kZT4gXCIke3Byb3RvY29sLmVuY3J5cHRpb25Nb2RlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y2FDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLmNhQ2VydGlmaWNhdGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjbGllbnRDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLmNsaWVudENlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y2xpZW50S2V5PiBcIiR7cHJvdG9jb2wuY2xpZW50S2V5fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8YXV0aE1vZGU+IFwiJHtwcm90b2NvbC5hdXRoTW9kZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHNlcnZlckNlcnRpY2F0ZT4gXCIke3Byb3RvY29sLnNlcnZlckNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8c2NvcGU+IFwiJHtwcm90b2NvbC5zY29wZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gcHJvdG9jb2wpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnYWRkIHByb3RvY29scycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQcm90b2NvbD4oJ2FkZFByb3RvY29scycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVQcm90b2NvbChwcm90b2NvbDogUHJvdG9jb2wsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFByb3RvY29sPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8dXVpZD4gXCIke3Byb3RvY29sLnV1aWR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8bW9kaWZpZWQ+IFwiJHtwcm90b2NvbC5tb2RpZmllZH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxwcm90b2NvbFR5cGU+IFwiJHtwcm90b2NvbC5wcm90b2NvbFR5cGV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8YnJva2VyVVJMPiBcIiR7cHJvdG9jb2wuYnJva2VyVVJMfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHRvcGljPiBcIiR7cHJvdG9jb2wudG9waWN9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8Y29uc3VtZXJHcm91cElkPiBcIiR7cHJvdG9jb2wuY29uc3VtZXJHcm91cElkfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGNvbm5lY3Rpb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuY29ubmVjdGlvblRpbWVvdXR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8c2Vzc2lvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5zZXNzaW9uVGltZW91dH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxpbml0aWFsT2Zmc2V0PiBcIiR7cHJvdG9jb2wuaW5pdGlhbE9mZnNldH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxyZXRyeUJhY2tvZmY+IFwiJHtwcm90b2NvbC5yZXRyeUJhY2tPZmZ9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8ZmV0Y2hNaW5CeXRlcz4gXCIke3Byb3RvY29sLmZldGNoTWluQnl0ZXN9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8ZmV0Y2hNYXhXYWl0PiBcIiR7cHJvdG9jb2wuZmV0Y2hNYXhXYWl0fVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGNvbW1pdEludGVydmFsPiBcIiR7cHJvdG9jb2wuY29tbWl0SW50ZXJ2YWx9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8aGVhcnRiZWF0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5oZWFydGJlYXRJbnRlcnZhbH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxtYXhpbXVtUU9TPiBcIiR7cHJvdG9jb2wubWF4aW11bVFPU31cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDx1c2VybmFtZT4gXCIke3Byb3RvY29sLnVzZXJuYW1lfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHBhc3N3b3JkPiBcIiR7cHJvdG9jb2wucGFzc3dvcmR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8ZW5jcnlwdGlvbk1vZGU+IFwiJHtwcm90b2NvbC5lbmNyeXB0aW9uTW9kZX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxjYUNlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2FDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxjbGllbnRDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLmNsaWVudENlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGNsaWVudEtleT4gXCIke3Byb3RvY29sLmNsaWVudEtleX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxhdXRoTW9kZT4gXCIke3Byb3RvY29sLmF1dGhNb2RlfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHNlcnZlckNlcnRpY2F0ZT4gXCIke3Byb3RvY29sLnNlcnZlckNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHNjb3BlPiBcIiR7cHJvdG9jb2wuc2NvcGV9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IHByb3RvY29sKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ3VwZGF0ZWQgcHJvdG9jb2xzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFByb3RvY29sPigndXBkYXRlUHJvdG9jb2xzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGRlbGV0ZVByb3RvY29sKGdhdGV3YXlVaWQ6IG51bWJlciwgcHJvdG9jb2xVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtwcm90b2NvbFVpZH0+ICogKiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdEZWxldGUgUHJvdG9jb2wgTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGAke3Byb3RvY29sVWlkfSBkZWxldGVkYCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdkZWxldGVkIHByb3RvY29sJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPHN0cmluZz4oJ2RlbGV0ZVByb3RvY29sJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldERhdGFTdG9yZXMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8RGF0YVN0b3JlW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZGF0YVN0b3JlKSkgQGZpbHRlcihlcShzY29wZSwgXCIke2dhdGV3YXlOYW1lfVwiKSBPUiBlcShzY29wZSwgXCJHTE9CQUxcIikpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIHV1aWRcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICBtb2RpZmllZFxuICAgICAgICBkYXRhU3RvcmVUeXBlXG4gICAgICAgIGhvc3RcbiAgICAgICAgcG9ydFxuICAgICAgICBkYXRhYmFzZU5hbWVcbiAgICAgICAgdXNlclxuICAgICAgICBwYXNzd29yZFxuICAgICAgICBhY2NvdW50TmFtZVxuICAgICAgICB3YXJlaG91c2VcbiAgICAgICAgZGF0YWJhc2VcbiAgICAgICAgc2NoZW1hXG4gICAgICAgIGF1dGhUeXBlXG4gICAgICAgIHVzZXJuYW1lXG4gICAgICAgIGNsaWVudElkXG4gICAgICAgIGNsaWVudFNlY3JldFxuICAgICAgICBhdXRob3JpemF0aW9uQ29kZVxuICAgICAgICByZWRpcmVjdFVSSVxuICAgICAgICBsb2dpblRpbWVvdXRcbiAgICAgICAgdXJsXG4gICAgICAgIHNjb3BlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgRGF0YVN0b3JlW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIGRhdGFTdG9yZXMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8RGF0YVN0b3JlW10+KCdnZXREYXRhU3RvcmVzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGREYXRhU3RvcmUoZ2F0ZXdheVVpZDogbnVtYmVyLCBkYXRhU3RvcmU6IERhdGFTdG9yZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8RGF0YVN0b3JlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICBfOkRhdGFTdG9yZSA8ZGdyYXBoLnR5cGU+IFwiRGF0YVN0b3JlXCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dHlwZT4gXCJkYXRhU3RvcmVcIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxkYXRhU3RvcmU+IFwiXCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXVpZD4gXCIke2RhdGFTdG9yZS51dWlkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGNyZWF0ZWQ+IFwiJHtkYXRhU3RvcmUuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxtb2RpZmllZD4gXCIke2RhdGFTdG9yZS5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxkYXRhU3RvcmVUeXBlPiBcIiR7ZGF0YVN0b3JlLmRhdGFTdG9yZVR5cGV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8aG9zdD4gXCIke2RhdGFTdG9yZS5ob3N0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHBvcnQ+IFwiJHtkYXRhU3RvcmUucG9ydH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxkYXRhYmFzZU5hbWU+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHVzZXI+IFwiJHtkYXRhU3RvcmUudXNlcn1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxwYXNzd29yZD4gXCIke2RhdGFTdG9yZS5wYXNzd29yZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhY2NvdW50TmFtZT4gXCIke2RhdGFTdG9yZS5hY2NvdW50TmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx3YXJlaG91c2U+IFwiJHtkYXRhU3RvcmUud2FyZWhvdXNlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFiYXNlPiBcIiR7ZGF0YVN0b3JlLmRhdGFiYXNlTmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxzY2hlbWE+IFwiJHtkYXRhU3RvcmUuc2NoZW1hfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGF1dGhUeXBlPiBcIiR7ZGF0YVN0b3JlLmF1dGhUeXBlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHVzZXJuYW1lPiBcIiR7ZGF0YVN0b3JlLnVzZXJuYW1lfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGNsaWVudElkPiBcIiR7ZGF0YVN0b3JlLmNsaWVudElkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGNsaWVudFNlY3JldD4gXCIke2RhdGFTdG9yZS5jbGllbnRTZWNyZXR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8YXV0aG9yaXphdGlvbkNvZGU+IFwiJHtkYXRhU3RvcmUuYXV0aG9yaXphdGlvbkNvZGV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8cmVkaXJlY3RVUkk+IFwiJHtkYXRhU3RvcmUucmVkaXJlY3RVUkl9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8bG9naW5UaW1lb3V0PiBcIiR7ZGF0YVN0b3JlLmxvZ2luVGltZW91dH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1cmw+IFwiJHtkYXRhU3RvcmUudXJsfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHNjb3BlPiBcIiR7ZGF0YVN0b3JlLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBkYXRhU3RvcmUpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnYWRkIGRhdGFTdG9yZXMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8RGF0YVN0b3JlPignYWRkRGF0YVN0b3JlcycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVEYXRhU3RvcmUoZGF0YVN0b3JlOiBEYXRhU3RvcmUsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERhdGFTdG9yZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDx1dWlkPiBcIiR7ZGF0YVN0b3JlLnV1aWR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPG1vZGlmaWVkPiBcIiR7ZGF0YVN0b3JlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxkYXRhU3RvcmVUeXBlPiBcIiR7ZGF0YVN0b3JlLmRhdGFTdG9yZVR5cGV9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGhvc3Q+IFwiJHtkYXRhU3RvcmUuaG9zdH1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8cG9ydD4gXCIke2RhdGFTdG9yZS5wb3J0fVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxkYXRhYmFzZU5hbWU+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDx1c2VyPiBcIiR7ZGF0YVN0b3JlLnVzZXJ9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHBhc3N3b3JkPiBcIiR7ZGF0YVN0b3JlLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxhY2NvdW50TmFtZT4gXCIke2RhdGFTdG9yZS5hY2NvdW50TmFtZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8d2FyZWhvdXNlPiBcIiR7ZGF0YVN0b3JlLndhcmVob3VzZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8ZGF0YWJhc2U+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxzY2hlbWE+IFwiJHtkYXRhU3RvcmUuc2NoZW1hfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxhdXRoVHlwZT4gXCIke2RhdGFTdG9yZS5hdXRoVHlwZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8dXNlcm5hbWU+IFwiJHtkYXRhU3RvcmUudXNlcm5hbWV9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGNsaWVudElkPiBcIiR7ZGF0YVN0b3JlLmNsaWVudElkfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxjbGllbnRTZWNyZXQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50U2VjcmV0fVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxhdXRob3JpemF0aW9uQ29kZT4gXCIke2RhdGFTdG9yZS5hdXRob3JpemF0aW9uQ29kZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8cmVkaXJlY3RVUkk+IFwiJHtkYXRhU3RvcmUucmVkaXJlY3RVUkl9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGxvZ2luVGltZW91dD4gXCIke2RhdGFTdG9yZS5sb2dpblRpbWVvdXR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHVybD4gXCIke2RhdGFTdG9yZS51cmx9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHNjb3BlPiBcIiR7ZGF0YVN0b3JlLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBkYXRhU3RvcmUpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygndXBkYXRlZCBkYXRhU3RvcmVzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPERhdGFTdG9yZT4oJ3VwZGF0ZURhdGFTdG9yZXMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlRGF0YVN0b3JlKGdhdGV3YXlVaWQ6IG51bWJlciwgZGF0YVN0b3JlVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgZGVsZXRlIHtcbiAgICAgICAgPCR7ZGF0YVN0b3JlVWlkfT4gKiAqIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBEYXRhU3RvcmUgTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGAke2RhdGFTdG9yZVVpZH0gZGVsZXRlZGApKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZGVsZXRlZCBkYXRhU3RvcmUnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlRGF0YVN0b3JlJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlBbmRNb2RlbHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWRcbiAgICAgICAgbW9kZWxzOiBnYXRld2F5X21vZGVsIHtcbiAgICAgICAgICB1aWRcbiAgICAgICAgICB1dWlkXG4gICAgICAgICAgY3JlYXRlZFxuICAgICAgICAgIG1vZGlmaWVkXG4gICAgICAgICAgbmFtZVxuICAgICAgICAgIGRlc2NyaXB0aW9uXG4gICAgICAgICAgaW5wdXRUeXBlXG4gICAgICAgICAgdXJsXG4gICAgICAgICAgc2NvcGVcbiAgICAgICAgICBpbnB1dFRlbXBsYXRlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0dldCBHYXRld2F5IGFuZCBQcm90b2NvbHMgcXVlcnkgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBHYXRld2F5JykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPEdhdGV3YXlbXT4oJ2dldEdhdGV3YXlXaXRoTW9kZWxzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRNb2RlbHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWxbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhtb2RlbCkpIEBmaWx0ZXIoZXEoc2NvcGUsIFwiJHtnYXRld2F5TmFtZX1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICB1dWlkXG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgbW9kaWZpZWRcbiAgICAgICAgbmFtZVxuICAgICAgICBkZXNjcmlwdGlvblxuICAgICAgICBpbnB1dFR5cGVcbiAgICAgICAgdXJsXG4gICAgICAgIHNjb3BlXG4gICAgICAgIGlucHV0VGVtcGxhdGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBNb2RlbFtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBtb2RlbHMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8TW9kZWxbXT4oJ2dldE1vZGVscycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkTW9kZWwoZ2F0ZXdheVVpZDogbnVtYmVyLCBtb2RlbDogTW9kZWwsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPE1vZGVsPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICBfOk1vZGVsIDxkZ3JhcGgudHlwZT4gXCJNb2RlbFwiIC5cbiAgICAgICAgXzpNb2RlbCA8dHlwZT4gXCJtb2RlbFwiIC5cbiAgICAgICAgXzpNb2RlbCA8bW9kZWw+IFwiXCIgLlxuICAgICAgICBfOk1vZGVsIDx1dWlkPiBcIiR7bW9kZWwudXVpZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPGNyZWF0ZWQ+IFwiJHttb2RlbC5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8bW9kaWZpZWQ+IFwiJHttb2RlbC5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86TW9kZWwgPG5hbWU+IFwiJHttb2RlbC5uYW1lfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8ZGVzY3JpcHRpb24+IFwiJHttb2RlbC5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIF86TW9kZWwgPGlucHV0VHlwZT4gXCIke21vZGVsLmlucHV0VHlwZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPHVybD4gXCIke21vZGVsLnVybH1cIiAuXG4gICAgICAgIF86TW9kZWwgPHNjb3BlPiBcIiR7bW9kZWwuc2NvcGV9XCIgLlxuICAgICAgICBfOk1vZGVsIDxpbnB1dFRlbXBsYXRlPiBcIiR7bW9kZWwuaW5wdXRUZW1wbGF0ZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gbW9kZWwpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnYWRkIG1vZGVscycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbD4oJ2FkZE1vZGVscycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVNb2RlbChtb2RlbDogTW9kZWwsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPE1vZGVsPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICA8JHttb2RlbC51aWR9PiA8dXVpZD4gXCIke21vZGVsLnV1aWR9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8bW9kaWZpZWQ+IFwiJHttb2RlbC5tb2RpZmllZH1cIiAuXG4gICAgICAgIDwke21vZGVsLnVpZH0+IDxuYW1lPiBcIiR7bW9kZWwubmFtZX1cIiAuXG4gICAgICAgIDwke21vZGVsLnVpZH0+IDxkZXNjcmlwdGlvbj4gXCIke21vZGVsLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPGlucHV0VHlwZT4gXCIke21vZGVsLmlucHV0VHlwZX1cIiAuXG4gICAgICAgIDwke21vZGVsLnVpZH0+IDx1cmw+IFwiJHttb2RlbC51cmx9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8c2NvcGU+IFwiJHttb2RlbC5zY29wZX1cIiAuXG4gICAgICAgIDwke21vZGVsLnVpZH0+IDxpbnB1dFRlbXBsYXRlPiBcIiR7bW9kZWwuaW5wdXRUZW1wbGF0ZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gbW9kZWwpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygndXBkYXRlZCBtb2RlbHMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8TW9kZWw+KCd1cGRhdGVNb2RlbHMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlTW9kZWwoZ2F0ZXdheVVpZDogbnVtYmVyLCBtb2RlbFVpZDogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIGRlbGV0ZSB7XG4gICAgICAgIDwke21vZGVsVWlkfT4gKiAqIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBNb2RlbCBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYCR7bW9kZWxVaWR9IGRlbGV0ZWRgKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgcHJvdG9jb2wnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlTW9kZWwnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheUFuZFBpcGVsaW5lcyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBwaXBlbGluZV9wcm90b2NvbCA9XG4gICAgICAgICAgICAncHJvdG9jb2w6IHBpcGVsaW5lX3Byb3RvY29sIHt1aWQgdXVpZCBicm9rZXJVUkwgdG9waWMgbWF4aW11bVFPUyB1c2VybmFtZSBwYXNzd29yZCBlbmNyeXB0aW9uTW9kZSBjYUNlcnRpZmljYXRlIGNsaWVudENlcnRpZmljYXRlIGNsaWVudEtleSBhdXRoTW9kZSBzZXJ2ZXJDZXJ0aWNhdGUgY29uc3VtZXJHcm91cElkIGNvbm5lY3Rpb25UaW1lb3V0IHNlc3Npb25UaW1lb3V0IHJldHJ5QmFja29mZiBjb21taXRJbnRlcnZhbCBpbml0aWFsT2Zmc2V0IGZldGNoTWluQnl0ZXMgZmV0Y2hNYXhXYWl0IGhlYXJ0YmVhdEludGVydmFsfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2RhdGFzdG9yZSA9XG4gICAgICAgICAgICAnZGF0YVN0b3JlOiBwaXBlbGluZV9kYXRhc3RvcmUge3VpZCB1dWlkIGhvc3QgcG9ydCBkYXRhYmFzZU5hbWUgdXNlciBwYXNzd29yZCBhY2NvdW50TmFtZSB3YXJlaG91c2UgZGF0YWJhc2Ugc2NoZW1hIGF1dGhUeXBlIHVzZXJuYW1lIGNsaWVudElkIGNsaWVudFNlY3JldCBhdXRob3JpemF0aW9uQ29kZSByZWRpcmVjdFVSSSBsb2dpblRpbWVvdXQgdXJsfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2ZpbHRlciA9ICdmaWx0ZXI6IHBpcGVsaW5lX2ZpbHRlciB7dWlkIGRldmljZU5hbWVzfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3N0cmVhbWluZyA9XG4gICAgICAgICAgICAnc3RyZWFtaW5nOiBwaXBlbGluZV9zdHJlYW1pbmcge3VpZCBkZXZpY2VOYW1lIGluc3RydW1lbnROYW1lIGZ1bmN0aW9uIHdpbmRvd1R5cGUgd2luZG93U2l6ZX0nO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWQgYWNjZXNzVG9rZW4gdXNlcm5hbWUgcGxhdGZvcm0gYWRkcmVzcyByb3V0ZXIgcm91dGVyUG9ydCBkZXBsb3lOZXR3b3JrIGRldmljZXNNZXRhZGF0YVxuICAgICAgICBwaXBlbGluZXM6IGdhdGV3YXlfcGlwZWxpbmUge1xuICAgICAgICAgIHVpZFxuICAgICAgICAgIG5hbWVcbiAgICAgICAgICB1dWlkXG4gICAgICAgICAgcGlwZWxpbmVUeXBlXG4gICAgICAgICAgZGVwbG95ZXJUeXBlXG4gICAgICAgICAgcHJvdG9jb2xUeXBlXG4gICAgICAgICAgcHJvdG9jb2xJZFxuICAgICAgICAgIGRhdGFTdG9yZVR5cGVcbiAgICAgICAgICBkYXRhU3RvcmVJZFxuICAgICAgICAgIGNyZWF0ZWRcbiAgICAgICAgICBtb2RpZmllZFxuICAgICAgICAgIGRlc2NyaXB0aW9uXG4gICAgICAgICAgc3RhdHVzXG4gICAgICAgICAgZmxvd0NvbmZpZ3VyYXRpb25cbiAgICAgICAgICBsb2dMZXZlbFxuICAgICAgICAgIHN1YnNjcmlwdGlvblRvcGljXG4gICAgICAgICAgJHtwaXBlbGluZV9wcm90b2NvbH1cbiAgICAgICAgICAke3BpcGVsaW5lX2RhdGFzdG9yZX1cbiAgICAgICAgICAke3BpcGVsaW5lX2ZpbHRlcn1cbiAgICAgICAgICAke3BpcGVsaW5lX3N0cmVhbWluZ31cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnR2V0IEdhdGV3YXkgYW5kIFBpcGVsaW5lcyBxdWVyeSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIEdhdGV3YXknKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheVtdPignZ2V0R2F0ZXdheVdpdGhQaXBlbGluZXMnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFBpcGVsaW5lcyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcGlwZWxpbmVfcHJvdG9jb2wgPVxuICAgICAgICAgICAgJ3Byb3RvY29sOiBwaXBlbGluZV9wcm90b2NvbCB7dWlkIGJyb2tlclVSTCB0b3BpYyBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGUgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5IGF1dGhNb2RlIHNlcnZlckNlcnRpY2F0ZSBjb25zdW1lckdyb3VwSWQgY29ubmVjdGlvblRpbWVvdXQgc2Vzc2lvblRpbWVvdXQgcmV0cnlCYWNrb2ZmIGNvbW1pdEludGVydmFsIGluaXRpYWxPZmZzZXQgZmV0Y2hNaW5CeXRlcyBmZXRjaE1heFdhaXQgaGVhcnRiZWF0SW50ZXJ2YWx9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZGF0YXN0b3JlID1cbiAgICAgICAgICAgICdkYXRhc3RvcmU6IHBpcGVsaW5lX2RhdGFzdG9yZSB7dWlkIGhvc3QgcG9ydCBkYXRhYmFzZU5hbWUgdXNlciBwYXNzd29yZCBhY2NvdW50TmFtZSB3YXJlaG91c2UgZGF0YWJhc2Ugc2NoZW1hIGF1dGhUeXBlIHVzZXJuYW1lIGNsaWVudElkIGNsaWVudFNlY3JldCBhdXRob3JpemF0aW9uQ29kZSByZWRpcmVjdFVSSSBsb2dpblRpbWVvdXQgdXJsfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2ZpbHRlciA9ICdmaWx0ZXI6IHBpcGVsaW5lX2ZpbHRlciB7dWlkIGRldmljZU5hbWVzfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3N0cmVhbWluZyA9XG4gICAgICAgICAgICAnc3RyZWFtaW5nOiBwaXBlbGluZV9zdHJlYW1pbmcge3VpZCBkZXZpY2VOYW1lIGluc3RydW1lbnROYW1lIGZ1bmN0aW9uIHdpbmRvd1R5cGUgd2luZG93U2l6ZX0nO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICBwaXBlbGluZXMgYXMgZ2F0ZXdheV9waXBlbGluZSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHBpcGVsaW5lcykpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIG5hbWVcbiAgICAgICAgdXVpZFxuICAgICAgICBwaXBlbGluZVR5cGVcbiAgICAgICAgZGVwbG95ZXJUeXBlXG4gICAgICAgIHByb3RvY29sVHlwZVxuICAgICAgICBwcm90b2NvbElkXG4gICAgICAgIGRhdGFTdG9yZVR5cGVcbiAgICAgICAgZGF0YVN0b3JlSWRcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICBtb2RpZmllZFxuICAgICAgICBkZXNjcmlwdGlvblxuICAgICAgICBzdGF0dXNcbiAgICAgICAgZmxvd0NvbmZpZ3VyYXRpb25cbiAgICAgICAgbG9nTGV2ZWxcbiAgICAgICAgc3Vic2NyaXB0aW9uVG9waWNcbiAgICAgICAgJHtwaXBlbGluZV9wcm90b2NvbH1cbiAgICAgICAgJHtwaXBlbGluZV9kYXRhc3RvcmV9XG4gICAgICAgICR7cGlwZWxpbmVfZmlsdGVyfVxuICAgICAgICAke3BpcGVsaW5lX3N0cmVhbWluZ31cbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBQaXBlbGluZVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBwaXBlbGluZXMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UGlwZWxpbmVbXT4oJ2dldFBpcGVsaW5lcycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkUGlwZWxpbmUoZ2F0ZXdheVVpZDogbnVtYmVyLCBwaXBlbGluZTogUGlwZWxpbmUsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFBpcGVsaW5lPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuXG4gICAgICAgIGxldCBxdWVyeSA9ICcnO1xuXG4gICAgICAgIHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UGlwZWxpbmUgPGRncmFwaC50eXBlPiBcIlBpcGVsaW5lXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxuYW1lPiBcIiR7cGlwZWxpbmUubmFtZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHV1aWQ+IFwiJHtwaXBlbGluZS5uYW1lfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8dHlwZT4gXCJwaXBlbGluZVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8cGlwZWxpbmU+IFwiXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxwaXBlbGluZVR5cGU+IFwiJHtwaXBlbGluZS5waXBlbGluZVR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXBsb3llclR5cGU+IFwiJHtwaXBlbGluZS5kZXBsb3llclR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxjcmVhdGVkPiBcIiR7cGlwZWxpbmUuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXNjcmlwdGlvbj4gXCIke3BpcGVsaW5lLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8c3RhdHVzPiBcIiR7cGlwZWxpbmUuc3RhdHVzfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGxvZ0xldmVsPiBcIiR7cGlwZWxpbmUubG9nTGV2ZWx9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxzdWJzY3JpcHRpb25Ub3BpYz4gXCIke3BpcGVsaW5lLnN1YnNjcmlwdGlvblRvcGljfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X3BpcGVsaW5lPiBfOlBpcGVsaW5lIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwaXBlbGluZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdhZGQgcGlwZWxpbmUnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UGlwZWxpbmU+KCdhZGRQaXBlbGluZXMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlUGlwZWxpbmUocGlwZWxpbmU6IFBpcGVsaW5lLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPGRlc2NyaXB0aW9uPiBcIiR7cGlwZWxpbmUuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiA8c3RhdHVzPiBcIiR7cGlwZWxpbmUuc3RhdHVzfVwiIC5cbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgIDwke3BpcGVsaW5lLnVpZH0+IDxsb2dMZXZlbD4gXCIke3BpcGVsaW5lLmxvZ0xldmVsfVwiIC5cbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPHN1YnNjcmlwdGlvblRvcGljPiBcIiR7cGlwZWxpbmUuc3Vic2NyaXB0aW9uVG9waWN9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IHBpcGVsaW5lKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ3VwZGF0ZWQgcGlwZWxpbmVzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFBpcGVsaW5lPigndXBkYXRlUGlwZWxpbmUnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlUGlwZWxpbmUoZ2F0ZXdheVVpZDogbnVtYmVyLCBwaXBlbGluZTogUGlwZWxpbmUsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiAqICogLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfcGlwZWxpbmU+IDwke3BpcGVsaW5lLnVpZH0+IC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBQaXBlbGluZSBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYHBpcGVsaW5lIGRlbGV0ZWRgKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgcGlwZWxpbmUnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlUGlwZWxpbmUnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGlkcyBvZiBhbGwgdGhlIHBpcGVsaW5lcyBhc3NvY2lhdGVkIHdpdGggdGhlIHNwZWNpZmllZCBwcm90b2NvbFxuICAgICAqIEBwYXJhbSBwcm90b2NvbFVpZCAtIHRoZSB1aWQgb2YgdGhlIHByb3RvY29sXG4gICAgICovXG4gICAgZ2V0UGlwZWxpbmVJZHNGcm9tUHJvdG9jb2xVaWQocHJvdG9jb2xVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiB1aWQoJHtwcm90b2NvbFVpZH0pKSB7XG4gICAgICAgIHBpcGVsaW5lcyBhcyB+cGlwZWxpbmVfcHJvdG9jb2wge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICB1dWlkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUGlwZWxpbmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcGlwZWxpbmUgaWRzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFBpcGVsaW5lW10+KCdnZXRQaXBlbGluZUlkc0Zyb21Qcm90b2NvbFVpZCcsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGlkcyBvZiBhbGwgdGhlIHBpcGVsaW5lcyBhc3NvY2lhdGVkIHdpdGggdGhlIHNwZWNpZmllZCBkYXRhIHN0b3JlXG4gICAgICogQHBhcmFtIGRhdGFTdG9yZVVpZCAtIHRoZSB1aWQgb2YgdGhlIGRhdGEgc3RvcmVcbiAgICAgKi9cbiAgICBnZXRQaXBlbGluZUlkc0Zyb21EYXRhU3RvcmVVaWQoZGF0YVN0b3JlVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFBpcGVsaW5lW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogdWlkKCR7ZGF0YVN0b3JlVWlkfSkpIHtcbiAgICAgICAgcGlwZWxpbmVzIGFzIH5waXBlbGluZV9kYXRhc3RvcmUge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICB1dWlkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUGlwZWxpbmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcGlwZWxpbmUgaWRzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFBpcGVsaW5lW10+KCdnZXRQaXBlbGluZUlkc0Zyb21EYXRhU3RvcmVVaWQnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldE1vZGVsQ29uZmlncyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbENvbmZpZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICBtb2RlbENvbmZpZ3MgYXMgZ2F0ZXdheV9tb2RlbGNvbmZpZyB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKG1vZGVsQ29uZmlncykpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIG5hbWVcbiAgICAgICAgdXVpZFxuICAgICAgICBkZXNjcmlwdGlvblxuICAgICAgICBkZXZpY2VcbiAgICAgICAgcmVzb3VyY2VcbiAgICAgICAgbW9kZWxcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICBtb2RpZmllZFxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdnZXRNb2RlbENvbmZpZ3Mgc2VydmljZSBxdWVyeTogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIE1vZGVsQ29uZmlnW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIG1vZGVsQ29uZmlncycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbENvbmZpZ1tdPignZ2V0TW9kZWxDb25maWdzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRNb2RlbENvbmZpZyhnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsQ29uZmlnOiBNb2RlbENvbmZpZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWxDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86TW9kZWxDb25maWcgPGRncmFwaC50eXBlPiBcIk1vZGVsQ29uZmlnXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxuYW1lPiBcIiR7bW9kZWxDb25maWcubmFtZX1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPHV1aWQ+IFwiJHttb2RlbENvbmZpZy5uYW1lfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8dHlwZT4gXCJtb2RlbENvbmZpZ1wiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8bW9kZWxDb25maWc+IFwiXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxkZXNjcmlwdGlvbj4gXCIke21vZGVsQ29uZmlnLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8ZGV2aWNlPiBcIiR7bW9kZWxDb25maWcuZGV2aWNlfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8cmVzb3VyY2U+IFwiJHttb2RlbENvbmZpZy5yZXNvdXJjZX1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPG1vZGVsPiBcIiR7bW9kZWxDb25maWcubW9kZWx9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxjcmVhdGVkPiBcIiR7bW9kZWxDb25maWcuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPG1vZGlmaWVkPiBcIiR7bW9kZWxDb25maWcubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfbW9kZWxjb25maWc+IF86TW9kZWxDb25maWcgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IG1vZGVsQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2FkZCBtb2RlbENvbmZpZycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbENvbmZpZz4oJ2FkZE1vZGVsQ29uZmlnJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZU1vZGVsQ29uZmlnKG1vZGVsQ29uZmlnOiBNb2RlbENvbmZpZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWxDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDxuYW1lPiBcIiR7bW9kZWxDb25maWcubmFtZX1cIiAuXG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDx1dWlkPiBcIiR7bW9kZWxDb25maWcudXVpZH1cIiAuXG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDxkZXNjcmlwdGlvbj4gXCIke21vZGVsQ29uZmlnLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgPCR7bW9kZWxDb25maWcudWlkfT4gPGNvbmREZXZpY2U+IFwiJHttb2RlbENvbmZpZy5kZXZpY2V9XCIgLlxuICAgICAgICA8JHttb2RlbENvbmZpZy51aWR9PiA8Y29uZFJlc291cmNlPiBcIiR7bW9kZWxDb25maWcucmVzb3VyY2V9XCIgLlxuICAgICAgICA8JHttb2RlbENvbmZpZy51aWR9PiA8bW9kZWw+IFwiJHttb2RlbENvbmZpZy5tb2RlbH1cIiAuXG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDxtb2RpZmllZD4gXCIke21vZGVsQ29uZmlnLm1vZGlmaWVkfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBtb2RlbENvbmZpZykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCd1cGRhdGVkIG1vZGVsQ29uZmlnJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE1vZGVsQ29uZmlnPigndXBkYXRlTW9kZWxDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlTW9kZWxDb25maWcoZ2F0ZXdheVVpZDogbnVtYmVyLCBtb2RlbENvbmZpZ1VpZDogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIGRlbGV0ZSB7XG4gICAgICAgIDwke21vZGVsQ29uZmlnVWlkfT4gKiAqIC5cbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X21vZGVsY29uZmlnPiA8JHttb2RlbENvbmZpZ1VpZH0+IC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBNb2RlbENvbmZpZyBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYCR7bW9kZWxDb25maWdVaWR9IGRlbGV0ZWRgKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgbW9kZWxDb25maWcnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlTW9kZWxDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0RmlsdGVyc0NvbmZpZyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5RmlsdGVyc0NvbmZpZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICBmaWx0ZXJzQ29uZmlnIGFzIGdhdGV3YXlfZmlsdGVyIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQoZmlsdGVyc0NvbmZpZykpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIGRldmljZU5hbWVzXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ2dldEZpbHRlcnNDb25maWcgc2VydmljZSBxdWVyeTogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlGaWx0ZXJzQ29uZmlnW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIGZpbHRlcnNDb25maWcnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheUZpbHRlcnNDb25maWdbXT4oJ2dldEZpbHRlcnNDb25maWdzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRGaWx0ZXJzQ29uZmlnKFxuICAgICAgICBnYXRld2F5VWlkOiBudW1iZXIsXG4gICAgICAgIGZpbHRlcnNDb25maWc6IEdhdGV3YXlGaWx0ZXJzQ29uZmlnLFxuICAgICAgICBhY2NvdW50Pzogc3RyaW5nLFxuICAgICk6IE9ic2VydmFibGU8R2F0ZXdheUZpbHRlcnNDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpGaWx0ZXIgPGRncmFwaC50eXBlPiBcImZpbHRlclwiIC5cbiAgICAgICAgXzpGaWx0ZXIgPHR5cGU+IFwiZmlsdGVyXCIgLlxuICAgICAgICBfOkZpbHRlciA8ZmlsdGVyPiBcIlwiIC5cbiAgICAgICAgXzpGaWx0ZXIgPGRldmljZU5hbWVzPiBcIiR7ZmlsdGVyc0NvbmZpZy5kZXZpY2VOYW1lc31cIiAuXG4gICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9maWx0ZXI+IF86RmlsdGVyIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBmaWx0ZXJzQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2FkZCBmaWx0ZXJzQ29uZmlnJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPEdhdGV3YXlGaWx0ZXJzQ29uZmlnPignYWRkRmlsdGVyc0NvbmZpZycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVGaWx0ZXJzQ29uZmlnKGZpbHRlcnNDb25maWc6IEdhdGV3YXlGaWx0ZXJzQ29uZmlnLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5RmlsdGVyc0NvbmZpZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7ZmlsdGVyc0NvbmZpZy51aWR9PiA8ZGV2aWNlTmFtZXM+IFwiJHtmaWx0ZXJzQ29uZmlnLmRldmljZU5hbWVzfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBmaWx0ZXJzQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ3VwZGF0ZWQgZmlsdGVyc0NvbmZpZycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5RmlsdGVyc0NvbmZpZz4oJ3VwZGF0ZUZpbHRlcnNDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3MoZGV2aWNlTmFtZTogc3RyaW5nLCBpbnN0cnVtZW50TmFtZTogc3RyaW5nLCBudW1SZWFkaW5nczogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIC8vIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgYHtyZXNwKGZ1bmM6IGhhcyhyZWFkaW5nKSkgQGNhc2NhZGUge3ZhbHVlIGNyZWF0ZWQgfnJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHt+ZGV2aWNlX3Jlc291cmNlIEBmaWx0ZXIgKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfVwiKSkge319fX1gLCBodHRwT3B0aW9ucylcbiAgICAgICAgLy8gcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAY2FzY2FkZSB7dmFsdWUgY3JlYXRlZCB+cmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkgeyB9fX1gLCBodHRwT3B0aW9ucylcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKHJlc291cmNlKSkgQGZpbHRlcihlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LSR7bnVtUmVhZGluZ3N9KSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ2dldFJlYWRpbmdzIHF1ZXJ5IHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFRTUmVhZGluZ1tdKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IGNvbnNvbGUubG9nKCdSZXNwb25zZSBmcm9tIGdldFJlYWRpbmdzOiAnLCByZXNwb25zZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHJlYWRpbmdzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFRTUmVhZGluZ1tdPignZ2V0UmVhZGluZ3MnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFJlYWRpbmdzQXQoZGV2aWNlTmFtZTogc3RyaW5nLCBpbnN0cnVtZW50TmFtZTogc3RyaW5nLCB0czogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEoY3JlYXRlZCwgJHt0c30pKSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ2dldFJlYWRpbmdzQXQgcXVlcnkgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgLy8gcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIEBjYXNjYWRlIHt2YWx1ZSBjcmVhdGVkIH5yZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7IH19fWAsIGh0dHBPcHRpb25zKVxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBUU1JlYWRpbmdbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcmVhZGluZ3MnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8VFNSZWFkaW5nW10+KCdnZXRSZWFkaW5nc0F0JywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc1N0YXJ0aW5nQXQoXG4gICAgICAgIGRldmljZU5hbWU6IHN0cmluZyxcbiAgICAgICAgaW5zdHJ1bWVudE5hbWU6IHN0cmluZyxcbiAgICAgICAgZnJvbXRzOiBudW1iZXIsXG4gICAgICAgIGFjY291bnQ/OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIC8vIGNvbnN0IG15cXVlcnkgPSBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIEBjYXNjYWRlIHt2YWx1ZSBjcmVhdGVkIH5yZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7IH19fWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCd0aGUgcXVlcnkgaXM6ICcsIHF1ZXJ5KTtcblxuICAgICAgICAvLyByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIGB7cmVzcChmdW5jOiBoYXMocmVhZGluZykpIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSkgQGNhc2NhZGUge3ZhbHVlIGNyZWF0ZWQgfnJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHsgfX19YCwgaHR0cE9wdGlvbnMpXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFRTUmVhZGluZ1tdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCByZWFkaW5ncycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxUU1JlYWRpbmdbXT4oJ2dldFJlYWRpbmdzU3RhcnRpbmdBdCcsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3NCZXR3ZWVuKFxuICAgICAgICBkZXZpY2VOYW1lOiBzdHJpbmcsXG4gICAgICAgIGluc3RydW1lbnROYW1lOiBzdHJpbmcsXG4gICAgICAgIGZyb210czogbnVtYmVyLFxuICAgICAgICB0b3RzOiBudW1iZXIsXG4gICAgICAgIGFjY291bnQ/OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIC8vIGNvbnN0IG15cXVlcnkgPSBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIEBjYXNjYWRlIHt2YWx1ZSBjcmVhdGVkIH5yZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7IH19fWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSBBTkQgbHQoY3JlYXRlZCwgJHt0b3RzfSkpIChmaXJzdDotNTAwKSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ3RoZSBxdWVyeSBpczogJywgcXVlcnkpO1xuXG4gICAgICAgIC8vIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgYHtyZXNwKGZ1bmM6IGhhcyhyZWFkaW5nKSkgQGZpbHRlcihndChjcmVhdGVkLCAke2Zyb210c30pKSBAY2FzY2FkZSB7dmFsdWUgY3JlYXRlZCB+cmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkgeyB9fX1gLCBodHRwT3B0aW9ucylcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgVFNSZWFkaW5nW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHJlYWRpbmdzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFRTUmVhZGluZ1tdPignZ2V0UmVhZGluZ3NCZXR3ZWVuJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRMYXN0UmVhZGluZ3NGb3JEZXZpY2UoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGRldmljZSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XCIpKSBAbm9ybWFsaXplIHtcbiAgICAgICAgZGV2aWNlX3Jlc291cmNlIHtcbiAgICAgICAgICBuYW1lOiBuYW1lXG4gICAgICAgICAgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LTEpIHtcbiAgICAgICAgICAgIGNyZWF0ZWQ6IGNyZWF0ZWRcbiAgICAgICAgICAgIHZhbHVlOiB2YWx1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdSZWFkaW5nIHF1ZXJ5IHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFRTUmVhZGluZ1tdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCByZWFkaW5ncycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxUU1JlYWRpbmdbXT4oJ2dldExhc3RSZWFkaW5nc0ZvckRldmljZScsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0Tm90aWZpY2F0aW9ucyhhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxOb3RpZmljYXRpb25bXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zb2xlLmxvZygnR2V0Tm90aWZpY2F0aW9ucyBzZXJ2aWNlIGNhbGxlZCcpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhub3RpZmljYXRpb24pKSBAbm9ybWFsaXplIHtcbiAgICAgICAgdWlkIHV1aWQ6dXVpZCBjcmVhdGVkOmNyZWF0ZWQgbm90aWZ5U291cmNlOm5vdGlmeVNvdXJjZSBub3RpZnlEZXZpY2U6bm90aWZ5RGV2aWNlIG5vdGlmeVJlc291cmNlOm5vdGlmeVJlc291cmNlIG5vdGlmeUxldmVsOm5vdGlmeUxldmVsIHZhbHVlOnZhbHVlIGRlc2NyaXB0aW9uOmRlc2NyaXB0aW9uIH5nYXRld2F5X25vdGlmaWNhdGlvbiB7XG4gICAgICAgICAgZ2F0ZXdheTogdXVpZFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgTm90aWZpY2F0aW9uW10pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gY29uc29sZS5sb2coJ1Jlc3BvbnNlIGZyb20gR2V0Tm90aTogJywgcmVzcG9uc2UpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBub3RpZmljYXRpb25zJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE5vdGlmaWNhdGlvbltdPignZ2V0Tm90aWZpY2F0aW9ucycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0Um91dGUoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogbnVtYmVyW11bXSB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGxldCByb3V0ZSA9IG51bGw7XG5cbiAgICAgICAgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDEnKSB7XG4gICAgICAgICAgICByb3V0ZSA9IHJvdXRlMTtcbiAgICAgICAgfSBlbHNlIGlmIChkZXZpY2VOYW1lID09ICd0cmFpbi0wMDAyJykge1xuICAgICAgICAgICAgcm91dGUgPSByb3V0ZTI7XG4gICAgICAgIH0gZWxzZSBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMycpIHtcbiAgICAgICAgICAgIHJvdXRlID0gcm91dGUzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcm91dGUgPSBlbXB0eXJvdXRlO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJvdXRlO1xuICAgIH1cblxuICAgIGdldFJvdXRlQ2VudGVyKGRldmljZU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IG51bWJlcltdIHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgbGV0IGNlbnRlciA9IG51bGw7XG5cbiAgICAgICAgLy8gMzkuMCAtOTguMCB6b29tIDRcbiAgICAgICAgLy8gRWFzdCAzNC43NjU1ODkgICAtNzguNzA5NDg4XG4gICAgICAgIC8vIFdlc3QgNDAuNDg3NDMyIC0xMjIuODAzMTE2XG5cbiAgICAgICAgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDEnKSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbMzQuMCwgLTk4LjBdO1xuICAgICAgICB9IGVsc2UgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDInKSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbNDAuMCwgLTk4LjBdO1xuICAgICAgICB9IGVsc2UgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDMnKSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbMzkuMCwgLTk4LjBdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2VudGVyID0gWzQyLjgsIDEyLjhdO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGNlbnRlcjtcbiAgICB9XG5cbiAgICBwcml2YXRlIGVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQ/OiBzdHJpbmcpIHtcbiAgICAgIGlmICh0aGlzLnJlcXVpcmVBY2NvdW50SWQpIHtcbiAgICAgICAgaWYgKCFhY2NvdW50KSB0aHJvdyBuZXcgRXJyb3IoJ0FjY291bnQgbXVzdCBleGlzdCcpO1xuICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBIYW5kbGUgSFRUUCBvcGVyYXRpb24gdGhhdCBmYWlsZWQuXG4gICAgICogTGV0IHRoZSBhcHAgY29udGludWUuXG4gICAgICogQHBhcmFtIG9wZXJhdGlvbiAtIC0gbmFtZSBvZiB0aGUgb3BlcmF0aW9uIHRoYXQgZmFpbGVkXG4gICAgICogQHBhcmFtIHJlc3VsdCAtIG9wdGlvbmFsIHZhbHVlIHRvIHJldHVybiBhcyB0aGUgb2JzZXJ2YWJsZSByZXN1bHRcbiAgICAgKi9cbiAgICBwcml2YXRlIGhhbmRsZUVycm9yPFQ+KG9wZXJhdGlvbiA9ICdvcGVyYXRpb24nLCByZXN1bHQ/OiBUKSB7XG4gICAgICAgIHJldHVybiAoZXJyb3I6IGFueSk6IE9ic2VydmFibGU8VD4gPT4ge1xuICAgICAgICAgICAgLy8gVE9ETzogYmV0dGVyIGpvYiBvZiB0cmFuc2Zvcm1pbmcgZXJyb3IgZm9yIHVzZXIgY29uc3VtcHRpb25cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke29wZXJhdGlvbn0gZmFpbGVkOiAke2Vycm9yLmNvZGV9OiAke2Vycm9yLm1lc3NhZ2V9YCk7XG5cbiAgICAgICAgICAgIC8vIExldCB0aGUgYXBwIGtlZXAgcnVubmluZyBieSByZXR1cm5pbmcgYW4gZW1wdHkgcmVzdWx0LlxuICAgICAgICAgICAgcmV0dXJuIG9mKHJlc3VsdCBhcyBUKTtcbiAgICAgICAgfTtcbiAgICB9XG59XG4iXX0=