import { catchError, map, of, tap } from 'rxjs';
const route1 = [
    [25.771088, -80.163483],
    [27.439775, -80.32299],
    [28.349469, -80.731105],
    [30.401564, -81.571033],
    [32.116716, -81.144147],
    [32.866511, -79.995399],
    [34.191224, -77.952419],
    [36.850172, -76.319269],
    [36.915037, -76.320643],
    [39.262025, -76.549294],
    [39.900933, -75.143453],
    [40.690263, -74.152375],
    [42.259951, -71.789244],
];
const route2 = [
    [47.492471, -122.26888],
    [45.552207, -122.722648],
    [39.53246, -119.751524],
    [37.803528, -122.312138],
    [37.899332, -121.169307],
    [36.273183, -115.070534],
    [33.77032, -118.273289],
    [34.106012, -117.320254],
    [33.515564, -112.160564],
    [32.126437, -110.848336],
    [31.752085, -106.488887],
    [35.04758, -106.653344],
    [39.796963, -104.995374],
];
const route3 = [
    [29.302729, -98.638744],
    [29.638421, -95.292245],
    [32.615525, -96.693485],
    [29.917836, -90.205272],
    [32.256403, -90.151546],
    [35.044849, -90.153006],
    [38.524627, -90.209535],
    [39.870851, -88.912284],
    [41.705694, -87.577341],
    [41.902382, -89.101932],
    [44.251243, -91.509663],
    [44.970069, -93.174527],
    [46.758181, -92.098748],
];
const emptyroute = [];
const httpOptions = {
    headers: { 'Content-Type': 'application/graphql+-' },
};
const httpMutateOptions = {
    headers: { 'Content-Type': 'application/rdf' },
};
export class GraphService {
    constructor(http, dGraphUrl) {
        this.http = http;
        this.dGraphUrl = dGraphUrl;
        console.log('dGraphUrl: ', this.dGraphUrl);
        //const dGraphBasicAuthEnabled = this.appConfigService.dGraphBasicAuthEnabled;
        //if (dGraphBasicAuthEnabled) {
        //    const dGraphBasicAuth = this.appConfigService.dGraphBasicAuth;
        //    (this.httpOptions.headers = { 'Content-Type': 'application/graphql+-' }), { Authorization: dGraphBasicAuth };
        //    (this.httpMutateOptions.headers = { 'Content-Type': 'application/rdf' }), { Authorization: dGraphBasicAuth };
        //}
    }
    getGateway(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        console.log('GetGateway service called for: ', gatewayName);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid description address router routerPort deployNetwork latitude longitude accessToken username platform devicesMetadata createdts updatedts
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(response => console.log("Response from getGateway: ", response)), catchError(this.handleError('getGateway', [])));
    }
    getGateways(account) {
        this.ensureAccountAuthorized(account);
        console.log(`GetGateways service called for ${account}`);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) {
        uid uuid description address router routerPort deployNetwork latitude longitude accessToken username platform devicesMetadata createdts updatedts
        numDevices: count(gateway_device)

      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched gateways')), catchError(this.handleError('getGateways', [])));
    }
    updateGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${gateway.uid}> <address> "${gateway.address}" .
        <${gateway.uid}> <router> "${gateway.router}" .
        <${gateway.uid}> <routerPort> "${gateway.routerPort}" .
        <${gateway.uid}> <deployNetwork> "${gateway.deployNetwork}" .
        <${gateway.uid}> <description> "${gateway.description}" .
        <${gateway.uid}> <latitude> "${gateway.latitude}" .
        <${gateway.uid}> <longitude> "${gateway.longitude}" .
        <${gateway.uid}> <accessToken> "${gateway.accessToken}" .
        <${gateway.uid}> <username> "${gateway.username}" .
        <${gateway.uid}> <platform> "${gateway.platform}" .
        <${gateway.uid}> <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log('Update Gateway Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => 'gateway updated'), tap(() => console.log('updated gateway')), catchError(this.handleError('updateGateway')));
    }
    addGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Gateway <dgraph.type> "Gateway" .
        _:Gateway <gateway> "" .
        _:Gateway <type> "gateway" .
        _:Gateway <uuid> "${gateway.uuid}" .
        _:Gateway <description> "${gateway.description}" .
        _:Gateway <address> "${gateway.address}" .
        _:Gateway <router> "${gateway.router}" .
        _:Gateway <routerPort> "${gateway.routerPort}" .
        _:Gateway <deployNetwork> "${gateway.deployNetwork}" .
        _:Gateway <latitude> "${gateway.latitude}" .
        _:Gateway <longitude> "${gateway.longitude}" .
        _:Gateway <accessToken> "${gateway.accessToken}" .
        _:Gateway <username> "${gateway.username}" .
        _:Gateway <platform> "${gateway.platform}" .
        _:Gateway <createdts> "${gateway.createdts}" .
        _:Gateway <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log('Add Gateway Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = gateway)), tap(() => console.log('add gateway')), catchError(this.handleError('addGateway')));
    }
    deleteGateway(gatewayUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${gatewayUid}> * * .
      }
    }`;
        console.log('Delete Gateway Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => `${gatewayUid} deleted`), tap(() => console.log('deleted gateway')), catchError(this.handleError('deleteGateway')));
    }
    getGatewayAndProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid
        protocols: gateway_protocol {
          uid
          uuid
          created
          modified
          protocolType
          brokerURL
          topic
          consumerGroupId
          connectionTimeout
          sessionTimeout
          initialOffset
          retryBackoff
          fetchMinBytes
          fetchMaxWait
          commitInterval
          heartbeatInterval
          maximumQOS
          username
          password
          encryptionMode
          caCertificate
          clientCertificate
          clientKey
          authMode
          serverCerticate
        }
      }
    }`;
        console.log('Get Gateway and Protocols query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched Gateway')), catchError(this.handleError('getGatewayWithProtocols', [])));
    }
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayName
     * @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500)
     */
    getProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(protocol)) @filter(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL")) {
        uid
        uuid
        created
        modified
        protocolType
        brokerURL
        topic
        consumerGroupId
        connectionTimeout
        sessionTimeout
        initialOffset
        retryBackoff
        fetchMinBytes
        fetchMaxWait
        commitInterval
        heartbeatInterval
        maximumQOS
        username
        password
        encryptionMode
        caCertificate
        clientCertificate
        clientKey
        authMode
        serverCerticate
        scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched protocols')), catchError(this.handleError('getProtocols', [])));
    }
    addProtocol(gatewayUid, protocol, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Protocol <dgraph.type> "Protocol" .
        _:Protocol <type> "protocol" .
        _:Protocol <protocol> "" .
        _:Protocol <uuid> "${protocol.uuid}" .
        _:Protocol <created> "${protocol.created}" .
        _:Protocol <modified> "${protocol.modified}" .
        _:Protocol <protocolType> "${protocol.protocolType}" .
        _:Protocol <brokerURL> "${protocol.brokerURL}" .
        _:Protocol <topic> "${protocol.topic}" .
        _:Protocol <consumerGroupId> "${protocol.consumerGroupId}" .
        _:Protocol <connectionTimeout> "${protocol.connectionTimeout}" .
        _:Protocol <sessionTimeout> "${protocol.sessionTimeout}" .
        _:Protocol <initialOffset> "${protocol.initialOffset}" .
        _:Protocol <retryBackoff> "${protocol.retryBackOff}" .
        _:Protocol <fetchMinBytes> "${protocol.fetchMinBytes}" .
        _:Protocol <fetchMaxWait> "${protocol.fetchMaxWait}" .
        _:Protocol <commitInterval> "${protocol.commitInterval}" .
        _:Protocol <heartbeatInterval> "${protocol.heartbeatInterval}" .
        _:Protocol <maximumQOS> "${protocol.maximumQOS}" .
        _:Protocol <username> "${protocol.username}" .
        _:Protocol <password> "${protocol.password}" .
        _:Protocol <encryptionMode> "${protocol.encryptionMode}" .
        _:Protocol <caCertificate> "${protocol.caCertificate}" .
        _:Protocol <clientCertificate> "${protocol.clientCertificate}" .
        _:Protocol <clientKey> "${protocol.clientKey}" .
        _:Protocol <authMode> "${protocol.authMode}" .
        _:Protocol <serverCerticate> "${protocol.serverCertificate}" .
        _:Protocol <scope> "${protocol.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = protocol)), tap(() => console.log('add protocols')), catchError(this.handleError('addProtocols')));
    }
    updateProtocol(protocol, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${protocol.uid}> <uuid> "${protocol.uuid}" .
        <${protocol.uid}> <modified> "${protocol.modified}" .
        <${protocol.uid}> <protocolType> "${protocol.protocolType}" .
        <${protocol.uid}> <brokerURL> "${protocol.brokerURL}" .
        <${protocol.uid}> <topic> "${protocol.topic}" .
        <${protocol.uid}> <consumerGroupId> "${protocol.consumerGroupId}" .
        <${protocol.uid}> <connectionTimeout> "${protocol.connectionTimeout}" .
        <${protocol.uid}> <sessionTimeout> "${protocol.sessionTimeout}" .
        <${protocol.uid}> <initialOffset> "${protocol.initialOffset}" .
        <${protocol.uid}> <retryBackoff> "${protocol.retryBackOff}" .
        <${protocol.uid}> <fetchMinBytes> "${protocol.fetchMinBytes}" .
        <${protocol.uid}> <fetchMaxWait> "${protocol.fetchMaxWait}" .
        <${protocol.uid}> <commitInterval> "${protocol.commitInterval}" .
        <${protocol.uid}> <heartbeatInterval> "${protocol.heartbeatInterval}" .
        <${protocol.uid}> <maximumQOS> "${protocol.maximumQOS}" .
        <${protocol.uid}> <username> "${protocol.username}" .
        <${protocol.uid}> <password> "${protocol.password}" .
        <${protocol.uid}> <encryptionMode> "${protocol.encryptionMode}" .
        <${protocol.uid}> <caCertificate> "${protocol.caCertificate}" .
        <${protocol.uid}> <clientCertificate> "${protocol.clientCertificate}" .
        <${protocol.uid}> <clientKey> "${protocol.clientKey}" .
        <${protocol.uid}> <authMode> "${protocol.authMode}" .
        <${protocol.uid}> <serverCerticate> "${protocol.serverCertificate}" .
        <${protocol.uid}> <scope> "${protocol.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = protocol)), tap(() => console.log('updated protocols')), catchError(this.handleError('updateProtocols')));
    }
    deleteProtocol(gatewayUid, protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${protocolUid}> * * .
      }
    }`;
        console.log('Delete Protocol Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${protocolUid} deleted`)), tap(() => console.log('deleted protocol')), catchError(this.handleError('deleteProtocol')));
    }
    getDataStores(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(dataStore)) @filter(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL")) {
        uid
        uuid
        created
        modified
        dataStoreType
        host
        port
        databaseName
        user
        password
        accountName
        warehouse
        database
        schema
        authType
        username
        clientId
        clientSecret
        authorizationCode
        redirectURI
        loginTimeout
        url
        scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched dataStores')), catchError(this.handleError('getDataStores', [])));
    }
    addDataStore(gatewayUid, dataStore, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:DataStore <dgraph.type> "DataStore" .
        _:DataStore <type> "dataStore" .
        _:DataStore <dataStore> "" .
        _:DataStore <uuid> "${dataStore.uuid}" .
        _:DataStore <created> "${dataStore.created}" .
        _:DataStore <modified> "${dataStore.modified}" .
        _:DataStore <dataStoreType> "${dataStore.dataStoreType}" .
        _:DataStore <host> "${dataStore.host}" .
        _:DataStore <port> "${dataStore.port}" .
        _:DataStore <databaseName> "${dataStore.databaseName}" .
        _:DataStore <user> "${dataStore.user}" .
        _:DataStore <password> "${dataStore.password}" .
        _:DataStore <accountName> "${dataStore.accountName}" .
        _:DataStore <warehouse> "${dataStore.warehouse}" .
        _:DataStore <database> "${dataStore.databaseName}" .
        _:DataStore <schema> "${dataStore.schema}" .
        _:DataStore <authType> "${dataStore.authType}" .
        _:DataStore <username> "${dataStore.username}" .
        _:DataStore <clientId> "${dataStore.clientId}" .
        _:DataStore <clientSecret> "${dataStore.clientSecret}" .
        _:DataStore <authorizationCode> "${dataStore.authorizationCode}" .
        _:DataStore <redirectURI> "${dataStore.redirectURI}" .
        _:DataStore <loginTimeout> "${dataStore.loginTimeout}" .
        _:DataStore <url> "${dataStore.url}" .
        _:DataStore <scope> "${dataStore.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = dataStore)), tap(() => console.log('add dataStores')), catchError(this.handleError('addDataStores')));
    }
    updateDataStore(dataStore, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${dataStore.uid}> <uuid> "${dataStore.uuid}" .
        <${dataStore.uid}> <modified> "${dataStore.modified}" .
        <${dataStore.uid}> <dataStoreType> "${dataStore.dataStoreType}" .
        <${dataStore.uid}> <host> "${dataStore.host}" .
        <${dataStore.uid}> <port> "${dataStore.port}" .
        <${dataStore.uid}> <databaseName> "${dataStore.databaseName}" .
        <${dataStore.uid}> <user> "${dataStore.user}" .
        <${dataStore.uid}> <password> "${dataStore.password}" .
        <${dataStore.uid}> <accountName> "${dataStore.accountName}" .
        <${dataStore.uid}> <warehouse> "${dataStore.warehouse}" .
        <${dataStore.uid}> <database> "${dataStore.databaseName}" .
        <${dataStore.uid}> <schema> "${dataStore.schema}" .
        <${dataStore.uid}> <authType> "${dataStore.authType}" .
        <${dataStore.uid}> <username> "${dataStore.username}" .
        <${dataStore.uid}> <clientId> "${dataStore.clientId}" .
        <${dataStore.uid}> <clientSecret> "${dataStore.clientSecret}" .
        <${dataStore.uid}> <authorizationCode> "${dataStore.authorizationCode}" .
        <${dataStore.uid}> <redirectURI> "${dataStore.redirectURI}" .
        <${dataStore.uid}> <loginTimeout> "${dataStore.loginTimeout}" .
        <${dataStore.uid}> <url> "${dataStore.url}" .
        <${dataStore.uid}> <scope> "${dataStore.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = dataStore)), tap(() => console.log('updated dataStores')), catchError(this.handleError('updateDataStores')));
    }
    deleteDataStore(gatewayUid, dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${dataStoreUid}> * * .
      }
    }`;
        console.log('Delete DataStore Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${dataStoreUid} deleted`)), tap(() => console.log('deleted dataStore')), catchError(this.handleError('deleteDataStore')));
    }
    getGatewayAndModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid
        models: gateway_model {
          uid
          uuid
          created
          modified
          name
          description
          inputType
          url
          scope
          inputTemplate
        }
      }
    }`;
        console.log('Get Gateway and Protocols query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched Gateway')), catchError(this.handleError('getGatewayWithModels', [])));
    }
    getModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(model)) @filter(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL")) {
        uid
        uuid
        created
        modified
        name
        description
        inputType
        url
        scope
        inputTemplate
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched models')), catchError(this.handleError('getModels', [])));
    }
    addModel(gatewayUid, model, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Model <dgraph.type> "Model" .
        _:Model <type> "model" .
        _:Model <model> "" .
        _:Model <uuid> "${model.uuid}" .
        _:Model <created> "${model.created}" .
        _:Model <modified> "${model.modified}" .
        _:Model <name> "${model.name}" .
        _:Model <description> "${model.description}" .
        _:Model <inputType> "${model.inputType}" .
        _:Model <url> "${model.url}" .
        _:Model <scope> "${model.scope}" .
        _:Model <inputTemplate> "${model.inputTemplate}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = model)), tap(() => console.log('add models')), catchError(this.handleError('addModels')));
    }
    updateModel(model, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${model.uid}> <uuid> "${model.uuid}" .
        <${model.uid}> <modified> "${model.modified}" .
        <${model.uid}> <name> "${model.name}" .
        <${model.uid}> <description> "${model.description}" .
        <${model.uid}> <inputType> "${model.inputType}" .
        <${model.uid}> <url> "${model.url}" .
        <${model.uid}> <scope> "${model.scope}" .
        <${model.uid}> <inputTemplate> "${model.inputTemplate}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = model)), tap(() => console.log('updated models')), catchError(this.handleError('updateModels')));
    }
    deleteModel(gatewayUid, modelUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${modelUid}> * * .
      }
    }`;
        console.log('Delete Model Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${modelUid} deleted`)), tap(() => console.log('deleted protocol')), catchError(this.handleError('deleteModel')));
    }
    getGatewayAndPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = 'protocol: pipeline_protocol {uid uuid brokerURL topic maximumQOS username password encryptionMode caCertificate clientCertificate clientKey authMode serverCerticate consumerGroupId connectionTimeout sessionTimeout retryBackoff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval}';
        const pipeline_datastore = 'dataStore: pipeline_datastore {uid uuid host port databaseName user password accountName warehouse database schema authType username clientId clientSecret authorizationCode redirectURI loginTimeout url}';
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid accessToken username platform address router routerPort deployNetwork devicesMetadata
        pipelines: gateway_pipeline {
          uid
          name
          uuid
          pipelineType
          deployerType
          protocolType
          protocolId
          dataStoreType
          dataStoreId
          created
          modified
          description
          status
          flowConfiguration
          logLevel
          subscriptionTopic
          ${pipeline_protocol}
          ${pipeline_datastore}
          ${pipeline_filter}
          ${pipeline_streaming}
        }
      }
    }`;
        console.log('Get Gateway and Pipelines query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched Gateway')), catchError(this.handleError('getGatewayWithPipelines', [])));
    }
    getPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = 'protocol: pipeline_protocol {uid brokerURL topic maximumQOS username password encryptionMode caCertificate clientCertificate clientKey authMode serverCerticate consumerGroupId connectionTimeout sessionTimeout retryBackoff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval}';
        const pipeline_datastore = 'datastore: pipeline_datastore {uid host port databaseName user password accountName warehouse database schema authType username clientId clientSecret authorizationCode redirectURI loginTimeout url}';
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      var(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        pipelines as gateway_pipeline {
        }
      }
      resp(func: uid(pipelines)) {
        uid
        name
        uuid
        pipelineType
        deployerType
        protocolType
        protocolId
        dataStoreType
        dataStoreId
        created
        modified
        description
        status
        flowConfiguration
        logLevel
        subscriptionTopic
        ${pipeline_protocol}
        ${pipeline_datastore}
        ${pipeline_filter}
        ${pipeline_streaming}
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipelines')), catchError(this.handleError('getPipelines', [])));
    }
    addPipeline(gatewayUid, pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        let query = '';
        query = `{
      set {
        _:Pipeline <dgraph.type> "Pipeline" .
        _:Pipeline <name> "${pipeline.name}" .
        _:Pipeline <uuid> "${pipeline.name}" .
        _:Pipeline <type> "pipeline" .
        _:Pipeline <pipeline> "" .
        _:Pipeline <pipelineType> "${pipeline.pipelineType}" .
        _:Pipeline <deployerType> "${pipeline.deployerType}" .
        _:Pipeline <created> "${pipeline.created}" .
        _:Pipeline <modified> "${pipeline.modified}" .
        _:Pipeline <description> "${pipeline.description}" .
        _:Pipeline <status> "${pipeline.status}" .
        _:Pipeline <flowConfiguration> "${pipeline.flowConfiguration}" .
        _:Pipeline <logLevel> "${pipeline.logLevel}" .
        _:Pipeline <subscriptionTopic> "${pipeline.subscriptionTopic}" .
        <${gatewayUid}> <gateway_pipeline> _:Pipeline .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = pipeline)), tap(() => console.log('add pipeline')), catchError(this.handleError('addPipelines')));
    }
    updatePipeline(pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${pipeline.uid}> <description> "${pipeline.description}" .
        <${pipeline.uid}> <status> "${pipeline.status}" .
        <${pipeline.uid}> <modified> "${pipeline.modified}" .
        <${pipeline.uid}> <flowConfiguration> "${pipeline.flowConfiguration}" .
        <${pipeline.uid}> <logLevel> "${pipeline.logLevel}" .
        <${pipeline.uid}> <subscriptionTopic> "${pipeline.subscriptionTopic}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = pipeline)), tap(() => console.log('updated pipelines')), catchError(this.handleError('updatePipeline')));
    }
    deletePipeline(gatewayUid, pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${pipeline.uid}> * * .
        <${gatewayUid}> <gateway_pipeline> <${pipeline.uid}> .
      }
    }`;
        console.log('Delete Pipeline Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `pipeline deleted`)), tap(() => console.log('deleted pipeline')), catchError(this.handleError('deletePipeline')));
    }
    /**
     * Get ids of all the pipelines associated with the specified protocol
     * @param protocolUid - the uid of the protocol
     */
    getPipelineIdsFromProtocolUid(protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${protocolUid})) {
        pipelines as ~pipeline_protocol {
        }
      }
      resp(func: uid(pipelines)) {
        uid
        uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipeline ids')), catchError(this.handleError('getPipelineIdsFromProtocolUid', [])));
    }
    /**
     * Get ids of all the pipelines associated with the specified data store
     * @param dataStoreUid - the uid of the data store
     */
    getPipelineIdsFromDataStoreUid(dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${dataStoreUid})) {
        pipelines as ~pipeline_datastore {
        }
      }
      resp(func: uid(pipelines)) {
        uid
        uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipeline ids')), catchError(this.handleError('getPipelineIdsFromDataStoreUid', [])));
    }
    getModelConfigs(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        modelConfigs as gateway_modelconfig {
        }
      }
      resp(func: uid(modelConfigs)) {
        uid
        name
        uuid
        description
        device
        resource
        model
        created
        modified
      }
    }`;
        console.log('getModelConfigs service query: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched modelConfigs')), catchError(this.handleError('getModelConfigs', [])));
    }
    addModelConfig(gatewayUid, modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:ModelConfig <dgraph.type> "ModelConfig" .
        _:ModelConfig <name> "${modelConfig.name}" .
        _:ModelConfig <uuid> "${modelConfig.name}" .
        _:ModelConfig <type> "modelConfig" .
        _:ModelConfig <modelConfig> "" .
        _:ModelConfig <description> "${modelConfig.description}" .
        _:ModelConfig <device> "${modelConfig.device}" .
        _:ModelConfig <resource> "${modelConfig.resource}" .
        _:ModelConfig <model> "${modelConfig.model}" .
        _:ModelConfig <created> "${modelConfig.created}" .
        _:ModelConfig <modified> "${modelConfig.modified}" .
        <${gatewayUid}> <gateway_modelconfig> _:ModelConfig .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = modelConfig)), tap(() => console.log('add modelConfig')), catchError(this.handleError('addModelConfig')));
    }
    updateModelConfig(modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${modelConfig.uid}> <name> "${modelConfig.name}" .
        <${modelConfig.uid}> <uuid> "${modelConfig.uuid}" .
        <${modelConfig.uid}> <description> "${modelConfig.description}" .
        <${modelConfig.uid}> <condDevice> "${modelConfig.device}" .
        <${modelConfig.uid}> <condResource> "${modelConfig.resource}" .
        <${modelConfig.uid}> <model> "${modelConfig.model}" .
        <${modelConfig.uid}> <modified> "${modelConfig.modified}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = modelConfig)), tap(() => console.log('updated modelConfig')), catchError(this.handleError('updateModelConfig')));
    }
    deleteModelConfig(gatewayUid, modelConfigUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${modelConfigUid}> * * .
        <${gatewayUid}> <gateway_modelconfig> <${modelConfigUid}> .
      }
    }`;
        console.log('Delete ModelConfig Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${modelConfigUid} deleted`)), tap(() => console.log('deleted modelConfig')), catchError(this.handleError('deleteModelConfig')));
    }
    getFiltersConfig(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        filtersConfig as gateway_filter {
        }
      }
      resp(func: uid(filtersConfig)) {
        uid
        deviceNames
      }
    }`;
        console.log('getFiltersConfig service query: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched filtersConfig')), catchError(this.handleError('getFiltersConfigs', [])));
    }
    addFiltersConfig(gatewayUid, filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Filter <dgraph.type> "filter" .
        _:Filter <type> "filter" .
        _:Filter <filter> "" .
        _:Filter <deviceNames> "${filtersConfig.deviceNames}" .
        <${gatewayUid}> <gateway_filter> _:Filter .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = filtersConfig)), tap(() => console.log('add filtersConfig')), catchError(this.handleError('addFiltersConfig')));
    }
    updateFiltersConfig(filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${filtersConfig.uid}> <deviceNames> "${filtersConfig.deviceNames}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = filtersConfig)), tap(() => console.log('updated filtersConfig')), catchError(this.handleError('updateFiltersConfig')));
    }
    getReadings(deviceName, instrumentName, numReadings, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        // return this.http.post<any>(url, `{resp(func: has(reading)) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) {~device_resource @filter (eq(uuid, "${deviceName}")) {}}}}`, httpOptions)
        // return this.http.post<any>(url, `{resp(func: has(reading)) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading (first:-${numReadings}) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('getReadings query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log('Response from getReadings: ', response)), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadings', [])));
    }
    getReadingsAt(deviceName, instrumentName, ts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(eq(created, ${ts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('getReadingsAt query statement: ', query);
        // return this.http.post<any>(url, `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadingsAt', [])));
    }
    getReadingsStartingAt(deviceName, instrumentName, fromts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        // const myquery = `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`;
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('the query is: ', query);
        // return this.http.post<any>(url, `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadingsStartingAt', [])));
    }
    getReadingsBetween(deviceName, instrumentName, fromts, tots, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        // const myquery = `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`;
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('the query is: ', query);
        // return this.http.post<any>(url, `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadingsBetween', [])));
    }
    getLastReadingsForDevice(deviceName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(device)) @filter(eq(uuid, "${deviceName}")) @normalize {
        device_resource {
          name: name
          resource_reading (first:-1) {
            created: created
            value: value
          }
        }
      }
    }`;
        console.log('Reading query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getLastReadingsForDevice', [])));
    }
    getNotifications(account) {
        this.ensureAccountAuthorized(account);
        console.log('GetNotifications service called');
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(notification)) @normalize {
        uid uuid:uuid created:created notifySource:notifySource notifyDevice:notifyDevice notifyResource:notifyResource notifyLevel:notifyLevel value:value description:description ~gateway_notification {
          gateway: uuid
        }
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log('Response from GetNoti: ', response)), tap(() => console.log('fetched notifications')), catchError(this.handleError('getNotifications', [])));
    }
    getRoute(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let route = null;
        if (deviceName == 'train-0001') {
            route = route1;
        }
        else if (deviceName == 'train-0002') {
            route = route2;
        }
        else if (deviceName == 'train-0003') {
            route = route3;
        }
        else {
            route = emptyroute;
        }
        return route;
    }
    getRouteCenter(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let center = null;
        // 39.0 -98.0 zoom 4
        // East 34.765589   -78.709488
        // West 40.487432 -122.803116
        if (deviceName == 'train-0001') {
            center = [34.0, -98.0];
        }
        else if (deviceName == 'train-0002') {
            center = [40.0, -98.0];
        }
        else if (deviceName == 'train-0003') {
            center = [39.0, -98.0];
        }
        else {
            center = [42.8, 12.8];
        }
        return center;
    }
    ensureAccountAuthorized(account) {
        if (!account)
            throw new Error('Account must exist');
    }
    /**
     * Handle HTTP operation that failed.
     * Let the app continue.
     * @param operation - - name of the operation that failed
     * @param result - optional value to return as the observable result
     */
    handleError(operation = 'operation', result) {
        return (error) => {
            // TODO: better job of transforming error for user consumption
            console.log(`${operation} failed: ${error.code}: ${error.message}`);
            // Let the app keep running by returning an empty result.
            return of(result);
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL2xhYnMtYWlyLWdyYXBoLWNsaWVudC9zcmMvYXBpL2dyYXBoLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBV0EsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQWMsRUFBRSxFQUFFLEdBQUcsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUk1RCxNQUFNLE1BQU0sR0FBZTtJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFFBQVEsQ0FBQztJQUN0QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztDQUMxQixDQUFDO0FBRUYsTUFBTSxNQUFNLEdBQWU7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7Q0FDM0IsQ0FBQztBQUVGLE1BQU0sTUFBTSxHQUFlO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0NBQzFCLENBQUM7QUFFRixNQUFNLFVBQVUsR0FBZSxFQUFFLENBQUM7QUFFbEMsTUFBTSxXQUFXLEdBQUc7SUFDaEIsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLHVCQUF1QixFQUFFO0NBQ3ZELENBQUM7QUFFRixNQUFNLGlCQUFpQixHQUFHO0lBQ3RCLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxpQkFBaUIsRUFBRTtDQUNqRCxDQUFDO0FBRUYsTUFBTSxPQUFPLFlBQVk7SUFHckIsWUFBb0IsSUFBVyxFQUFZLFNBQWlCO1FBQXhDLFNBQUksR0FBSixJQUFJLENBQU87UUFBWSxjQUFTLEdBQVQsU0FBUyxDQUFRO1FBQ3hELE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUUzQyw4RUFBOEU7UUFDOUUsK0JBQStCO1FBQy9CLG9FQUFvRTtRQUNwRSxtSEFBbUg7UUFDbkgsbUhBQW1IO1FBQ25ILEdBQUc7SUFDUCxDQUFDO0lBRUQsVUFBVSxDQUFDLFdBQW1CLEVBQUUsT0FBZTtRQUMzQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUM1RCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzttREFDNkIsV0FBVzs7O01BR3hELENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ3BFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFZLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUM1RCxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFlO1FBQ3ZCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3pELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHOzs7Ozs7TUFNaEIsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVksYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQzdELENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLE9BQWdCLEVBQUUsT0FBZTtRQUMzQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxPQUFPLENBQUMsR0FBRyxnQkFBZ0IsT0FBTyxDQUFDLE9BQU87V0FDMUMsT0FBTyxDQUFDLEdBQUcsZUFBZSxPQUFPLENBQUMsTUFBTTtXQUN4QyxPQUFPLENBQUMsR0FBRyxtQkFBbUIsT0FBTyxDQUFDLFVBQVU7V0FDaEQsT0FBTyxDQUFDLEdBQUcsc0JBQXNCLE9BQU8sQ0FBQyxhQUFhO1dBQ3RELE9BQU8sQ0FBQyxHQUFHLG9CQUFvQixPQUFPLENBQUMsV0FBVztXQUNsRCxPQUFPLENBQUMsR0FBRyxpQkFBaUIsT0FBTyxDQUFDLFFBQVE7V0FDNUMsT0FBTyxDQUFDLEdBQUcsa0JBQWtCLE9BQU8sQ0FBQyxTQUFTO1dBQzlDLE9BQU8sQ0FBQyxHQUFHLG9CQUFvQixPQUFPLENBQUMsV0FBVztXQUNsRCxPQUFPLENBQUMsR0FBRyxpQkFBaUIsT0FBTyxDQUFDLFFBQVE7V0FDNUMsT0FBTyxDQUFDLEdBQUcsaUJBQWlCLE9BQU8sQ0FBQyxRQUFRO1dBQzVDLE9BQU8sQ0FBQyxHQUFHLGtCQUFrQixPQUFPLENBQUMsU0FBUzs7TUFFbkQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFeEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLGlCQUFpQixDQUFDLEVBQ3BDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFDekMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsZUFBZSxDQUFDLENBQUMsQ0FDeEQsQ0FBQztJQUNOLENBQUM7SUFFRCxVQUFVLENBQUMsT0FBZ0IsRUFBRSxPQUFlO1FBQ3hDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7Ozs0QkFLTSxPQUFPLENBQUMsSUFBSTttQ0FDTCxPQUFPLENBQUMsV0FBVzsrQkFDdkIsT0FBTyxDQUFDLE9BQU87OEJBQ2hCLE9BQU8sQ0FBQyxNQUFNO2tDQUNWLE9BQU8sQ0FBQyxVQUFVO3FDQUNmLE9BQU8sQ0FBQyxhQUFhO2dDQUMxQixPQUFPLENBQUMsUUFBUTtpQ0FDZixPQUFPLENBQUMsU0FBUzttQ0FDZixPQUFPLENBQUMsV0FBVztnQ0FDdEIsT0FBTyxDQUFDLFFBQVE7Z0NBQ2hCLE9BQU8sQ0FBQyxRQUFRO2lDQUNmLE9BQU8sQ0FBQyxTQUFTO2lDQUNqQixPQUFPLENBQUMsU0FBUzs7TUFFNUMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFckQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFDakQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUMsRUFDckMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVUsWUFBWSxDQUFDLENBQUMsQ0FDdEQsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsVUFBa0IsRUFBRSxPQUFlO1FBQzdDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFVBQVU7O01BRWYsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFeEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxVQUFVLFVBQVUsQ0FBQyxFQUNsQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQ3pDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFTLGVBQWUsQ0FBQyxDQUFDLENBQ3hELENBQUM7SUFDTixDQUFDO0lBRUQsc0JBQXNCLENBQUMsV0FBbUIsRUFBRSxPQUFlO1FBQ3ZELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzttREFDNkIsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O01BOEJ4RCxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2Q0FBNkMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQ3pDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFZLHlCQUF5QixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3pFLENBQUM7SUFDTixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFlBQVksQ0FBQyxXQUFtQixFQUFFLE9BQWU7UUFDN0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3FEQUMrQixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O01BNEIxRCxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWtCLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxFQUMzQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYSxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDL0QsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxRQUFrQixFQUFFLE9BQWU7UUFDL0QsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OzZCQUtPLFFBQVEsQ0FBQyxJQUFJO2dDQUNWLFFBQVEsQ0FBQyxPQUFPO2lDQUNmLFFBQVEsQ0FBQyxRQUFRO3FDQUNiLFFBQVEsQ0FBQyxZQUFZO2tDQUN4QixRQUFRLENBQUMsU0FBUzs4QkFDdEIsUUFBUSxDQUFDLEtBQUs7d0NBQ0osUUFBUSxDQUFDLGVBQWU7MENBQ3RCLFFBQVEsQ0FBQyxpQkFBaUI7dUNBQzdCLFFBQVEsQ0FBQyxjQUFjO3NDQUN4QixRQUFRLENBQUMsYUFBYTtxQ0FDdkIsUUFBUSxDQUFDLFlBQVk7c0NBQ3BCLFFBQVEsQ0FBQyxhQUFhO3FDQUN2QixRQUFRLENBQUMsWUFBWTt1Q0FDbkIsUUFBUSxDQUFDLGNBQWM7MENBQ3BCLFFBQVEsQ0FBQyxpQkFBaUI7bUNBQ2pDLFFBQVEsQ0FBQyxVQUFVO2lDQUNyQixRQUFRLENBQUMsUUFBUTtpQ0FDakIsUUFBUSxDQUFDLFFBQVE7dUNBQ1gsUUFBUSxDQUFDLGNBQWM7c0NBQ3hCLFFBQVEsQ0FBQyxhQUFhOzBDQUNsQixRQUFRLENBQUMsaUJBQWlCO2tDQUNsQyxRQUFRLENBQUMsU0FBUztpQ0FDbkIsUUFBUSxDQUFDLFFBQVE7d0NBQ1YsUUFBUSxDQUFDLGlCQUFpQjs4QkFDcEMsUUFBUSxDQUFDLEtBQUs7O01BRXRDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQ3ZDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFXLGNBQWMsQ0FBQyxDQUFDLENBQ3pELENBQUM7SUFDTixDQUFDO0lBRUQsY0FBYyxDQUFDLFFBQWtCLEVBQUUsT0FBZTtRQUM5QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxRQUFRLENBQUMsR0FBRyxhQUFhLFFBQVEsQ0FBQyxJQUFJO1dBQ3RDLFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRyxxQkFBcUIsUUFBUSxDQUFDLFlBQVk7V0FDdEQsUUFBUSxDQUFDLEdBQUcsa0JBQWtCLFFBQVEsQ0FBQyxTQUFTO1dBQ2hELFFBQVEsQ0FBQyxHQUFHLGNBQWMsUUFBUSxDQUFDLEtBQUs7V0FDeEMsUUFBUSxDQUFDLEdBQUcsd0JBQXdCLFFBQVEsQ0FBQyxlQUFlO1dBQzVELFFBQVEsQ0FBQyxHQUFHLDBCQUEwQixRQUFRLENBQUMsaUJBQWlCO1dBQ2hFLFFBQVEsQ0FBQyxHQUFHLHVCQUF1QixRQUFRLENBQUMsY0FBYztXQUMxRCxRQUFRLENBQUMsR0FBRyxzQkFBc0IsUUFBUSxDQUFDLGFBQWE7V0FDeEQsUUFBUSxDQUFDLEdBQUcscUJBQXFCLFFBQVEsQ0FBQyxZQUFZO1dBQ3RELFFBQVEsQ0FBQyxHQUFHLHNCQUFzQixRQUFRLENBQUMsYUFBYTtXQUN4RCxRQUFRLENBQUMsR0FBRyxxQkFBcUIsUUFBUSxDQUFDLFlBQVk7V0FDdEQsUUFBUSxDQUFDLEdBQUcsdUJBQXVCLFFBQVEsQ0FBQyxjQUFjO1dBQzFELFFBQVEsQ0FBQyxHQUFHLDBCQUEwQixRQUFRLENBQUMsaUJBQWlCO1dBQ2hFLFFBQVEsQ0FBQyxHQUFHLG1CQUFtQixRQUFRLENBQUMsVUFBVTtXQUNsRCxRQUFRLENBQUMsR0FBRyxpQkFBaUIsUUFBUSxDQUFDLFFBQVE7V0FDOUMsUUFBUSxDQUFDLEdBQUcsaUJBQWlCLFFBQVEsQ0FBQyxRQUFRO1dBQzlDLFFBQVEsQ0FBQyxHQUFHLHVCQUF1QixRQUFRLENBQUMsY0FBYztXQUMxRCxRQUFRLENBQUMsR0FBRyxzQkFBc0IsUUFBUSxDQUFDLGFBQWE7V0FDeEQsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7V0FDaEUsUUFBUSxDQUFDLEdBQUcsa0JBQWtCLFFBQVEsQ0FBQyxTQUFTO1dBQ2hELFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRyx3QkFBd0IsUUFBUSxDQUFDLGlCQUFpQjtXQUM5RCxRQUFRLENBQUMsR0FBRyxjQUFjLFFBQVEsQ0FBQyxLQUFLOztNQUU3QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV6QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEVBQzNDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFXLGlCQUFpQixDQUFDLENBQUMsQ0FDNUQsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxXQUFtQixFQUFFLE9BQWU7UUFDbkUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsV0FBVzs7TUFFaEIsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxXQUFXLFVBQVUsQ0FBQyxDQUFDLEVBQ2xFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsZ0JBQWdCLENBQUMsQ0FBQyxDQUN6RCxDQUFDO0lBQ04sQ0FBQztJQUVELGFBQWEsQ0FBQyxXQUFtQixFQUFFLE9BQWU7UUFDOUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO3NEQUNnQyxXQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O01BeUIzRCxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxFQUM1QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYyxlQUFlLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDakUsQ0FBQztJQUNOLENBQUM7SUFFRCxZQUFZLENBQUMsVUFBa0IsRUFBRSxTQUFvQixFQUFFLE9BQWU7UUFDbEUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OzhCQUtRLFNBQVMsQ0FBQyxJQUFJO2lDQUNYLFNBQVMsQ0FBQyxPQUFPO2tDQUNoQixTQUFTLENBQUMsUUFBUTt1Q0FDYixTQUFTLENBQUMsYUFBYTs4QkFDaEMsU0FBUyxDQUFDLElBQUk7OEJBQ2QsU0FBUyxDQUFDLElBQUk7c0NBQ04sU0FBUyxDQUFDLFlBQVk7OEJBQzlCLFNBQVMsQ0FBQyxJQUFJO2tDQUNWLFNBQVMsQ0FBQyxRQUFRO3FDQUNmLFNBQVMsQ0FBQyxXQUFXO21DQUN2QixTQUFTLENBQUMsU0FBUztrQ0FDcEIsU0FBUyxDQUFDLFlBQVk7Z0NBQ3hCLFNBQVMsQ0FBQyxNQUFNO2tDQUNkLFNBQVMsQ0FBQyxRQUFRO2tDQUNsQixTQUFTLENBQUMsUUFBUTtrQ0FDbEIsU0FBUyxDQUFDLFFBQVE7c0NBQ2QsU0FBUyxDQUFDLFlBQVk7MkNBQ2pCLFNBQVMsQ0FBQyxpQkFBaUI7cUNBQ2pDLFNBQVMsQ0FBQyxXQUFXO3NDQUNwQixTQUFTLENBQUMsWUFBWTs2QkFDL0IsU0FBUyxDQUFDLEdBQUc7K0JBQ1gsU0FBUyxDQUFDLEtBQUs7O01BRXhDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQyxDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsRUFDeEMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVksZUFBZSxDQUFDLENBQUMsQ0FDM0QsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsU0FBb0IsRUFBRSxPQUFlO1FBQ2pELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFNBQVMsQ0FBQyxHQUFHLGFBQWEsU0FBUyxDQUFDLElBQUk7V0FDeEMsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxRQUFRO1dBQ2hELFNBQVMsQ0FBQyxHQUFHLHNCQUFzQixTQUFTLENBQUMsYUFBYTtXQUMxRCxTQUFTLENBQUMsR0FBRyxhQUFhLFNBQVMsQ0FBQyxJQUFJO1dBQ3hDLFNBQVMsQ0FBQyxHQUFHLGFBQWEsU0FBUyxDQUFDLElBQUk7V0FDeEMsU0FBUyxDQUFDLEdBQUcscUJBQXFCLFNBQVMsQ0FBQyxZQUFZO1dBQ3hELFNBQVMsQ0FBQyxHQUFHLGFBQWEsU0FBUyxDQUFDLElBQUk7V0FDeEMsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxRQUFRO1dBQ2hELFNBQVMsQ0FBQyxHQUFHLG9CQUFvQixTQUFTLENBQUMsV0FBVztXQUN0RCxTQUFTLENBQUMsR0FBRyxrQkFBa0IsU0FBUyxDQUFDLFNBQVM7V0FDbEQsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxZQUFZO1dBQ3BELFNBQVMsQ0FBQyxHQUFHLGVBQWUsU0FBUyxDQUFDLE1BQU07V0FDNUMsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxRQUFRO1dBQ2hELFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsUUFBUTtXQUNoRCxTQUFTLENBQUMsR0FBRyxpQkFBaUIsU0FBUyxDQUFDLFFBQVE7V0FDaEQsU0FBUyxDQUFDLEdBQUcscUJBQXFCLFNBQVMsQ0FBQyxZQUFZO1dBQ3hELFNBQVMsQ0FBQyxHQUFHLDBCQUEwQixTQUFTLENBQUMsaUJBQWlCO1dBQ2xFLFNBQVMsQ0FBQyxHQUFHLG9CQUFvQixTQUFTLENBQUMsV0FBVztXQUN0RCxTQUFTLENBQUMsR0FBRyxxQkFBcUIsU0FBUyxDQUFDLFlBQVk7V0FDeEQsU0FBUyxDQUFDLEdBQUcsWUFBWSxTQUFTLENBQUMsR0FBRztXQUN0QyxTQUFTLENBQUMsR0FBRyxjQUFjLFNBQVMsQ0FBQyxLQUFLOztNQUUvQyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV6QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLEVBQzVDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFZLGtCQUFrQixDQUFDLENBQUMsQ0FDOUQsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsVUFBa0IsRUFBRSxZQUFvQixFQUFFLE9BQWU7UUFDckUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsWUFBWTs7TUFFakIsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFMUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxZQUFZLFVBQVUsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsaUJBQWlCLENBQUMsQ0FBQyxDQUMxRCxDQUFDO0lBQ04sQ0FBQztJQUVELG1CQUFtQixDQUFDLFdBQW1CLEVBQUUsT0FBZTtRQUNwRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7bURBQzZCLFdBQVc7Ozs7Ozs7Ozs7Ozs7OztNQWV4RCxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2Q0FBNkMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQ3pDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFZLHNCQUFzQixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3RFLENBQUM7SUFDTixDQUFDO0lBRUQsU0FBUyxDQUFDLFdBQW1CLEVBQUUsT0FBZTtRQUMxQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7a0RBQzRCLFdBQVc7Ozs7Ozs7Ozs7OztNQVl2RCxDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWUsQ0FBQyxFQUNoRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEVBQ3hDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFVLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUN6RCxDQUFDO0lBQ04sQ0FBQztJQUVELFFBQVEsQ0FBQyxVQUFrQixFQUFFLEtBQVksRUFBRSxPQUFlO1FBQ3RELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7OzswQkFLSSxLQUFLLENBQUMsSUFBSTs2QkFDUCxLQUFLLENBQUMsT0FBTzs4QkFDWixLQUFLLENBQUMsUUFBUTswQkFDbEIsS0FBSyxDQUFDLElBQUk7aUNBQ0gsS0FBSyxDQUFDLFdBQVc7K0JBQ25CLEtBQUssQ0FBQyxTQUFTO3lCQUNyQixLQUFLLENBQUMsR0FBRzsyQkFDUCxLQUFLLENBQUMsS0FBSzttQ0FDSCxLQUFLLENBQUMsYUFBYTs7TUFFaEQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFDL0MsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsRUFDcEMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVEsV0FBVyxDQUFDLENBQUMsQ0FDbkQsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsS0FBWSxFQUFFLE9BQWU7UUFDckMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsS0FBSyxDQUFDLEdBQUcsYUFBYSxLQUFLLENBQUMsSUFBSTtXQUNoQyxLQUFLLENBQUMsR0FBRyxpQkFBaUIsS0FBSyxDQUFDLFFBQVE7V0FDeEMsS0FBSyxDQUFDLEdBQUcsYUFBYSxLQUFLLENBQUMsSUFBSTtXQUNoQyxLQUFLLENBQUMsR0FBRyxvQkFBb0IsS0FBSyxDQUFDLFdBQVc7V0FDOUMsS0FBSyxDQUFDLEdBQUcsa0JBQWtCLEtBQUssQ0FBQyxTQUFTO1dBQzFDLEtBQUssQ0FBQyxHQUFHLFlBQVksS0FBSyxDQUFDLEdBQUc7V0FDOUIsS0FBSyxDQUFDLEdBQUcsY0FBYyxLQUFLLENBQUMsS0FBSztXQUNsQyxLQUFLLENBQUMsR0FBRyxzQkFBc0IsS0FBSyxDQUFDLGFBQWE7O01BRXZELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQy9DLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsRUFDeEMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVEsY0FBYyxDQUFDLENBQUMsQ0FDdEQsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxRQUFnQixFQUFFLE9BQWU7UUFDN0QsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsUUFBUTs7TUFFYixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV0RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLFFBQVEsVUFBVSxDQUFDLENBQUMsRUFDL0QsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUyxhQUFhLENBQUMsQ0FBQyxDQUN0RCxDQUFDO0lBQ04sQ0FBQztJQUVELHNCQUFzQixDQUFDLFdBQW1CLEVBQUUsT0FBZTtRQUN2RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxpQkFBaUIsR0FDbkIsK1NBQStTLENBQUM7UUFDcFQsTUFBTSxrQkFBa0IsR0FDcEIsNE1BQTRNLENBQUM7UUFDak4sTUFBTSxlQUFlLEdBQUcsMkNBQTJDLENBQUM7UUFDcEUsTUFBTSxrQkFBa0IsR0FDcEIsOEZBQThGLENBQUM7UUFFbkcsTUFBTSxLQUFLLEdBQUc7bURBQzZCLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFtQmxELGlCQUFpQjtZQUNqQixrQkFBa0I7WUFDbEIsZUFBZTtZQUNmLGtCQUFrQjs7O01BR3hCLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZDQUE2QyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRWxFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFDekMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVkseUJBQXlCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDekUsQ0FBQztJQUNOLENBQUM7SUFFRCxZQUFZLENBQUMsV0FBbUIsRUFBRSxPQUFlO1FBQzdDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLGlCQUFpQixHQUNuQiwwU0FBMFMsQ0FBQztRQUMvUyxNQUFNLGtCQUFrQixHQUNwQix1TUFBdU0sQ0FBQztRQUM1TSxNQUFNLGVBQWUsR0FBRywyQ0FBMkMsQ0FBQztRQUNwRSxNQUFNLGtCQUFrQixHQUNwQiw4RkFBOEYsQ0FBQztRQUVuRyxNQUFNLEtBQUssR0FBRztrREFDNEIsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1VBcUJuRCxpQkFBaUI7VUFDakIsa0JBQWtCO1VBQ2xCLGVBQWU7VUFDZixrQkFBa0I7O01BRXRCLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBa0IsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEVBQzNDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFhLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUMvRCxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FDUCxVQUFrQixFQUNsQixRQUFrQixFQUNsQixPQUFlO1FBRWYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFFdEQsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBRWYsS0FBSyxHQUFHOzs7NkJBR2EsUUFBUSxDQUFDLElBQUk7NkJBQ2IsUUFBUSxDQUFDLElBQUk7OztxQ0FHTCxRQUFRLENBQUMsWUFBWTtxQ0FDckIsUUFBUSxDQUFDLFlBQVk7Z0NBQzFCLFFBQVEsQ0FBQyxPQUFPO2lDQUNmLFFBQVEsQ0FBQyxRQUFRO29DQUNkLFFBQVEsQ0FBQyxXQUFXOytCQUN6QixRQUFRLENBQUMsTUFBTTswQ0FDSixRQUFRLENBQUMsaUJBQWlCO2lDQUNuQyxRQUFRLENBQUMsUUFBUTswQ0FDUixRQUFRLENBQUMsaUJBQWlCO1dBQ3pELFVBQVU7O01BRWYsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsRUFDdEMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVcsY0FBYyxDQUFDLENBQUMsQ0FDekQsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsUUFBa0IsRUFBRSxPQUFlO1FBQzlDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFFBQVEsQ0FBQyxHQUFHLG9CQUFvQixRQUFRLENBQUMsV0FBVztXQUNwRCxRQUFRLENBQUMsR0FBRyxlQUFlLFFBQVEsQ0FBQyxNQUFNO1dBQzFDLFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRywwQkFBMEIsUUFBUSxDQUFDLGlCQUFpQjtXQUNoRSxRQUFRLENBQUMsR0FBRyxpQkFBaUIsUUFBUSxDQUFDLFFBQVE7V0FDOUMsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7O01BRXJFLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVcsZ0JBQWdCLENBQUMsQ0FBQyxDQUMzRCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLFFBQWtCLEVBQUUsT0FBZTtRQUNsRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUV0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxRQUFRLENBQUMsR0FBRztXQUNaLFVBQVUseUJBQXlCLFFBQVEsQ0FBQyxHQUFHOztNQUVwRCxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV6RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxrQkFBa0IsQ0FBQyxDQUFDLEVBQzVELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsZ0JBQWdCLENBQUMsQ0FBQyxDQUN6RCxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILDZCQUE2QixDQUFDLFdBQW1CLEVBQUUsT0FBZTtRQUM5RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7c0JBQ0EsV0FBVzs7Ozs7Ozs7TUFRM0IsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFrQixDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUMsRUFDOUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWEsK0JBQStCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDaEYsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCw4QkFBOEIsQ0FBQyxZQUFvQixFQUFFLE9BQWU7UUFDaEUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3NCQUNBLFlBQVk7Ozs7Ozs7O01BUTVCLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBa0IsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEVBQzlDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFhLGdDQUFnQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ2pGLENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFdBQW1CLEVBQUUsT0FBZTtRQUNoRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7a0RBQzRCLFdBQVc7Ozs7Ozs7Ozs7Ozs7OztNQWV2RCxDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV0RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBcUIsQ0FBQyxFQUN0RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEVBQzlDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFnQixpQkFBaUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNyRSxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLFdBQXdCLEVBQUUsT0FBZTtRQUN4RSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7O2dDQUdVLFdBQVcsQ0FBQyxJQUFJO2dDQUNoQixXQUFXLENBQUMsSUFBSTs7O3VDQUdULFdBQVcsQ0FBQyxXQUFXO2tDQUM1QixXQUFXLENBQUMsTUFBTTtvQ0FDaEIsV0FBVyxDQUFDLFFBQVE7aUNBQ3ZCLFdBQVcsQ0FBQyxLQUFLO21DQUNmLFdBQVcsQ0FBQyxPQUFPO29DQUNsQixXQUFXLENBQUMsUUFBUTtXQUM3QyxVQUFVOztNQUVmLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxDQUFDLEVBQ3JELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFDekMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsZ0JBQWdCLENBQUMsQ0FBQyxDQUM5RCxDQUFDO0lBQ04sQ0FBQztJQUVELGlCQUFpQixDQUFDLFdBQXdCLEVBQUUsT0FBZTtRQUN2RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxXQUFXLENBQUMsR0FBRyxhQUFhLFdBQVcsQ0FBQyxJQUFJO1dBQzVDLFdBQVcsQ0FBQyxHQUFHLGFBQWEsV0FBVyxDQUFDLElBQUk7V0FDNUMsV0FBVyxDQUFDLEdBQUcsb0JBQW9CLFdBQVcsQ0FBQyxXQUFXO1dBQzFELFdBQVcsQ0FBQyxHQUFHLG1CQUFtQixXQUFXLENBQUMsTUFBTTtXQUNwRCxXQUFXLENBQUMsR0FBRyxxQkFBcUIsV0FBVyxDQUFDLFFBQVE7V0FDeEQsV0FBVyxDQUFDLEdBQUcsY0FBYyxXQUFXLENBQUMsS0FBSztXQUM5QyxXQUFXLENBQUMsR0FBRyxpQkFBaUIsV0FBVyxDQUFDLFFBQVE7O01BRXpELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxDQUFDLEVBQ3JELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUMsRUFDN0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsbUJBQW1CLENBQUMsQ0FBQyxDQUNqRSxDQUFDO0lBQ04sQ0FBQztJQUVELGlCQUFpQixDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxPQUFlO1FBQ3pFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLGNBQWM7V0FDZCxVQUFVLDRCQUE0QixjQUFjOztNQUV6RCxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1Q0FBdUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUU1RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLGNBQWMsVUFBVSxDQUFDLENBQUMsRUFDckUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQyxFQUM3QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUyxtQkFBbUIsQ0FBQyxDQUFDLENBQzVELENBQUM7SUFDTixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsV0FBbUIsRUFBRSxPQUFlO1FBQ2pELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRztrREFDNEIsV0FBVzs7Ozs7Ozs7TUFRdkQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFdkQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQThCLENBQUMsRUFDL0QsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxFQUMvQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBeUIsbUJBQW1CLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDaEYsQ0FBQztJQUNOLENBQUM7SUFFRCxnQkFBZ0IsQ0FDWixVQUFrQixFQUNsQixhQUFtQyxFQUNuQyxPQUFlO1FBRWYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFFdEQsTUFBTSxLQUFLLEdBQUc7Ozs7O2tDQUtZLGFBQWEsQ0FBQyxXQUFXO1dBQ2hELFVBQVU7O01BRWYsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDLENBQUMsRUFDdkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxFQUMzQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBdUIsa0JBQWtCLENBQUMsQ0FBQyxDQUN6RSxDQUFDO0lBQ04sQ0FBQztJQUVELG1CQUFtQixDQUFDLGFBQW1DLEVBQUUsT0FBZTtRQUNwRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxhQUFhLENBQUMsR0FBRyxvQkFBb0IsYUFBYSxDQUFDLFdBQVc7O01BRW5FLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxDQUFDLEVBQ3ZELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUMsRUFDL0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQXVCLHFCQUFxQixDQUFDLENBQUMsQ0FDNUUsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxjQUFzQixFQUFFLFdBQW1CLEVBQUUsT0FBZTtRQUN4RixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsdU9BQXVPO1FBQ3ZPLGlMQUFpTDtRQUVqTCxNQUFNLEtBQUssR0FBRzttREFDNkIsVUFBVSxJQUFJLGNBQWM7K0NBQ2hDLFdBQVc7Ozs7Ozs7TUFPcEQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFcEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ3ZFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQy9ELENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxFQUFVLEVBQUUsT0FBZTtRQUNqRixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUc7bURBQzZCLFVBQVUsSUFBSSxjQUFjOzJEQUNwQixFQUFFOzs7Ozs7O01BT3ZELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXRELGlOQUFpTjtRQUNqTixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQzFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLGVBQWUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNqRSxDQUFDO0lBQ04sQ0FBQztJQUVELHFCQUFxQixDQUNqQixVQUFrQixFQUNsQixjQUFzQixFQUN0QixNQUFjLEVBQ2QsT0FBZTtRQUVmLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxvTEFBb0w7UUFDcEwsTUFBTSxLQUFLLEdBQUc7bURBQzZCLFVBQVUsSUFBSSxjQUFjOzJEQUNwQixNQUFNOzs7Ozs7O01BTzNELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXJDLGlOQUFpTjtRQUNqTixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQzFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3pFLENBQUM7SUFDTixDQUFDO0lBRUQsa0JBQWtCLENBQ2QsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsTUFBYyxFQUNkLElBQVksRUFDWixPQUFlO1FBRWYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLG9MQUFvTDtRQUNwTCxNQUFNLEtBQUssR0FBRzttREFDNkIsVUFBVSxJQUFJLGNBQWM7MkRBQ3BCLE1BQU0scUJBQXFCLElBQUk7Ozs7Ozs7TUFPcEYsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFckMsaU5BQWlOO1FBQ2pOLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFtQixDQUFDLEVBQ3BELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsb0JBQW9CLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDdEUsQ0FBQztJQUNOLENBQUM7SUFFRCx3QkFBd0IsQ0FBQyxVQUFrQixFQUFFLE9BQWU7UUFDeEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO2tEQUM0QixVQUFVOzs7Ozs7Ozs7TUFTdEQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFaEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYywwQkFBMEIsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUM1RSxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUFDLE9BQWU7UUFDNUIsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUMvQyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzs7Ozs7O01BTWhCLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBc0IsQ0FBQyxFQUN2RCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxFQUMvQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBaUIsa0JBQWtCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDdkUsQ0FBQztJQUNOLENBQUM7SUFFRCxRQUFRLENBQUMsVUFBa0IsRUFBRSxPQUFlO1FBQ3hDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUM7UUFFakIsSUFBSSxVQUFVLElBQUksWUFBWSxFQUFFO1lBQzVCLEtBQUssR0FBRyxNQUFNLENBQUM7U0FDbEI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsS0FBSyxHQUFHLE1BQU0sQ0FBQztTQUNsQjthQUFNLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRTtZQUNuQyxLQUFLLEdBQUcsTUFBTSxDQUFDO1NBQ2xCO2FBQU07WUFDSCxLQUFLLEdBQUcsVUFBVSxDQUFDO1NBQ3RCO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLE9BQWU7UUFDOUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztRQUVsQixvQkFBb0I7UUFDcEIsOEJBQThCO1FBQzlCLDZCQUE2QjtRQUU3QixJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDNUIsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTTtZQUNILE1BQU0sR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztTQUN6QjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxPQUFlO1FBQzNDLElBQUksQ0FBQyxPQUFPO1lBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRDs7Ozs7T0FLRztJQUNLLFdBQVcsQ0FBSSxTQUFTLEdBQUcsV0FBVyxFQUFFLE1BQVU7UUFDdEQsT0FBTyxDQUFDLEtBQVUsRUFBaUIsRUFBRTtZQUNqQyw4REFBOEQ7WUFDOUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFNBQVMsWUFBWSxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBRXBFLHlEQUF5RDtZQUN6RCxPQUFPLEVBQUUsQ0FBQyxNQUFXLENBQUMsQ0FBQztRQUMzQixDQUFDLENBQUM7SUFDTixDQUFDO0NBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICAgIERhdGFTdG9yZSxcbiAgICBHYXRld2F5LFxuICAgIEdhdGV3YXlGaWx0ZXJzQ29uZmlnLFxuICAgIE1vZGVsLFxuICAgIE1vZGVsQ29uZmlnLFxuICAgIE5vdGlmaWNhdGlvbixcbiAgICBQaXBlbGluZSxcbiAgICBQcm90b2NvbCxcbiAgICBUU1JlYWRpbmcsXG59IGZyb20gJy4uL21vZGVsL21vZGVscyc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBtYXAsIE9ic2VydmFibGUsIG9mLCB0YXAgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEF4aW9zIH0gZnJvbSAnYXhpb3Mtb2JzZXJ2YWJsZSc7XG5cblxuY29uc3Qgcm91dGUxOiBudW1iZXJbXVtdID0gW1xuICAgIFsyNS43NzEwODgsIC04MC4xNjM0ODNdLFxuICAgIFsyNy40Mzk3NzUsIC04MC4zMjI5OV0sXG4gICAgWzI4LjM0OTQ2OSwgLTgwLjczMTEwNV0sXG4gICAgWzMwLjQwMTU2NCwgLTgxLjU3MTAzM10sXG4gICAgWzMyLjExNjcxNiwgLTgxLjE0NDE0N10sXG4gICAgWzMyLjg2NjUxMSwgLTc5Ljk5NTM5OV0sXG4gICAgWzM0LjE5MTIyNCwgLTc3Ljk1MjQxOV0sXG4gICAgWzM2Ljg1MDE3MiwgLTc2LjMxOTI2OV0sXG4gICAgWzM2LjkxNTAzNywgLTc2LjMyMDY0M10sXG4gICAgWzM5LjI2MjAyNSwgLTc2LjU0OTI5NF0sXG4gICAgWzM5LjkwMDkzMywgLTc1LjE0MzQ1M10sXG4gICAgWzQwLjY5MDI2MywgLTc0LjE1MjM3NV0sXG4gICAgWzQyLjI1OTk1MSwgLTcxLjc4OTI0NF0sXG5dO1xuXG5jb25zdCByb3V0ZTI6IG51bWJlcltdW10gPSBbXG4gICAgWzQ3LjQ5MjQ3MSwgLTEyMi4yNjg4OF0sXG4gICAgWzQ1LjU1MjIwNywgLTEyMi43MjI2NDhdLFxuICAgIFszOS41MzI0NiwgLTExOS43NTE1MjRdLFxuICAgIFszNy44MDM1MjgsIC0xMjIuMzEyMTM4XSxcbiAgICBbMzcuODk5MzMyLCAtMTIxLjE2OTMwN10sXG4gICAgWzM2LjI3MzE4MywgLTExNS4wNzA1MzRdLFxuICAgIFszMy43NzAzMiwgLTExOC4yNzMyODldLFxuICAgIFszNC4xMDYwMTIsIC0xMTcuMzIwMjU0XSxcbiAgICBbMzMuNTE1NTY0LCAtMTEyLjE2MDU2NF0sXG4gICAgWzMyLjEyNjQzNywgLTExMC44NDgzMzZdLFxuICAgIFszMS43NTIwODUsIC0xMDYuNDg4ODg3XSxcbiAgICBbMzUuMDQ3NTgsIC0xMDYuNjUzMzQ0XSxcbiAgICBbMzkuNzk2OTYzLCAtMTA0Ljk5NTM3NF0sXG5dO1xuXG5jb25zdCByb3V0ZTM6IG51bWJlcltdW10gPSBbXG4gICAgWzI5LjMwMjcyOSwgLTk4LjYzODc0NF0sXG4gICAgWzI5LjYzODQyMSwgLTk1LjI5MjI0NV0sXG4gICAgWzMyLjYxNTUyNSwgLTk2LjY5MzQ4NV0sXG4gICAgWzI5LjkxNzgzNiwgLTkwLjIwNTI3Ml0sXG4gICAgWzMyLjI1NjQwMywgLTkwLjE1MTU0Nl0sXG4gICAgWzM1LjA0NDg0OSwgLTkwLjE1MzAwNl0sXG4gICAgWzM4LjUyNDYyNywgLTkwLjIwOTUzNV0sXG4gICAgWzM5Ljg3MDg1MSwgLTg4LjkxMjI4NF0sXG4gICAgWzQxLjcwNTY5NCwgLTg3LjU3NzM0MV0sXG4gICAgWzQxLjkwMjM4MiwgLTg5LjEwMTkzMl0sXG4gICAgWzQ0LjI1MTI0MywgLTkxLjUwOTY2M10sXG4gICAgWzQ0Ljk3MDA2OSwgLTkzLjE3NDUyN10sXG4gICAgWzQ2Ljc1ODE4MSwgLTkyLjA5ODc0OF0sXG5dO1xuXG5jb25zdCBlbXB0eXJvdXRlOiBudW1iZXJbXVtdID0gW107XG5cbmNvbnN0IGh0dHBPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9ncmFwaHFsKy0nIH0sXG59O1xuXG5jb25zdCBodHRwTXV0YXRlT3B0aW9ucyA9IHtcbiAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vcmRmJyB9LFxufTtcblxuZXhwb3J0IGNsYXNzIEdyYXBoU2VydmljZSB7XG5cblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogQXhpb3MsIHByb3RlY3RlZCBkR3JhcGhVcmw6IHN0cmluZykge1xuICAgICAgICBjb25zb2xlLmxvZygnZEdyYXBoVXJsOiAnLCB0aGlzLmRHcmFwaFVybCk7XG5cbiAgICAgICAgLy9jb25zdCBkR3JhcGhCYXNpY0F1dGhFbmFibGVkID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aEVuYWJsZWQ7XG4gICAgICAgIC8vaWYgKGRHcmFwaEJhc2ljQXV0aEVuYWJsZWQpIHtcbiAgICAgICAgLy8gICAgY29uc3QgZEdyYXBoQmFzaWNBdXRoID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aDtcbiAgICAgICAgLy8gICAgKHRoaXMuaHR0cE9wdGlvbnMuaGVhZGVycyA9IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9ncmFwaHFsKy0nIH0pLCB7IEF1dGhvcml6YXRpb246IGRHcmFwaEJhc2ljQXV0aCB9O1xuICAgICAgICAvLyAgICAodGhpcy5odHRwTXV0YXRlT3B0aW9ucy5oZWFkZXJzID0geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3JkZicgfSksIHsgQXV0aG9yaXphdGlvbjogZEdyYXBoQmFzaWNBdXRoIH07XG4gICAgICAgIC8vfVxuICAgIH1cblxuICAgIGdldEdhdGV3YXkoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcblxuICAgICAgICBjb25zb2xlLmxvZygnR2V0R2F0ZXdheSBzZXJ2aWNlIGNhbGxlZCBmb3I6ICcsIGdhdGV3YXlOYW1lKTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICB1aWQgdXVpZCBkZXNjcmlwdGlvbiBhZGRyZXNzIHJvdXRlciByb3V0ZXJQb3J0IGRlcGxveU5ldHdvcmsgbGF0aXR1ZGUgbG9uZ2l0dWRlIGFjY2Vzc1Rva2VuIHVzZXJuYW1lIHBsYXRmb3JtIGRldmljZXNNZXRhZGF0YSBjcmVhdGVkdHMgdXBkYXRlZHRzXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgICAgIHRhcChyZXNwb25zZSA9PiBjb25zb2xlLmxvZyhcIlJlc3BvbnNlIGZyb20gZ2V0R2F0ZXdheTogXCIsIHJlc3BvbnNlKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheVtdPignZ2V0R2F0ZXdheScsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheXMoYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc29sZS5sb2coYEdldEdhdGV3YXlzIHNlcnZpY2UgY2FsbGVkIGZvciAke2FjY291bnR9YCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSB7XG4gICAgICAgIHVpZCB1dWlkIGRlc2NyaXB0aW9uIGFkZHJlc3Mgcm91dGVyIHJvdXRlclBvcnQgZGVwbG95TmV0d29yayBsYXRpdHVkZSBsb25naXR1ZGUgYWNjZXNzVG9rZW4gdXNlcm5hbWUgcGxhdGZvcm0gZGV2aWNlc01ldGFkYXRhIGNyZWF0ZWR0cyB1cGRhdGVkdHNcbiAgICAgICAgbnVtRGV2aWNlczogY291bnQoZ2F0ZXdheV9kZXZpY2UpXG5cbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIGdhdGV3YXlzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPEdhdGV3YXlbXT4oJ2dldEdhdGV3YXlzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVHYXRld2F5KGdhdGV3YXk6IEdhdGV3YXksIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxhZGRyZXNzPiBcIiR7Z2F0ZXdheS5hZGRyZXNzfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8cm91dGVyPiBcIiR7Z2F0ZXdheS5yb3V0ZXJ9XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxyb3V0ZXJQb3J0PiBcIiR7Z2F0ZXdheS5yb3V0ZXJQb3J0fVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8ZGVwbG95TmV0d29yaz4gXCIke2dhdGV3YXkuZGVwbG95TmV0d29ya31cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPGRlc2NyaXB0aW9uPiBcIiR7Z2F0ZXdheS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPGxhdGl0dWRlPiBcIiR7Z2F0ZXdheS5sYXRpdHVkZX1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPGxvbmdpdHVkZT4gXCIke2dhdGV3YXkubG9uZ2l0dWRlfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8YWNjZXNzVG9rZW4+IFwiJHtnYXRld2F5LmFjY2Vzc1Rva2VufVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8dXNlcm5hbWU+IFwiJHtnYXRld2F5LnVzZXJuYW1lfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8cGxhdGZvcm0+IFwiJHtnYXRld2F5LnBsYXRmb3JtfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8dXBkYXRlZHRzPiBcIiR7Z2F0ZXdheS51cGRhdGVkdHN9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnVXBkYXRlIEdhdGV3YXkgTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gJ2dhdGV3YXkgdXBkYXRlZCcpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCd1cGRhdGVkIGdhdGV3YXknKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPigndXBkYXRlR2F0ZXdheScpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRHYXRld2F5KGdhdGV3YXk6IEdhdGV3YXksIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpHYXRld2F5IDxkZ3JhcGgudHlwZT4gXCJHYXRld2F5XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGdhdGV3YXk+IFwiXCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHR5cGU+IFwiZ2F0ZXdheVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx1dWlkPiBcIiR7Z2F0ZXdheS51dWlkfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxkZXNjcmlwdGlvbj4gXCIke2dhdGV3YXkuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGFkZHJlc3M+IFwiJHtnYXRld2F5LmFkZHJlc3N9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHJvdXRlcj4gXCIke2dhdGV3YXkucm91dGVyfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxyb3V0ZXJQb3J0PiBcIiR7Z2F0ZXdheS5yb3V0ZXJQb3J0fVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxkZXBsb3lOZXR3b3JrPiBcIiR7Z2F0ZXdheS5kZXBsb3lOZXR3b3JrfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxsYXRpdHVkZT4gXCIke2dhdGV3YXkubGF0aXR1ZGV9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGxvbmdpdHVkZT4gXCIke2dhdGV3YXkubG9uZ2l0dWRlfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxhY2Nlc3NUb2tlbj4gXCIke2dhdGV3YXkuYWNjZXNzVG9rZW59XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHVzZXJuYW1lPiBcIiR7Z2F0ZXdheS51c2VybmFtZX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8cGxhdGZvcm0+IFwiJHtnYXRld2F5LnBsYXRmb3JtfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxjcmVhdGVkdHM+IFwiJHtnYXRld2F5LmNyZWF0ZWR0c31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8dXBkYXRlZHRzPiBcIiR7Z2F0ZXdheS51cGRhdGVkdHN9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnQWRkIEdhdGV3YXkgTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGdhdGV3YXkpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnYWRkIGdhdGV3YXknKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheT4oJ2FkZEdhdGV3YXknKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlR2F0ZXdheShnYXRld2F5VWlkOiBudW1iZXIsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtnYXRld2F5VWlkfT4gKiAqIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBHYXRld2F5IE11dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgJHtnYXRld2F5VWlkfSBkZWxldGVkYCksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgZ2F0ZXdheScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxzdHJpbmc+KCdkZWxldGVHYXRld2F5JykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlBbmRQcm90b2NvbHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICB1aWQgdXVpZFxuICAgICAgICBwcm90b2NvbHM6IGdhdGV3YXlfcHJvdG9jb2wge1xuICAgICAgICAgIHVpZFxuICAgICAgICAgIHV1aWRcbiAgICAgICAgICBjcmVhdGVkXG4gICAgICAgICAgbW9kaWZpZWRcbiAgICAgICAgICBwcm90b2NvbFR5cGVcbiAgICAgICAgICBicm9rZXJVUkxcbiAgICAgICAgICB0b3BpY1xuICAgICAgICAgIGNvbnN1bWVyR3JvdXBJZFxuICAgICAgICAgIGNvbm5lY3Rpb25UaW1lb3V0XG4gICAgICAgICAgc2Vzc2lvblRpbWVvdXRcbiAgICAgICAgICBpbml0aWFsT2Zmc2V0XG4gICAgICAgICAgcmV0cnlCYWNrb2ZmXG4gICAgICAgICAgZmV0Y2hNaW5CeXRlc1xuICAgICAgICAgIGZldGNoTWF4V2FpdFxuICAgICAgICAgIGNvbW1pdEludGVydmFsXG4gICAgICAgICAgaGVhcnRiZWF0SW50ZXJ2YWxcbiAgICAgICAgICBtYXhpbXVtUU9TXG4gICAgICAgICAgdXNlcm5hbWVcbiAgICAgICAgICBwYXNzd29yZFxuICAgICAgICAgIGVuY3J5cHRpb25Nb2RlXG4gICAgICAgICAgY2FDZXJ0aWZpY2F0ZVxuICAgICAgICAgIGNsaWVudENlcnRpZmljYXRlXG4gICAgICAgICAgY2xpZW50S2V5XG4gICAgICAgICAgYXV0aE1vZGVcbiAgICAgICAgICBzZXJ2ZXJDZXJ0aWNhdGVcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnR2V0IEdhdGV3YXkgYW5kIFByb3RvY29scyBxdWVyeSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIEdhdGV3YXknKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheVtdPignZ2V0R2F0ZXdheVdpdGhQcm90b2NvbHMnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhbGwgZ2xvYmFsIHByb3RvY29scyBhbmQgdGhlIHByb3RvY29scyBzY29wZWQgZm9yIHRoZSBnYXRld2F5XG4gICAgICogQHBhcmFtIGdhdGV3YXlOYW1lXG4gICAgICogQGZpbHRlcihndChjcmVhdGVkLCAke2Zyb210c30pIEFORCBsdChjcmVhdGVkLCAke3RvdHN9KSkgKGZpcnN0Oi01MDApXG4gICAgICovXG4gICAgZ2V0UHJvdG9jb2xzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2xbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhwcm90b2NvbCkpIEBmaWx0ZXIoZXEoc2NvcGUsIFwiJHtnYXRld2F5TmFtZX1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICB1dWlkXG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgbW9kaWZpZWRcbiAgICAgICAgcHJvdG9jb2xUeXBlXG4gICAgICAgIGJyb2tlclVSTFxuICAgICAgICB0b3BpY1xuICAgICAgICBjb25zdW1lckdyb3VwSWRcbiAgICAgICAgY29ubmVjdGlvblRpbWVvdXRcbiAgICAgICAgc2Vzc2lvblRpbWVvdXRcbiAgICAgICAgaW5pdGlhbE9mZnNldFxuICAgICAgICByZXRyeUJhY2tvZmZcbiAgICAgICAgZmV0Y2hNaW5CeXRlc1xuICAgICAgICBmZXRjaE1heFdhaXRcbiAgICAgICAgY29tbWl0SW50ZXJ2YWxcbiAgICAgICAgaGVhcnRiZWF0SW50ZXJ2YWxcbiAgICAgICAgbWF4aW11bVFPU1xuICAgICAgICB1c2VybmFtZVxuICAgICAgICBwYXNzd29yZFxuICAgICAgICBlbmNyeXB0aW9uTW9kZVxuICAgICAgICBjYUNlcnRpZmljYXRlXG4gICAgICAgIGNsaWVudENlcnRpZmljYXRlXG4gICAgICAgIGNsaWVudEtleVxuICAgICAgICBhdXRoTW9kZVxuICAgICAgICBzZXJ2ZXJDZXJ0aWNhdGVcbiAgICAgICAgc2NvcGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBQcm90b2NvbFtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBwcm90b2NvbHMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UHJvdG9jb2xbXT4oJ2dldFByb3RvY29scycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkUHJvdG9jb2woZ2F0ZXdheVVpZDogbnVtYmVyLCBwcm90b2NvbDogUHJvdG9jb2wsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2w+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UHJvdG9jb2wgPGRncmFwaC50eXBlPiBcIlByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDx0eXBlPiBcInByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwcm90b2NvbD4gXCJcIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHV1aWQ+IFwiJHtwcm90b2NvbC51dWlkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y3JlYXRlZD4gXCIke3Byb3RvY29sLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxtb2RpZmllZD4gXCIke3Byb3RvY29sLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8cHJvdG9jb2xUeXBlPiBcIiR7cHJvdG9jb2wucHJvdG9jb2xUeXBlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8YnJva2VyVVJMPiBcIiR7cHJvdG9jb2wuYnJva2VyVVJMfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8dG9waWM+IFwiJHtwcm90b2NvbC50b3BpY31cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNvbnN1bWVyR3JvdXBJZD4gXCIke3Byb3RvY29sLmNvbnN1bWVyR3JvdXBJZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNvbm5lY3Rpb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuY29ubmVjdGlvblRpbWVvdXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxzZXNzaW9uVGltZW91dD4gXCIke3Byb3RvY29sLnNlc3Npb25UaW1lb3V0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8aW5pdGlhbE9mZnNldD4gXCIke3Byb3RvY29sLmluaXRpYWxPZmZzZXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxyZXRyeUJhY2tvZmY+IFwiJHtwcm90b2NvbC5yZXRyeUJhY2tPZmZ9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxmZXRjaE1pbkJ5dGVzPiBcIiR7cHJvdG9jb2wuZmV0Y2hNaW5CeXRlc31cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGZldGNoTWF4V2FpdD4gXCIke3Byb3RvY29sLmZldGNoTWF4V2FpdH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNvbW1pdEludGVydmFsPiBcIiR7cHJvdG9jb2wuY29tbWl0SW50ZXJ2YWx9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxoZWFydGJlYXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmhlYXJ0YmVhdEludGVydmFsfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8bWF4aW11bVFPUz4gXCIke3Byb3RvY29sLm1heGltdW1RT1N9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDx1c2VybmFtZT4gXCIke3Byb3RvY29sLnVzZXJuYW1lfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8cGFzc3dvcmQ+IFwiJHtwcm90b2NvbC5wYXNzd29yZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGVuY3J5cHRpb25Nb2RlPiBcIiR7cHJvdG9jb2wuZW5jcnlwdGlvbk1vZGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjYUNlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2FDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNsaWVudENlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2xpZW50Q2VydGlmaWNhdGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjbGllbnRLZXk+IFwiJHtwcm90b2NvbC5jbGllbnRLZXl9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxhdXRoTW9kZT4gXCIke3Byb3RvY29sLmF1dGhNb2RlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8c2VydmVyQ2VydGljYXRlPiBcIiR7cHJvdG9jb2wuc2VydmVyQ2VydGlmaWNhdGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxzY29wZT4gXCIke3Byb3RvY29sLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwcm90b2NvbCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdhZGQgcHJvdG9jb2xzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFByb3RvY29sPignYWRkUHJvdG9jb2xzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZVByb3RvY29sKHByb3RvY29sOiBQcm90b2NvbCwgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxQcm90b2NvbD4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHV1aWQ+IFwiJHtwcm90b2NvbC51dWlkfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPG1vZGlmaWVkPiBcIiR7cHJvdG9jb2wubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8cHJvdG9jb2xUeXBlPiBcIiR7cHJvdG9jb2wucHJvdG9jb2xUeXBlfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGJyb2tlclVSTD4gXCIke3Byb3RvY29sLmJyb2tlclVSTH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDx0b3BpYz4gXCIke3Byb3RvY29sLnRvcGljfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGNvbnN1bWVyR3JvdXBJZD4gXCIke3Byb3RvY29sLmNvbnN1bWVyR3JvdXBJZH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxjb25uZWN0aW9uVGltZW91dD4gXCIke3Byb3RvY29sLmNvbm5lY3Rpb25UaW1lb3V0fVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHNlc3Npb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuc2Vzc2lvblRpbWVvdXR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8aW5pdGlhbE9mZnNldD4gXCIke3Byb3RvY29sLmluaXRpYWxPZmZzZXR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8cmV0cnlCYWNrb2ZmPiBcIiR7cHJvdG9jb2wucmV0cnlCYWNrT2ZmfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGZldGNoTWluQnl0ZXM+IFwiJHtwcm90b2NvbC5mZXRjaE1pbkJ5dGVzfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGZldGNoTWF4V2FpdD4gXCIke3Byb3RvY29sLmZldGNoTWF4V2FpdH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxjb21taXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmNvbW1pdEludGVydmFsfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGhlYXJ0YmVhdEludGVydmFsPiBcIiR7cHJvdG9jb2wuaGVhcnRiZWF0SW50ZXJ2YWx9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8bWF4aW11bVFPUz4gXCIke3Byb3RvY29sLm1heGltdW1RT1N9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8dXNlcm5hbWU+IFwiJHtwcm90b2NvbC51c2VybmFtZX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxwYXNzd29yZD4gXCIke3Byb3RvY29sLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGVuY3J5cHRpb25Nb2RlPiBcIiR7cHJvdG9jb2wuZW5jcnlwdGlvbk1vZGV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8Y2FDZXJ0aWZpY2F0ZT4gXCIke3Byb3RvY29sLmNhQ2VydGlmaWNhdGV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8Y2xpZW50Q2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jbGllbnRDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxjbGllbnRLZXk+IFwiJHtwcm90b2NvbC5jbGllbnRLZXl9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8YXV0aE1vZGU+IFwiJHtwcm90b2NvbC5hdXRoTW9kZX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxzZXJ2ZXJDZXJ0aWNhdGU+IFwiJHtwcm90b2NvbC5zZXJ2ZXJDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxzY29wZT4gXCIke3Byb3RvY29sLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwcm90b2NvbCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCd1cGRhdGVkIHByb3RvY29scycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQcm90b2NvbD4oJ3VwZGF0ZVByb3RvY29scycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVQcm90b2NvbChnYXRld2F5VWlkOiBudW1iZXIsIHByb3RvY29sVWlkOiBudW1iZXIsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtwcm90b2NvbFVpZH0+ICogKiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdEZWxldGUgUHJvdG9jb2wgTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGAke3Byb3RvY29sVWlkfSBkZWxldGVkYCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdkZWxldGVkIHByb3RvY29sJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPHN0cmluZz4oJ2RlbGV0ZVByb3RvY29sJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldERhdGFTdG9yZXMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxEYXRhU3RvcmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhkYXRhU3RvcmUpKSBAZmlsdGVyKGVxKHNjb3BlLCBcIiR7Z2F0ZXdheU5hbWV9XCIpIE9SIGVxKHNjb3BlLCBcIkdMT0JBTFwiKSkge1xuICAgICAgICB1aWRcbiAgICAgICAgdXVpZFxuICAgICAgICBjcmVhdGVkXG4gICAgICAgIG1vZGlmaWVkXG4gICAgICAgIGRhdGFTdG9yZVR5cGVcbiAgICAgICAgaG9zdFxuICAgICAgICBwb3J0XG4gICAgICAgIGRhdGFiYXNlTmFtZVxuICAgICAgICB1c2VyXG4gICAgICAgIHBhc3N3b3JkXG4gICAgICAgIGFjY291bnROYW1lXG4gICAgICAgIHdhcmVob3VzZVxuICAgICAgICBkYXRhYmFzZVxuICAgICAgICBzY2hlbWFcbiAgICAgICAgYXV0aFR5cGVcbiAgICAgICAgdXNlcm5hbWVcbiAgICAgICAgY2xpZW50SWRcbiAgICAgICAgY2xpZW50U2VjcmV0XG4gICAgICAgIGF1dGhvcml6YXRpb25Db2RlXG4gICAgICAgIHJlZGlyZWN0VVJJXG4gICAgICAgIGxvZ2luVGltZW91dFxuICAgICAgICB1cmxcbiAgICAgICAgc2NvcGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBEYXRhU3RvcmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgZGF0YVN0b3JlcycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxEYXRhU3RvcmVbXT4oJ2dldERhdGFTdG9yZXMnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZERhdGFTdG9yZShnYXRld2F5VWlkOiBudW1iZXIsIGRhdGFTdG9yZTogRGF0YVN0b3JlLCBhY2NvdW50OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERhdGFTdG9yZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpEYXRhU3RvcmUgPGRncmFwaC50eXBlPiBcIkRhdGFTdG9yZVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHR5cGU+IFwiZGF0YVN0b3JlXCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YVN0b3JlPiBcIlwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHV1aWQ+IFwiJHtkYXRhU3RvcmUudXVpZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjcmVhdGVkPiBcIiR7ZGF0YVN0b3JlLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8bW9kaWZpZWQ+IFwiJHtkYXRhU3RvcmUubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YVN0b3JlVHlwZT4gXCIke2RhdGFTdG9yZS5kYXRhU3RvcmVUeXBlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGhvc3Q+IFwiJHtkYXRhU3RvcmUuaG9zdH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxwb3J0PiBcIiR7ZGF0YVN0b3JlLnBvcnR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YWJhc2VOYW1lPiBcIiR7ZGF0YVN0b3JlLmRhdGFiYXNlTmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1c2VyPiBcIiR7ZGF0YVN0b3JlLnVzZXJ9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8cGFzc3dvcmQ+IFwiJHtkYXRhU3RvcmUucGFzc3dvcmR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8YWNjb3VudE5hbWU+IFwiJHtkYXRhU3RvcmUuYWNjb3VudE5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8d2FyZWhvdXNlPiBcIiR7ZGF0YVN0b3JlLndhcmVob3VzZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxkYXRhYmFzZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8c2NoZW1hPiBcIiR7ZGF0YVN0b3JlLnNjaGVtYX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhdXRoVHlwZT4gXCIke2RhdGFTdG9yZS5hdXRoVHlwZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1c2VybmFtZT4gXCIke2RhdGFTdG9yZS51c2VybmFtZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjbGllbnRJZD4gXCIke2RhdGFTdG9yZS5jbGllbnRJZH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxjbGllbnRTZWNyZXQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50U2VjcmV0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGF1dGhvcml6YXRpb25Db2RlPiBcIiR7ZGF0YVN0b3JlLmF1dGhvcml6YXRpb25Db2RlfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHJlZGlyZWN0VVJJPiBcIiR7ZGF0YVN0b3JlLnJlZGlyZWN0VVJJfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGxvZ2luVGltZW91dD4gXCIke2RhdGFTdG9yZS5sb2dpblRpbWVvdXR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXJsPiBcIiR7ZGF0YVN0b3JlLnVybH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxzY29wZT4gXCIke2RhdGFTdG9yZS5zY29wZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gZGF0YVN0b3JlKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2FkZCBkYXRhU3RvcmVzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPERhdGFTdG9yZT4oJ2FkZERhdGFTdG9yZXMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlRGF0YVN0b3JlKGRhdGFTdG9yZTogRGF0YVN0b3JlLCBhY2NvdW50OiBzdHJpbmcpOiBPYnNlcnZhYmxlPERhdGFTdG9yZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDx1dWlkPiBcIiR7ZGF0YVN0b3JlLnV1aWR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPG1vZGlmaWVkPiBcIiR7ZGF0YVN0b3JlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxkYXRhU3RvcmVUeXBlPiBcIiR7ZGF0YVN0b3JlLmRhdGFTdG9yZVR5cGV9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGhvc3Q+IFwiJHtkYXRhU3RvcmUuaG9zdH1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8cG9ydD4gXCIke2RhdGFTdG9yZS5wb3J0fVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxkYXRhYmFzZU5hbWU+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDx1c2VyPiBcIiR7ZGF0YVN0b3JlLnVzZXJ9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHBhc3N3b3JkPiBcIiR7ZGF0YVN0b3JlLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxhY2NvdW50TmFtZT4gXCIke2RhdGFTdG9yZS5hY2NvdW50TmFtZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8d2FyZWhvdXNlPiBcIiR7ZGF0YVN0b3JlLndhcmVob3VzZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8ZGF0YWJhc2U+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxzY2hlbWE+IFwiJHtkYXRhU3RvcmUuc2NoZW1hfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxhdXRoVHlwZT4gXCIke2RhdGFTdG9yZS5hdXRoVHlwZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8dXNlcm5hbWU+IFwiJHtkYXRhU3RvcmUudXNlcm5hbWV9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGNsaWVudElkPiBcIiR7ZGF0YVN0b3JlLmNsaWVudElkfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxjbGllbnRTZWNyZXQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50U2VjcmV0fVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxhdXRob3JpemF0aW9uQ29kZT4gXCIke2RhdGFTdG9yZS5hdXRob3JpemF0aW9uQ29kZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8cmVkaXJlY3RVUkk+IFwiJHtkYXRhU3RvcmUucmVkaXJlY3RVUkl9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGxvZ2luVGltZW91dD4gXCIke2RhdGFTdG9yZS5sb2dpblRpbWVvdXR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHVybD4gXCIke2RhdGFTdG9yZS51cmx9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHNjb3BlPiBcIiR7ZGF0YVN0b3JlLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBkYXRhU3RvcmUpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygndXBkYXRlZCBkYXRhU3RvcmVzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPERhdGFTdG9yZT4oJ3VwZGF0ZURhdGFTdG9yZXMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlRGF0YVN0b3JlKGdhdGV3YXlVaWQ6IG51bWJlciwgZGF0YVN0b3JlVWlkOiBudW1iZXIsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtkYXRhU3RvcmVVaWR9PiAqICogLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnRGVsZXRlIERhdGFTdG9yZSBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYCR7ZGF0YVN0b3JlVWlkfSBkZWxldGVkYCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdkZWxldGVkIGRhdGFTdG9yZScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxzdHJpbmc+KCdkZWxldGVEYXRhU3RvcmUnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheUFuZE1vZGVscyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhnYXRld2F5KSkgQGZpbHRlcihlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHVpZCB1dWlkXG4gICAgICAgIG1vZGVsczogZ2F0ZXdheV9tb2RlbCB7XG4gICAgICAgICAgdWlkXG4gICAgICAgICAgdXVpZFxuICAgICAgICAgIGNyZWF0ZWRcbiAgICAgICAgICBtb2RpZmllZFxuICAgICAgICAgIG5hbWVcbiAgICAgICAgICBkZXNjcmlwdGlvblxuICAgICAgICAgIGlucHV0VHlwZVxuICAgICAgICAgIHVybFxuICAgICAgICAgIHNjb3BlXG4gICAgICAgICAgaW5wdXRUZW1wbGF0ZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdHZXQgR2F0ZXdheSBhbmQgUHJvdG9jb2xzIHF1ZXJ5IHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgR2F0ZXdheScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5W10+KCdnZXRHYXRld2F5V2l0aE1vZGVscycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0TW9kZWxzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWxbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhtb2RlbCkpIEBmaWx0ZXIoZXEoc2NvcGUsIFwiJHtnYXRld2F5TmFtZX1cIikgT1IgZXEoc2NvcGUsIFwiR0xPQkFMXCIpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICB1dWlkXG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgbW9kaWZpZWRcbiAgICAgICAgbmFtZVxuICAgICAgICBkZXNjcmlwdGlvblxuICAgICAgICBpbnB1dFR5cGVcbiAgICAgICAgdXJsXG4gICAgICAgIHNjb3BlXG4gICAgICAgIGlucHV0VGVtcGxhdGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBNb2RlbFtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBtb2RlbHMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8TW9kZWxbXT4oJ2dldE1vZGVscycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkTW9kZWwoZ2F0ZXdheVVpZDogbnVtYmVyLCBtb2RlbDogTW9kZWwsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWw+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86TW9kZWwgPGRncmFwaC50eXBlPiBcIk1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDx0eXBlPiBcIm1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDxtb2RlbD4gXCJcIiAuXG4gICAgICAgIF86TW9kZWwgPHV1aWQ+IFwiJHttb2RlbC51dWlkfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8Y3JlYXRlZD4gXCIke21vZGVsLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOk1vZGVsIDxtb2RpZmllZD4gXCIke21vZGVsLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8bmFtZT4gXCIke21vZGVsLm5hbWV9XCIgLlxuICAgICAgICBfOk1vZGVsIDxkZXNjcmlwdGlvbj4gXCIke21vZGVsLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpNb2RlbCA8aW5wdXRUeXBlPiBcIiR7bW9kZWwuaW5wdXRUeXBlfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8dXJsPiBcIiR7bW9kZWwudXJsfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8c2NvcGU+IFwiJHttb2RlbC5zY29wZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPGlucHV0VGVtcGxhdGU+IFwiJHttb2RlbC5pbnB1dFRlbXBsYXRlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBtb2RlbCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdhZGQgbW9kZWxzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE1vZGVsPignYWRkTW9kZWxzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZU1vZGVsKG1vZGVsOiBNb2RlbCwgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbD4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPHV1aWQ+IFwiJHttb2RlbC51dWlkfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPG1vZGlmaWVkPiBcIiR7bW9kZWwubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8bmFtZT4gXCIke21vZGVsLm5hbWV9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8ZGVzY3JpcHRpb24+IFwiJHttb2RlbC5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIDwke21vZGVsLnVpZH0+IDxpbnB1dFR5cGU+IFwiJHttb2RlbC5pbnB1dFR5cGV9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8dXJsPiBcIiR7bW9kZWwudXJsfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPHNjb3BlPiBcIiR7bW9kZWwuc2NvcGV9XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8aW5wdXRUZW1wbGF0ZT4gXCIke21vZGVsLmlucHV0VGVtcGxhdGV9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IG1vZGVsKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ3VwZGF0ZWQgbW9kZWxzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE1vZGVsPigndXBkYXRlTW9kZWxzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGRlbGV0ZU1vZGVsKGdhdGV3YXlVaWQ6IG51bWJlciwgbW9kZWxVaWQ6IG51bWJlciwgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIGRlbGV0ZSB7XG4gICAgICAgIDwke21vZGVsVWlkfT4gKiAqIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBNb2RlbCBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYCR7bW9kZWxVaWR9IGRlbGV0ZWRgKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgcHJvdG9jb2wnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlTW9kZWwnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheUFuZFBpcGVsaW5lcyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3Byb3RvY29sID1cbiAgICAgICAgICAgICdwcm90b2NvbDogcGlwZWxpbmVfcHJvdG9jb2wge3VpZCB1dWlkIGJyb2tlclVSTCB0b3BpYyBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGUgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5IGF1dGhNb2RlIHNlcnZlckNlcnRpY2F0ZSBjb25zdW1lckdyb3VwSWQgY29ubmVjdGlvblRpbWVvdXQgc2Vzc2lvblRpbWVvdXQgcmV0cnlCYWNrb2ZmIGNvbW1pdEludGVydmFsIGluaXRpYWxPZmZzZXQgZmV0Y2hNaW5CeXRlcyBmZXRjaE1heFdhaXQgaGVhcnRiZWF0SW50ZXJ2YWx9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZGF0YXN0b3JlID1cbiAgICAgICAgICAgICdkYXRhU3RvcmU6IHBpcGVsaW5lX2RhdGFzdG9yZSB7dWlkIHV1aWQgaG9zdCBwb3J0IGRhdGFiYXNlTmFtZSB1c2VyIHBhc3N3b3JkIGFjY291bnROYW1lIHdhcmVob3VzZSBkYXRhYmFzZSBzY2hlbWEgYXV0aFR5cGUgdXNlcm5hbWUgY2xpZW50SWQgY2xpZW50U2VjcmV0IGF1dGhvcml6YXRpb25Db2RlIHJlZGlyZWN0VVJJIGxvZ2luVGltZW91dCB1cmx9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZmlsdGVyID0gJ2ZpbHRlcjogcGlwZWxpbmVfZmlsdGVyIHt1aWQgZGV2aWNlTmFtZXN9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfc3RyZWFtaW5nID1cbiAgICAgICAgICAgICdzdHJlYW1pbmc6IHBpcGVsaW5lX3N0cmVhbWluZyB7dWlkIGRldmljZU5hbWUgaW5zdHJ1bWVudE5hbWUgZnVuY3Rpb24gd2luZG93VHlwZSB3aW5kb3dTaXplfSc7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICB1aWQgdXVpZCBhY2Nlc3NUb2tlbiB1c2VybmFtZSBwbGF0Zm9ybSBhZGRyZXNzIHJvdXRlciByb3V0ZXJQb3J0IGRlcGxveU5ldHdvcmsgZGV2aWNlc01ldGFkYXRhXG4gICAgICAgIHBpcGVsaW5lczogZ2F0ZXdheV9waXBlbGluZSB7XG4gICAgICAgICAgdWlkXG4gICAgICAgICAgbmFtZVxuICAgICAgICAgIHV1aWRcbiAgICAgICAgICBwaXBlbGluZVR5cGVcbiAgICAgICAgICBkZXBsb3llclR5cGVcbiAgICAgICAgICBwcm90b2NvbFR5cGVcbiAgICAgICAgICBwcm90b2NvbElkXG4gICAgICAgICAgZGF0YVN0b3JlVHlwZVxuICAgICAgICAgIGRhdGFTdG9yZUlkXG4gICAgICAgICAgY3JlYXRlZFxuICAgICAgICAgIG1vZGlmaWVkXG4gICAgICAgICAgZGVzY3JpcHRpb25cbiAgICAgICAgICBzdGF0dXNcbiAgICAgICAgICBmbG93Q29uZmlndXJhdGlvblxuICAgICAgICAgIGxvZ0xldmVsXG4gICAgICAgICAgc3Vic2NyaXB0aW9uVG9waWNcbiAgICAgICAgICAke3BpcGVsaW5lX3Byb3RvY29sfVxuICAgICAgICAgICR7cGlwZWxpbmVfZGF0YXN0b3JlfVxuICAgICAgICAgICR7cGlwZWxpbmVfZmlsdGVyfVxuICAgICAgICAgICR7cGlwZWxpbmVfc3RyZWFtaW5nfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdHZXQgR2F0ZXdheSBhbmQgUGlwZWxpbmVzIHF1ZXJ5IHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgR2F0ZXdheScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5W10+KCdnZXRHYXRld2F5V2l0aFBpcGVsaW5lcycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UGlwZWxpbmVzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3Byb3RvY29sID1cbiAgICAgICAgICAgICdwcm90b2NvbDogcGlwZWxpbmVfcHJvdG9jb2wge3VpZCBicm9rZXJVUkwgdG9waWMgbWF4aW11bVFPUyB1c2VybmFtZSBwYXNzd29yZCBlbmNyeXB0aW9uTW9kZSBjYUNlcnRpZmljYXRlIGNsaWVudENlcnRpZmljYXRlIGNsaWVudEtleSBhdXRoTW9kZSBzZXJ2ZXJDZXJ0aWNhdGUgY29uc3VtZXJHcm91cElkIGNvbm5lY3Rpb25UaW1lb3V0IHNlc3Npb25UaW1lb3V0IHJldHJ5QmFja29mZiBjb21taXRJbnRlcnZhbCBpbml0aWFsT2Zmc2V0IGZldGNoTWluQnl0ZXMgZmV0Y2hNYXhXYWl0IGhlYXJ0YmVhdEludGVydmFsfSc7XG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX2RhdGFzdG9yZSA9XG4gICAgICAgICAgICAnZGF0YXN0b3JlOiBwaXBlbGluZV9kYXRhc3RvcmUge3VpZCBob3N0IHBvcnQgZGF0YWJhc2VOYW1lIHVzZXIgcGFzc3dvcmQgYWNjb3VudE5hbWUgd2FyZWhvdXNlIGRhdGFiYXNlIHNjaGVtYSBhdXRoVHlwZSB1c2VybmFtZSBjbGllbnRJZCBjbGllbnRTZWNyZXQgYXV0aG9yaXphdGlvbkNvZGUgcmVkaXJlY3RVUkkgbG9naW5UaW1lb3V0IHVybH0nO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9maWx0ZXIgPSAnZmlsdGVyOiBwaXBlbGluZV9maWx0ZXIge3VpZCBkZXZpY2VOYW1lc30nO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9zdHJlYW1pbmcgPVxuICAgICAgICAgICAgJ3N0cmVhbWluZzogcGlwZWxpbmVfc3RyZWFtaW5nIHt1aWQgZGV2aWNlTmFtZSBpbnN0cnVtZW50TmFtZSBmdW5jdGlvbiB3aW5kb3dUeXBlIHdpbmRvd1NpemV9JztcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgcGlwZWxpbmVzIGFzIGdhdGV3YXlfcGlwZWxpbmUge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICBuYW1lXG4gICAgICAgIHV1aWRcbiAgICAgICAgcGlwZWxpbmVUeXBlXG4gICAgICAgIGRlcGxveWVyVHlwZVxuICAgICAgICBwcm90b2NvbFR5cGVcbiAgICAgICAgcHJvdG9jb2xJZFxuICAgICAgICBkYXRhU3RvcmVUeXBlXG4gICAgICAgIGRhdGFTdG9yZUlkXG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgbW9kaWZpZWRcbiAgICAgICAgZGVzY3JpcHRpb25cbiAgICAgICAgc3RhdHVzXG4gICAgICAgIGZsb3dDb25maWd1cmF0aW9uXG4gICAgICAgIGxvZ0xldmVsXG4gICAgICAgIHN1YnNjcmlwdGlvblRvcGljXG4gICAgICAgICR7cGlwZWxpbmVfcHJvdG9jb2x9XG4gICAgICAgICR7cGlwZWxpbmVfZGF0YXN0b3JlfVxuICAgICAgICAke3BpcGVsaW5lX2ZpbHRlcn1cbiAgICAgICAgJHtwaXBlbGluZV9zdHJlYW1pbmd9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUGlwZWxpbmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcGlwZWxpbmVzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFBpcGVsaW5lW10+KCdnZXRQaXBlbGluZXMnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZFBpcGVsaW5lKFxuICAgICAgICBnYXRld2F5VWlkOiBudW1iZXIsXG4gICAgICAgIHBpcGVsaW5lOiBQaXBlbGluZSxcbiAgICAgICAgYWNjb3VudDogc3RyaW5nLFxuICAgICk6IE9ic2VydmFibGU8UGlwZWxpbmU+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG5cbiAgICAgICAgbGV0IHF1ZXJ5ID0gJyc7XG5cbiAgICAgICAgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpQaXBlbGluZSA8ZGdyYXBoLnR5cGU+IFwiUGlwZWxpbmVcIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPG5hbWU+IFwiJHtwaXBlbGluZS5uYW1lfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8dXVpZD4gXCIke3BpcGVsaW5lLm5hbWV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDx0eXBlPiBcInBpcGVsaW5lXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxwaXBlbGluZT4gXCJcIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHBpcGVsaW5lVHlwZT4gXCIke3BpcGVsaW5lLnBpcGVsaW5lVHlwZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGRlcGxveWVyVHlwZT4gXCIke3BpcGVsaW5lLmRlcGxveWVyVHlwZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGNyZWF0ZWQ+IFwiJHtwaXBlbGluZS5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8bW9kaWZpZWQ+IFwiJHtwaXBlbGluZS5tb2RpZmllZH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGRlc2NyaXB0aW9uPiBcIiR7cGlwZWxpbmUuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxzdGF0dXM+IFwiJHtwaXBlbGluZS5zdGF0dXN9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxmbG93Q29uZmlndXJhdGlvbj4gXCIke3BpcGVsaW5lLmZsb3dDb25maWd1cmF0aW9ufVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8bG9nTGV2ZWw+IFwiJHtwaXBlbGluZS5sb2dMZXZlbH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHN1YnNjcmlwdGlvblRvcGljPiBcIiR7cGlwZWxpbmUuc3Vic2NyaXB0aW9uVG9waWN9XCIgLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfcGlwZWxpbmU+IF86UGlwZWxpbmUgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IHBpcGVsaW5lKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2FkZCBwaXBlbGluZScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQaXBlbGluZT4oJ2FkZFBpcGVsaW5lcycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVQaXBlbGluZShwaXBlbGluZTogUGlwZWxpbmUsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmU+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIDwke3BpcGVsaW5lLnVpZH0+IDxkZXNjcmlwdGlvbj4gXCIke3BpcGVsaW5lLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPHN0YXR1cz4gXCIke3BpcGVsaW5lLnN0YXR1c31cIiAuXG4gICAgICAgIDwke3BpcGVsaW5lLnVpZH0+IDxtb2RpZmllZD4gXCIke3BpcGVsaW5lLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPGZsb3dDb25maWd1cmF0aW9uPiBcIiR7cGlwZWxpbmUuZmxvd0NvbmZpZ3VyYXRpb259XCIgLlxuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiA8bG9nTGV2ZWw+IFwiJHtwaXBlbGluZS5sb2dMZXZlbH1cIiAuXG4gICAgICAgIDwke3BpcGVsaW5lLnVpZH0+IDxzdWJzY3JpcHRpb25Ub3BpYz4gXCIke3BpcGVsaW5lLnN1YnNjcmlwdGlvblRvcGljfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwaXBlbGluZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCd1cGRhdGVkIHBpcGVsaW5lcycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQaXBlbGluZT4oJ3VwZGF0ZVBpcGVsaW5lJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGRlbGV0ZVBpcGVsaW5lKGdhdGV3YXlVaWQ6IG51bWJlciwgcGlwZWxpbmU6IFBpcGVsaW5lLCBhY2NvdW50OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiAqICogLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfcGlwZWxpbmU+IDwke3BpcGVsaW5lLnVpZH0+IC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBQaXBlbGluZSBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYHBpcGVsaW5lIGRlbGV0ZWRgKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgcGlwZWxpbmUnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlUGlwZWxpbmUnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGlkcyBvZiBhbGwgdGhlIHBpcGVsaW5lcyBhc3NvY2lhdGVkIHdpdGggdGhlIHNwZWNpZmllZCBwcm90b2NvbFxuICAgICAqIEBwYXJhbSBwcm90b2NvbFVpZCAtIHRoZSB1aWQgb2YgdGhlIHByb3RvY29sXG4gICAgICovXG4gICAgZ2V0UGlwZWxpbmVJZHNGcm9tUHJvdG9jb2xVaWQocHJvdG9jb2xVaWQ6IG51bWJlciwgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IHVpZCgke3Byb3RvY29sVWlkfSkpIHtcbiAgICAgICAgcGlwZWxpbmVzIGFzIH5waXBlbGluZV9wcm90b2NvbCB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHBpcGVsaW5lcykpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIHV1aWRcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBQaXBlbGluZVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBwaXBlbGluZSBpZHMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UGlwZWxpbmVbXT4oJ2dldFBpcGVsaW5lSWRzRnJvbVByb3RvY29sVWlkJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgaWRzIG9mIGFsbCB0aGUgcGlwZWxpbmVzIGFzc29jaWF0ZWQgd2l0aCB0aGUgc3BlY2lmaWVkIGRhdGEgc3RvcmVcbiAgICAgKiBAcGFyYW0gZGF0YVN0b3JlVWlkIC0gdGhlIHVpZCBvZiB0aGUgZGF0YSBzdG9yZVxuICAgICAqL1xuICAgIGdldFBpcGVsaW5lSWRzRnJvbURhdGFTdG9yZVVpZChkYXRhU3RvcmVVaWQ6IG51bWJlciwgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IHVpZCgke2RhdGFTdG9yZVVpZH0pKSB7XG4gICAgICAgIHBpcGVsaW5lcyBhcyB+cGlwZWxpbmVfZGF0YXN0b3JlIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocGlwZWxpbmVzKSkge1xuICAgICAgICB1aWRcbiAgICAgICAgdXVpZFxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFBpcGVsaW5lW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHBpcGVsaW5lIGlkcycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQaXBlbGluZVtdPignZ2V0UGlwZWxpbmVJZHNGcm9tRGF0YVN0b3JlVWlkJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRNb2RlbENvbmZpZ3MoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbENvbmZpZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICBtb2RlbENvbmZpZ3MgYXMgZ2F0ZXdheV9tb2RlbGNvbmZpZyB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKG1vZGVsQ29uZmlncykpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIG5hbWVcbiAgICAgICAgdXVpZFxuICAgICAgICBkZXNjcmlwdGlvblxuICAgICAgICBkZXZpY2VcbiAgICAgICAgcmVzb3VyY2VcbiAgICAgICAgbW9kZWxcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICBtb2RpZmllZFxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdnZXRNb2RlbENvbmZpZ3Mgc2VydmljZSBxdWVyeTogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIE1vZGVsQ29uZmlnW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIG1vZGVsQ29uZmlncycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbENvbmZpZ1tdPignZ2V0TW9kZWxDb25maWdzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRNb2RlbENvbmZpZyhnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsQ29uZmlnOiBNb2RlbENvbmZpZywgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbENvbmZpZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpNb2RlbENvbmZpZyA8ZGdyYXBoLnR5cGU+IFwiTW9kZWxDb25maWdcIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPG5hbWU+IFwiJHttb2RlbENvbmZpZy5uYW1lfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8dXVpZD4gXCIke21vZGVsQ29uZmlnLm5hbWV9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDx0eXBlPiBcIm1vZGVsQ29uZmlnXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxtb2RlbENvbmZpZz4gXCJcIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWxDb25maWcuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxkZXZpY2U+IFwiJHttb2RlbENvbmZpZy5kZXZpY2V9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxyZXNvdXJjZT4gXCIke21vZGVsQ29uZmlnLnJlc291cmNlfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8bW9kZWw+IFwiJHttb2RlbENvbmZpZy5tb2RlbH1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPGNyZWF0ZWQ+IFwiJHttb2RlbENvbmZpZy5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8bW9kaWZpZWQ+IFwiJHttb2RlbENvbmZpZy5tb2RpZmllZH1cIiAuXG4gICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9tb2RlbGNvbmZpZz4gXzpNb2RlbENvbmZpZyAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gbW9kZWxDb25maWcpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnYWRkIG1vZGVsQ29uZmlnJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE1vZGVsQ29uZmlnPignYWRkTW9kZWxDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlTW9kZWxDb25maWcobW9kZWxDb25maWc6IE1vZGVsQ29uZmlnLCBhY2NvdW50OiBzdHJpbmcpOiBPYnNlcnZhYmxlPE1vZGVsQ29uZmlnPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICA8JHttb2RlbENvbmZpZy51aWR9PiA8bmFtZT4gXCIke21vZGVsQ29uZmlnLm5hbWV9XCIgLlxuICAgICAgICA8JHttb2RlbENvbmZpZy51aWR9PiA8dXVpZD4gXCIke21vZGVsQ29uZmlnLnV1aWR9XCIgLlxuICAgICAgICA8JHttb2RlbENvbmZpZy51aWR9PiA8ZGVzY3JpcHRpb24+IFwiJHttb2RlbENvbmZpZy5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDxjb25kRGV2aWNlPiBcIiR7bW9kZWxDb25maWcuZGV2aWNlfVwiIC5cbiAgICAgICAgPCR7bW9kZWxDb25maWcudWlkfT4gPGNvbmRSZXNvdXJjZT4gXCIke21vZGVsQ29uZmlnLnJlc291cmNlfVwiIC5cbiAgICAgICAgPCR7bW9kZWxDb25maWcudWlkfT4gPG1vZGVsPiBcIiR7bW9kZWxDb25maWcubW9kZWx9XCIgLlxuICAgICAgICA8JHttb2RlbENvbmZpZy51aWR9PiA8bW9kaWZpZWQ+IFwiJHttb2RlbENvbmZpZy5tb2RpZmllZH1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gbW9kZWxDb25maWcpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygndXBkYXRlZCBtb2RlbENvbmZpZycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbENvbmZpZz4oJ3VwZGF0ZU1vZGVsQ29uZmlnJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGRlbGV0ZU1vZGVsQ29uZmlnKGdhdGV3YXlVaWQ6IG51bWJlciwgbW9kZWxDb25maWdVaWQ6IG51bWJlciwgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIGRlbGV0ZSB7XG4gICAgICAgIDwke21vZGVsQ29uZmlnVWlkfT4gKiAqIC5cbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X21vZGVsY29uZmlnPiA8JHttb2RlbENvbmZpZ1VpZH0+IC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBNb2RlbENvbmZpZyBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYCR7bW9kZWxDb25maWdVaWR9IGRlbGV0ZWRgKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgbW9kZWxDb25maWcnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlTW9kZWxDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0RmlsdGVyc0NvbmZpZyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlGaWx0ZXJzQ29uZmlnW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhnYXRld2F5KSkgQGZpbHRlcihlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIGZpbHRlcnNDb25maWcgYXMgZ2F0ZXdheV9maWx0ZXIge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChmaWx0ZXJzQ29uZmlnKSkge1xuICAgICAgICB1aWRcbiAgICAgICAgZGV2aWNlTmFtZXNcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZygnZ2V0RmlsdGVyc0NvbmZpZyBzZXJ2aWNlIHF1ZXJ5OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheUZpbHRlcnNDb25maWdbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgZmlsdGVyc0NvbmZpZycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5RmlsdGVyc0NvbmZpZ1tdPignZ2V0RmlsdGVyc0NvbmZpZ3MnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZEZpbHRlcnNDb25maWcoXG4gICAgICAgIGdhdGV3YXlVaWQ6IG51bWJlcixcbiAgICAgICAgZmlsdGVyc0NvbmZpZzogR2F0ZXdheUZpbHRlcnNDb25maWcsXG4gICAgICAgIGFjY291bnQ6IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPEdhdGV3YXlGaWx0ZXJzQ29uZmlnPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86RmlsdGVyIDxkZ3JhcGgudHlwZT4gXCJmaWx0ZXJcIiAuXG4gICAgICAgIF86RmlsdGVyIDx0eXBlPiBcImZpbHRlclwiIC5cbiAgICAgICAgXzpGaWx0ZXIgPGZpbHRlcj4gXCJcIiAuXG4gICAgICAgIF86RmlsdGVyIDxkZXZpY2VOYW1lcz4gXCIke2ZpbHRlcnNDb25maWcuZGV2aWNlTmFtZXN9XCIgLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfZmlsdGVyPiBfOkZpbHRlciAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gZmlsdGVyc0NvbmZpZykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdhZGQgZmlsdGVyc0NvbmZpZycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5RmlsdGVyc0NvbmZpZz4oJ2FkZEZpbHRlcnNDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlRmlsdGVyc0NvbmZpZyhmaWx0ZXJzQ29uZmlnOiBHYXRld2F5RmlsdGVyc0NvbmZpZywgYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5RmlsdGVyc0NvbmZpZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7ZmlsdGVyc0NvbmZpZy51aWR9PiA8ZGV2aWNlTmFtZXM+IFwiJHtmaWx0ZXJzQ29uZmlnLmRldmljZU5hbWVzfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBmaWx0ZXJzQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ3VwZGF0ZWQgZmlsdGVyc0NvbmZpZycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5RmlsdGVyc0NvbmZpZz4oJ3VwZGF0ZUZpbHRlcnNDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3MoZGV2aWNlTmFtZTogc3RyaW5nLCBpbnN0cnVtZW50TmFtZTogc3RyaW5nLCBudW1SZWFkaW5nczogbnVtYmVyLCBhY2NvdW50OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRTUmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgLy8gcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAY2FzY2FkZSB7dmFsdWUgY3JlYXRlZCB+cmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge35kZXZpY2VfcmVzb3VyY2UgQGZpbHRlciAoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XCIpKSB7fX19fWAsIGh0dHBPcHRpb25zKVxuICAgICAgICAvLyByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIGB7cmVzcChmdW5jOiBoYXMocmVhZGluZykpIEBjYXNjYWRlIHt2YWx1ZSBjcmVhdGVkIH5yZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7IH19fWAsIGh0dHBPcHRpb25zKVxuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIChmaXJzdDotJHtudW1SZWFkaW5nc30pIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocmVhZGluZ3MpLCBvcmRlcmFzYzpjcmVhdGVkKSB7XG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgdmFsdWVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZygnZ2V0UmVhZGluZ3MgcXVlcnkgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgVFNSZWFkaW5nW10pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gY29uc29sZS5sb2coJ1Jlc3BvbnNlIGZyb20gZ2V0UmVhZGluZ3M6ICcsIHJlc3BvbnNlKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcmVhZGluZ3MnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8VFNSZWFkaW5nW10+KCdnZXRSZWFkaW5ncycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3NBdChkZXZpY2VOYW1lOiBzdHJpbmcsIGluc3RydW1lbnROYW1lOiBzdHJpbmcsIHRzOiBudW1iZXIsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8VFNSZWFkaW5nW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKHJlc291cmNlKSkgQGZpbHRlcihlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGVxKGNyZWF0ZWQsICR7dHN9KSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdnZXRSZWFkaW5nc0F0IHF1ZXJ5IHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIC8vIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgYHtyZXNwKGZ1bmM6IGhhcyhyZWFkaW5nKSkgQGZpbHRlcihndChjcmVhdGVkLCAke2Zyb210c30pKSBAY2FzY2FkZSB7dmFsdWUgY3JlYXRlZCB+cmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkgeyB9fX1gLCBodHRwT3B0aW9ucylcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgVFNSZWFkaW5nW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHJlYWRpbmdzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFRTUmVhZGluZ1tdPignZ2V0UmVhZGluZ3NBdCcsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3NTdGFydGluZ0F0KFxuICAgICAgICBkZXZpY2VOYW1lOiBzdHJpbmcsXG4gICAgICAgIGluc3RydW1lbnROYW1lOiBzdHJpbmcsXG4gICAgICAgIGZyb210czogbnVtYmVyLFxuICAgICAgICBhY2NvdW50OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIC8vIGNvbnN0IG15cXVlcnkgPSBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIEBjYXNjYWRlIHt2YWx1ZSBjcmVhdGVkIH5yZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7IH19fWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCd0aGUgcXVlcnkgaXM6ICcsIHF1ZXJ5KTtcblxuICAgICAgICAvLyByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIGB7cmVzcChmdW5jOiBoYXMocmVhZGluZykpIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSkgQGNhc2NhZGUge3ZhbHVlIGNyZWF0ZWQgfnJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHsgfX19YCwgaHR0cE9wdGlvbnMpXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFRTUmVhZGluZ1tdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCByZWFkaW5ncycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxUU1JlYWRpbmdbXT4oJ2dldFJlYWRpbmdzU3RhcnRpbmdBdCcsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3NCZXR3ZWVuKFxuICAgICAgICBkZXZpY2VOYW1lOiBzdHJpbmcsXG4gICAgICAgIGluc3RydW1lbnROYW1lOiBzdHJpbmcsXG4gICAgICAgIGZyb210czogbnVtYmVyLFxuICAgICAgICB0b3RzOiBudW1iZXIsXG4gICAgICAgIGFjY291bnQ6IHN0cmluZyxcbiAgICApOiBPYnNlcnZhYmxlPFRTUmVhZGluZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG5cbiAgICAgICAgLy8gY29uc3QgbXlxdWVyeSA9IGB7cmVzcChmdW5jOiBoYXMocmVhZGluZykpIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSkgQGNhc2NhZGUge3ZhbHVlIGNyZWF0ZWQgfnJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHsgfX19YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhyZXNvdXJjZSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7XG4gICAgICAgIHJlYWRpbmdzIGFzIHJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihndChjcmVhdGVkLCAke2Zyb210c30pIEFORCBsdChjcmVhdGVkLCAke3RvdHN9KSkgKGZpcnN0Oi01MDApIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocmVhZGluZ3MpLCBvcmRlcmFzYzpjcmVhdGVkKSB7XG4gICAgICAgIGNyZWF0ZWRcbiAgICAgICAgdmFsdWVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZygndGhlIHF1ZXJ5IGlzOiAnLCBxdWVyeSk7XG5cbiAgICAgICAgLy8gcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIEBjYXNjYWRlIHt2YWx1ZSBjcmVhdGVkIH5yZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7IH19fWAsIGh0dHBPcHRpb25zKVxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBUU1JlYWRpbmdbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcmVhZGluZ3MnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8VFNSZWFkaW5nW10+KCdnZXRSZWFkaW5nc0JldHdlZW4nLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldExhc3RSZWFkaW5nc0ZvckRldmljZShkZXZpY2VOYW1lOiBzdHJpbmcsIGFjY291bnQ6IHN0cmluZyk6IE9ic2VydmFibGU8VFNSZWFkaW5nW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhkZXZpY2UpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfVwiKSkgQG5vcm1hbGl6ZSB7XG4gICAgICAgIGRldmljZV9yZXNvdXJjZSB7XG4gICAgICAgICAgbmFtZTogbmFtZVxuICAgICAgICAgIHJlc291cmNlX3JlYWRpbmcgKGZpcnN0Oi0xKSB7XG4gICAgICAgICAgICBjcmVhdGVkOiBjcmVhdGVkXG4gICAgICAgICAgICB2YWx1ZTogdmFsdWVcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICBjb25zb2xlLmxvZygnUmVhZGluZyBxdWVyeSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBUU1JlYWRpbmdbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcmVhZGluZ3MnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8VFNSZWFkaW5nW10+KCdnZXRMYXN0UmVhZGluZ3NGb3JEZXZpY2UnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldE5vdGlmaWNhdGlvbnMoYWNjb3VudDogc3RyaW5nKTogT2JzZXJ2YWJsZTxOb3RpZmljYXRpb25bXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zb2xlLmxvZygnR2V0Tm90aWZpY2F0aW9ucyBzZXJ2aWNlIGNhbGxlZCcpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhub3RpZmljYXRpb24pKSBAbm9ybWFsaXplIHtcbiAgICAgICAgdWlkIHV1aWQ6dXVpZCBjcmVhdGVkOmNyZWF0ZWQgbm90aWZ5U291cmNlOm5vdGlmeVNvdXJjZSBub3RpZnlEZXZpY2U6bm90aWZ5RGV2aWNlIG5vdGlmeVJlc291cmNlOm5vdGlmeVJlc291cmNlIG5vdGlmeUxldmVsOm5vdGlmeUxldmVsIHZhbHVlOnZhbHVlIGRlc2NyaXB0aW9uOmRlc2NyaXB0aW9uIH5nYXRld2F5X25vdGlmaWNhdGlvbiB7XG4gICAgICAgICAgZ2F0ZXdheTogdXVpZFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgTm90aWZpY2F0aW9uW10pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gY29uc29sZS5sb2coJ1Jlc3BvbnNlIGZyb20gR2V0Tm90aTogJywgcmVzcG9uc2UpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBub3RpZmljYXRpb25zJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE5vdGlmaWNhdGlvbltdPignZ2V0Tm90aWZpY2F0aW9ucycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0Um91dGUoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50OiBzdHJpbmcpOiBudW1iZXJbXVtdIHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgbGV0IHJvdXRlID0gbnVsbDtcblxuICAgICAgICBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMScpIHtcbiAgICAgICAgICAgIHJvdXRlID0gcm91dGUxO1xuICAgICAgICB9IGVsc2UgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDInKSB7XG4gICAgICAgICAgICByb3V0ZSA9IHJvdXRlMjtcbiAgICAgICAgfSBlbHNlIGlmIChkZXZpY2VOYW1lID09ICd0cmFpbi0wMDAzJykge1xuICAgICAgICAgICAgcm91dGUgPSByb3V0ZTM7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByb3V0ZSA9IGVtcHR5cm91dGU7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcm91dGU7XG4gICAgfVxuXG4gICAgZ2V0Um91dGVDZW50ZXIoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50OiBzdHJpbmcpOiBudW1iZXJbXSB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGxldCBjZW50ZXIgPSBudWxsO1xuXG4gICAgICAgIC8vIDM5LjAgLTk4LjAgem9vbSA0XG4gICAgICAgIC8vIEVhc3QgMzQuNzY1NTg5ICAgLTc4LjcwOTQ4OFxuICAgICAgICAvLyBXZXN0IDQwLjQ4NzQzMiAtMTIyLjgwMzExNlxuXG4gICAgICAgIGlmIChkZXZpY2VOYW1lID09ICd0cmFpbi0wMDAxJykge1xuICAgICAgICAgICAgY2VudGVyID0gWzM0LjAsIC05OC4wXTtcbiAgICAgICAgfSBlbHNlIGlmIChkZXZpY2VOYW1lID09ICd0cmFpbi0wMDAyJykge1xuICAgICAgICAgICAgY2VudGVyID0gWzQwLjAsIC05OC4wXTtcbiAgICAgICAgfSBlbHNlIGlmIChkZXZpY2VOYW1lID09ICd0cmFpbi0wMDAzJykge1xuICAgICAgICAgICAgY2VudGVyID0gWzM5LjAsIC05OC4wXTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNlbnRlciA9IFs0Mi44LCAxMi44XTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBjZW50ZXI7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBlbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50OiBzdHJpbmcpIHtcbiAgICAgICAgaWYgKCFhY2NvdW50KSB0aHJvdyBuZXcgRXJyb3IoJ0FjY291bnQgbXVzdCBleGlzdCcpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBIYW5kbGUgSFRUUCBvcGVyYXRpb24gdGhhdCBmYWlsZWQuXG4gICAgICogTGV0IHRoZSBhcHAgY29udGludWUuXG4gICAgICogQHBhcmFtIG9wZXJhdGlvbiAtIC0gbmFtZSBvZiB0aGUgb3BlcmF0aW9uIHRoYXQgZmFpbGVkXG4gICAgICogQHBhcmFtIHJlc3VsdCAtIG9wdGlvbmFsIHZhbHVlIHRvIHJldHVybiBhcyB0aGUgb2JzZXJ2YWJsZSByZXN1bHRcbiAgICAgKi9cbiAgICBwcml2YXRlIGhhbmRsZUVycm9yPFQ+KG9wZXJhdGlvbiA9ICdvcGVyYXRpb24nLCByZXN1bHQ/OiBUKSB7XG4gICAgICAgIHJldHVybiAoZXJyb3I6IGFueSk6IE9ic2VydmFibGU8VD4gPT4ge1xuICAgICAgICAgICAgLy8gVE9ETzogYmV0dGVyIGpvYiBvZiB0cmFuc2Zvcm1pbmcgZXJyb3IgZm9yIHVzZXIgY29uc3VtcHRpb25cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke29wZXJhdGlvbn0gZmFpbGVkOiAke2Vycm9yLmNvZGV9OiAke2Vycm9yLm1lc3NhZ2V9YCk7XG5cbiAgICAgICAgICAgIC8vIExldCB0aGUgYXBwIGtlZXAgcnVubmluZyBieSByZXR1cm5pbmcgYW4gZW1wdHkgcmVzdWx0LlxuICAgICAgICAgICAgcmV0dXJuIG9mKHJlc3VsdCBhcyBUKTtcbiAgICAgICAgfTtcbiAgICB9XG59XG4iXX0=