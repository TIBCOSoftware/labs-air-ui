import { catchError, map, of, tap } from 'rxjs';
const route1 = [
    [25.771088, -80.163483],
    [27.439775, -80.32299],
    [28.349469, -80.731105],
    [30.401564, -81.571033],
    [32.116716, -81.144147],
    [32.866511, -79.995399],
    [34.191224, -77.952419],
    [36.850172, -76.319269],
    [36.915037, -76.320643],
    [39.262025, -76.549294],
    [39.900933, -75.143453],
    [40.690263, -74.152375],
    [42.259951, -71.789244],
];
const route2 = [
    [47.492471, -122.26888],
    [45.552207, -122.722648],
    [39.53246, -119.751524],
    [37.803528, -122.312138],
    [37.899332, -121.169307],
    [36.273183, -115.070534],
    [33.77032, -118.273289],
    [34.106012, -117.320254],
    [33.515564, -112.160564],
    [32.126437, -110.848336],
    [31.752085, -106.488887],
    [35.04758, -106.653344],
    [39.796963, -104.995374],
];
const route3 = [
    [29.302729, -98.638744],
    [29.638421, -95.292245],
    [32.615525, -96.693485],
    [29.917836, -90.205272],
    [32.256403, -90.151546],
    [35.044849, -90.153006],
    [38.524627, -90.209535],
    [39.870851, -88.912284],
    [41.705694, -87.577341],
    [41.902382, -89.101932],
    [44.251243, -91.509663],
    [44.970069, -93.174527],
    [46.758181, -92.098748],
];
const emptyroute = [];
const httpOptions = {
    headers: { 'Content-Type': 'application/graphql+-' },
};
const httpMutateOptions = {
    headers: { 'Content-Type': 'application/rdf' },
};
export class GraphService {
    constructor(http, dGraphUrl, accountRequired) {
        this.http = http;
        this.dGraphUrl = dGraphUrl;
        this.accountRequired = accountRequired;
        this.requireAccountId = true;
        console.log(`dGraphUrl: ${this.dGraphUrl} requires account identifier ${accountRequired}`);
        this.requireAccountId = accountRequired;
        //const dGraphBasicAuthEnabled = this.appConfigService.dGraphBasicAuthEnabled;
        //if (dGraphBasicAuthEnabled) {
        //    const dGraphBasicAuth = this.appConfigService.dGraphBasicAuth;
        //    (this.httpOptions.headers = { 'Content-Type': 'application/graphql+-' }), { Authorization: dGraphBasicAuth };
        //    (this.httpMutateOptions.headers = { 'Content-Type': 'application/rdf' }), { Authorization: dGraphBasicAuth };
        //}
    }
    getGateway(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        console.log('GetGateway service called for: ', gatewayName);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid description address router routerPort deployNetwork latitude longitude accessToken username platform devicesMetadata createdts updatedts
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log('Response from getGateway: ', response)), catchError(this.handleError('getGateway', [])));
    }
    getGateways(account) {
        this.ensureAccountAuthorized(account);
        console.log(`GetGateways service called for ${account}`);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) {
        uid uuid description address router routerPort deployNetwork latitude longitude accessToken username platform devicesMetadata createdts updatedts
        numDevices: count(gateway_device)

      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched gateways')), catchError(this.handleError('getGateways', [])));
    }
    updateGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${gateway.uid}> <address> "${gateway.address}" .
        <${gateway.uid}> <router> "${gateway.router}" .
        <${gateway.uid}> <routerPort> "${gateway.routerPort}" .
        <${gateway.uid}> <deployNetwork> "${gateway.deployNetwork}" .
        <${gateway.uid}> <description> "${gateway.description}" .
        <${gateway.uid}> <latitude> "${gateway.latitude}" .
        <${gateway.uid}> <longitude> "${gateway.longitude}" .
        <${gateway.uid}> <accessToken> "${gateway.accessToken}" .
        <${gateway.uid}> <username> "${gateway.username}" .
        <${gateway.uid}> <platform> "${gateway.platform}" .
        <${gateway.uid}> <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log('Update Gateway Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => 'gateway updated'), tap(() => console.log('updated gateway')), catchError(this.handleError('updateGateway')));
    }
    addGateway(gateway, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Gateway <dgraph.type> "Gateway" .
        _:Gateway <gateway> "" .
        _:Gateway <type> "gateway" .
        _:Gateway <uuid> "${gateway.uuid}" .
        _:Gateway <description> "${gateway.description}" .
        _:Gateway <address> "${gateway.address}" .
        _:Gateway <router> "${gateway.router}" .
        _:Gateway <routerPort> "${gateway.routerPort}" .
        _:Gateway <deployNetwork> "${gateway.deployNetwork}" .
        _:Gateway <latitude> "${gateway.latitude}" .
        _:Gateway <longitude> "${gateway.longitude}" .
        _:Gateway <accessToken> "${gateway.accessToken}" .
        _:Gateway <username> "${gateway.username}" .
        _:Gateway <platform> "${gateway.platform}" .
        _:Gateway <createdts> "${gateway.createdts}" .
        _:Gateway <updatedts> "${gateway.updatedts}" .
      }
    }`;
        console.log('Add Gateway Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = gateway)), tap(() => console.log('add gateway')), catchError(this.handleError('addGateway')));
    }
    deleteGateway(gatewayUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${gatewayUid}> * * .
      }
    }`;
        console.log('Delete Gateway Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map(() => `${gatewayUid} deleted`), tap(() => console.log('deleted gateway')), catchError(this.handleError('deleteGateway')));
    }
    getGatewayAndProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid
        protocols: gateway_protocol {
          uid
          uuid
          created
          modified
          protocolType
          brokerURL
          topic
          consumerGroupId
          connectionTimeout
          sessionTimeout
          initialOffset
          retryBackoff
          fetchMinBytes
          fetchMaxWait
          commitInterval
          heartbeatInterval
          maximumQOS
          username
          password
          encryptionMode
          caCertificate
          clientCertificate
          clientKey
          authMode
          serverCerticate
        }
      }
    }`;
        console.log('Get Gateway and Protocols query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched Gateway')), catchError(this.handleError('getGatewayWithProtocols', [])));
    }
    /**
     * Get all global protocols and the protocols scoped for the gateway
     * @param gatewayName
     * @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500)
     */
    getProtocols(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(protocol)) @filter(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL")) {
        uid
        uuid
        created
        modified
        protocolType
        brokerURL
        topic
        consumerGroupId
        connectionTimeout
        sessionTimeout
        initialOffset
        retryBackoff
        fetchMinBytes
        fetchMaxWait
        commitInterval
        heartbeatInterval
        maximumQOS
        username
        password
        encryptionMode
        caCertificate
        clientCertificate
        clientKey
        authMode
        serverCerticate
        scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched protocols')), catchError(this.handleError('getProtocols', [])));
    }
    addProtocol(gatewayUid, protocol, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Protocol <dgraph.type> "Protocol" .
        _:Protocol <type> "protocol" .
        _:Protocol <protocol> "" .
        _:Protocol <uuid> "${protocol.uuid}" .
        _:Protocol <created> "${protocol.created}" .
        _:Protocol <modified> "${protocol.modified}" .
        _:Protocol <protocolType> "${protocol.protocolType}" .
        _:Protocol <brokerURL> "${protocol.brokerURL}" .
        _:Protocol <topic> "${protocol.topic}" .
        _:Protocol <consumerGroupId> "${protocol.consumerGroupId}" .
        _:Protocol <connectionTimeout> "${protocol.connectionTimeout}" .
        _:Protocol <sessionTimeout> "${protocol.sessionTimeout}" .
        _:Protocol <initialOffset> "${protocol.initialOffset}" .
        _:Protocol <retryBackoff> "${protocol.retryBackOff}" .
        _:Protocol <fetchMinBytes> "${protocol.fetchMinBytes}" .
        _:Protocol <fetchMaxWait> "${protocol.fetchMaxWait}" .
        _:Protocol <commitInterval> "${protocol.commitInterval}" .
        _:Protocol <heartbeatInterval> "${protocol.heartbeatInterval}" .
        _:Protocol <maximumQOS> "${protocol.maximumQOS}" .
        _:Protocol <username> "${protocol.username}" .
        _:Protocol <password> "${protocol.password}" .
        _:Protocol <encryptionMode> "${protocol.encryptionMode}" .
        _:Protocol <caCertificate> "${protocol.caCertificate}" .
        _:Protocol <clientCertificate> "${protocol.clientCertificate}" .
        _:Protocol <clientKey> "${protocol.clientKey}" .
        _:Protocol <authMode> "${protocol.authMode}" .
        _:Protocol <serverCerticate> "${protocol.serverCertificate}" .
        _:Protocol <scope> "${protocol.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = protocol)), tap(() => console.log('add protocols')), catchError(this.handleError('addProtocols')));
    }
    updateProtocol(protocol, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${protocol.uid}> <uuid> "${protocol.uuid}" .
        <${protocol.uid}> <modified> "${protocol.modified}" .
        <${protocol.uid}> <protocolType> "${protocol.protocolType}" .
        <${protocol.uid}> <brokerURL> "${protocol.brokerURL}" .
        <${protocol.uid}> <topic> "${protocol.topic}" .
        <${protocol.uid}> <consumerGroupId> "${protocol.consumerGroupId}" .
        <${protocol.uid}> <connectionTimeout> "${protocol.connectionTimeout}" .
        <${protocol.uid}> <sessionTimeout> "${protocol.sessionTimeout}" .
        <${protocol.uid}> <initialOffset> "${protocol.initialOffset}" .
        <${protocol.uid}> <retryBackoff> "${protocol.retryBackOff}" .
        <${protocol.uid}> <fetchMinBytes> "${protocol.fetchMinBytes}" .
        <${protocol.uid}> <fetchMaxWait> "${protocol.fetchMaxWait}" .
        <${protocol.uid}> <commitInterval> "${protocol.commitInterval}" .
        <${protocol.uid}> <heartbeatInterval> "${protocol.heartbeatInterval}" .
        <${protocol.uid}> <maximumQOS> "${protocol.maximumQOS}" .
        <${protocol.uid}> <username> "${protocol.username}" .
        <${protocol.uid}> <password> "${protocol.password}" .
        <${protocol.uid}> <encryptionMode> "${protocol.encryptionMode}" .
        <${protocol.uid}> <caCertificate> "${protocol.caCertificate}" .
        <${protocol.uid}> <clientCertificate> "${protocol.clientCertificate}" .
        <${protocol.uid}> <clientKey> "${protocol.clientKey}" .
        <${protocol.uid}> <authMode> "${protocol.authMode}" .
        <${protocol.uid}> <serverCerticate> "${protocol.serverCertificate}" .
        <${protocol.uid}> <scope> "${protocol.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = protocol)), tap(() => console.log('updated protocols')), catchError(this.handleError('updateProtocols')));
    }
    deleteProtocol(gatewayUid, protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${protocolUid}> * * .
      }
    }`;
        console.log('Delete Protocol Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${protocolUid} deleted`)), tap(() => console.log('deleted protocol')), catchError(this.handleError('deleteProtocol')));
    }
    getDataStores(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(dataStore)) @filter(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL")) {
        uid
        uuid
        created
        modified
        dataStoreType
        host
        port
        databaseName
        user
        password
        accountName
        warehouse
        database
        schema
        authType
        username
        clientId
        clientSecret
        authorizationCode
        redirectURI
        loginTimeout
        url
        scope
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched dataStores')), catchError(this.handleError('getDataStores', [])));
    }
    addDataStore(gatewayUid, dataStore, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:DataStore <dgraph.type> "DataStore" .
        _:DataStore <type> "dataStore" .
        _:DataStore <dataStore> "" .
        _:DataStore <uuid> "${dataStore.uuid}" .
        _:DataStore <created> "${dataStore.created}" .
        _:DataStore <modified> "${dataStore.modified}" .
        _:DataStore <dataStoreType> "${dataStore.dataStoreType}" .
        _:DataStore <host> "${dataStore.host}" .
        _:DataStore <port> "${dataStore.port}" .
        _:DataStore <databaseName> "${dataStore.databaseName}" .
        _:DataStore <user> "${dataStore.user}" .
        _:DataStore <password> "${dataStore.password}" .
        _:DataStore <accountName> "${dataStore.accountName}" .
        _:DataStore <warehouse> "${dataStore.warehouse}" .
        _:DataStore <database> "${dataStore.databaseName}" .
        _:DataStore <schema> "${dataStore.schema}" .
        _:DataStore <authType> "${dataStore.authType}" .
        _:DataStore <username> "${dataStore.username}" .
        _:DataStore <clientId> "${dataStore.clientId}" .
        _:DataStore <clientSecret> "${dataStore.clientSecret}" .
        _:DataStore <authorizationCode> "${dataStore.authorizationCode}" .
        _:DataStore <redirectURI> "${dataStore.redirectURI}" .
        _:DataStore <loginTimeout> "${dataStore.loginTimeout}" .
        _:DataStore <url> "${dataStore.url}" .
        _:DataStore <scope> "${dataStore.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = dataStore)), tap(() => console.log('add dataStores')), catchError(this.handleError('addDataStores')));
    }
    updateDataStore(dataStore, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${dataStore.uid}> <uuid> "${dataStore.uuid}" .
        <${dataStore.uid}> <modified> "${dataStore.modified}" .
        <${dataStore.uid}> <dataStoreType> "${dataStore.dataStoreType}" .
        <${dataStore.uid}> <host> "${dataStore.host}" .
        <${dataStore.uid}> <port> "${dataStore.port}" .
        <${dataStore.uid}> <databaseName> "${dataStore.databaseName}" .
        <${dataStore.uid}> <user> "${dataStore.user}" .
        <${dataStore.uid}> <password> "${dataStore.password}" .
        <${dataStore.uid}> <accountName> "${dataStore.accountName}" .
        <${dataStore.uid}> <warehouse> "${dataStore.warehouse}" .
        <${dataStore.uid}> <database> "${dataStore.databaseName}" .
        <${dataStore.uid}> <schema> "${dataStore.schema}" .
        <${dataStore.uid}> <authType> "${dataStore.authType}" .
        <${dataStore.uid}> <username> "${dataStore.username}" .
        <${dataStore.uid}> <clientId> "${dataStore.clientId}" .
        <${dataStore.uid}> <clientSecret> "${dataStore.clientSecret}" .
        <${dataStore.uid}> <authorizationCode> "${dataStore.authorizationCode}" .
        <${dataStore.uid}> <redirectURI> "${dataStore.redirectURI}" .
        <${dataStore.uid}> <loginTimeout> "${dataStore.loginTimeout}" .
        <${dataStore.uid}> <url> "${dataStore.url}" .
        <${dataStore.uid}> <scope> "${dataStore.scope}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = dataStore)), tap(() => console.log('updated dataStores')), catchError(this.handleError('updateDataStores')));
    }
    deleteDataStore(gatewayUid, dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${dataStoreUid}> * * .
      }
    }`;
        console.log('Delete DataStore Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${dataStoreUid} deleted`)), tap(() => console.log('deleted dataStore')), catchError(this.handleError('deleteDataStore')));
    }
    getGatewayAndModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid
        models: gateway_model {
          uid
          uuid
          created
          modified
          name
          description
          inputType
          url
          scope
          inputTemplate
        }
      }
    }`;
        console.log('Get Gateway and Protocols query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched Gateway')), catchError(this.handleError('getGatewayWithModels', [])));
    }
    getModels(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(model)) @filter(eq(scope, "${gatewayName}") OR eq(scope, "GLOBAL")) {
        uid
        uuid
        created
        modified
        name
        description
        inputType
        url
        scope
        inputTemplate
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched models')), catchError(this.handleError('getModels', [])));
    }
    addModel(gatewayUid, model, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Model <dgraph.type> "Model" .
        _:Model <type> "model" .
        _:Model <model> "" .
        _:Model <uuid> "${model.uuid}" .
        _:Model <created> "${model.created}" .
        _:Model <modified> "${model.modified}" .
        _:Model <name> "${model.name}" .
        _:Model <description> "${model.description}" .
        _:Model <inputType> "${model.inputType}" .
        _:Model <url> "${model.url}" .
        _:Model <scope> "${model.scope}" .
        _:Model <inputTemplate> "${model.inputTemplate}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = model)), tap(() => console.log('add models')), catchError(this.handleError('addModels')));
    }
    updateModel(model, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${model.uid}> <uuid> "${model.uuid}" .
        <${model.uid}> <modified> "${model.modified}" .
        <${model.uid}> <name> "${model.name}" .
        <${model.uid}> <description> "${model.description}" .
        <${model.uid}> <inputType> "${model.inputType}" .
        <${model.uid}> <url> "${model.url}" .
        <${model.uid}> <scope> "${model.scope}" .
        <${model.uid}> <inputTemplate> "${model.inputTemplate}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = model)), tap(() => console.log('updated models')), catchError(this.handleError('updateModels')));
    }
    deleteModel(gatewayUid, modelUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${modelUid}> * * .
      }
    }`;
        console.log('Delete Model Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${modelUid} deleted`)), tap(() => console.log('deleted protocol')), catchError(this.handleError('deleteModel')));
    }
    getGatewayAndPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = 'protocol: pipeline_protocol {uid uuid brokerURL topic maximumQOS username password encryptionMode caCertificate clientCertificate clientKey authMode serverCerticate consumerGroupId connectionTimeout sessionTimeout retryBackoff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval}';
        const pipeline_datastore = 'dataStore: pipeline_datastore {uid uuid host port databaseName user password accountName warehouse database schema authType username clientId clientSecret authorizationCode redirectURI loginTimeout url}';
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      resp(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        uid uuid accessToken username platform address router routerPort deployNetwork devicesMetadata
        pipelines: gateway_pipeline {
          uid
          name
          uuid
          pipelineType
          deployerType
          protocolType
          protocolId
          dataStoreType
          dataStoreId
          created
          modified
          description
          status
          flowConfiguration
          logLevel
          subscriptionTopic
          ${pipeline_protocol}
          ${pipeline_datastore}
          ${pipeline_filter}
          ${pipeline_streaming}
        }
      }
    }`;
        console.log('Get Gateway and Pipelines query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched Gateway')), catchError(this.handleError('getGatewayWithPipelines', [])));
    }
    getPipelines(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const pipeline_protocol = 'protocol: pipeline_protocol {uid brokerURL topic maximumQOS username password encryptionMode caCertificate clientCertificate clientKey authMode serverCerticate consumerGroupId connectionTimeout sessionTimeout retryBackoff commitInterval initialOffset fetchMinBytes fetchMaxWait heartbeatInterval}';
        const pipeline_datastore = 'datastore: pipeline_datastore {uid host port databaseName user password accountName warehouse database schema authType username clientId clientSecret authorizationCode redirectURI loginTimeout url}';
        const pipeline_filter = 'filter: pipeline_filter {uid deviceNames}';
        const pipeline_streaming = 'streaming: pipeline_streaming {uid deviceName instrumentName function windowType windowSize}';
        const query = `{
      var(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        pipelines as gateway_pipeline {
        }
      }
      resp(func: uid(pipelines)) {
        uid
        name
        uuid
        pipelineType
        deployerType
        protocolType
        protocolId
        dataStoreType
        dataStoreId
        created
        modified
        description
        status
        flowConfiguration
        logLevel
        subscriptionTopic
        ${pipeline_protocol}
        ${pipeline_datastore}
        ${pipeline_filter}
        ${pipeline_streaming}
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipelines')), catchError(this.handleError('getPipelines', [])));
    }
    addPipeline(gatewayUid, pipeline, transportObj, dataStoreObj, filterObj, streamingObj, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        let query = '';
        query = `{
      set {
        _:Pipeline <dgraph.type> "Pipeline" .
        _:Pipeline <name> "${pipeline.name}" .
        _:Pipeline <uuid> "${pipeline.name}" .
        _:Pipeline <type> "pipeline" .
        _:Pipeline <pipeline> "" .
        _:Pipeline <pipelineType> "${pipeline.pipelineType}" .
        _:Pipeline <deployerType> "${pipeline.deployerType}" .
        _:Pipeline <created> "${pipeline.created}" .
        _:Pipeline <modified> "${pipeline.modified}" .
        _:Pipeline <description> "${pipeline.description}" .
        _:Pipeline <status> "${pipeline.status}" .
        _:Pipeline <flowConfiguration> "${pipeline.flowConfiguration}" .
        _:Pipeline <logLevel> "${pipeline.logLevel}" .
        _:Pipeline <subscriptionTopic> "${pipeline.subscriptionTopic}" .
        <${gatewayUid}> <gateway_pipeline> _:Pipeline .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = pipeline)), tap(() => console.log('add pipeline')), catchError(this.handleError('addPipelines')));
    }
    updatePipeline(pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${pipeline.uid}> <description> "${pipeline.description}" .
        <${pipeline.uid}> <status> "${pipeline.status}" .
        <${pipeline.uid}> <modified> "${pipeline.modified}" .
        <${pipeline.uid}> <flowConfiguration> "${pipeline.flowConfiguration}" .
        <${pipeline.uid}> <logLevel> "${pipeline.logLevel}" .
        <${pipeline.uid}> <subscriptionTopic> "${pipeline.subscriptionTopic}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = pipeline)), tap(() => console.log('updated pipelines')), catchError(this.handleError('updatePipeline')));
    }
    deletePipeline(gatewayUid, pipeline, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${pipeline.uid}> * * .
        <${gatewayUid}> <gateway_pipeline> <${pipeline.uid}> .
      }
    }`;
        console.log('Delete Pipeline Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `pipeline deleted`)), tap(() => console.log('deleted pipeline')), catchError(this.handleError('deletePipeline')));
    }
    /**
     * Get ids of all the pipelines associated with the specified protocol
     * @param protocolUid - the uid of the protocol
     */
    getPipelineIdsFromProtocolUid(protocolUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${protocolUid})) {
        pipelines as ~pipeline_protocol {
        }
      }
      resp(func: uid(pipelines)) {
        uid
        uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipeline ids')), catchError(this.handleError('getPipelineIdsFromProtocolUid', [])));
    }
    /**
     * Get ids of all the pipelines associated with the specified data store
     * @param dataStoreUid - the uid of the data store
     */
    getPipelineIdsFromDataStoreUid(dataStoreUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: uid(${dataStoreUid})) {
        pipelines as ~pipeline_datastore {
        }
      }
      resp(func: uid(pipelines)) {
        uid
        uuid
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched pipeline ids')), catchError(this.handleError('getPipelineIdsFromDataStoreUid', [])));
    }
    getModelConfigs(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        modelConfigs as gateway_modelconfig {
        }
      }
      resp(func: uid(modelConfigs)) {
        uid
        name
        uuid
        description
        device
        resource
        model
        created
        modified
      }
    }`;
        console.log('getModelConfigs service query: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched modelConfigs')), catchError(this.handleError('getModelConfigs', [])));
    }
    addModelConfig(gatewayUid, modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:ModelConfig <dgraph.type> "ModelConfig" .
        _:ModelConfig <name> "${modelConfig.name}" .
        _:ModelConfig <uuid> "${modelConfig.name}" .
        _:ModelConfig <type> "modelConfig" .
        _:ModelConfig <modelConfig> "" .
        _:ModelConfig <description> "${modelConfig.description}" .
        _:ModelConfig <device> "${modelConfig.device}" .
        _:ModelConfig <resource> "${modelConfig.resource}" .
        _:ModelConfig <model> "${modelConfig.model}" .
        _:ModelConfig <created> "${modelConfig.created}" .
        _:ModelConfig <modified> "${modelConfig.modified}" .
        <${gatewayUid}> <gateway_modelconfig> _:ModelConfig .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = modelConfig)), tap(() => console.log('add modelConfig')), catchError(this.handleError('addModelConfig')));
    }
    updateModelConfig(modelConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${modelConfig.uid}> <name> "${modelConfig.name}" .
        <${modelConfig.uid}> <uuid> "${modelConfig.uuid}" .
        <${modelConfig.uid}> <description> "${modelConfig.description}" .
        <${modelConfig.uid}> <condDevice> "${modelConfig.device}" .
        <${modelConfig.uid}> <condResource> "${modelConfig.resource}" .
        <${modelConfig.uid}> <model> "${modelConfig.model}" .
        <${modelConfig.uid}> <modified> "${modelConfig.modified}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = modelConfig)), tap(() => console.log('updated modelConfig')), catchError(this.handleError('updateModelConfig')));
    }
    deleteModelConfig(gatewayUid, modelConfigUid, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      delete {
        <${modelConfigUid}> * * .
        <${gatewayUid}> <gateway_modelconfig> <${modelConfigUid}> .
      }
    }`;
        console.log('Delete ModelConfig Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = `${modelConfigUid} deleted`)), tap(() => console.log('deleted modelConfig')), catchError(this.handleError('deleteModelConfig')));
    }
    getFiltersConfig(gatewayName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(gateway)) @filter(eq(uuid, "${gatewayName}")) {
        filtersConfig as gateway_filter {
        }
      }
      resp(func: uid(filtersConfig)) {
        uid
        deviceNames
      }
    }`;
        console.log('getFiltersConfig service query: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched filtersConfig')), catchError(this.handleError('getFiltersConfigs', [])));
    }
    addFiltersConfig(gatewayUid, filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        _:Filter <dgraph.type> "filter" .
        _:Filter <type> "filter" .
        _:Filter <filter> "" .
        _:Filter <deviceNames> "${filtersConfig.deviceNames}" .
        <${gatewayUid}> <gateway_filter> _:Filter .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = filtersConfig)), tap(() => console.log('add filtersConfig')), catchError(this.handleError('addFiltersConfig')));
    }
    updateFiltersConfig(filtersConfig, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/mutate?commitNow=true`;
        const query = `{
      set {
        <${filtersConfig.uid}> <deviceNames> "${filtersConfig.deviceNames}" .
      }
    }`;
        console.log('Mutate statement: ', query);
        return this.http.post(url, query, httpMutateOptions).pipe(map((response) => (response.data.resp = filtersConfig)), tap(() => console.log('updated filtersConfig')), catchError(this.handleError('updateFiltersConfig')));
    }
    getReadings(deviceName, instrumentName, numReadings, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        // return this.http.post<any>(url, `{resp(func: has(reading)) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) {~device_resource @filter (eq(uuid, "${deviceName}")) {}}}}`, httpOptions)
        // return this.http.post<any>(url, `{resp(func: has(reading)) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading (first:-${numReadings}) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('getReadings query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log('Response from getReadings: ', response)), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadings', [])));
    }
    getReadingsAt(deviceName, instrumentName, ts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(eq(created, ${ts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('getReadingsAt query statement: ', query);
        // return this.http.post<any>(url, `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadingsAt', [])));
    }
    getReadingsStartingAt(deviceName, instrumentName, fromts, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        // const myquery = `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`;
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts})) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('the query is: ', query);
        // return this.http.post<any>(url, `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadingsStartingAt', [])));
    }
    getReadingsBetween(deviceName, instrumentName, fromts, tots, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        // const myquery = `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`;
        const query = `{
      var(func: has(resource)) @filter(eq(uuid, "${deviceName}_${instrumentName}")) {
        readings as resource_reading @filter(gt(created, ${fromts}) AND lt(created, ${tots})) (first:-500) {
        }
      }
      resp(func: uid(readings), orderasc:created) {
        created
        value
      }
    }`;
        console.log('the query is: ', query);
        // return this.http.post<any>(url, `{resp(func: has(reading)) @filter(gt(created, ${fromts})) @cascade {value created ~resource_reading @filter(eq(uuid, "${deviceName}_${instrumentName}")) { }}}`, httpOptions)
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getReadingsBetween', [])));
    }
    getLastReadingsForDevice(deviceName, account) {
        this.ensureAccountAuthorized(account);
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(device)) @filter(eq(uuid, "${deviceName}")) @normalize {
        device_resource {
          name: name
          resource_reading (first:-1) {
            created: created
            value: value
          }
        }
      }
    }`;
        console.log('Reading query statement: ', query);
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap(() => console.log('fetched readings')), catchError(this.handleError('getLastReadingsForDevice', [])));
    }
    getNotifications(account) {
        this.ensureAccountAuthorized(account);
        console.log('GetNotifications service called');
        const url = `${this.dGraphUrl}/query`;
        const query = `{
      resp(func: has(notification)) @normalize {
        uid uuid:uuid created:created notifySource:notifySource notifyDevice:notifyDevice notifyResource:notifyResource notifyLevel:notifyLevel value:value description:description ~gateway_notification {
          gateway: uuid
        }
      }
    }`;
        return this.http.post(url, query, httpOptions).pipe(map((response) => response.data.resp), tap((response) => console.log('Response from GetNoti: ', response)), tap(() => console.log('fetched notifications')), catchError(this.handleError('getNotifications', [])));
    }
    getRoute(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let route = null;
        if (deviceName == 'train-0001') {
            route = route1;
        }
        else if (deviceName == 'train-0002') {
            route = route2;
        }
        else if (deviceName == 'train-0003') {
            route = route3;
        }
        else {
            route = emptyroute;
        }
        return route;
    }
    getRouteCenter(deviceName, account) {
        this.ensureAccountAuthorized(account);
        let center = null;
        // 39.0 -98.0 zoom 4
        // East 34.765589   -78.709488
        // West 40.487432 -122.803116
        if (deviceName == 'train-0001') {
            center = [34.0, -98.0];
        }
        else if (deviceName == 'train-0002') {
            center = [40.0, -98.0];
        }
        else if (deviceName == 'train-0003') {
            center = [39.0, -98.0];
        }
        else {
            center = [42.8, 12.8];
        }
        return center;
    }
    ensureAccountAuthorized(account) {
        if (this.requireAccountId) {
            if (!account)
                throw new Error('Account must exist');
        }
    }
    /**
     * Handle HTTP operation that failed.
     * Let the app continue.
     * @param operation - - name of the operation that failed
     * @param result - optional value to return as the observable result
     */
    handleError(operation = 'operation', result) {
        return (error) => {
            // TODO: better job of transforming error for user consumption
            console.log(`${operation} failed: ${error.code}: ${error.message}`);
            // Let the app keep running by returning an empty result.
            return of(result);
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL2xhYnMtYWlyLWdyYXBoLWNsaWVudC9zcmMvYXBpL2dyYXBoLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBV0EsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQWMsRUFBRSxFQUFFLEdBQUcsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUc1RCxNQUFNLE1BQU0sR0FBZTtJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFFBQVEsQ0FBQztJQUN0QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsQ0FBQztDQUMxQixDQUFDO0FBRUYsTUFBTSxNQUFNLEdBQWU7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDeEIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDdkIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUM7Q0FDM0IsQ0FBQztBQUVGLE1BQU0sTUFBTSxHQUFlO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUMsU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFDO0NBQzFCLENBQUM7QUFFRixNQUFNLFVBQVUsR0FBZSxFQUFFLENBQUM7QUFFbEMsTUFBTSxXQUFXLEdBQUc7SUFDaEIsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLHVCQUF1QixFQUFFO0NBQ3ZELENBQUM7QUFFRixNQUFNLGlCQUFpQixHQUFHO0lBQ3RCLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxpQkFBaUIsRUFBRTtDQUNqRCxDQUFDO0FBRUYsTUFBTSxPQUFPLFlBQVk7SUFJckIsWUFBb0IsSUFBZ0IsRUFBWSxTQUFpQixFQUFVLGVBQXdCO1FBQS9FLFNBQUksR0FBSixJQUFJLENBQVk7UUFBWSxjQUFTLEdBQVQsU0FBUyxDQUFRO1FBQVUsb0JBQWUsR0FBZixlQUFlLENBQVM7UUFGN0YscUJBQWdCLEdBQUcsSUFBSSxDQUFDO1FBRzFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxJQUFJLENBQUMsU0FBUyxnQ0FBZ0MsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUM3RixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsZUFBZSxDQUFDO1FBQ3RDLDhFQUE4RTtRQUM5RSwrQkFBK0I7UUFDL0Isb0VBQW9FO1FBQ3BFLG1IQUFtSDtRQUNuSCxtSEFBbUg7UUFDbkgsR0FBRztJQUNQLENBQUM7SUFFRCxVQUFVLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUM1QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUM1RCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzttREFDNkIsV0FBVzs7O01BR3hELENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFDdEUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVksWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQzVELENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQWdCO1FBQ3hCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3pELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHOzs7Ozs7TUFNaEIsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFpQixDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVksYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQzdELENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLE9BQWdCLEVBQUUsT0FBZ0I7UUFDNUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsT0FBTyxDQUFDLEdBQUcsZ0JBQWdCLE9BQU8sQ0FBQyxPQUFPO1dBQzFDLE9BQU8sQ0FBQyxHQUFHLGVBQWUsT0FBTyxDQUFDLE1BQU07V0FDeEMsT0FBTyxDQUFDLEdBQUcsbUJBQW1CLE9BQU8sQ0FBQyxVQUFVO1dBQ2hELE9BQU8sQ0FBQyxHQUFHLHNCQUFzQixPQUFPLENBQUMsYUFBYTtXQUN0RCxPQUFPLENBQUMsR0FBRyxvQkFBb0IsT0FBTyxDQUFDLFdBQVc7V0FDbEQsT0FBTyxDQUFDLEdBQUcsaUJBQWlCLE9BQU8sQ0FBQyxRQUFRO1dBQzVDLE9BQU8sQ0FBQyxHQUFHLGtCQUFrQixPQUFPLENBQUMsU0FBUztXQUM5QyxPQUFPLENBQUMsR0FBRyxvQkFBb0IsT0FBTyxDQUFDLFdBQVc7V0FDbEQsT0FBTyxDQUFDLEdBQUcsaUJBQWlCLE9BQU8sQ0FBQyxRQUFRO1dBQzVDLE9BQU8sQ0FBQyxHQUFHLGlCQUFpQixPQUFPLENBQUMsUUFBUTtXQUM1QyxPQUFPLENBQUMsR0FBRyxrQkFBa0IsT0FBTyxDQUFDLFNBQVM7O01BRW5ELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXhELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixDQUFDLEVBQzVCLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFDekMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsZUFBZSxDQUFDLENBQUMsQ0FDeEQsQ0FBQztJQUNOLENBQUM7SUFFRCxVQUFVLENBQUMsT0FBZ0IsRUFBRSxPQUFnQjtRQUN6QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7NEJBS00sT0FBTyxDQUFDLElBQUk7bUNBQ0wsT0FBTyxDQUFDLFdBQVc7K0JBQ3ZCLE9BQU8sQ0FBQyxPQUFPOzhCQUNoQixPQUFPLENBQUMsTUFBTTtrQ0FDVixPQUFPLENBQUMsVUFBVTtxQ0FDZixPQUFPLENBQUMsYUFBYTtnQ0FDMUIsT0FBTyxDQUFDLFFBQVE7aUNBQ2YsT0FBTyxDQUFDLFNBQVM7bUNBQ2YsT0FBTyxDQUFDLFdBQVc7Z0NBQ3RCLE9BQU8sQ0FBQyxRQUFRO2dDQUNoQixPQUFPLENBQUMsUUFBUTtpQ0FDZixPQUFPLENBQUMsU0FBUztpQ0FDakIsT0FBTyxDQUFDLFNBQVM7O01BRTVDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXJELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQ2pELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQ3JDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFVLFlBQVksQ0FBQyxDQUFDLENBQ3RELENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLFVBQWtCLEVBQUUsT0FBZ0I7UUFDOUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsVUFBVTs7TUFFZixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV4RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFVBQVUsVUFBVSxDQUFDLEVBQ2xDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFDekMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsZUFBZSxDQUFDLENBQUMsQ0FDeEQsQ0FBQztJQUNOLENBQUM7SUFFRCxzQkFBc0IsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQ3hELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRzttREFDNkIsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O01BOEJ4RCxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2Q0FBNkMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQ3pDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFZLHlCQUF5QixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3pFLENBQUM7SUFDTixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFlBQVksQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQzlDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRztxREFDK0IsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztNQTRCMUQsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFrQixDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWEsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQy9ELENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLFVBQWtCLEVBQUUsUUFBa0IsRUFBRSxPQUFnQjtRQUNoRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7Ozs7NkJBS08sUUFBUSxDQUFDLElBQUk7Z0NBQ1YsUUFBUSxDQUFDLE9BQU87aUNBQ2YsUUFBUSxDQUFDLFFBQVE7cUNBQ2IsUUFBUSxDQUFDLFlBQVk7a0NBQ3hCLFFBQVEsQ0FBQyxTQUFTOzhCQUN0QixRQUFRLENBQUMsS0FBSzt3Q0FDSixRQUFRLENBQUMsZUFBZTswQ0FDdEIsUUFBUSxDQUFDLGlCQUFpQjt1Q0FDN0IsUUFBUSxDQUFDLGNBQWM7c0NBQ3hCLFFBQVEsQ0FBQyxhQUFhO3FDQUN2QixRQUFRLENBQUMsWUFBWTtzQ0FDcEIsUUFBUSxDQUFDLGFBQWE7cUNBQ3ZCLFFBQVEsQ0FBQyxZQUFZO3VDQUNuQixRQUFRLENBQUMsY0FBYzswQ0FDcEIsUUFBUSxDQUFDLGlCQUFpQjttQ0FDakMsUUFBUSxDQUFDLFVBQVU7aUNBQ3JCLFFBQVEsQ0FBQyxRQUFRO2lDQUNqQixRQUFRLENBQUMsUUFBUTt1Q0FDWCxRQUFRLENBQUMsY0FBYztzQ0FDeEIsUUFBUSxDQUFDLGFBQWE7MENBQ2xCLFFBQVEsQ0FBQyxpQkFBaUI7a0NBQ2xDLFFBQVEsQ0FBQyxTQUFTO2lDQUNuQixRQUFRLENBQUMsUUFBUTt3Q0FDVixRQUFRLENBQUMsaUJBQWlCOzhCQUNwQyxRQUFRLENBQUMsS0FBSzs7TUFFdEMsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsRUFDdkMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVcsY0FBYyxDQUFDLENBQUMsQ0FDekQsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsUUFBa0IsRUFBRSxPQUFnQjtRQUMvQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxRQUFRLENBQUMsR0FBRyxhQUFhLFFBQVEsQ0FBQyxJQUFJO1dBQ3RDLFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRyxxQkFBcUIsUUFBUSxDQUFDLFlBQVk7V0FDdEQsUUFBUSxDQUFDLEdBQUcsa0JBQWtCLFFBQVEsQ0FBQyxTQUFTO1dBQ2hELFFBQVEsQ0FBQyxHQUFHLGNBQWMsUUFBUSxDQUFDLEtBQUs7V0FDeEMsUUFBUSxDQUFDLEdBQUcsd0JBQXdCLFFBQVEsQ0FBQyxlQUFlO1dBQzVELFFBQVEsQ0FBQyxHQUFHLDBCQUEwQixRQUFRLENBQUMsaUJBQWlCO1dBQ2hFLFFBQVEsQ0FBQyxHQUFHLHVCQUF1QixRQUFRLENBQUMsY0FBYztXQUMxRCxRQUFRLENBQUMsR0FBRyxzQkFBc0IsUUFBUSxDQUFDLGFBQWE7V0FDeEQsUUFBUSxDQUFDLEdBQUcscUJBQXFCLFFBQVEsQ0FBQyxZQUFZO1dBQ3RELFFBQVEsQ0FBQyxHQUFHLHNCQUFzQixRQUFRLENBQUMsYUFBYTtXQUN4RCxRQUFRLENBQUMsR0FBRyxxQkFBcUIsUUFBUSxDQUFDLFlBQVk7V0FDdEQsUUFBUSxDQUFDLEdBQUcsdUJBQXVCLFFBQVEsQ0FBQyxjQUFjO1dBQzFELFFBQVEsQ0FBQyxHQUFHLDBCQUEwQixRQUFRLENBQUMsaUJBQWlCO1dBQ2hFLFFBQVEsQ0FBQyxHQUFHLG1CQUFtQixRQUFRLENBQUMsVUFBVTtXQUNsRCxRQUFRLENBQUMsR0FBRyxpQkFBaUIsUUFBUSxDQUFDLFFBQVE7V0FDOUMsUUFBUSxDQUFDLEdBQUcsaUJBQWlCLFFBQVEsQ0FBQyxRQUFRO1dBQzlDLFFBQVEsQ0FBQyxHQUFHLHVCQUF1QixRQUFRLENBQUMsY0FBYztXQUMxRCxRQUFRLENBQUMsR0FBRyxzQkFBc0IsUUFBUSxDQUFDLGFBQWE7V0FDeEQsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7V0FDaEUsUUFBUSxDQUFDLEdBQUcsa0JBQWtCLFFBQVEsQ0FBQyxTQUFTO1dBQ2hELFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRyx3QkFBd0IsUUFBUSxDQUFDLGlCQUFpQjtXQUM5RCxRQUFRLENBQUMsR0FBRyxjQUFjLFFBQVEsQ0FBQyxLQUFLOztNQUU3QyxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV6QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEVBQzNDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFXLGlCQUFpQixDQUFDLENBQUMsQ0FDNUQsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxXQUFtQixFQUFFLE9BQWdCO1FBQ3BFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFdBQVc7O01BRWhCLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLEdBQUcsV0FBVyxVQUFVLENBQUMsQ0FBQyxFQUNsRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQzFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFTLGdCQUFnQixDQUFDLENBQUMsQ0FDekQsQ0FBQztJQUNOLENBQUM7SUFFRCxhQUFhLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUMvQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7c0RBQ2dDLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7TUF5QjNELENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLEVBQzVDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLGVBQWUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNqRSxDQUFDO0lBQ04sQ0FBQztJQUVELFlBQVksQ0FBQyxVQUFrQixFQUFFLFNBQW9CLEVBQUUsT0FBZ0I7UUFDbkUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OzhCQUtRLFNBQVMsQ0FBQyxJQUFJO2lDQUNYLFNBQVMsQ0FBQyxPQUFPO2tDQUNoQixTQUFTLENBQUMsUUFBUTt1Q0FDYixTQUFTLENBQUMsYUFBYTs4QkFDaEMsU0FBUyxDQUFDLElBQUk7OEJBQ2QsU0FBUyxDQUFDLElBQUk7c0NBQ04sU0FBUyxDQUFDLFlBQVk7OEJBQzlCLFNBQVMsQ0FBQyxJQUFJO2tDQUNWLFNBQVMsQ0FBQyxRQUFRO3FDQUNmLFNBQVMsQ0FBQyxXQUFXO21DQUN2QixTQUFTLENBQUMsU0FBUztrQ0FDcEIsU0FBUyxDQUFDLFlBQVk7Z0NBQ3hCLFNBQVMsQ0FBQyxNQUFNO2tDQUNkLFNBQVMsQ0FBQyxRQUFRO2tDQUNsQixTQUFTLENBQUMsUUFBUTtrQ0FDbEIsU0FBUyxDQUFDLFFBQVE7c0NBQ2QsU0FBUyxDQUFDLFlBQVk7MkNBQ2pCLFNBQVMsQ0FBQyxpQkFBaUI7cUNBQ2pDLFNBQVMsQ0FBQyxXQUFXO3NDQUNwQixTQUFTLENBQUMsWUFBWTs2QkFDL0IsU0FBUyxDQUFDLEdBQUc7K0JBQ1gsU0FBUyxDQUFDLEtBQUs7O01BRXhDLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQyxDQUFDLEVBQ25ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsRUFDeEMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVksZUFBZSxDQUFDLENBQUMsQ0FDM0QsQ0FBQztJQUNOLENBQUM7SUFFRCxlQUFlLENBQUMsU0FBb0IsRUFBRSxPQUFnQjtRQUNsRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxTQUFTLENBQUMsR0FBRyxhQUFhLFNBQVMsQ0FBQyxJQUFJO1dBQ3hDLFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsUUFBUTtXQUNoRCxTQUFTLENBQUMsR0FBRyxzQkFBc0IsU0FBUyxDQUFDLGFBQWE7V0FDMUQsU0FBUyxDQUFDLEdBQUcsYUFBYSxTQUFTLENBQUMsSUFBSTtXQUN4QyxTQUFTLENBQUMsR0FBRyxhQUFhLFNBQVMsQ0FBQyxJQUFJO1dBQ3hDLFNBQVMsQ0FBQyxHQUFHLHFCQUFxQixTQUFTLENBQUMsWUFBWTtXQUN4RCxTQUFTLENBQUMsR0FBRyxhQUFhLFNBQVMsQ0FBQyxJQUFJO1dBQ3hDLFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsUUFBUTtXQUNoRCxTQUFTLENBQUMsR0FBRyxvQkFBb0IsU0FBUyxDQUFDLFdBQVc7V0FDdEQsU0FBUyxDQUFDLEdBQUcsa0JBQWtCLFNBQVMsQ0FBQyxTQUFTO1dBQ2xELFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsWUFBWTtXQUNwRCxTQUFTLENBQUMsR0FBRyxlQUFlLFNBQVMsQ0FBQyxNQUFNO1dBQzVDLFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixTQUFTLENBQUMsUUFBUTtXQUNoRCxTQUFTLENBQUMsR0FBRyxpQkFBaUIsU0FBUyxDQUFDLFFBQVE7V0FDaEQsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxRQUFRO1dBQ2hELFNBQVMsQ0FBQyxHQUFHLHFCQUFxQixTQUFTLENBQUMsWUFBWTtXQUN4RCxTQUFTLENBQUMsR0FBRywwQkFBMEIsU0FBUyxDQUFDLGlCQUFpQjtXQUNsRSxTQUFTLENBQUMsR0FBRyxvQkFBb0IsU0FBUyxDQUFDLFdBQVc7V0FDdEQsU0FBUyxDQUFDLEdBQUcscUJBQXFCLFNBQVMsQ0FBQyxZQUFZO1dBQ3hELFNBQVMsQ0FBQyxHQUFHLFlBQVksU0FBUyxDQUFDLEdBQUc7V0FDdEMsU0FBUyxDQUFDLEdBQUcsY0FBYyxTQUFTLENBQUMsS0FBSzs7TUFFL0MsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxFQUM1QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBWSxrQkFBa0IsQ0FBQyxDQUFDLENBQzlELENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFVBQWtCLEVBQUUsWUFBb0IsRUFBRSxPQUFnQjtRQUN0RSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxZQUFZOztNQUVqQixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUUxRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLFlBQVksVUFBVSxDQUFDLENBQUMsRUFDbkUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxFQUMzQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUyxpQkFBaUIsQ0FBQyxDQUFDLENBQzFELENBQUM7SUFDTixDQUFDO0lBRUQsbUJBQW1CLENBQUMsV0FBbUIsRUFBRSxPQUFnQjtRQUNyRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7bURBQzZCLFdBQVc7Ozs7Ozs7Ozs7Ozs7OztNQWV4RCxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2Q0FBNkMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBaUIsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQ3pDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFZLHNCQUFzQixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3RFLENBQUM7SUFDTixDQUFDO0lBRUQsU0FBUyxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDM0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO2tEQUM0QixXQUFXOzs7Ozs7Ozs7Ozs7TUFZdkQsQ0FBQztRQUVDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQ3BELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFlLENBQUMsRUFDaEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxFQUN4QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBVSxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDekQsQ0FBQztJQUNOLENBQUM7SUFFRCxRQUFRLENBQUMsVUFBa0IsRUFBRSxLQUFZLEVBQUUsT0FBZ0I7UUFDdkQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7Ozs7OzBCQUtJLEtBQUssQ0FBQyxJQUFJOzZCQUNQLEtBQUssQ0FBQyxPQUFPOzhCQUNaLEtBQUssQ0FBQyxRQUFROzBCQUNsQixLQUFLLENBQUMsSUFBSTtpQ0FDSCxLQUFLLENBQUMsV0FBVzsrQkFDbkIsS0FBSyxDQUFDLFNBQVM7eUJBQ3JCLEtBQUssQ0FBQyxHQUFHOzJCQUNQLEtBQUssQ0FBQyxLQUFLO21DQUNILEtBQUssQ0FBQyxhQUFhOztNQUVoRCxDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV6QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUMvQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUNwQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBUSxXQUFXLENBQUMsQ0FBQyxDQUNuRCxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxLQUFZLEVBQUUsT0FBZ0I7UUFDdEMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFDdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsS0FBSyxDQUFDLEdBQUcsYUFBYSxLQUFLLENBQUMsSUFBSTtXQUNoQyxLQUFLLENBQUMsR0FBRyxpQkFBaUIsS0FBSyxDQUFDLFFBQVE7V0FDeEMsS0FBSyxDQUFDLEdBQUcsYUFBYSxLQUFLLENBQUMsSUFBSTtXQUNoQyxLQUFLLENBQUMsR0FBRyxvQkFBb0IsS0FBSyxDQUFDLFdBQVc7V0FDOUMsS0FBSyxDQUFDLEdBQUcsa0JBQWtCLEtBQUssQ0FBQyxTQUFTO1dBQzFDLEtBQUssQ0FBQyxHQUFHLFlBQVksS0FBSyxDQUFDLEdBQUc7V0FDOUIsS0FBSyxDQUFDLEdBQUcsY0FBYyxLQUFLLENBQUMsS0FBSztXQUNsQyxLQUFLLENBQUMsR0FBRyxzQkFBc0IsS0FBSyxDQUFDLGFBQWE7O01BRXZELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQy9DLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsRUFDeEMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVEsY0FBYyxDQUFDLENBQUMsQ0FDdEQsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxRQUFnQixFQUFFLE9BQWdCO1FBQzlELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFFBQVE7O01BRWIsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFdEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxRQUFRLFVBQVUsQ0FBQyxDQUFDLEVBQy9ELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsYUFBYSxDQUFDLENBQUMsQ0FDdEQsQ0FBQztJQUNOLENBQUM7SUFFRCxzQkFBc0IsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQ3hELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLGlCQUFpQixHQUNuQiwrU0FBK1MsQ0FBQztRQUNwVCxNQUFNLGtCQUFrQixHQUNwQiw0TUFBNE0sQ0FBQztRQUNqTixNQUFNLGVBQWUsR0FBRywyQ0FBMkMsQ0FBQztRQUNwRSxNQUFNLGtCQUFrQixHQUNwQiw4RkFBOEYsQ0FBQztRQUVuRyxNQUFNLEtBQUssR0FBRzttREFDNkIsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQW1CbEQsaUJBQWlCO1lBQ2pCLGtCQUFrQjtZQUNsQixlQUFlO1lBQ2Ysa0JBQWtCOzs7TUFHeEIsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkNBQTZDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFbEUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWlCLENBQUMsRUFDbEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUN6QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBWSx5QkFBeUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUN6RSxDQUFDO0lBQ04sQ0FBQztJQUVELFlBQVksQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQzlDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLGlCQUFpQixHQUNuQiwwU0FBMFMsQ0FBQztRQUMvUyxNQUFNLGtCQUFrQixHQUNwQix1TUFBdU0sQ0FBQztRQUM1TSxNQUFNLGVBQWUsR0FBRywyQ0FBMkMsQ0FBQztRQUNwRSxNQUFNLGtCQUFrQixHQUNwQiw4RkFBOEYsQ0FBQztRQUVuRyxNQUFNLEtBQUssR0FBRztrREFDNEIsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1VBcUJuRCxpQkFBaUI7VUFDakIsa0JBQWtCO1VBQ2xCLGVBQWU7VUFDZixrQkFBa0I7O01BRXRCLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBa0IsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEVBQzNDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFhLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUMvRCxDQUFDO0lBQ04sQ0FBQztJQUVILFdBQVcsQ0FBQyxVQUFrQixFQUFFLFFBQWtCLEVBQ2hELFlBQWtCLEVBQUUsWUFBa0IsRUFBRSxTQUFlLEVBQUUsWUFBa0IsRUFDM0UsT0FBZ0I7UUFDWixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUV0RCxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7UUFFZixLQUFLLEdBQUc7Ozs2QkFHYSxRQUFRLENBQUMsSUFBSTs2QkFDYixRQUFRLENBQUMsSUFBSTs7O3FDQUdMLFFBQVEsQ0FBQyxZQUFZO3FDQUNyQixRQUFRLENBQUMsWUFBWTtnQ0FDMUIsUUFBUSxDQUFDLE9BQU87aUNBQ2YsUUFBUSxDQUFDLFFBQVE7b0NBQ2QsUUFBUSxDQUFDLFdBQVc7K0JBQ3pCLFFBQVEsQ0FBQyxNQUFNOzBDQUNKLFFBQVEsQ0FBQyxpQkFBaUI7aUNBQ25DLFFBQVEsQ0FBQyxRQUFROzBDQUNSLFFBQVEsQ0FBQyxpQkFBaUI7V0FDekQsVUFBVTs7TUFFZixDQUFDO1FBQ0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV6QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQzFELEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUNsRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUN0QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBVyxjQUFjLENBQUMsQ0FBQyxDQUN6RCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxRQUFrQixFQUFFLE9BQWdCO1FBQy9DLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLFFBQVEsQ0FBQyxHQUFHLG9CQUFvQixRQUFRLENBQUMsV0FBVztXQUNwRCxRQUFRLENBQUMsR0FBRyxlQUFlLFFBQVEsQ0FBQyxNQUFNO1dBQzFDLFFBQVEsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLENBQUMsUUFBUTtXQUM5QyxRQUFRLENBQUMsR0FBRywwQkFBMEIsUUFBUSxDQUFDLGlCQUFpQjtXQUNoRSxRQUFRLENBQUMsR0FBRyxpQkFBaUIsUUFBUSxDQUFDLFFBQVE7V0FDOUMsUUFBUSxDQUFDLEdBQUcsMEJBQTBCLFFBQVEsQ0FBQyxpQkFBaUI7O01BRXJFLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVcsZ0JBQWdCLENBQUMsQ0FBQyxDQUMzRCxDQUFDO0lBQ04sQ0FBQztJQUVELGNBQWMsQ0FBQyxVQUFrQixFQUFFLFFBQWtCLEVBQUUsT0FBZ0I7UUFDbkUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXdCLENBQUM7UUFFdEQsTUFBTSxLQUFLLEdBQUc7O1dBRVgsUUFBUSxDQUFDLEdBQUc7V0FDWixVQUFVLHlCQUF5QixRQUFRLENBQUMsR0FBRzs7TUFFcEQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsa0JBQWtCLENBQUMsQ0FBQyxFQUM1RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQzFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFTLGdCQUFnQixDQUFDLENBQUMsQ0FDekQsQ0FBQztJQUNOLENBQUM7SUFFRDs7O09BR0c7SUFDSCw2QkFBNkIsQ0FBQyxXQUFtQixFQUFFLE9BQWdCO1FBQy9ELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxNQUFNLEtBQUssR0FBRztzQkFDQSxXQUFXOzs7Ozs7OztNQVEzQixDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQWtCLENBQUMsRUFDbkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxFQUM5QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYSwrQkFBK0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNoRixDQUFDO0lBQ04sQ0FBQztJQUVEOzs7T0FHRztJQUNILDhCQUE4QixDQUFDLFlBQW9CLEVBQUUsT0FBZ0I7UUFDakUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO3NCQUNBLFlBQVk7Ozs7Ozs7O01BUTVCLENBQUM7UUFFQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBa0IsQ0FBQyxFQUNuRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEVBQzlDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFhLGdDQUFnQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ2pGLENBQUM7SUFDTixDQUFDO0lBRUQsZUFBZSxDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDakQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO2tEQUM0QixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7TUFldkQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFdEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQXFCLENBQUMsRUFDdEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxFQUM5QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBZ0IsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDckUsQ0FBQztJQUNOLENBQUM7SUFFRCxjQUFjLENBQUMsVUFBa0IsRUFBRSxXQUF3QixFQUFFLE9BQWdCO1FBQ3pFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOzs7Z0NBR1UsV0FBVyxDQUFDLElBQUk7Z0NBQ2hCLFdBQVcsQ0FBQyxJQUFJOzs7dUNBR1QsV0FBVyxDQUFDLFdBQVc7a0NBQzVCLFdBQVcsQ0FBQyxNQUFNO29DQUNoQixXQUFXLENBQUMsUUFBUTtpQ0FDdkIsV0FBVyxDQUFDLEtBQUs7bUNBQ2YsV0FBVyxDQUFDLE9BQU87b0NBQ2xCLFdBQVcsQ0FBQyxRQUFRO1dBQzdDLFVBQVU7O01BRWYsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsV0FBVyxDQUFDLENBQUMsRUFDckQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUN6QyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYyxnQkFBZ0IsQ0FBQyxDQUFDLENBQzlELENBQUM7SUFDTixDQUFDO0lBRUQsaUJBQWlCLENBQUMsV0FBd0IsRUFBRSxPQUFnQjtRQUN4RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxXQUFXLENBQUMsR0FBRyxhQUFhLFdBQVcsQ0FBQyxJQUFJO1dBQzVDLFdBQVcsQ0FBQyxHQUFHLGFBQWEsV0FBVyxDQUFDLElBQUk7V0FDNUMsV0FBVyxDQUFDLEdBQUcsb0JBQW9CLFdBQVcsQ0FBQyxXQUFXO1dBQzFELFdBQVcsQ0FBQyxHQUFHLG1CQUFtQixXQUFXLENBQUMsTUFBTTtXQUNwRCxXQUFXLENBQUMsR0FBRyxxQkFBcUIsV0FBVyxDQUFDLFFBQVE7V0FDeEQsV0FBVyxDQUFDLEdBQUcsY0FBYyxXQUFXLENBQUMsS0FBSztXQUM5QyxXQUFXLENBQUMsR0FBRyxpQkFBaUIsV0FBVyxDQUFDLFFBQVE7O01BRXpELENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxDQUFDLEVBQ3JELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUMsRUFDN0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsbUJBQW1CLENBQUMsQ0FBQyxDQUNqRSxDQUFDO0lBQ04sQ0FBQztJQUVELGlCQUFpQixDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxPQUFnQjtRQUMxRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQztRQUN0RCxNQUFNLEtBQUssR0FBRzs7V0FFWCxjQUFjO1dBQ2QsVUFBVSw0QkFBNEIsY0FBYzs7TUFFekQsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxjQUFjLFVBQVUsQ0FBQyxDQUFDLEVBQ3JFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUMsRUFDN0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQVMsbUJBQW1CLENBQUMsQ0FBQyxDQUM1RCxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUFDLFdBQW1CLEVBQUUsT0FBZ0I7UUFDbEQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBQ3RDLE1BQU0sS0FBSyxHQUFHO2tEQUM0QixXQUFXOzs7Ozs7OztNQVF2RCxDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV2RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBOEIsQ0FBQyxFQUMvRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLEVBQy9DLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUF5QixtQkFBbUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUNoRixDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUNaLFVBQWtCLEVBQ2xCLGFBQW1DLEVBQ25DLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBRXRELE1BQU0sS0FBSyxHQUFHOzs7OztrQ0FLWSxhQUFhLENBQUMsV0FBVztXQUNoRCxVQUFVOztNQUVmLENBQUM7UUFDQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FDMUQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxDQUFDLEVBQ3ZELEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQXVCLGtCQUFrQixDQUFDLENBQUMsQ0FDekUsQ0FBQztJQUNOLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxhQUFtQyxFQUFFLE9BQWdCO1FBQ3JFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDO1FBQ3RELE1BQU0sS0FBSyxHQUFHOztXQUVYLGFBQWEsQ0FBQyxHQUFHLG9CQUFvQixhQUFhLENBQUMsV0FBVzs7TUFFbkUsQ0FBQztRQUNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMxRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDLENBQUMsRUFDdkQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxFQUMvQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBdUIscUJBQXFCLENBQUMsQ0FBQyxDQUM1RSxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxVQUFrQixFQUFFLGNBQXNCLEVBQUUsV0FBbUIsRUFBRSxPQUFnQjtRQUN6RixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsdU9BQXVPO1FBQ3ZPLGlMQUFpTDtRQUVqTCxNQUFNLEtBQUssR0FBRzttREFDNkIsVUFBVSxJQUFJLGNBQWM7K0NBQ2hDLFdBQVc7Ozs7Ozs7TUFPcEQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFcEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ3ZFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWMsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQy9ELENBQUM7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLFVBQWtCLEVBQUUsY0FBc0IsRUFBRSxFQUFVLEVBQUUsT0FBZ0I7UUFDbEYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO21EQUM2QixVQUFVLElBQUksY0FBYzsyREFDcEIsRUFBRTs7Ozs7OztNQU92RCxDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV0RCxpTkFBaU47UUFDak4sT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYyxlQUFlLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDakUsQ0FBQztJQUNOLENBQUM7SUFFRCxxQkFBcUIsQ0FDakIsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsTUFBYyxFQUNkLE9BQWdCO1FBRWhCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQztRQUV0QyxvTEFBb0w7UUFDcEwsTUFBTSxLQUFLLEdBQUc7bURBQzZCLFVBQVUsSUFBSSxjQUFjOzJEQUNwQixNQUFNOzs7Ozs7O01BTzNELENBQUM7UUFFQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXJDLGlOQUFpTjtRQUNqTixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFNLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBbUIsQ0FBQyxFQUNwRCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQzFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFjLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3pFLENBQUM7SUFDTixDQUFDO0lBRUQsa0JBQWtCLENBQ2QsVUFBa0IsRUFDbEIsY0FBc0IsRUFDdEIsTUFBYyxFQUNkLElBQVksRUFDWixPQUFnQjtRQUVoQixJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFFdEMsb0xBQW9MO1FBQ3BMLE1BQU0sS0FBSyxHQUFHO21EQUM2QixVQUFVLElBQUksY0FBYzsyREFDcEIsTUFBTSxxQkFBcUIsSUFBSTs7Ozs7OztNQU9wRixDQUFDO1FBRUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVyQyxpTkFBaU47UUFDak4sT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYyxvQkFBb0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUN0RSxDQUFDO0lBQ04sQ0FBQztJQUVELHdCQUF3QixDQUFDLFVBQWtCLEVBQUUsT0FBZ0I7UUFDekQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsUUFBUSxDQUFDO1FBRXRDLE1BQU0sS0FBSyxHQUFHO2tEQUM0QixVQUFVOzs7Ozs7Ozs7TUFTdEQsQ0FBQztRQUVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFaEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQW1CLENBQUMsRUFDcEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBYywwQkFBMEIsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUM1RSxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUFDLE9BQWdCO1FBQzdCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFDL0MsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUc7Ozs7OztNQU1oQixDQUFDO1FBRUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FDcEQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQXNCLENBQUMsRUFDdkQsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ25FLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUMsRUFDL0MsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQWlCLGtCQUFrQixFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQ3ZFLENBQUM7SUFDTixDQUFDO0lBRUQsUUFBUSxDQUFDLFVBQWtCLEVBQUUsT0FBZ0I7UUFDekMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQztRQUVqQixJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDNUIsS0FBSyxHQUFHLE1BQU0sQ0FBQztTQUNsQjthQUFNLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRTtZQUNuQyxLQUFLLEdBQUcsTUFBTSxDQUFDO1NBQ2xCO2FBQU0sSUFBSSxVQUFVLElBQUksWUFBWSxFQUFFO1lBQ25DLEtBQUssR0FBRyxNQUFNLENBQUM7U0FDbEI7YUFBTTtZQUNILEtBQUssR0FBRyxVQUFVLENBQUM7U0FDdEI7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQsY0FBYyxDQUFDLFVBQWtCLEVBQUUsT0FBZ0I7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztRQUVsQixvQkFBb0I7UUFDcEIsOEJBQThCO1FBQzlCLDZCQUE2QjtRQUU3QixJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDNUIsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTSxJQUFJLFVBQVUsSUFBSSxZQUFZLEVBQUU7WUFDbkMsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUI7YUFBTTtZQUNILE1BQU0sR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztTQUN6QjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxPQUFnQjtRQUM5QyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN6QixJQUFJLENBQUMsT0FBTztnQkFBRSxNQUFNLElBQUksS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7U0FDckQ7SUFDSCxDQUFDO0lBQ0Q7Ozs7O09BS0c7SUFDSyxXQUFXLENBQUksU0FBUyxHQUFHLFdBQVcsRUFBRSxNQUFVO1FBQ3RELE9BQU8sQ0FBQyxLQUFVLEVBQWlCLEVBQUU7WUFDakMsOERBQThEO1lBQzlELE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLFlBQVksS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUVwRSx5REFBeUQ7WUFDekQsT0FBTyxFQUFFLENBQUMsTUFBVyxDQUFDLENBQUM7UUFDM0IsQ0FBQyxDQUFDO0lBQ04sQ0FBQztDQUNKIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgICBEYXRhU3RvcmUsXG4gICAgR2F0ZXdheSxcbiAgICBHYXRld2F5RmlsdGVyc0NvbmZpZyxcbiAgICBNb2RlbCxcbiAgICBNb2RlbENvbmZpZyxcbiAgICBOb3RpZmljYXRpb24sXG4gICAgUGlwZWxpbmUsXG4gICAgUHJvdG9jb2wsXG4gICAgVFNSZWFkaW5nLFxufSBmcm9tICcuLi9tb2RlbC9tb2RlbHMnO1xuaW1wb3J0IHsgY2F0Y2hFcnJvciwgbWFwLCBPYnNlcnZhYmxlLCBvZiwgdGFwIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuXG5jb25zdCByb3V0ZTE6IG51bWJlcltdW10gPSBbXG4gICAgWzI1Ljc3MTA4OCwgLTgwLjE2MzQ4M10sXG4gICAgWzI3LjQzOTc3NSwgLTgwLjMyMjk5XSxcbiAgICBbMjguMzQ5NDY5LCAtODAuNzMxMTA1XSxcbiAgICBbMzAuNDAxNTY0LCAtODEuNTcxMDMzXSxcbiAgICBbMzIuMTE2NzE2LCAtODEuMTQ0MTQ3XSxcbiAgICBbMzIuODY2NTExLCAtNzkuOTk1Mzk5XSxcbiAgICBbMzQuMTkxMjI0LCAtNzcuOTUyNDE5XSxcbiAgICBbMzYuODUwMTcyLCAtNzYuMzE5MjY5XSxcbiAgICBbMzYuOTE1MDM3LCAtNzYuMzIwNjQzXSxcbiAgICBbMzkuMjYyMDI1LCAtNzYuNTQ5Mjk0XSxcbiAgICBbMzkuOTAwOTMzLCAtNzUuMTQzNDUzXSxcbiAgICBbNDAuNjkwMjYzLCAtNzQuMTUyMzc1XSxcbiAgICBbNDIuMjU5OTUxLCAtNzEuNzg5MjQ0XSxcbl07XG5cbmNvbnN0IHJvdXRlMjogbnVtYmVyW11bXSA9IFtcbiAgICBbNDcuNDkyNDcxLCAtMTIyLjI2ODg4XSxcbiAgICBbNDUuNTUyMjA3LCAtMTIyLjcyMjY0OF0sXG4gICAgWzM5LjUzMjQ2LCAtMTE5Ljc1MTUyNF0sXG4gICAgWzM3LjgwMzUyOCwgLTEyMi4zMTIxMzhdLFxuICAgIFszNy44OTkzMzIsIC0xMjEuMTY5MzA3XSxcbiAgICBbMzYuMjczMTgzLCAtMTE1LjA3MDUzNF0sXG4gICAgWzMzLjc3MDMyLCAtMTE4LjI3MzI4OV0sXG4gICAgWzM0LjEwNjAxMiwgLTExNy4zMjAyNTRdLFxuICAgIFszMy41MTU1NjQsIC0xMTIuMTYwNTY0XSxcbiAgICBbMzIuMTI2NDM3LCAtMTEwLjg0ODMzNl0sXG4gICAgWzMxLjc1MjA4NSwgLTEwNi40ODg4ODddLFxuICAgIFszNS4wNDc1OCwgLTEwNi42NTMzNDRdLFxuICAgIFszOS43OTY5NjMsIC0xMDQuOTk1Mzc0XSxcbl07XG5cbmNvbnN0IHJvdXRlMzogbnVtYmVyW11bXSA9IFtcbiAgICBbMjkuMzAyNzI5LCAtOTguNjM4NzQ0XSxcbiAgICBbMjkuNjM4NDIxLCAtOTUuMjkyMjQ1XSxcbiAgICBbMzIuNjE1NTI1LCAtOTYuNjkzNDg1XSxcbiAgICBbMjkuOTE3ODM2LCAtOTAuMjA1MjcyXSxcbiAgICBbMzIuMjU2NDAzLCAtOTAuMTUxNTQ2XSxcbiAgICBbMzUuMDQ0ODQ5LCAtOTAuMTUzMDA2XSxcbiAgICBbMzguNTI0NjI3LCAtOTAuMjA5NTM1XSxcbiAgICBbMzkuODcwODUxLCAtODguOTEyMjg0XSxcbiAgICBbNDEuNzA1Njk0LCAtODcuNTc3MzQxXSxcbiAgICBbNDEuOTAyMzgyLCAtODkuMTAxOTMyXSxcbiAgICBbNDQuMjUxMjQzLCAtOTEuNTA5NjYzXSxcbiAgICBbNDQuOTcwMDY5LCAtOTMuMTc0NTI3XSxcbiAgICBbNDYuNzU4MTgxLCAtOTIuMDk4NzQ4XSxcbl07XG5cbmNvbnN0IGVtcHR5cm91dGU6IG51bWJlcltdW10gPSBbXTtcblxuY29uc3QgaHR0cE9wdGlvbnMgPSB7XG4gICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2dyYXBocWwrLScgfSxcbn07XG5cbmNvbnN0IGh0dHBNdXRhdGVPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9yZGYnIH0sXG59O1xuXG5leHBvcnQgY2xhc3MgR3JhcGhTZXJ2aWNlIHtcblxuICBwcml2YXRlIHJlcXVpcmVBY2NvdW50SWQgPSB0cnVlO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LCBwcm90ZWN0ZWQgZEdyYXBoVXJsOiBzdHJpbmcsIHByaXZhdGUgYWNjb3VudFJlcXVpcmVkOiBib29sZWFuKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBkR3JhcGhVcmw6ICR7dGhpcy5kR3JhcGhVcmx9IHJlcXVpcmVzIGFjY291bnQgaWRlbnRpZmllciAke2FjY291bnRSZXF1aXJlZH1gKTtcbiAgICAgIHRoaXMucmVxdWlyZUFjY291bnRJZCA9IGFjY291bnRSZXF1aXJlZDtcbiAgICAgICAgLy9jb25zdCBkR3JhcGhCYXNpY0F1dGhFbmFibGVkID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aEVuYWJsZWQ7XG4gICAgICAgIC8vaWYgKGRHcmFwaEJhc2ljQXV0aEVuYWJsZWQpIHtcbiAgICAgICAgLy8gICAgY29uc3QgZEdyYXBoQmFzaWNBdXRoID0gdGhpcy5hcHBDb25maWdTZXJ2aWNlLmRHcmFwaEJhc2ljQXV0aDtcbiAgICAgICAgLy8gICAgKHRoaXMuaHR0cE9wdGlvbnMuaGVhZGVycyA9IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9ncmFwaHFsKy0nIH0pLCB7IEF1dGhvcml6YXRpb246IGRHcmFwaEJhc2ljQXV0aCB9O1xuICAgICAgICAvLyAgICAodGhpcy5odHRwTXV0YXRlT3B0aW9ucy5oZWFkZXJzID0geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3JkZicgfSksIHsgQXV0aG9yaXphdGlvbjogZEdyYXBoQmFzaWNBdXRoIH07XG4gICAgICAgIC8vfVxuICAgIH1cblxuICAgIGdldEdhdGV3YXkoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ0dldEdhdGV3YXkgc2VydmljZSBjYWxsZWQgZm9yOiAnLCBnYXRld2F5TmFtZSk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWQgZGVzY3JpcHRpb24gYWRkcmVzcyByb3V0ZXIgcm91dGVyUG9ydCBkZXBsb3lOZXR3b3JrIGxhdGl0dWRlIGxvbmdpdHVkZSBhY2Nlc3NUb2tlbiB1c2VybmFtZSBwbGF0Zm9ybSBkZXZpY2VzTWV0YWRhdGEgY3JlYXRlZHRzIHVwZGF0ZWR0c1xuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiBjb25zb2xlLmxvZygnUmVzcG9uc2UgZnJvbSBnZXRHYXRld2F5OiAnLCByZXNwb25zZSkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPEdhdGV3YXlbXT4oJ2dldEdhdGV3YXknLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlzKGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zb2xlLmxvZyhgR2V0R2F0ZXdheXMgc2VydmljZSBjYWxsZWQgZm9yICR7YWNjb3VudH1gKTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIHtcbiAgICAgICAgdWlkIHV1aWQgZGVzY3JpcHRpb24gYWRkcmVzcyByb3V0ZXIgcm91dGVyUG9ydCBkZXBsb3lOZXR3b3JrIGxhdGl0dWRlIGxvbmdpdHVkZSBhY2Nlc3NUb2tlbiB1c2VybmFtZSBwbGF0Zm9ybSBkZXZpY2VzTWV0YWRhdGEgY3JlYXRlZHRzIHVwZGF0ZWR0c1xuICAgICAgICBudW1EZXZpY2VzOiBjb3VudChnYXRld2F5X2RldmljZSlcblxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgZ2F0ZXdheXMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheVtdPignZ2V0R2F0ZXdheXMnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZUdhdGV3YXkoZ2F0ZXdheTogR2F0ZXdheSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxhZGRyZXNzPiBcIiR7Z2F0ZXdheS5hZGRyZXNzfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8cm91dGVyPiBcIiR7Z2F0ZXdheS5yb3V0ZXJ9XCIgLlxuICAgICAgICA8JHtnYXRld2F5LnVpZH0+IDxyb3V0ZXJQb3J0PiBcIiR7Z2F0ZXdheS5yb3V0ZXJQb3J0fVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8ZGVwbG95TmV0d29yaz4gXCIke2dhdGV3YXkuZGVwbG95TmV0d29ya31cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPGRlc2NyaXB0aW9uPiBcIiR7Z2F0ZXdheS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPGxhdGl0dWRlPiBcIiR7Z2F0ZXdheS5sYXRpdHVkZX1cIiAuXG4gICAgICAgIDwke2dhdGV3YXkudWlkfT4gPGxvbmdpdHVkZT4gXCIke2dhdGV3YXkubG9uZ2l0dWRlfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8YWNjZXNzVG9rZW4+IFwiJHtnYXRld2F5LmFjY2Vzc1Rva2VufVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8dXNlcm5hbWU+IFwiJHtnYXRld2F5LnVzZXJuYW1lfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8cGxhdGZvcm0+IFwiJHtnYXRld2F5LnBsYXRmb3JtfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheS51aWR9PiA8dXBkYXRlZHRzPiBcIiR7Z2F0ZXdheS51cGRhdGVkdHN9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnVXBkYXRlIEdhdGV3YXkgTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKCgpID0+ICdnYXRld2F5IHVwZGF0ZWQnKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygndXBkYXRlZCBnYXRld2F5JykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPHN0cmluZz4oJ3VwZGF0ZUdhdGV3YXknKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgYWRkR2F0ZXdheShnYXRld2F5OiBHYXRld2F5LCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5PiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICBfOkdhdGV3YXkgPGRncmFwaC50eXBlPiBcIkdhdGV3YXlcIiAuXG4gICAgICAgIF86R2F0ZXdheSA8Z2F0ZXdheT4gXCJcIiAuXG4gICAgICAgIF86R2F0ZXdheSA8dHlwZT4gXCJnYXRld2F5XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHV1aWQ+IFwiJHtnYXRld2F5LnV1aWR9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGRlc2NyaXB0aW9uPiBcIiR7Z2F0ZXdheS5kZXNjcmlwdGlvbn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8YWRkcmVzcz4gXCIke2dhdGV3YXkuYWRkcmVzc31cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8cm91dGVyPiBcIiR7Z2F0ZXdheS5yb3V0ZXJ9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPHJvdXRlclBvcnQ+IFwiJHtnYXRld2F5LnJvdXRlclBvcnR9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGRlcGxveU5ldHdvcms+IFwiJHtnYXRld2F5LmRlcGxveU5ldHdvcmt9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGxhdGl0dWRlPiBcIiR7Z2F0ZXdheS5sYXRpdHVkZX1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8bG9uZ2l0dWRlPiBcIiR7Z2F0ZXdheS5sb25naXR1ZGV9XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGFjY2Vzc1Rva2VuPiBcIiR7Z2F0ZXdheS5hY2Nlc3NUb2tlbn1cIiAuXG4gICAgICAgIF86R2F0ZXdheSA8dXNlcm5hbWU+IFwiJHtnYXRld2F5LnVzZXJuYW1lfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDxwbGF0Zm9ybT4gXCIke2dhdGV3YXkucGxhdGZvcm19XCIgLlxuICAgICAgICBfOkdhdGV3YXkgPGNyZWF0ZWR0cz4gXCIke2dhdGV3YXkuY3JlYXRlZHRzfVwiIC5cbiAgICAgICAgXzpHYXRld2F5IDx1cGRhdGVkdHM+IFwiJHtnYXRld2F5LnVwZGF0ZWR0c31cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdBZGQgR2F0ZXdheSBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gZ2F0ZXdheSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdhZGQgZ2F0ZXdheScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5PignYWRkR2F0ZXdheScpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVHYXRld2F5KGdhdGV3YXlVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtnYXRld2F5VWlkfT4gKiAqIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBHYXRld2F5IE11dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgoKSA9PiBgJHtnYXRld2F5VWlkfSBkZWxldGVkYCksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgZ2F0ZXdheScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxzdHJpbmc+KCdkZWxldGVHYXRld2F5JykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldEdhdGV3YXlBbmRQcm90b2NvbHMoZ2F0ZXdheU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8R2F0ZXdheVtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGdhdGV3YXkpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtnYXRld2F5TmFtZX1cIikpIHtcbiAgICAgICAgdWlkIHV1aWRcbiAgICAgICAgcHJvdG9jb2xzOiBnYXRld2F5X3Byb3RvY29sIHtcbiAgICAgICAgICB1aWRcbiAgICAgICAgICB1dWlkXG4gICAgICAgICAgY3JlYXRlZFxuICAgICAgICAgIG1vZGlmaWVkXG4gICAgICAgICAgcHJvdG9jb2xUeXBlXG4gICAgICAgICAgYnJva2VyVVJMXG4gICAgICAgICAgdG9waWNcbiAgICAgICAgICBjb25zdW1lckdyb3VwSWRcbiAgICAgICAgICBjb25uZWN0aW9uVGltZW91dFxuICAgICAgICAgIHNlc3Npb25UaW1lb3V0XG4gICAgICAgICAgaW5pdGlhbE9mZnNldFxuICAgICAgICAgIHJldHJ5QmFja29mZlxuICAgICAgICAgIGZldGNoTWluQnl0ZXNcbiAgICAgICAgICBmZXRjaE1heFdhaXRcbiAgICAgICAgICBjb21taXRJbnRlcnZhbFxuICAgICAgICAgIGhlYXJ0YmVhdEludGVydmFsXG4gICAgICAgICAgbWF4aW11bVFPU1xuICAgICAgICAgIHVzZXJuYW1lXG4gICAgICAgICAgcGFzc3dvcmRcbiAgICAgICAgICBlbmNyeXB0aW9uTW9kZVxuICAgICAgICAgIGNhQ2VydGlmaWNhdGVcbiAgICAgICAgICBjbGllbnRDZXJ0aWZpY2F0ZVxuICAgICAgICAgIGNsaWVudEtleVxuICAgICAgICAgIGF1dGhNb2RlXG4gICAgICAgICAgc2VydmVyQ2VydGljYXRlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0dldCBHYXRld2F5IGFuZCBQcm90b2NvbHMgcXVlcnkgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgR2F0ZXdheVtdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBHYXRld2F5JykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPEdhdGV3YXlbXT4oJ2dldEdhdGV3YXlXaXRoUHJvdG9jb2xzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgYWxsIGdsb2JhbCBwcm90b2NvbHMgYW5kIHRoZSBwcm90b2NvbHMgc2NvcGVkIGZvciB0aGUgZ2F0ZXdheVxuICAgICAqIEBwYXJhbSBnYXRld2F5TmFtZVxuICAgICAqIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSBBTkQgbHQoY3JlYXRlZCwgJHt0b3RzfSkpIChmaXJzdDotNTAwKVxuICAgICAqL1xuICAgIGdldFByb3RvY29scyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQcm90b2NvbFtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKHByb3RvY29sKSkgQGZpbHRlcihlcShzY29wZSwgXCIke2dhdGV3YXlOYW1lfVwiKSBPUiBlcShzY29wZSwgXCJHTE9CQUxcIikpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIHV1aWRcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICBtb2RpZmllZFxuICAgICAgICBwcm90b2NvbFR5cGVcbiAgICAgICAgYnJva2VyVVJMXG4gICAgICAgIHRvcGljXG4gICAgICAgIGNvbnN1bWVyR3JvdXBJZFxuICAgICAgICBjb25uZWN0aW9uVGltZW91dFxuICAgICAgICBzZXNzaW9uVGltZW91dFxuICAgICAgICBpbml0aWFsT2Zmc2V0XG4gICAgICAgIHJldHJ5QmFja29mZlxuICAgICAgICBmZXRjaE1pbkJ5dGVzXG4gICAgICAgIGZldGNoTWF4V2FpdFxuICAgICAgICBjb21taXRJbnRlcnZhbFxuICAgICAgICBoZWFydGJlYXRJbnRlcnZhbFxuICAgICAgICBtYXhpbXVtUU9TXG4gICAgICAgIHVzZXJuYW1lXG4gICAgICAgIHBhc3N3b3JkXG4gICAgICAgIGVuY3J5cHRpb25Nb2RlXG4gICAgICAgIGNhQ2VydGlmaWNhdGVcbiAgICAgICAgY2xpZW50Q2VydGlmaWNhdGVcbiAgICAgICAgY2xpZW50S2V5XG4gICAgICAgIGF1dGhNb2RlXG4gICAgICAgIHNlcnZlckNlcnRpY2F0ZVxuICAgICAgICBzY29wZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFByb3RvY29sW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHByb3RvY29scycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQcm90b2NvbFtdPignZ2V0UHJvdG9jb2xzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRQcm90b2NvbChnYXRld2F5VWlkOiBudW1iZXIsIHByb3RvY29sOiBQcm90b2NvbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2w+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UHJvdG9jb2wgPGRncmFwaC50eXBlPiBcIlByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDx0eXBlPiBcInByb3RvY29sXCIgLlxuICAgICAgICBfOlByb3RvY29sIDxwcm90b2NvbD4gXCJcIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPHV1aWQ+IFwiJHtwcm90b2NvbC51dWlkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8Y3JlYXRlZD4gXCIke3Byb3RvY29sLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxtb2RpZmllZD4gXCIke3Byb3RvY29sLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8cHJvdG9jb2xUeXBlPiBcIiR7cHJvdG9jb2wucHJvdG9jb2xUeXBlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8YnJva2VyVVJMPiBcIiR7cHJvdG9jb2wuYnJva2VyVVJMfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8dG9waWM+IFwiJHtwcm90b2NvbC50b3BpY31cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNvbnN1bWVyR3JvdXBJZD4gXCIke3Byb3RvY29sLmNvbnN1bWVyR3JvdXBJZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNvbm5lY3Rpb25UaW1lb3V0PiBcIiR7cHJvdG9jb2wuY29ubmVjdGlvblRpbWVvdXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxzZXNzaW9uVGltZW91dD4gXCIke3Byb3RvY29sLnNlc3Npb25UaW1lb3V0fVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8aW5pdGlhbE9mZnNldD4gXCIke3Byb3RvY29sLmluaXRpYWxPZmZzZXR9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxyZXRyeUJhY2tvZmY+IFwiJHtwcm90b2NvbC5yZXRyeUJhY2tPZmZ9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxmZXRjaE1pbkJ5dGVzPiBcIiR7cHJvdG9jb2wuZmV0Y2hNaW5CeXRlc31cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGZldGNoTWF4V2FpdD4gXCIke3Byb3RvY29sLmZldGNoTWF4V2FpdH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNvbW1pdEludGVydmFsPiBcIiR7cHJvdG9jb2wuY29tbWl0SW50ZXJ2YWx9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxoZWFydGJlYXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmhlYXJ0YmVhdEludGVydmFsfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8bWF4aW11bVFPUz4gXCIke3Byb3RvY29sLm1heGltdW1RT1N9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDx1c2VybmFtZT4gXCIke3Byb3RvY29sLnVzZXJuYW1lfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8cGFzc3dvcmQ+IFwiJHtwcm90b2NvbC5wYXNzd29yZH1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGVuY3J5cHRpb25Nb2RlPiBcIiR7cHJvdG9jb2wuZW5jcnlwdGlvbk1vZGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjYUNlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2FDZXJ0aWZpY2F0ZX1cIiAuXG4gICAgICAgIF86UHJvdG9jb2wgPGNsaWVudENlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2xpZW50Q2VydGlmaWNhdGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxjbGllbnRLZXk+IFwiJHtwcm90b2NvbC5jbGllbnRLZXl9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxhdXRoTW9kZT4gXCIke3Byb3RvY29sLmF1dGhNb2RlfVwiIC5cbiAgICAgICAgXzpQcm90b2NvbCA8c2VydmVyQ2VydGljYXRlPiBcIiR7cHJvdG9jb2wuc2VydmVyQ2VydGlmaWNhdGV9XCIgLlxuICAgICAgICBfOlByb3RvY29sIDxzY29wZT4gXCIke3Byb3RvY29sLnNjb3BlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwcm90b2NvbCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdhZGQgcHJvdG9jb2xzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFByb3RvY29sPignYWRkUHJvdG9jb2xzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZVByb3RvY29sKHByb3RvY29sOiBQcm90b2NvbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UHJvdG9jb2w+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDx1dWlkPiBcIiR7cHJvdG9jb2wudXVpZH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxtb2RpZmllZD4gXCIke3Byb3RvY29sLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHByb3RvY29sVHlwZT4gXCIke3Byb3RvY29sLnByb3RvY29sVHlwZX1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxicm9rZXJVUkw+IFwiJHtwcm90b2NvbC5icm9rZXJVUkx9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8dG9waWM+IFwiJHtwcm90b2NvbC50b3BpY31cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxjb25zdW1lckdyb3VwSWQ+IFwiJHtwcm90b2NvbC5jb25zdW1lckdyb3VwSWR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8Y29ubmVjdGlvblRpbWVvdXQ+IFwiJHtwcm90b2NvbC5jb25uZWN0aW9uVGltZW91dH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxzZXNzaW9uVGltZW91dD4gXCIke3Byb3RvY29sLnNlc3Npb25UaW1lb3V0fVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGluaXRpYWxPZmZzZXQ+IFwiJHtwcm90b2NvbC5pbml0aWFsT2Zmc2V0fVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHJldHJ5QmFja29mZj4gXCIke3Byb3RvY29sLnJldHJ5QmFja09mZn1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxmZXRjaE1pbkJ5dGVzPiBcIiR7cHJvdG9jb2wuZmV0Y2hNaW5CeXRlc31cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxmZXRjaE1heFdhaXQ+IFwiJHtwcm90b2NvbC5mZXRjaE1heFdhaXR9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8Y29tbWl0SW50ZXJ2YWw+IFwiJHtwcm90b2NvbC5jb21taXRJbnRlcnZhbH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxoZWFydGJlYXRJbnRlcnZhbD4gXCIke3Byb3RvY29sLmhlYXJ0YmVhdEludGVydmFsfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPG1heGltdW1RT1M+IFwiJHtwcm90b2NvbC5tYXhpbXVtUU9TfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPHVzZXJuYW1lPiBcIiR7cHJvdG9jb2wudXNlcm5hbWV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8cGFzc3dvcmQ+IFwiJHtwcm90b2NvbC5wYXNzd29yZH1cIiAuXG4gICAgICAgIDwke3Byb3RvY29sLnVpZH0+IDxlbmNyeXB0aW9uTW9kZT4gXCIke3Byb3RvY29sLmVuY3J5cHRpb25Nb2RlfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGNhQ2VydGlmaWNhdGU+IFwiJHtwcm90b2NvbC5jYUNlcnRpZmljYXRlfVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGNsaWVudENlcnRpZmljYXRlPiBcIiR7cHJvdG9jb2wuY2xpZW50Q2VydGlmaWNhdGV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8Y2xpZW50S2V5PiBcIiR7cHJvdG9jb2wuY2xpZW50S2V5fVwiIC5cbiAgICAgICAgPCR7cHJvdG9jb2wudWlkfT4gPGF1dGhNb2RlPiBcIiR7cHJvdG9jb2wuYXV0aE1vZGV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8c2VydmVyQ2VydGljYXRlPiBcIiR7cHJvdG9jb2wuc2VydmVyQ2VydGlmaWNhdGV9XCIgLlxuICAgICAgICA8JHtwcm90b2NvbC51aWR9PiA8c2NvcGU+IFwiJHtwcm90b2NvbC5zY29wZX1cIiAuXG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gcHJvdG9jb2wpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygndXBkYXRlZCBwcm90b2NvbHMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UHJvdG9jb2w+KCd1cGRhdGVQcm90b2NvbHMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlUHJvdG9jb2woZ2F0ZXdheVVpZDogbnVtYmVyLCBwcm90b2NvbFVpZDogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIGRlbGV0ZSB7XG4gICAgICAgIDwke3Byb3RvY29sVWlkfT4gKiAqIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBQcm90b2NvbCBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYCR7cHJvdG9jb2xVaWR9IGRlbGV0ZWRgKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgcHJvdG9jb2wnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlUHJvdG9jb2wnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0RGF0YVN0b3JlcyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxEYXRhU3RvcmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhkYXRhU3RvcmUpKSBAZmlsdGVyKGVxKHNjb3BlLCBcIiR7Z2F0ZXdheU5hbWV9XCIpIE9SIGVxKHNjb3BlLCBcIkdMT0JBTFwiKSkge1xuICAgICAgICB1aWRcbiAgICAgICAgdXVpZFxuICAgICAgICBjcmVhdGVkXG4gICAgICAgIG1vZGlmaWVkXG4gICAgICAgIGRhdGFTdG9yZVR5cGVcbiAgICAgICAgaG9zdFxuICAgICAgICBwb3J0XG4gICAgICAgIGRhdGFiYXNlTmFtZVxuICAgICAgICB1c2VyXG4gICAgICAgIHBhc3N3b3JkXG4gICAgICAgIGFjY291bnROYW1lXG4gICAgICAgIHdhcmVob3VzZVxuICAgICAgICBkYXRhYmFzZVxuICAgICAgICBzY2hlbWFcbiAgICAgICAgYXV0aFR5cGVcbiAgICAgICAgdXNlcm5hbWVcbiAgICAgICAgY2xpZW50SWRcbiAgICAgICAgY2xpZW50U2VjcmV0XG4gICAgICAgIGF1dGhvcml6YXRpb25Db2RlXG4gICAgICAgIHJlZGlyZWN0VVJJXG4gICAgICAgIGxvZ2luVGltZW91dFxuICAgICAgICB1cmxcbiAgICAgICAgc2NvcGVcbiAgICAgIH1cbiAgICB9YDtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBEYXRhU3RvcmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgZGF0YVN0b3JlcycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxEYXRhU3RvcmVbXT4oJ2dldERhdGFTdG9yZXMnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGFkZERhdGFTdG9yZShnYXRld2F5VWlkOiBudW1iZXIsIGRhdGFTdG9yZTogRGF0YVN0b3JlLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxEYXRhU3RvcmU+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86RGF0YVN0b3JlIDxkZ3JhcGgudHlwZT4gXCJEYXRhU3RvcmVcIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx0eXBlPiBcImRhdGFTdG9yZVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFTdG9yZT4gXCJcIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDx1dWlkPiBcIiR7ZGF0YVN0b3JlLnV1aWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8Y3JlYXRlZD4gXCIke2RhdGFTdG9yZS5jcmVhdGVkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPG1vZGlmaWVkPiBcIiR7ZGF0YVN0b3JlLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFTdG9yZVR5cGU+IFwiJHtkYXRhU3RvcmUuZGF0YVN0b3JlVHlwZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxob3N0PiBcIiR7ZGF0YVN0b3JlLmhvc3R9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8cG9ydD4gXCIke2RhdGFTdG9yZS5wb3J0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGRhdGFiYXNlTmFtZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXNlcj4gXCIke2RhdGFTdG9yZS51c2VyfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHBhc3N3b3JkPiBcIiR7ZGF0YVN0b3JlLnBhc3N3b3JkfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPGFjY291bnROYW1lPiBcIiR7ZGF0YVN0b3JlLmFjY291bnROYW1lfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHdhcmVob3VzZT4gXCIke2RhdGFTdG9yZS53YXJlaG91c2V9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8ZGF0YWJhc2U+IFwiJHtkYXRhU3RvcmUuZGF0YWJhc2VOYW1lfVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHNjaGVtYT4gXCIke2RhdGFTdG9yZS5zY2hlbWF9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8YXV0aFR5cGU+IFwiJHtkYXRhU3RvcmUuYXV0aFR5cGV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8dXNlcm5hbWU+IFwiJHtkYXRhU3RvcmUudXNlcm5hbWV9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8Y2xpZW50SWQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50SWR9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8Y2xpZW50U2VjcmV0PiBcIiR7ZGF0YVN0b3JlLmNsaWVudFNlY3JldH1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxhdXRob3JpemF0aW9uQ29kZT4gXCIke2RhdGFTdG9yZS5hdXRob3JpemF0aW9uQ29kZX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxyZWRpcmVjdFVSST4gXCIke2RhdGFTdG9yZS5yZWRpcmVjdFVSSX1cIiAuXG4gICAgICAgIF86RGF0YVN0b3JlIDxsb2dpblRpbWVvdXQ+IFwiJHtkYXRhU3RvcmUubG9naW5UaW1lb3V0fVwiIC5cbiAgICAgICAgXzpEYXRhU3RvcmUgPHVybD4gXCIke2RhdGFTdG9yZS51cmx9XCIgLlxuICAgICAgICBfOkRhdGFTdG9yZSA8c2NvcGU+IFwiJHtkYXRhU3RvcmUuc2NvcGV9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGRhdGFTdG9yZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdhZGQgZGF0YVN0b3JlcycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxEYXRhU3RvcmU+KCdhZGREYXRhU3RvcmVzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZURhdGFTdG9yZShkYXRhU3RvcmU6IERhdGFTdG9yZSwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8RGF0YVN0b3JlPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBzZXQge1xuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHV1aWQ+IFwiJHtkYXRhU3RvcmUudXVpZH1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8bW9kaWZpZWQ+IFwiJHtkYXRhU3RvcmUubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGRhdGFTdG9yZVR5cGU+IFwiJHtkYXRhU3RvcmUuZGF0YVN0b3JlVHlwZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8aG9zdD4gXCIke2RhdGFTdG9yZS5ob3N0fVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxwb3J0PiBcIiR7ZGF0YVN0b3JlLnBvcnR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGRhdGFiYXNlTmFtZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHVzZXI+IFwiJHtkYXRhU3RvcmUudXNlcn1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8cGFzc3dvcmQ+IFwiJHtkYXRhU3RvcmUucGFzc3dvcmR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGFjY291bnROYW1lPiBcIiR7ZGF0YVN0b3JlLmFjY291bnROYW1lfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDx3YXJlaG91c2U+IFwiJHtkYXRhU3RvcmUud2FyZWhvdXNlfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxkYXRhYmFzZT4gXCIke2RhdGFTdG9yZS5kYXRhYmFzZU5hbWV9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPHNjaGVtYT4gXCIke2RhdGFTdG9yZS5zY2hlbWF9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGF1dGhUeXBlPiBcIiR7ZGF0YVN0b3JlLmF1dGhUeXBlfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDx1c2VybmFtZT4gXCIke2RhdGFTdG9yZS51c2VybmFtZX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8Y2xpZW50SWQ+IFwiJHtkYXRhU3RvcmUuY2xpZW50SWR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGNsaWVudFNlY3JldD4gXCIke2RhdGFTdG9yZS5jbGllbnRTZWNyZXR9XCIgLlxuICAgICAgICA8JHtkYXRhU3RvcmUudWlkfT4gPGF1dGhvcml6YXRpb25Db2RlPiBcIiR7ZGF0YVN0b3JlLmF1dGhvcml6YXRpb25Db2RlfVwiIC5cbiAgICAgICAgPCR7ZGF0YVN0b3JlLnVpZH0+IDxyZWRpcmVjdFVSST4gXCIke2RhdGFTdG9yZS5yZWRpcmVjdFVSSX1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8bG9naW5UaW1lb3V0PiBcIiR7ZGF0YVN0b3JlLmxvZ2luVGltZW91dH1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8dXJsPiBcIiR7ZGF0YVN0b3JlLnVybH1cIiAuXG4gICAgICAgIDwke2RhdGFTdG9yZS51aWR9PiA8c2NvcGU+IFwiJHtkYXRhU3RvcmUuc2NvcGV9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IGRhdGFTdG9yZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCd1cGRhdGVkIGRhdGFTdG9yZXMnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8RGF0YVN0b3JlPigndXBkYXRlRGF0YVN0b3JlcycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVEYXRhU3RvcmUoZ2F0ZXdheVVpZDogbnVtYmVyLCBkYXRhU3RvcmVVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtkYXRhU3RvcmVVaWR9PiAqICogLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnRGVsZXRlIERhdGFTdG9yZSBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYCR7ZGF0YVN0b3JlVWlkfSBkZWxldGVkYCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdkZWxldGVkIGRhdGFTdG9yZScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxzdHJpbmc+KCdkZWxldGVEYXRhU3RvcmUnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0R2F0ZXdheUFuZE1vZGVscyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5W10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICB1aWQgdXVpZFxuICAgICAgICBtb2RlbHM6IGdhdGV3YXlfbW9kZWwge1xuICAgICAgICAgIHVpZFxuICAgICAgICAgIHV1aWRcbiAgICAgICAgICBjcmVhdGVkXG4gICAgICAgICAgbW9kaWZpZWRcbiAgICAgICAgICBuYW1lXG4gICAgICAgICAgZGVzY3JpcHRpb25cbiAgICAgICAgICBpbnB1dFR5cGVcbiAgICAgICAgICB1cmxcbiAgICAgICAgICBzY29wZVxuICAgICAgICAgIGlucHV0VGVtcGxhdGVcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnR2V0IEdhdGV3YXkgYW5kIFByb3RvY29scyBxdWVyeSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBHYXRld2F5W10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIEdhdGV3YXknKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheVtdPignZ2V0R2F0ZXdheVdpdGhNb2RlbHMnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldE1vZGVscyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbFtdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKG1vZGVsKSkgQGZpbHRlcihlcShzY29wZSwgXCIke2dhdGV3YXlOYW1lfVwiKSBPUiBlcShzY29wZSwgXCJHTE9CQUxcIikpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIHV1aWRcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICBtb2RpZmllZFxuICAgICAgICBuYW1lXG4gICAgICAgIGRlc2NyaXB0aW9uXG4gICAgICAgIGlucHV0VHlwZVxuICAgICAgICB1cmxcbiAgICAgICAgc2NvcGVcbiAgICAgICAgaW5wdXRUZW1wbGF0ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIE1vZGVsW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIG1vZGVscycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbFtdPignZ2V0TW9kZWxzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRNb2RlbChnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsOiBNb2RlbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWw+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86TW9kZWwgPGRncmFwaC50eXBlPiBcIk1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDx0eXBlPiBcIm1vZGVsXCIgLlxuICAgICAgICBfOk1vZGVsIDxtb2RlbD4gXCJcIiAuXG4gICAgICAgIF86TW9kZWwgPHV1aWQ+IFwiJHttb2RlbC51dWlkfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8Y3JlYXRlZD4gXCIke21vZGVsLmNyZWF0ZWR9XCIgLlxuICAgICAgICBfOk1vZGVsIDxtb2RpZmllZD4gXCIke21vZGVsLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8bmFtZT4gXCIke21vZGVsLm5hbWV9XCIgLlxuICAgICAgICBfOk1vZGVsIDxkZXNjcmlwdGlvbj4gXCIke21vZGVsLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpNb2RlbCA8aW5wdXRUeXBlPiBcIiR7bW9kZWwuaW5wdXRUeXBlfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8dXJsPiBcIiR7bW9kZWwudXJsfVwiIC5cbiAgICAgICAgXzpNb2RlbCA8c2NvcGU+IFwiJHttb2RlbC5zY29wZX1cIiAuXG4gICAgICAgIF86TW9kZWwgPGlucHV0VGVtcGxhdGU+IFwiJHttb2RlbC5pbnB1dFRlbXBsYXRlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBtb2RlbCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdhZGQgbW9kZWxzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE1vZGVsPignYWRkTW9kZWxzJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZU1vZGVsKG1vZGVsOiBNb2RlbCwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWw+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIDwke21vZGVsLnVpZH0+IDx1dWlkPiBcIiR7bW9kZWwudXVpZH1cIiAuXG4gICAgICAgIDwke21vZGVsLnVpZH0+IDxtb2RpZmllZD4gXCIke21vZGVsLm1vZGlmaWVkfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPG5hbWU+IFwiJHttb2RlbC5uYW1lfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPGRlc2NyaXB0aW9uPiBcIiR7bW9kZWwuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICA8JHttb2RlbC51aWR9PiA8aW5wdXRUeXBlPiBcIiR7bW9kZWwuaW5wdXRUeXBlfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPHVybD4gXCIke21vZGVsLnVybH1cIiAuXG4gICAgICAgIDwke21vZGVsLnVpZH0+IDxzY29wZT4gXCIke21vZGVsLnNjb3BlfVwiIC5cbiAgICAgICAgPCR7bW9kZWwudWlkfT4gPGlucHV0VGVtcGxhdGU+IFwiJHttb2RlbC5pbnB1dFRlbXBsYXRlfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBtb2RlbCkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCd1cGRhdGVkIG1vZGVscycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbD4oJ3VwZGF0ZU1vZGVscycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBkZWxldGVNb2RlbChnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgZGVsZXRlIHtcbiAgICAgICAgPCR7bW9kZWxVaWR9PiAqICogLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnRGVsZXRlIE1vZGVsIE11dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBgJHttb2RlbFVpZH0gZGVsZXRlZGApKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZGVsZXRlZCBwcm90b2NvbCcpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxzdHJpbmc+KCdkZWxldGVNb2RlbCcpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRHYXRld2F5QW5kUGlwZWxpbmVzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdhdGV3YXlbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHBpcGVsaW5lX3Byb3RvY29sID1cbiAgICAgICAgICAgICdwcm90b2NvbDogcGlwZWxpbmVfcHJvdG9jb2wge3VpZCB1dWlkIGJyb2tlclVSTCB0b3BpYyBtYXhpbXVtUU9TIHVzZXJuYW1lIHBhc3N3b3JkIGVuY3J5cHRpb25Nb2RlIGNhQ2VydGlmaWNhdGUgY2xpZW50Q2VydGlmaWNhdGUgY2xpZW50S2V5IGF1dGhNb2RlIHNlcnZlckNlcnRpY2F0ZSBjb25zdW1lckdyb3VwSWQgY29ubmVjdGlvblRpbWVvdXQgc2Vzc2lvblRpbWVvdXQgcmV0cnlCYWNrb2ZmIGNvbW1pdEludGVydmFsIGluaXRpYWxPZmZzZXQgZmV0Y2hNaW5CeXRlcyBmZXRjaE1heFdhaXQgaGVhcnRiZWF0SW50ZXJ2YWx9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZGF0YXN0b3JlID1cbiAgICAgICAgICAgICdkYXRhU3RvcmU6IHBpcGVsaW5lX2RhdGFzdG9yZSB7dWlkIHV1aWQgaG9zdCBwb3J0IGRhdGFiYXNlTmFtZSB1c2VyIHBhc3N3b3JkIGFjY291bnROYW1lIHdhcmVob3VzZSBkYXRhYmFzZSBzY2hlbWEgYXV0aFR5cGUgdXNlcm5hbWUgY2xpZW50SWQgY2xpZW50U2VjcmV0IGF1dGhvcml6YXRpb25Db2RlIHJlZGlyZWN0VVJJIGxvZ2luVGltZW91dCB1cmx9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZmlsdGVyID0gJ2ZpbHRlcjogcGlwZWxpbmVfZmlsdGVyIHt1aWQgZGV2aWNlTmFtZXN9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfc3RyZWFtaW5nID1cbiAgICAgICAgICAgICdzdHJlYW1pbmc6IHBpcGVsaW5lX3N0cmVhbWluZyB7dWlkIGRldmljZU5hbWUgaW5zdHJ1bWVudE5hbWUgZnVuY3Rpb24gd2luZG93VHlwZSB3aW5kb3dTaXplfSc7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgcmVzcChmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICB1aWQgdXVpZCBhY2Nlc3NUb2tlbiB1c2VybmFtZSBwbGF0Zm9ybSBhZGRyZXNzIHJvdXRlciByb3V0ZXJQb3J0IGRlcGxveU5ldHdvcmsgZGV2aWNlc01ldGFkYXRhXG4gICAgICAgIHBpcGVsaW5lczogZ2F0ZXdheV9waXBlbGluZSB7XG4gICAgICAgICAgdWlkXG4gICAgICAgICAgbmFtZVxuICAgICAgICAgIHV1aWRcbiAgICAgICAgICBwaXBlbGluZVR5cGVcbiAgICAgICAgICBkZXBsb3llclR5cGVcbiAgICAgICAgICBwcm90b2NvbFR5cGVcbiAgICAgICAgICBwcm90b2NvbElkXG4gICAgICAgICAgZGF0YVN0b3JlVHlwZVxuICAgICAgICAgIGRhdGFTdG9yZUlkXG4gICAgICAgICAgY3JlYXRlZFxuICAgICAgICAgIG1vZGlmaWVkXG4gICAgICAgICAgZGVzY3JpcHRpb25cbiAgICAgICAgICBzdGF0dXNcbiAgICAgICAgICBmbG93Q29uZmlndXJhdGlvblxuICAgICAgICAgIGxvZ0xldmVsXG4gICAgICAgICAgc3Vic2NyaXB0aW9uVG9waWNcbiAgICAgICAgICAke3BpcGVsaW5lX3Byb3RvY29sfVxuICAgICAgICAgICR7cGlwZWxpbmVfZGF0YXN0b3JlfVxuICAgICAgICAgICR7cGlwZWxpbmVfZmlsdGVyfVxuICAgICAgICAgICR7cGlwZWxpbmVfc3RyZWFtaW5nfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG4gICAgICAgIGNvbnNvbGUubG9nKCdHZXQgR2F0ZXdheSBhbmQgUGlwZWxpbmVzIHF1ZXJ5IHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgR2F0ZXdheScpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5W10+KCdnZXRHYXRld2F5V2l0aFBpcGVsaW5lcycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UGlwZWxpbmVzKGdhdGV3YXlOYW1lOiBzdHJpbmcsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFBpcGVsaW5lW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBwaXBlbGluZV9wcm90b2NvbCA9XG4gICAgICAgICAgICAncHJvdG9jb2w6IHBpcGVsaW5lX3Byb3RvY29sIHt1aWQgYnJva2VyVVJMIHRvcGljIG1heGltdW1RT1MgdXNlcm5hbWUgcGFzc3dvcmQgZW5jcnlwdGlvbk1vZGUgY2FDZXJ0aWZpY2F0ZSBjbGllbnRDZXJ0aWZpY2F0ZSBjbGllbnRLZXkgYXV0aE1vZGUgc2VydmVyQ2VydGljYXRlIGNvbnN1bWVyR3JvdXBJZCBjb25uZWN0aW9uVGltZW91dCBzZXNzaW9uVGltZW91dCByZXRyeUJhY2tvZmYgY29tbWl0SW50ZXJ2YWwgaW5pdGlhbE9mZnNldCBmZXRjaE1pbkJ5dGVzIGZldGNoTWF4V2FpdCBoZWFydGJlYXRJbnRlcnZhbH0nO1xuICAgICAgICBjb25zdCBwaXBlbGluZV9kYXRhc3RvcmUgPVxuICAgICAgICAgICAgJ2RhdGFzdG9yZTogcGlwZWxpbmVfZGF0YXN0b3JlIHt1aWQgaG9zdCBwb3J0IGRhdGFiYXNlTmFtZSB1c2VyIHBhc3N3b3JkIGFjY291bnROYW1lIHdhcmVob3VzZSBkYXRhYmFzZSBzY2hlbWEgYXV0aFR5cGUgdXNlcm5hbWUgY2xpZW50SWQgY2xpZW50U2VjcmV0IGF1dGhvcml6YXRpb25Db2RlIHJlZGlyZWN0VVJJIGxvZ2luVGltZW91dCB1cmx9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfZmlsdGVyID0gJ2ZpbHRlcjogcGlwZWxpbmVfZmlsdGVyIHt1aWQgZGV2aWNlTmFtZXN9JztcbiAgICAgICAgY29uc3QgcGlwZWxpbmVfc3RyZWFtaW5nID1cbiAgICAgICAgICAgICdzdHJlYW1pbmc6IHBpcGVsaW5lX3N0cmVhbWluZyB7dWlkIGRldmljZU5hbWUgaW5zdHJ1bWVudE5hbWUgZnVuY3Rpb24gd2luZG93VHlwZSB3aW5kb3dTaXplfSc7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgdmFyKGZ1bmM6IGhhcyhnYXRld2F5KSkgQGZpbHRlcihlcSh1dWlkLCBcIiR7Z2F0ZXdheU5hbWV9XCIpKSB7XG4gICAgICAgIHBpcGVsaW5lcyBhcyBnYXRld2F5X3BpcGVsaW5lIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQocGlwZWxpbmVzKSkge1xuICAgICAgICB1aWRcbiAgICAgICAgbmFtZVxuICAgICAgICB1dWlkXG4gICAgICAgIHBpcGVsaW5lVHlwZVxuICAgICAgICBkZXBsb3llclR5cGVcbiAgICAgICAgcHJvdG9jb2xUeXBlXG4gICAgICAgIHByb3RvY29sSWRcbiAgICAgICAgZGF0YVN0b3JlVHlwZVxuICAgICAgICBkYXRhU3RvcmVJZFxuICAgICAgICBjcmVhdGVkXG4gICAgICAgIG1vZGlmaWVkXG4gICAgICAgIGRlc2NyaXB0aW9uXG4gICAgICAgIHN0YXR1c1xuICAgICAgICBmbG93Q29uZmlndXJhdGlvblxuICAgICAgICBsb2dMZXZlbFxuICAgICAgICBzdWJzY3JpcHRpb25Ub3BpY1xuICAgICAgICAke3BpcGVsaW5lX3Byb3RvY29sfVxuICAgICAgICAke3BpcGVsaW5lX2RhdGFzdG9yZX1cbiAgICAgICAgJHtwaXBlbGluZV9maWx0ZXJ9XG4gICAgICAgICR7cGlwZWxpbmVfc3RyZWFtaW5nfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFBpcGVsaW5lW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHBpcGVsaW5lcycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxQaXBlbGluZVtdPignZ2V0UGlwZWxpbmVzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgYWRkUGlwZWxpbmUoZ2F0ZXdheVVpZDogbnVtYmVyLCBwaXBlbGluZTogUGlwZWxpbmUsXG4gICAgdHJhbnNwb3J0T2JqPzogYW55LCBkYXRhU3RvcmVPYmo/OiBhbnksIGZpbHRlck9iaj86IGFueSwgc3RyZWFtaW5nT2JqPzogYW55LFxuICAgIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFBpcGVsaW5lPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9tdXRhdGU/Y29tbWl0Tm93PXRydWVgO1xuXG4gICAgICAgIGxldCBxdWVyeSA9ICcnO1xuXG4gICAgICAgIHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86UGlwZWxpbmUgPGRncmFwaC50eXBlPiBcIlBpcGVsaW5lXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxuYW1lPiBcIiR7cGlwZWxpbmUubmFtZX1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPHV1aWQ+IFwiJHtwaXBlbGluZS5uYW1lfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8dHlwZT4gXCJwaXBlbGluZVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8cGlwZWxpbmU+IFwiXCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxwaXBlbGluZVR5cGU+IFwiJHtwaXBlbGluZS5waXBlbGluZVR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXBsb3llclR5cGU+IFwiJHtwaXBlbGluZS5kZXBsb3llclR5cGV9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxjcmVhdGVkPiBcIiR7cGlwZWxpbmUuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxkZXNjcmlwdGlvbj4gXCIke3BpcGVsaW5lLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8c3RhdHVzPiBcIiR7cGlwZWxpbmUuc3RhdHVzfVwiIC5cbiAgICAgICAgXzpQaXBlbGluZSA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgIF86UGlwZWxpbmUgPGxvZ0xldmVsPiBcIiR7cGlwZWxpbmUubG9nTGV2ZWx9XCIgLlxuICAgICAgICBfOlBpcGVsaW5lIDxzdWJzY3JpcHRpb25Ub3BpYz4gXCIke3BpcGVsaW5lLnN1YnNjcmlwdGlvblRvcGljfVwiIC5cbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X3BpcGVsaW5lPiBfOlBpcGVsaW5lIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBwaXBlbGluZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdhZGQgcGlwZWxpbmUnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8UGlwZWxpbmU+KCdhZGRQaXBlbGluZXMnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgdXBkYXRlUGlwZWxpbmUocGlwZWxpbmU6IFBpcGVsaW5lLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxQaXBlbGluZT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPGRlc2NyaXB0aW9uPiBcIiR7cGlwZWxpbmUuZGVzY3JpcHRpb259XCIgLlxuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiA8c3RhdHVzPiBcIiR7cGlwZWxpbmUuc3RhdHVzfVwiIC5cbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPG1vZGlmaWVkPiBcIiR7cGlwZWxpbmUubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiA8Zmxvd0NvbmZpZ3VyYXRpb24+IFwiJHtwaXBlbGluZS5mbG93Q29uZmlndXJhdGlvbn1cIiAuXG4gICAgICAgIDwke3BpcGVsaW5lLnVpZH0+IDxsb2dMZXZlbD4gXCIke3BpcGVsaW5lLmxvZ0xldmVsfVwiIC5cbiAgICAgICAgPCR7cGlwZWxpbmUudWlkfT4gPHN1YnNjcmlwdGlvblRvcGljPiBcIiR7cGlwZWxpbmUuc3Vic2NyaXB0aW9uVG9waWN9XCIgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IHBpcGVsaW5lKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ3VwZGF0ZWQgcGlwZWxpbmVzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFBpcGVsaW5lPigndXBkYXRlUGlwZWxpbmUnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlUGlwZWxpbmUoZ2F0ZXdheVVpZDogbnVtYmVyLCBwaXBlbGluZTogUGlwZWxpbmUsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICBkZWxldGUge1xuICAgICAgICA8JHtwaXBlbGluZS51aWR9PiAqICogLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfcGlwZWxpbmU+IDwke3BpcGVsaW5lLnVpZH0+IC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBQaXBlbGluZSBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYHBpcGVsaW5lIGRlbGV0ZWRgKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgcGlwZWxpbmUnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlUGlwZWxpbmUnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGlkcyBvZiBhbGwgdGhlIHBpcGVsaW5lcyBhc3NvY2lhdGVkIHdpdGggdGhlIHNwZWNpZmllZCBwcm90b2NvbFxuICAgICAqIEBwYXJhbSBwcm90b2NvbFVpZCAtIHRoZSB1aWQgb2YgdGhlIHByb3RvY29sXG4gICAgICovXG4gICAgZ2V0UGlwZWxpbmVJZHNGcm9tUHJvdG9jb2xVaWQocHJvdG9jb2xVaWQ6IG51bWJlciwgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8UGlwZWxpbmVbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiB1aWQoJHtwcm90b2NvbFVpZH0pKSB7XG4gICAgICAgIHBpcGVsaW5lcyBhcyB+cGlwZWxpbmVfcHJvdG9jb2wge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICB1dWlkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUGlwZWxpbmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcGlwZWxpbmUgaWRzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFBpcGVsaW5lW10+KCdnZXRQaXBlbGluZUlkc0Zyb21Qcm90b2NvbFVpZCcsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGlkcyBvZiBhbGwgdGhlIHBpcGVsaW5lcyBhc3NvY2lhdGVkIHdpdGggdGhlIHNwZWNpZmllZCBkYXRhIHN0b3JlXG4gICAgICogQHBhcmFtIGRhdGFTdG9yZVVpZCAtIHRoZSB1aWQgb2YgdGhlIGRhdGEgc3RvcmVcbiAgICAgKi9cbiAgICBnZXRQaXBlbGluZUlkc0Zyb21EYXRhU3RvcmVVaWQoZGF0YVN0b3JlVWlkOiBudW1iZXIsIGFjY291bnQ/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFBpcGVsaW5lW10+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L3F1ZXJ5YDtcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogdWlkKCR7ZGF0YVN0b3JlVWlkfSkpIHtcbiAgICAgICAgcGlwZWxpbmVzIGFzIH5waXBlbGluZV9kYXRhc3RvcmUge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChwaXBlbGluZXMpKSB7XG4gICAgICAgIHVpZFxuICAgICAgICB1dWlkXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgUGlwZWxpbmVbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcGlwZWxpbmUgaWRzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFBpcGVsaW5lW10+KCdnZXRQaXBlbGluZUlkc0Zyb21EYXRhU3RvcmVVaWQnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldE1vZGVsQ29uZmlncyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxNb2RlbENvbmZpZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICBtb2RlbENvbmZpZ3MgYXMgZ2F0ZXdheV9tb2RlbGNvbmZpZyB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKG1vZGVsQ29uZmlncykpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIG5hbWVcbiAgICAgICAgdXVpZFxuICAgICAgICBkZXNjcmlwdGlvblxuICAgICAgICBkZXZpY2VcbiAgICAgICAgcmVzb3VyY2VcbiAgICAgICAgbW9kZWxcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICBtb2RpZmllZFxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdnZXRNb2RlbENvbmZpZ3Mgc2VydmljZSBxdWVyeTogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIE1vZGVsQ29uZmlnW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIG1vZGVsQ29uZmlncycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbENvbmZpZ1tdPignZ2V0TW9kZWxDb25maWdzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRNb2RlbENvbmZpZyhnYXRld2F5VWlkOiBudW1iZXIsIG1vZGVsQ29uZmlnOiBNb2RlbENvbmZpZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWxDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIF86TW9kZWxDb25maWcgPGRncmFwaC50eXBlPiBcIk1vZGVsQ29uZmlnXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxuYW1lPiBcIiR7bW9kZWxDb25maWcubmFtZX1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPHV1aWQ+IFwiJHttb2RlbENvbmZpZy5uYW1lfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8dHlwZT4gXCJtb2RlbENvbmZpZ1wiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8bW9kZWxDb25maWc+IFwiXCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxkZXNjcmlwdGlvbj4gXCIke21vZGVsQ29uZmlnLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8ZGV2aWNlPiBcIiR7bW9kZWxDb25maWcuZGV2aWNlfVwiIC5cbiAgICAgICAgXzpNb2RlbENvbmZpZyA8cmVzb3VyY2U+IFwiJHttb2RlbENvbmZpZy5yZXNvdXJjZX1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPG1vZGVsPiBcIiR7bW9kZWxDb25maWcubW9kZWx9XCIgLlxuICAgICAgICBfOk1vZGVsQ29uZmlnIDxjcmVhdGVkPiBcIiR7bW9kZWxDb25maWcuY3JlYXRlZH1cIiAuXG4gICAgICAgIF86TW9kZWxDb25maWcgPG1vZGlmaWVkPiBcIiR7bW9kZWxDb25maWcubW9kaWZpZWR9XCIgLlxuICAgICAgICA8JHtnYXRld2F5VWlkfT4gPGdhdGV3YXlfbW9kZWxjb25maWc+IF86TW9kZWxDb25maWcgLlxuICAgICAgfVxuICAgIH1gO1xuICAgICAgICBjb25zb2xlLmxvZygnTXV0YXRlIHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBNdXRhdGVPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gKHJlc3BvbnNlLmRhdGEucmVzcCA9IG1vZGVsQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2FkZCBtb2RlbENvbmZpZycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxNb2RlbENvbmZpZz4oJ2FkZE1vZGVsQ29uZmlnJykpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHVwZGF0ZU1vZGVsQ29uZmlnKG1vZGVsQ29uZmlnOiBNb2RlbENvbmZpZywgYWNjb3VudD86IHN0cmluZyk6IE9ic2VydmFibGU8TW9kZWxDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHNldCB7XG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDxuYW1lPiBcIiR7bW9kZWxDb25maWcubmFtZX1cIiAuXG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDx1dWlkPiBcIiR7bW9kZWxDb25maWcudXVpZH1cIiAuXG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDxkZXNjcmlwdGlvbj4gXCIke21vZGVsQ29uZmlnLmRlc2NyaXB0aW9ufVwiIC5cbiAgICAgICAgPCR7bW9kZWxDb25maWcudWlkfT4gPGNvbmREZXZpY2U+IFwiJHttb2RlbENvbmZpZy5kZXZpY2V9XCIgLlxuICAgICAgICA8JHttb2RlbENvbmZpZy51aWR9PiA8Y29uZFJlc291cmNlPiBcIiR7bW9kZWxDb25maWcucmVzb3VyY2V9XCIgLlxuICAgICAgICA8JHttb2RlbENvbmZpZy51aWR9PiA8bW9kZWw+IFwiJHttb2RlbENvbmZpZy5tb2RlbH1cIiAuXG4gICAgICAgIDwke21vZGVsQ29uZmlnLnVpZH0+IDxtb2RpZmllZD4gXCIke21vZGVsQ29uZmlnLm1vZGlmaWVkfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBtb2RlbENvbmZpZykpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCd1cGRhdGVkIG1vZGVsQ29uZmlnJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE1vZGVsQ29uZmlnPigndXBkYXRlTW9kZWxDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZGVsZXRlTW9kZWxDb25maWcoZ2F0ZXdheVVpZDogbnVtYmVyLCBtb2RlbENvbmZpZ1VpZDogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIGRlbGV0ZSB7XG4gICAgICAgIDwke21vZGVsQ29uZmlnVWlkfT4gKiAqIC5cbiAgICAgICAgPCR7Z2F0ZXdheVVpZH0+IDxnYXRld2F5X21vZGVsY29uZmlnPiA8JHttb2RlbENvbmZpZ1VpZH0+IC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ0RlbGV0ZSBNb2RlbENvbmZpZyBNdXRhdGUgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE11dGF0ZU9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiAocmVzcG9uc2UuZGF0YS5yZXNwID0gYCR7bW9kZWxDb25maWdVaWR9IGRlbGV0ZWRgKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2RlbGV0ZWQgbW9kZWxDb25maWcnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8c3RyaW5nPignZGVsZXRlTW9kZWxDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0RmlsdGVyc0NvbmZpZyhnYXRld2F5TmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5RmlsdGVyc0NvbmZpZ1tdPiB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMuZEdyYXBoVXJsfS9xdWVyeWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMoZ2F0ZXdheSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2dhdGV3YXlOYW1lfVwiKSkge1xuICAgICAgICBmaWx0ZXJzQ29uZmlnIGFzIGdhdGV3YXlfZmlsdGVyIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzcChmdW5jOiB1aWQoZmlsdGVyc0NvbmZpZykpIHtcbiAgICAgICAgdWlkXG4gICAgICAgIGRldmljZU5hbWVzXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ2dldEZpbHRlcnNDb25maWcgc2VydmljZSBxdWVyeTogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIEdhdGV3YXlGaWx0ZXJzQ29uZmlnW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIGZpbHRlcnNDb25maWcnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8R2F0ZXdheUZpbHRlcnNDb25maWdbXT4oJ2dldEZpbHRlcnNDb25maWdzJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBhZGRGaWx0ZXJzQ29uZmlnKFxuICAgICAgICBnYXRld2F5VWlkOiBudW1iZXIsXG4gICAgICAgIGZpbHRlcnNDb25maWc6IEdhdGV3YXlGaWx0ZXJzQ29uZmlnLFxuICAgICAgICBhY2NvdW50Pzogc3RyaW5nLFxuICAgICk6IE9ic2VydmFibGU8R2F0ZXdheUZpbHRlcnNDb25maWc+IHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5kR3JhcGhVcmx9L211dGF0ZT9jb21taXROb3c9dHJ1ZWA7XG5cbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgXzpGaWx0ZXIgPGRncmFwaC50eXBlPiBcImZpbHRlclwiIC5cbiAgICAgICAgXzpGaWx0ZXIgPHR5cGU+IFwiZmlsdGVyXCIgLlxuICAgICAgICBfOkZpbHRlciA8ZmlsdGVyPiBcIlwiIC5cbiAgICAgICAgXzpGaWx0ZXIgPGRldmljZU5hbWVzPiBcIiR7ZmlsdGVyc0NvbmZpZy5kZXZpY2VOYW1lc31cIiAuXG4gICAgICAgIDwke2dhdGV3YXlVaWR9PiA8Z2F0ZXdheV9maWx0ZXI+IF86RmlsdGVyIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBmaWx0ZXJzQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2FkZCBmaWx0ZXJzQ29uZmlnJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPEdhdGV3YXlGaWx0ZXJzQ29uZmlnPignYWRkRmlsdGVyc0NvbmZpZycpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICB1cGRhdGVGaWx0ZXJzQ29uZmlnKGZpbHRlcnNDb25maWc6IEdhdGV3YXlGaWx0ZXJzQ29uZmlnLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxHYXRld2F5RmlsdGVyc0NvbmZpZz4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vbXV0YXRlP2NvbW1pdE5vdz10cnVlYDtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBge1xuICAgICAgc2V0IHtcbiAgICAgICAgPCR7ZmlsdGVyc0NvbmZpZy51aWR9PiA8ZGV2aWNlTmFtZXM+IFwiJHtmaWx0ZXJzQ29uZmlnLmRldmljZU5hbWVzfVwiIC5cbiAgICAgIH1cbiAgICB9YDtcbiAgICAgICAgY29uc29sZS5sb2coJ011dGF0ZSBzdGF0ZW1lbnQ6ICcsIHF1ZXJ5KTtcblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwTXV0YXRlT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IChyZXNwb25zZS5kYXRhLnJlc3AgPSBmaWx0ZXJzQ29uZmlnKSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ3VwZGF0ZWQgZmlsdGVyc0NvbmZpZycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxHYXRld2F5RmlsdGVyc0NvbmZpZz4oJ3VwZGF0ZUZpbHRlcnNDb25maWcnKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3MoZGV2aWNlTmFtZTogc3RyaW5nLCBpbnN0cnVtZW50TmFtZTogc3RyaW5nLCBudW1SZWFkaW5nczogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIC8vIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgYHtyZXNwKGZ1bmM6IGhhcyhyZWFkaW5nKSkgQGNhc2NhZGUge3ZhbHVlIGNyZWF0ZWQgfnJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHt+ZGV2aWNlX3Jlc291cmNlIEBmaWx0ZXIgKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfVwiKSkge319fX1gLCBodHRwT3B0aW9ucylcbiAgICAgICAgLy8gcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAY2FzY2FkZSB7dmFsdWUgY3JlYXRlZCB+cmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkgeyB9fX1gLCBodHRwT3B0aW9ucylcblxuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICB2YXIoZnVuYzogaGFzKHJlc291cmNlKSkgQGZpbHRlcihlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHtcbiAgICAgICAgcmVhZGluZ3MgYXMgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LSR7bnVtUmVhZGluZ3N9KSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ2dldFJlYWRpbmdzIHF1ZXJ5IHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFRTUmVhZGluZ1tdKSxcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IGNvbnNvbGUubG9nKCdSZXNwb25zZSBmcm9tIGdldFJlYWRpbmdzOiAnLCByZXNwb25zZSkpLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHJlYWRpbmdzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFRTUmVhZGluZ1tdPignZ2V0UmVhZGluZ3MnLCBbXSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIGdldFJlYWRpbmdzQXQoZGV2aWNlTmFtZTogc3RyaW5nLCBpbnN0cnVtZW50TmFtZTogc3RyaW5nLCB0czogbnVtYmVyLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEoY3JlYXRlZCwgJHt0c30pKSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ2dldFJlYWRpbmdzQXQgcXVlcnkgc3RhdGVtZW50OiAnLCBxdWVyeSk7XG5cbiAgICAgICAgLy8gcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIEBjYXNjYWRlIHt2YWx1ZSBjcmVhdGVkIH5yZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7IH19fWAsIGh0dHBPcHRpb25zKVxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIHF1ZXJ5LCBodHRwT3B0aW9ucykucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEucmVzcCBhcyBUU1JlYWRpbmdbXSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gY29uc29sZS5sb2coJ2ZldGNoZWQgcmVhZGluZ3MnKSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3I8VFNSZWFkaW5nW10+KCdnZXRSZWFkaW5nc0F0JywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRSZWFkaW5nc1N0YXJ0aW5nQXQoXG4gICAgICAgIGRldmljZU5hbWU6IHN0cmluZyxcbiAgICAgICAgaW5zdHJ1bWVudE5hbWU6IHN0cmluZyxcbiAgICAgICAgZnJvbXRzOiBudW1iZXIsXG4gICAgICAgIGFjY291bnQ/OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIC8vIGNvbnN0IG15cXVlcnkgPSBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIEBjYXNjYWRlIHt2YWx1ZSBjcmVhdGVkIH5yZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7IH19fWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXNwKGZ1bmM6IHVpZChyZWFkaW5ncyksIG9yZGVyYXNjOmNyZWF0ZWQpIHtcbiAgICAgICAgY3JlYXRlZFxuICAgICAgICB2YWx1ZVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCd0aGUgcXVlcnkgaXM6ICcsIHF1ZXJ5KTtcblxuICAgICAgICAvLyByZXR1cm4gdGhpcy5odHRwLnBvc3Q8YW55Pih1cmwsIGB7cmVzcChmdW5jOiBoYXMocmVhZGluZykpIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSkgQGNhc2NhZGUge3ZhbHVlIGNyZWF0ZWQgfnJlc291cmNlX3JlYWRpbmcgQGZpbHRlcihlcSh1dWlkLCBcIiR7ZGV2aWNlTmFtZX1fJHtpbnN0cnVtZW50TmFtZX1cIikpIHsgfX19YCwgaHR0cE9wdGlvbnMpXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFRTUmVhZGluZ1tdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCByZWFkaW5ncycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxUU1JlYWRpbmdbXT4oJ2dldFJlYWRpbmdzU3RhcnRpbmdBdCcsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0UmVhZGluZ3NCZXR3ZWVuKFxuICAgICAgICBkZXZpY2VOYW1lOiBzdHJpbmcsXG4gICAgICAgIGluc3RydW1lbnROYW1lOiBzdHJpbmcsXG4gICAgICAgIGZyb210czogbnVtYmVyLFxuICAgICAgICB0b3RzOiBudW1iZXIsXG4gICAgICAgIGFjY291bnQ/OiBzdHJpbmcsXG4gICAgKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIC8vIGNvbnN0IG15cXVlcnkgPSBge3Jlc3AoZnVuYzogaGFzKHJlYWRpbmcpKSBAZmlsdGVyKGd0KGNyZWF0ZWQsICR7ZnJvbXRzfSkpIEBjYXNjYWRlIHt2YWx1ZSBjcmVhdGVkIH5yZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XyR7aW5zdHJ1bWVudE5hbWV9XCIpKSB7IH19fWA7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHZhcihmdW5jOiBoYXMocmVzb3VyY2UpKSBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkge1xuICAgICAgICByZWFkaW5ncyBhcyByZXNvdXJjZV9yZWFkaW5nIEBmaWx0ZXIoZ3QoY3JlYXRlZCwgJHtmcm9tdHN9KSBBTkQgbHQoY3JlYXRlZCwgJHt0b3RzfSkpIChmaXJzdDotNTAwKSB7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3AoZnVuYzogdWlkKHJlYWRpbmdzKSwgb3JkZXJhc2M6Y3JlYXRlZCkge1xuICAgICAgICBjcmVhdGVkXG4gICAgICAgIHZhbHVlXG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ3RoZSBxdWVyeSBpczogJywgcXVlcnkpO1xuXG4gICAgICAgIC8vIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgYHtyZXNwKGZ1bmM6IGhhcyhyZWFkaW5nKSkgQGZpbHRlcihndChjcmVhdGVkLCAke2Zyb210c30pKSBAY2FzY2FkZSB7dmFsdWUgY3JlYXRlZCB+cmVzb3VyY2VfcmVhZGluZyBAZmlsdGVyKGVxKHV1aWQsIFwiJHtkZXZpY2VOYW1lfV8ke2luc3RydW1lbnROYW1lfVwiKSkgeyB9fX1gLCBodHRwT3B0aW9ucylcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgVFNSZWFkaW5nW10pLFxuICAgICAgICAgICAgdGFwKCgpID0+IGNvbnNvbGUubG9nKCdmZXRjaGVkIHJlYWRpbmdzJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPFRTUmVhZGluZ1tdPignZ2V0UmVhZGluZ3NCZXR3ZWVuJywgW10pKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRMYXN0UmVhZGluZ3NGb3JEZXZpY2UoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUU1JlYWRpbmdbXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYHtcbiAgICAgIHJlc3AoZnVuYzogaGFzKGRldmljZSkpIEBmaWx0ZXIoZXEodXVpZCwgXCIke2RldmljZU5hbWV9XCIpKSBAbm9ybWFsaXplIHtcbiAgICAgICAgZGV2aWNlX3Jlc291cmNlIHtcbiAgICAgICAgICBuYW1lOiBuYW1lXG4gICAgICAgICAgcmVzb3VyY2VfcmVhZGluZyAoZmlyc3Q6LTEpIHtcbiAgICAgICAgICAgIGNyZWF0ZWQ6IGNyZWF0ZWRcbiAgICAgICAgICAgIHZhbHVlOiB2YWx1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1gO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdSZWFkaW5nIHF1ZXJ5IHN0YXRlbWVudDogJywgcXVlcnkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxhbnk+KHVybCwgcXVlcnksIGh0dHBPcHRpb25zKS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YS5yZXNwIGFzIFRTUmVhZGluZ1tdKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCByZWFkaW5ncycpKSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcjxUU1JlYWRpbmdbXT4oJ2dldExhc3RSZWFkaW5nc0ZvckRldmljZScsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0Tm90aWZpY2F0aW9ucyhhY2NvdW50Pzogc3RyaW5nKTogT2JzZXJ2YWJsZTxOb3RpZmljYXRpb25bXT4ge1xuICAgICAgICB0aGlzLmVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQpO1xuICAgICAgICBjb25zb2xlLmxvZygnR2V0Tm90aWZpY2F0aW9ucyBzZXJ2aWNlIGNhbGxlZCcpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmRHcmFwaFVybH0vcXVlcnlgO1xuICAgICAgICBjb25zdCBxdWVyeSA9IGB7XG4gICAgICByZXNwKGZ1bmM6IGhhcyhub3RpZmljYXRpb24pKSBAbm9ybWFsaXplIHtcbiAgICAgICAgdWlkIHV1aWQ6dXVpZCBjcmVhdGVkOmNyZWF0ZWQgbm90aWZ5U291cmNlOm5vdGlmeVNvdXJjZSBub3RpZnlEZXZpY2U6bm90aWZ5RGV2aWNlIG5vdGlmeVJlc291cmNlOm5vdGlmeVJlc291cmNlIG5vdGlmeUxldmVsOm5vdGlmeUxldmVsIHZhbHVlOnZhbHVlIGRlc2NyaXB0aW9uOmRlc2NyaXB0aW9uIH5nYXRld2F5X25vdGlmaWNhdGlvbiB7XG4gICAgICAgICAgZ2F0ZXdheTogdXVpZFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfWA7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4odXJsLCBxdWVyeSwgaHR0cE9wdGlvbnMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhLnJlc3AgYXMgTm90aWZpY2F0aW9uW10pLFxuICAgICAgICAgICAgdGFwKChyZXNwb25zZSkgPT4gY29uc29sZS5sb2coJ1Jlc3BvbnNlIGZyb20gR2V0Tm90aTogJywgcmVzcG9uc2UpKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiBjb25zb2xlLmxvZygnZmV0Y2hlZCBub3RpZmljYXRpb25zJykpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yPE5vdGlmaWNhdGlvbltdPignZ2V0Tm90aWZpY2F0aW9ucycsIFtdKSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0Um91dGUoZGV2aWNlTmFtZTogc3RyaW5nLCBhY2NvdW50Pzogc3RyaW5nKTogbnVtYmVyW11bXSB7XG4gICAgICAgIHRoaXMuZW5zdXJlQWNjb3VudEF1dGhvcml6ZWQoYWNjb3VudCk7XG4gICAgICAgIGxldCByb3V0ZSA9IG51bGw7XG5cbiAgICAgICAgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDEnKSB7XG4gICAgICAgICAgICByb3V0ZSA9IHJvdXRlMTtcbiAgICAgICAgfSBlbHNlIGlmIChkZXZpY2VOYW1lID09ICd0cmFpbi0wMDAyJykge1xuICAgICAgICAgICAgcm91dGUgPSByb3V0ZTI7XG4gICAgICAgIH0gZWxzZSBpZiAoZGV2aWNlTmFtZSA9PSAndHJhaW4tMDAwMycpIHtcbiAgICAgICAgICAgIHJvdXRlID0gcm91dGUzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcm91dGUgPSBlbXB0eXJvdXRlO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJvdXRlO1xuICAgIH1cblxuICAgIGdldFJvdXRlQ2VudGVyKGRldmljZU5hbWU6IHN0cmluZywgYWNjb3VudD86IHN0cmluZyk6IG51bWJlcltdIHtcbiAgICAgICAgdGhpcy5lbnN1cmVBY2NvdW50QXV0aG9yaXplZChhY2NvdW50KTtcbiAgICAgICAgbGV0IGNlbnRlciA9IG51bGw7XG5cbiAgICAgICAgLy8gMzkuMCAtOTguMCB6b29tIDRcbiAgICAgICAgLy8gRWFzdCAzNC43NjU1ODkgICAtNzguNzA5NDg4XG4gICAgICAgIC8vIFdlc3QgNDAuNDg3NDMyIC0xMjIuODAzMTE2XG5cbiAgICAgICAgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDEnKSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbMzQuMCwgLTk4LjBdO1xuICAgICAgICB9IGVsc2UgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDInKSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbNDAuMCwgLTk4LjBdO1xuICAgICAgICB9IGVsc2UgaWYgKGRldmljZU5hbWUgPT0gJ3RyYWluLTAwMDMnKSB7XG4gICAgICAgICAgICBjZW50ZXIgPSBbMzkuMCwgLTk4LjBdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2VudGVyID0gWzQyLjgsIDEyLjhdO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGNlbnRlcjtcbiAgICB9XG5cbiAgICBwcml2YXRlIGVuc3VyZUFjY291bnRBdXRob3JpemVkKGFjY291bnQ/OiBzdHJpbmcpIHtcbiAgICAgIGlmICh0aGlzLnJlcXVpcmVBY2NvdW50SWQpIHtcbiAgICAgICAgaWYgKCFhY2NvdW50KSB0aHJvdyBuZXcgRXJyb3IoJ0FjY291bnQgbXVzdCBleGlzdCcpO1xuICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBIYW5kbGUgSFRUUCBvcGVyYXRpb24gdGhhdCBmYWlsZWQuXG4gICAgICogTGV0IHRoZSBhcHAgY29udGludWUuXG4gICAgICogQHBhcmFtIG9wZXJhdGlvbiAtIC0gbmFtZSBvZiB0aGUgb3BlcmF0aW9uIHRoYXQgZmFpbGVkXG4gICAgICogQHBhcmFtIHJlc3VsdCAtIG9wdGlvbmFsIHZhbHVlIHRvIHJldHVybiBhcyB0aGUgb2JzZXJ2YWJsZSByZXN1bHRcbiAgICAgKi9cbiAgICBwcml2YXRlIGhhbmRsZUVycm9yPFQ+KG9wZXJhdGlvbiA9ICdvcGVyYXRpb24nLCByZXN1bHQ/OiBUKSB7XG4gICAgICAgIHJldHVybiAoZXJyb3I6IGFueSk6IE9ic2VydmFibGU8VD4gPT4ge1xuICAgICAgICAgICAgLy8gVE9ETzogYmV0dGVyIGpvYiBvZiB0cmFuc2Zvcm1pbmcgZXJyb3IgZm9yIHVzZXIgY29uc3VtcHRpb25cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke29wZXJhdGlvbn0gZmFpbGVkOiAke2Vycm9yLmNvZGV9OiAke2Vycm9yLm1lc3NhZ2V9YCk7XG5cbiAgICAgICAgICAgIC8vIExldCB0aGUgYXBwIGtlZXAgcnVubmluZyBieSByZXR1cm5pbmcgYW4gZW1wdHkgcmVzdWx0LlxuICAgICAgICAgICAgcmV0dXJuIG9mKHJlc3VsdCBhcyBUKTtcbiAgICAgICAgfTtcbiAgICB9XG59XG4iXX0=